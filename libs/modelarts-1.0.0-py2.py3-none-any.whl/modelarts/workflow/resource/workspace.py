import threading


class Workspace(object):
    _instance_lock = threading.Lock()
    _instance = None

    def __init__(self, workspace_id="0"):
        self.workspace_id = workspace_id

    def __new__(cls, *args, **kwargs):
        if not Workspace._instance:
            with Workspace._instance_lock:
                if not Workspace._instance:
                    Workspace._instance = object.__new__(cls)
        return Workspace._instance

    @staticmethod
    def instance():
        if Workspace._instance:
            return Workspace._instance
        return Workspace()
