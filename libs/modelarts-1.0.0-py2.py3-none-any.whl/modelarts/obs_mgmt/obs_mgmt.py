"""
Description: OBS management with obs client and Roma API
Author: ModelArts SDK Team
Date: 2021/07/01 - 2021/07/29
"""

from .hwc_obs import HwcOBSApiImpl
from .obs_base import OBSApiBase
from .roma_obs import RomaOBSApiImpl
from ..util.secret_util import read_ak_sk_from_secret
from modelarts.util.notebook_util import is_roma_notebook
from modelarts import constant


class OBSManagement(object):
    """
        OBS Management, operate OBS object, upload and download  data
    """

    def __init__(self, server=None, ak=None, sk=None, security_token=None,
                 app_id=None, app_token=None,
                 region_name=None):
        """
        OBS Management initial, include hwc obs and roma obs
        :param server: OBS server
        :param ak: access_key_id
        :param sk: secret_access_key
        :param security_token: security token for temporary ak:sk
        :param app_id: roma app_id
        :param app_token: roma csb token
        :param region_name: OBS region name
        """
        self.region_name = region_name
        if all([server, ak, sk, app_id, app_token, region_name]):
            error_reason = "Can not initialize obs client, " \
                           "for redundant authentication information," \
                           "please choose server/ak/sk/region_name or " \
                           "app_id/app_token/region_name"
            OBSApiBase.handle_exception_logs(error_reason)

        elif all([server, ak, sk]):
            self.obs_client = HwcOBSApiImpl(server, ak, sk, security_token)

        elif all([app_id, app_token, region_name]):
            self.obs_client = RomaOBSApiImpl(app_id, app_token, region_name)

        else:
            error_reason = "Can not initialize obs client, " \
                           "for redundant authentication information"
            OBSApiBase.handle_exception_logs(error_reason)

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        """
        return self.obs_client.is_obs_file(obs_file)

    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload local file to obs
        :param src_local_file: source local file path
        :param dst_obs_dir: destination obs directory
        :return:
        """
        self.obs_client.upload_file(src_local_file, dst_obs_dir)

    def upload_dir(self, src_local_dir, dst_obs_dir, keep_last_dir=True):
        """ upload local directory to obs
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        self.obs_client.upload_dir(src_local_dir, dst_obs_dir, keep_last_dir)

    def increment_upload_dir(self, src_local_dir, dst_obs_dir, increment_files=None, keep_last_dir=True):
        """ upload obs directory to local incrementally
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param increment_files: list of increment files to be upload, ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        self.obs_client.increment_upload_dir(src_local_dir, dst_obs_dir, increment_files, keep_last_dir)

    def download_file(self, src_obs_file, dst_local_dir):
        """ download obs file to local
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :return:
        """
        self.obs_client.download_file(src_obs_file, dst_local_dir)

    def download_dir(self, src_obs_dir, dst_local_dir, keep_last_dir=True, specified_objects=None):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :param specified_objects: type: list, specified objects to be download, e.g. [object1, object2, ...]
        :return:
        """
        self.obs_client.download_dir(src_obs_dir, dst_local_dir, keep_last_dir, specified_objects)

    def increment_download_dir(self, src_obs_dir, dst_local_dir, increment_files=None, keep_last_dir=True):
        """ download obs directory to local path incrementally
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param increment_files: list of increment files to be download, ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        self.obs_client.increment_download_dir(src_obs_dir, dst_local_dir, increment_files, keep_last_dir)

    def copy(self, src_path, dst_path, keep_last_dir=True):
        """ Transfer data between OBS and Local. Support download from OBS or upload to OBS;
            Support transter files or directory.
        :param src_path: obs path or local path
        :param dst_path: obs path or local path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        self.obs_client.copy(src_path, dst_path, keep_last_dir)

    def del_obs_file(self, obs_file):
        """ delete obs object(file)
        :param obs_file: obs object(file)
        :return:
        """
        self.obs_client.del_obs_file(obs_file)

    def del_obs_dir(self, obs_dir):
        """ delete obs object(directory)
        :param obs_dir: obs object(directory)
        :return:
        """
        self.obs_client.del_obs_dir(obs_dir)

    def is_obs_path_exists(self, obs_path):
        """ check whether the obs path exists
        :param obs_path: obs directory or obs file
        :return: bool, True or False
        """
        return self.obs_client.is_obs_path_exists(obs_path)

    def is_obs_directory(self, obs_path):
        """ check whether obs path is directory
        :param obs_path: obs directory or obs file
        :return: bool, True or False
        """
        return self.obs_client.is_obs_directory(obs_path)

    def list_all_objects(self, obs_path, is_list_whole_objects=True, show_progress=True):
        """ get all objects in obs directory
        :param obs_path: obs directory which should starts with obs:/ and ends with /
        :param is_list_whole_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_progress: show the progress of listing obs objects, default is True
        """
        if not self.is_obs_path_exists(obs_path):
            raise ValueError("The obs path {} does not exist.".format(obs_path))
        return self.obs_client.list_all_objects(obs_path, is_list_whole_objects, show_progress)

    def is_bucket_exists(self, bucket_name):
        bucket_name = self.normalize_bucket_name(bucket_name)
        return self.obs_client.is_bucket_exists(bucket_name)

    def get_default_bucket(self):
        try:
            user_id = read_ak_sk_from_secret()[-1]
            bucket_name = f"modelarts-{self.region_name}-{user_id}"
        except Exception:
            raise ValueError('Please use `session.obs.create_obs_bucket(bucket_name="your_bucket_name")` instead.')
        if not self.is_bucket_exists(bucket_name):
            self.create_obs_bucket(bucket_name=bucket_name)
        return constant.OBS_HEAD_FORMAT + bucket_name

    def list_buckets(self):
        self.roma_notebook_ak_sk_handler(message="query buckets list")
        return self.obs_client.list_buckets()

    def create_obs_bucket(self, bucket_name, region_name=None):
        self.roma_notebook_ak_sk_handler(message="create obs bucket")
        bucket_name = self.normalize_bucket_name(bucket_name)
        if region_name is None:
            region_name = self.region_name
        return self.obs_client.create_obs_bucket(bucket_name, region_name)

    @staticmethod
    def roma_notebook_ak_sk_handler(message=""):
        if not is_roma_notebook():
            return
        raise ValueError(f"Roma does not support {message} operation.")

    @staticmethod
    def normalize_bucket_name(bucket_name: str):
        return bucket_name.replace(constant.OBS_HEAD_FORMAT, "")

    def make_obs_dir(self, obs_dir):
        """ make obs directory
        :param obs_dir: obs directory which should starts with obs://
        """
        self.obs_client.make_obs_dir(obs_dir)

    def get_objects_size(self, obs_path):
        """ get size of obs objects
        :param obs_path: obs directory or obs file
        :return: dict of obs path and obs file size, e.g. {'obs_object': file_size}
        """
        return self.obs_client.get_objects_size(obs_path)

    def get_object(self, obs_path, limited_size):
        """ get obs object with limited size
        :param obs_path: obs file path
        :param limited_size: obs object limited size
        :return: content size and content
        """
        return self.obs_client.get_object(obs_path, limited_size)
