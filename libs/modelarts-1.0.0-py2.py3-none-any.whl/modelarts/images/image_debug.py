"""
Description: Cloud image debug.
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/11/30
"""
import abc
from datetime import datetime, timedelta

from .image_def import Image, ImageArch
from .deploy_config import ImageBuildDeployConfig, RegionCategory
from ..util.docker_util import DockerCli
from ..util.process_utils import ProgressDisplay
from .. import constant
from modelarts.util.string_util import query_var


class ImageDebugger(metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def debug(self, region_name, **kwargs):
        pass


class NotebookImageDebugger(ImageDebugger):
    X86_NOTEBOOK_RELEASE_IMAGE_PATH = "atelier/modelarts-authoring-nb-release-package-x86_64"
    ARM_NOTEBOOK_RELEASE_IMAGE_PATH = "atelier/modelarts-authoring-nb-release-package-aarch64"

    def __init__(self, image: Image):
        self.__image = image

    def debug(self, region_name, **kwargs):
        """
        Debug notebook image.
        :param region_name: Region name like 'cn-north-4' or 'cn-north-7'.
        """
        release_image = NotebookImageDebugger._get_release_image(self.__image.arch, region_name)
        DockerCli.pull(swr_path=release_image,
                       progress_display=ProgressDisplay(msg="Preparing the necessary packages", new_line=False))
        beijing_date = (datetime.now() + timedelta(hours=8)).strftime(constant.ISO_TIME_FORMAT)
        release_container_name = "notebook-latest-release-image-" + beijing_date
        DockerCli.run(swr_path=release_image,
                      options=["-d", "--name", release_container_name, "--rm"],
                      run_command="sleep",
                      args=["60"],
                      progress_display=ProgressDisplay())
        options = NotebookImageDebugger._get_start_options()
        options.extend(["--volumes-from", release_container_name])
        if "gpus" in kwargs:
            options.extend(["--gpus", kwargs["gpus"]])
        container_id = DockerCli.run(swr_path=self.__image.swr_path,
                                     options=options,
                                     progress_display=ProgressDisplay(msg="Starting a container from the image"))
        if isinstance(container_id, bytes):
            container_id = container_id.decode()
        return container_id.strip()

    @staticmethod
    def _get_release_image(arch, region_name):
        release_image = NotebookImageDebugger.ARM_NOTEBOOK_RELEASE_IMAGE_PATH \
            if arch.upper() == ImageArch.AARCH64.value else NotebookImageDebugger.X86_NOTEBOOK_RELEASE_IMAGE_PATH
        region_category = ImageBuildDeployConfig.get_region_category().lower()
        if region_category == RegionCategory.HWC.value:
            swr_domain = query_var(cfg_var=f"SWR_{region_name}", env_var="SWR_ENDPOINT", remove_prefix=True)
            if swr_domain is None:
                raise ValueError("SWR endpoint info is required for image debug.")
        else:
            swr_domain = ImageBuildDeployConfig.get_service_domains()["SWR_ENDPOINT"]
        return swr_domain + "/" + release_image + ":" + ImageBuildDeployConfig.get_release_image_version()

    @staticmethod
    def _get_start_options():
        return ["-d", "-u", "1000:100", "--security-opt", "no-new-privileges:true",
                "--entrypoint=/modelarts/authoring/script/entrypoint/notebook/boot/start.sh",
                "-e", "JUPYTER_DEV=false", "-e", "REMOTE_DEV=true",
                "-e", "MODELARTS_NOTEBOOOK_AUTHORING_DEBUG=true"]
