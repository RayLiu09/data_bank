"""
Description: parse file of manifest format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""


class Sample(object):
    """
    A dataset maybe contains many samples. A sample maybe contains many annotations,
    this class is used to record sample.
    sample contain source, source type, source property, annotation and so on.
    """

    def __init__(
            self,
            source,
            annotations=None,
            usage=None,
            inference_loc=None,
            id=None,
            source_type=None,
            source_property=None,
            hard=None,
            hard_coefficient=None,
            hard_reasons=None,
            source_map=None):
        """
         :param source: source image path
         :param annotations: annotations of image
         :param usage: usage of image
         :param inference_loc: label file of image
         :param id: annotation id
         :param source_type: image source type
         :param source_property: image source property
         :param hard: whether is hard
         :param hard_coefficient: hard coefficient
         :param hard_reasons: hard reasons
         :param source_map: source map
        """
        self.__source = source
        self.__source_map = source_map
        self.__source_type = source_type
        self.__source_property = source_property
        self.__usage = usage
        self.__annotations = annotations
        self.__inference_loc = inference_loc
        self.__id = id
        self.__hard = hard
        self.__hard_coefficient = hard_coefficient
        self.__hard_reasons = hard_reasons

    @property
    def source(self):
        """
        :return "source" attribute
        Mandatory field
        """
        return self.__source

    @source.setter
    def source(self, source):
        """
        set "source" attribute
        """
        self.__source = source

    @property
    def source_map(self):
        """
        :return "source_map" attribute
        Mandatory field
        """
        return self.__source_map

    @source_map.setter
    def source_map(self, source_map):
        """
        set "source_map" attribute
        """
        self.__source_map = source_map

    @property
    def source_type(self):
        """
        :return "source_type" attribute
        Optional field
        """
        return self.__source_type

    @property
    def id(self):
        """
        :return "id" attribute, one of
        Optional field
        """
        return self.__id

    @property
    def usage(self):
        """
        :return "usage" attribute, one of
        Optional field
        """
        return self.__usage

    @property
    def inference_loc(self):
        """
        :return "inference_loc" attribute, one of Optional field
        """
        return self.__inference_loc

    @inference_loc.setter
    def inference_loc(self, loc):
        """
        set inference loc
        """
        self.__inference_loc = loc

    @property
    def annotations(self):
        """
        :return a list of class Annotation
        Optional field
        """
        return self.__annotations

    @annotations.setter
    def annotations(self, annotations):
        """
        set Annotation
        """
        self.__annotations = annotations

    @property
    def hard(self):
        """
        :return set true if it's hard annotation, set false  if it's not hard annotation
        Optional field
        """
        return self.__hard

    @hard.setter
    def hard(self, hard):
        """
        set true if it's hard annotation, set false  if it's not hard annotation
        Optional field
        """
        self.__hard = hard

    @property
    def hard_coefficient(self):
        """
        get hard_coefficient value
        Optional field
        """
        return self.__hard_coefficient

    @hard_coefficient.setter
    def hard_coefficient(self, hard_coefficient):
        """
        set hard_coefficient value
        Optional field
        """
        self.__hard_coefficient = hard_coefficient

    @property
    def hard_reasons(self):
        """
        get hard_reasons value
        """
        return self.__hard_reasons

    @hard_reasons.setter
    def hard_reasons(self, hard_reasons):
        """
        set hard_reasons value
        Optional field
        """
        self.__hard_reasons = hard_reasons

    @property
    def source_property(self):
        """
        set source_property value
        Optional field
        """
        return self.__source_property

    @source_property.setter
    def source_property(self, source_property):
        """
        set source_property value
        Optional field
        """
        self.__source_property = source_property
