# -*- coding: utf-8 -*-
"""
MA webservice app
"""
import argparse
import collections
import io
import json
import os
import sys
import tempfile
import traceback

from error_code import MR0101, MR0105, MR0107
from flask import Flask, request

sys.path.append("/home/ma-user/modelarts-dev/modelarts-sdk/")

from modelarts.local.commons import log
from modelarts.local.commons.model import Model
from model_manager.model_manager import ModelManager

app = Flask("aa")

LOGGER = log.getLogger(__name__)


def get_result_json(ais_error):
    """
        Create a json response with error code and error message
    """
    data = ais_error.to_dict()
    data['words_result'] = {}

    return json.dumps(data, ensure_ascii=False)


@app.route('/health', methods=['GET'])
def healthy():
    return "{\"status\": \"OK\"}"


@app.route('/', methods=['POST'])
def inference_task():
    if ModelManager.model_service is None:
        return get_result_json(MR0107()), 400, {'Content-Type': 'application/json'}
    # get all data from different media
    rec_dict = {}
    if request.json:
        rec_dict = request.json
    elif request.form or request.files:
        form = request.form
        files = request.files
        rec_dict = {}
        for k, v in form.items():
            rec_dict[k] = v

        for k, file in files.items():
            list = files.getlist(k)
            filename_dict = collections.OrderedDict()
            for one in list:
                if isinstance(one.stream, tempfile.SpooledTemporaryFile):
                    filename_dict[one.filename] = io.BytesIO(one.stream.read())
                elif isinstance(one.stream, io.BytesIO):
                    filename_dict[one.filename] = one.stream
                else:
                    LOGGER.error('receive file not recognized!')
                    raise Exception

            rec_dict[k] = filename_dict

    else:
        return get_result_json(MR0101()), 400, {'Content-Type': 'application/json'}

    args = request.args
    for k, v in args.items():
        rec_dict[k] = v

    try:
        res = ModelManager.model_service.inference(rec_dict)
        return json.dumps(res, ensure_ascii=False), 200, {'Content-Type': 'application/json'}
    except KeyError:
        LOGGER.error('Algorithm crashed!')
        LOGGER.error(traceback.format_exc())
        return get_result_json(MR0105()), 400, {'Content-Type': 'application/json'}
    except TypeError:
        LOGGER.error('Algorithm crashed!')
        LOGGER.error(traceback.format_exc())
        return get_result_json(MR0105()), 400, {'Content-Type': 'application/json'}
    except Exception:
        LOGGER.error('Algorithm crashed!')
        LOGGER.error(traceback.format_exc())
        return get_result_json(MR0105()), 500, {'Content-Type': 'application/json'}


parser = argparse.ArgumentParser(description='Flask App')
parser.add_argument('--model_path', action="store", type=str)
parser.add_argument('--model_name', action="store", default="serve", type=str)
parser.add_argument('--pt_server_name', action="store",
                    default="127.0.0.1", type=str)
parser.add_argument('--service_file', action="store", type=str)

args = parser.parse_args(os.environ['MODEL_SERVER_ARGS'].split())

print(args)

model_name = args.model_name
model_path = args.model_path
model = Model(model_name, model_path)
ModelManager.load_service(model)
