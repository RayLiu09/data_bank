"""
Description: constants
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

# annotation info
ANNOTATION = "annotation"
ANNOTATION_TYPE = "type"
ANNOTATION_LOC = "annotation-loc"
ANNOTATION_LOC2 = "annotation_loc"
ANNOTATION_LOC_MAP = "annotation_loc_map"
ANNOTATION_FORMAT = "annotation-format"
ANNOTATION_FORMAT2 = "annotation_format"
ANNOTATION_NAME = "name"
ANNOTATION_ID = "id"
ANNOTATION_PROPERTY = "property"
ANNOTATION_HARD = "hard"
ANNOTATION_HARD_COEFFICIENT = "hard-coefficient"
ANNOTATION_CONFIDENCE = "confidence"
ANNOTATION_CREATION_TIME = "creation-time"
ANNOTATION_CREATION_TIME2 = "creation_time"
ANNOTATION_ANNOTATED_BY = "annotated-by"
ANNOTATION_ANNOTATED_BY2 = "annotated_by"

SOURCE_MAP = "source_map"
SOURCE_TYPE = "source-type"
SAMPLE_TYPE = "sample-type"
SOURCE_PROPERTY = "property"
USAGE = "usage"
ID = "id"
SAMPLE_HARD = "hard"
SAMPLE_HARD_COEFFICIENT = "hard-coefficient"
HARD_REASONS = "hard-reasons"
INFERENCE_LOC = "inference-loc"
INFERENCE_LOC2 = "inference_loc"

# annotation type
IMAGE_CLASSIFICATION = "image_classification"
OBJECT_DETECTION = "object_detection"
IMAGE_SEGMENTATION = "image_segmentation"

AUDIO_CLASSIFICATION = "audio_classification"
SOUND_CLASSIFICATION = "sound_classification"
AUDIO_CONTENT = "audio_content"
AUDIO_SEGMENTATION = "audio_segmentation"

TEXT_CLASSIFICATION = "text_classification"
TEXT_ENTITY = "text_entity"
TEXT_TRIPLET = "text_triplet"

VIDEO_ANNOTATION = "video_annotation"

PREFIX_TEXT = "content://"

# annotation number， multi is more than 1 annotation
SINGLE_LABLE = "single"
MULTI_LABLE = "multi"

# S3 prefix
S3 = "s3:"
PREFIX_S3 = "s3://"
PREFIX_S3_UPPER = "S3://"

S3A = "s3a:"
PREFIX_S3A = "s3a://"
PREFIX_S3A_UPPER = "S3a://"
OBS = "obs:"
PREFIX_OBS = "obs://"

SEPARATOR = "/"
NEWLINE_CHARACTER = "\n"

# Usage
DEFAULT_USAGE = "all"
USAGE_TRAIN = "train"
USAGE_EVAL = "eval"
USAGE_TEST = "test"
USAGE_INFERENCE = "inference"

# inner property
LABEL_SEPARATOR = '\t'
PROPERTY_START_INDEX = "@modelarts:start_index"
PROPERTY_END_INDEX = "@modelarts:end_index"
PROPERTY_FROM = "@modelarts:from"
PROPERTY_TO = "@modelarts:to"

PROPERTY_CONTENT = "@modelarts:content"

CARBON = "carbon"
CARBONDATA = "carbondata"

# PASCAL VOC
ANNOTATIONS = "annotation"
FOLDER_NAME = "folder"
FILE_NAME = "filename"
SOURCE = "source"
DATABASE = "database"
IMAGE = "image"
SIZE = "size"
WIDTH = "width"
HEIGHT = "height"
DEPTH = "depth"
SEGMENTED = "segmented"
MASK_SOURCE = "mask_source"
OBJECT = "object"
NAME = "name"
VOC_PROPERTIES = "properties"
VOC_PROPERTY = "property"
VOC_PROPERTY_KEY = "key"
VOC_PROPERTY_VALUE = "value"
POSE = "pose"
TRUNCATED = "truncated"
OCCLUDED = "occluded"
DIFFICULT = "difficult"
DIFFICULT_COEFFICIENT = "difficult-coefficient"
CONFIDENCE = "confidence"
X_MIN = "xmin"
X_MAX = "xmax"
Y_MIN = "ymin"
Y_MAX = "ymax"
X1 = "x1"
Y1 = "y1"
X2 = "x2"
Y2 = "y2"
CX = "cx"
CY = "cy"
R = "r"
X = "x"
Y = "y"
PART = "part"
MASK_COLOR = "mask_color"
PARSE_PASCAL_VOC = "parsePascalVOC"

SECONDARY_LABELS = "secondary_labels"
SECONDARY_LABELS_NAME = "name"
SECONDARY_LABELS_VALUE = "value"

# built-in properties
INTERNAL_PROPERTY_KEY_PREFIX = "@modelarts:"

SHORTCUT = INTERNAL_PROPERTY_KEY_PREFIX + "shortcut"
COLOR = INTERNAL_PROPERTY_KEY_PREFIX + "color"

# label properties
SHAPE = INTERNAL_PROPERTY_KEY_PREFIX + "shape"
FEATURE = INTERNAL_PROPERTY_KEY_PREFIX + "feature"
CLOCKWISE_ANGLE = INTERNAL_PROPERTY_KEY_PREFIX + "clockwise_angle"
ROTATE_BACKGROUND = INTERNAL_PROPERTY_KEY_PREFIX + "rotate_background"
