import configparser
import os


class _Config(object):

    def __init__(self, conf_file):
        self.__config = configparser.ConfigParser()
        self.__config.read(conf_file, encoding="utf-8")

    def getenv(self, key, default=None, strict=False):
        try:
            if os.getenv(key) is not None:
                return os.getenv(key)
            else:
                sections = key.split('_', 1)
                value = self.__config[sections[0]][sections[1]]
                return value
        except Exception:
            if strict:
                raise ValueError(f"Constant {key} does not defined in config.ini.")
            return default

    def get(self, key, default=None):
        try:
            if os.getenv(key) is not None:
                return os.getenv(key)
            else:
                sections = key.split('_', 1)
                value = self.__config[sections[0]][sections[1]]
                return value
        except Exception:
            return default

    def getconfig(self):
        return self.__config

    def is_empty(self):
        # only contains default section
        return len(self.__config) == 1


default_config_file = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")) + '/config/config.ini'
Config = _Config(default_config_file)
