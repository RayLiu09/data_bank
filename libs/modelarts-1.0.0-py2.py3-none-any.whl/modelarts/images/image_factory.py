"""
Description: Cloud image factory
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/11/30
"""
import abc

from .image_debug import ImageDebugger, NotebookImageDebugger
from .image_def import Image


class ImageFactory(metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def create_image_debugger(self, image: Image) -> ImageDebugger:
        pass


class NotebookImageFactory(ImageFactory):
    """
    A factory managing the instances of image debugger.
    """

    def create_image_debugger(self, image: Image):
        """
        Get the instance of image debugger according to the service.
        :param image: includes all the necessary information to describe image.
        :return: an instance of image debugger
        """
        return NotebookImageDebugger(image)
