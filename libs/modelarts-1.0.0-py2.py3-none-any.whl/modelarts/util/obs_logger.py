"""
HWC OBS and ROMA OBS logger
"""
import json
import logging

logging.basicConfig()
logging.getLogger("urllib3").setLevel(logging.ERROR)

OBS_LOGGER = logging.getLogger('OBS')
OBS_LOGGER.setLevel(logging.INFO)


class OBSLogger(object):

    @classmethod
    def common_info_log(cls, info_content):
        """
        :param info_content: information
        :return:
        """
        if info_content:
            OBS_LOGGER.info(info_content)

    @classmethod
    def common_error_log(cls, error_content):
        """
        :param error_content: error message
        :return:
        """
        if error_content:
            OBS_LOGGER.error(error_content)

    @classmethod
    def hwc_error_log(cls, api_response):
        """
        :param api_response: roma api client response
        :return:
        """
        content = "HWC OBS response\n" + \
                  "{}{} : {} \n".format(len("ERROR:OBS: ") * " ", "STATUS",
                                        api_response.status) + \
                  "{}{} : {} \n".format(len("ERROR:OBS: ") * " ", "REASON",
                                        api_response.reason) + \
                  "{}{} : {} \n".format(len("ERROR:OBS: ") * " ", "ERROR_CODE",
                                        api_response.errorCode) + \
                  "{}{} : {} \n".format(len("ERROR:OBS: ") * " ",
                                        "ERROR_MESSAGE",
                                        api_response.errorMessage) + \
                  "{}{} : {} \n".format(len("ERROR:OBS: ") * " ", "REQUEST_Id",
                                        api_response.requestId)

        OBS_LOGGER.error(content)

    @classmethod
    def roma_error_log(cls, api_response):
        """
        :param api_response: roma api response
        :return:
        """
        content = """ ROMA OBS response\n"""
        content = content + "{}{} : {} \n".format(len("ERROR:OBS: ") * " ",
                                                  "STATUS_CODE",
                                                  api_response.status_code)

        if cls._check_json(api_response.content):
            resp_content = json.loads(api_response.content)
            for key, value in resp_content.items():
                content = content + "{}{} : {} \n".format(
                    len("ERROR:OBS: ") * " ", key.upper(), value)
        else:
            content = content + "{}{} : {} \n".format(len("ERROR:OBS: ") * " ",
                                                      "ERROR_INFO",
                                                      api_response.content)

        OBS_LOGGER.error(content)

    @classmethod
    def _check_json(cls, input_str):
        try:
            json.loads(input_str)
            return True
        except Exception:
            return False
