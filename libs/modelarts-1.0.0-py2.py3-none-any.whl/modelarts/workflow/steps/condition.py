import abc
from enum import Enum
from typing import Sequence

import attr

from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.data.obs import OBSConsumption
from modelarts.workflow.data.metric import MetricsConsumption

ConditionValueType = (int, float, str, bool, Placeholder, Sequence)


@attr.s
class MetricInfo:
    """
    Get the metric information output by Step

    Attributes:
        input_data (OBSConsumption, MetricsConsumption): The source of metric_info.
        json_key (str): The metric_info mapping key.
    """
    input_data = attr.ib(validator=attr.validators.instance_of((OBSConsumption, MetricsConsumption)))
    json_key = attr.ib(validator=attr.validators.instance_of(str))


    def get_value(self, client):
        """
        Get the metric information according to json_key
        Args:
            client (ObsClient): building interactions with obs service.

        Returns: metric value

        """
        if isinstance(self.input_data, OBSConsumption):
            path_list = [self.get_path_with_obs_consumption()]
        else:
            path_list = self.get_path_with_metrics_consumption()
        for path in path_list:
            data = client.get_data_from_obs_file(path)
            if isinstance(data, dict):
                if data.get(self.json_key):
                    return data.get(self.json_key)
            if isinstance(data, list):
                metric_value = self.get_value_from_metric_list(data)
                if metric_value:
                    return metric_value

        raise KeyError('the json key {} is not exist'.format(self.json_key))

    def get_value_from_metric_list(self, metric_list):
        """
        Only search value from k-v type metrics
        Args:
            metric_list (list): metric list info

        Returns (str): metric value

        """
        for metric in metric_list:
            if metric.get("type") != "float":
                continue
            if metric.get("key") == self.json_key:
                return metric.get("data").get("value")
        return None

    def get_path_with_obs_consumption(self):
        """
        Construct a new path(f'{obs_path}/{metric_file}') based on the obs_path and
        metric_file(the name of the metric file) of OBSOutputConfig

        Returns (str): obs path with metric file

        """
        obs_output_config = self.input_data.config
        obs_data = self.input_data.consume()
        actual_path = obs_data.obs_path
        metric_file = MetricInfo._check_metric_file(obs_output_config.metric_file)
        bucket_path = '{}/{}'.format(actual_path.strip('/'), metric_file)
        return bucket_path

    def get_path_with_metrics_consumption(self):
        return self.input_data.consume().metric_files

    @staticmethod
    def _check_metric_file(metric_file):
        if metric_file is None:
            raise ValueError('metric_file can not be None')
        metric_file = metric_file.value if isinstance(metric_file, Placeholder) else metric_file
        if not metric_file.endswith('.json'):
            raise ValueError("metric_file must be ends with '.json'")
        return metric_file

    def to_definition_json(self):
        """
        Get the reference method of the MetricInfo in the workflow serialization format
        Returns (str): reference method of the MetricInfo

        """
        return "$ref/metric_consumption/{}/{}/{}".format(
            self.input_data.step_name, self.input_data.output_name, self.json_key)


class ConditionTypeEnum(Enum):
    """Condition type enum."""

    EQ = "Equals"
    GT = "GreaterThan"
    GTE = "GreaterThanOrEqualTo"
    IN = "In"
    LT = "LessThan"
    LTE = "LessThanOrEqualTo"
    NOT = "Not"
    OR = "Or"

    @property
    def condition_op(self):
        mapping = {
            ConditionTypeEnum.EQ: "==",
            ConditionTypeEnum.GT: ">",
            ConditionTypeEnum.GTE: ">=",
            ConditionTypeEnum.IN: "in",
            ConditionTypeEnum.LT: "<",
            ConditionTypeEnum.LTE: "<=",
            ConditionTypeEnum.NOT: "!=",
            ConditionTypeEnum.OR: "or"
        }
        return mapping[self]


class AbstractCondition(abc.ABC):
    pass


@attr.s
class Condition(AbstractCondition):
    """Generic comparison condition.

    Attributes:
        condition_type (ConditionTypeEnum): The type of condition.
        left (Union[ConditionValueType, MetricInfo, AbstractCondition]): The left value in the comparison.
        right (Union[ConditionValueType, MetricInfo, AbstractCondition]): The right value in the comparison.
    """

    condition_type = attr.ib(validator=attr.validators.instance_of(ConditionTypeEnum))
    left = attr.ib(validator=attr.validators.instance_of((*ConditionValueType, MetricInfo, AbstractCondition)))
    right = attr.ib(validator=attr.validators.instance_of((*ConditionValueType, MetricInfo, AbstractCondition)))

    def __attrs_post_init__(self):
        self._check_condition_valid()

    def _check_condition_valid(self):
        if self.condition_type in (ConditionTypeEnum.GT, ConditionTypeEnum.GTE, ConditionTypeEnum.LT,
                                   ConditionTypeEnum.LTE):
            if isinstance(self.left, (str, Sequence)) or isinstance(self.right, (str, Sequence)):
                raise ValueError(
                    "Condition expression is illegal: left is {}, right is {}, condition type is {}".format(
                        type(self.left), type(self.right), self.condition_type)
                )
        if self.condition_type == ConditionTypeEnum.IN:
            if isinstance(self.left, Sequence) or not isinstance(self.right, Sequence):
                raise ValueError(
                    "Condition expression is illegal: left is {}, right is {}, condition type is {}".format(
                        type(self.left), type(self.right), self.condition_type)
                )

    def is_satisfied(self, client):
        """
        Construct the calculation expression of the condition and return the calculation result

        Returns(bool): The result of the conditional expression

        """
        left = self._get_value(self.left, client)
        right = self._get_value(self.right, client)
        express_op = '{} {} {}'.format(left, self.condition_type.condition_op, right)
        print(express_op)
        return eval(express_op)

    @classmethod
    def _get_value(cls, value, client):
        if isinstance(value, Placeholder):
            return value.value
        elif isinstance(value, MetricInfo):
            return value.get_value(client)
        elif isinstance(value, Condition):
            return value.is_satisfied(client)
        else:
            return value

    def ref(self):
        """
        Get the reference method of the Condition in the workflow serialization format
        Returns (dict): serialized result

        """
        result = {
            "type": self.condition_type.condition_op,
            "left": self._transfer_to_definition_json(self.left),
            "right": self._transfer_to_definition_json(self.right)
        }
        return result

    @classmethod
    def _transfer_to_definition_json(cls, value):
        if isinstance(value, Placeholder):
            return value.ref()
        elif isinstance(value, MetricInfo):
            return value.to_definition_json()
        elif isinstance(value, Condition):
            return value.ref()
        else:
            return value

    def get_snapshot(self) -> TransformType:
        """
        Get a snapshot of Condition info
        Returns (dict): snapshot of Condition info

        """
        return self.ref()
