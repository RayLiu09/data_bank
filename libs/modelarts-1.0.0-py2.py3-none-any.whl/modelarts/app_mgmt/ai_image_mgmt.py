# coding=utf-8
"""
A ModelArts APP can create APP, deploy APP service, get APP info and list,and delete APP.
"""
import os
import sys

sys.path.append(os.getcwd())

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from json import JSONEncoder


class Image(object):
    """
    ModelArts image manager to create image, query image by id and delete image
    """

    @staticmethod
    def create(session, **kwargs):
        """
        Create image
        :param session: modelarts session
        :param kwargs:
        :return: create result
        """
        body = Image.create_image_body(kwargs)
        body_encode = JSONEncoder().encode(body).encode("utf8")
        request_url = '/v1/' + session.project_id + '/imagepacker/images'
        return auth_by_apig(session, constant.HTTPS_POST, request_url, body=body_encode)

    @staticmethod
    def get(session, image_id):
        """
        Query image info
        :param session: modelarts session
        :param image_id: image id
        :return: image details
        """
        request_url = '/v1/' + session.project_id + '/imagepacker/images/' + image_id
        return auth_by_apig(session, constant.HTTPS_GET, request_url)

    @staticmethod
    def delete(session, image_id):
        """
        Delete image
        :param session: modelarts session
        :param image_id: image id
        :return: delete result
        """
        request_url = '/v1/' + session.project_id + '/imagepacker/images/' + image_id
        return auth_by_apig(session, constant.HTTPS_DELETE, request_url)

    @staticmethod
    def create_image_body(kwargs):
        """
        Request body for building an image
        :param session: modelarts session
        :param kwargs: image build parameters
        :return: request body
        """
        if "path" not in kwargs:
            raise Exception("path is none, please check")
        if "storage_type" not in kwargs:
            raise Exception("storage_type is none, please check")
        if "name" not in kwargs:
            raise Exception("name is none, please check")
        if "version" not in kwargs:
            raise Exception("version is none, please check")
        if "platform" not in kwargs:
            raise Exception("platform is none, please check")
        if "namespace" not in kwargs:
            raise Exception("namespace is none, please check")
        if "xrole_name" not in kwargs:
            raise Exception("xrole_name is none, please check")
        if "description" not in kwargs:
            kwargs["description"] = 'ModelArts Default Desc'
        storage_location = {
            'path': kwargs["path"]
        }
        file_locator = {
            "storage_type": kwargs["storage_type"],
            "storage_location": storage_location
        }
        body = {
            "description": kwargs["description"],
            "name": kwargs["name"],
            "version": kwargs["version"],
            "platform": kwargs["platform"],
            "namespace": kwargs["namespace"],
            "xrole_name": kwargs["xrole_name"],
            "file_locator": file_locator
        }
        return body
