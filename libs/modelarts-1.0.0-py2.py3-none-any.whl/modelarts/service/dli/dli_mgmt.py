import logging
import json
import time
from typing import List, Dict
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.notebook_util import roma_notebook_operation_handler
from modelarts.util.string_util import query_var


class Queue(object):

    def __init__(self, queue_info):
        self._queue_info = queue_info

    def to_dict(self):
        result = {
            'queue_id': self.id,
            'queue_name': self.name,
            'queue_type': self.queue_type,
            'owner': self.owner,
            'cu_count': self.cu_count,
            'charging_mode': self.charging_mode,
            'enterprise_project_id': self.enterprise_project_id,
            'create_time': self.create_time,
            'description': self.description
        }
        return result

    def to_str(self):
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.to_str()

    @property
    def name(self):
        return self._queue_info.get("queue_name")

    @property
    def id(self):
        return self._queue_info.get("queue_id")

    @property
    def create_time(self):
        create_time = int(self._queue_info.get("create_time"))
        return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(create_time // 1000))

    @property
    def cu_count(self):
        return self._queue_info.get("cu_count")

    @property
    def owner(self):
        return self._queue_info.get("owner")

    @property
    def charging_mode(self):
        return self._queue_info.get("charging_mode")

    @property
    def description(self):
        return self._queue_info.get("description")

    @property
    def queue_type(self):
        return self._queue_info.get("queue_type")

    @property
    def enterprise_project_id(self):
        return self._queue_info.get("enterprise_project_id")


class SparkBatchJob(object):
    def __init__(self, client, job_info):
        """
        Init the SparkBatchJob instance

        :param SessionInfo job_info: The job_info return form the server
        :param DliClient client: The object of the DLIClient
        """

        self._job_info = job_info
        self._client = client
        self._status = None
        self._duration = 0
        self._name = None

    @property
    def job_id(self):
        return self._job_info.get("id")

    @property
    def job_name(self):
        job_info = self._client.get_spark_batch_job_info(batch_id=self.job_id)
        self._name = job_info.get("name")
        return self._name or "N/A"

    @property
    def status(self):
        return self._status

    @property
    def duration(self):
        job_info = self._client.get_spark_batch_job_info(batch_id=self.job_id)
        self._duration = job_info.get("duration")
        return self._duration

    def get_job_status(self):
        """
        Get Spark batch job status from dli server

        :return: str Status include 'starting','running','dead','success','recovering'

        """

        job_status = self._client.get_batch_state(batch_id=self._job_info.get("id"))
        self._status = job_status.get("state")

        return job_status.get("state") or "UNKNOWN"

    def get_driver_log(self, size=None):
        """
        Get Spark batch job driver log from dli server

        :param size: log length size
        :return: list[str]

        """

        kwargs = {
            'batch_id': self._job_info.get("id"),
            'size': size,
            'log_type': "driver",
            'index': 0
        }

        session_log = self._client.get_batch_log(**kwargs)

        return session_log.get("log")


class SparkJobInfo(object):
    _fields = ["file", "class_name", "queue", "cluster_name", "args",
               "sc_type", "jars", "python_files", "files", "modules",
               "resources", "groups", "conf", "name", "driver_memory",
               "driver_cores", "executor_memory", "executor_cores",
               "num_executors", "obs_bucket", "auto_recovery", "max_retry_times",
               "feature", "spark_version", "image", "catalog_name"]

    def __init__(self, **kwargs):
        self.params = {}
        for key, val in kwargs.items():
            if key not in self._fields:
                raise TypeError("Got an unexpected keyword argument '%s'" % key)
            self.params[key] = val

        for name in self._fields:
            setattr(self, name, None)
        for key, value in kwargs.items():
            setattr(self, key, value)

    def get_request_body(self, queue_name: str = None):
        rest_request_body = {}
        for name in self.params.keys():
            if getattr(self, name) is not None:
                rest_request_body[name] = getattr(self, name)
        if queue_name is not None:
            rest_request_body.update({"queue": queue_name})
        return rest_request_body


class DLIManagement(object):
    """
        DLI Management, operate DLI object, create, get and delete DLI spark job
    """

    @roma_notebook_operation_handler
    def __init__(self, session):

        """
        DLI Management initialization.

        """
        self.session = session
        if self.session.auth == constant.ROMA_AUTH:
            raise Exception(f"DLI does not support in roma auth for now.")
        dli_host = query_var(cfg_var=f"DLI_{session.region_name}", env_var="DLI_ENDPOINT", remove_prefix=True)
        if dli_host is None:
            raise ValueError("DLI endpoint info is required for dli management.")
        self.host = dli_host

    def share_image_to_dli(self, namespace: str, image_name: str):
        if ":" in image_name:
            image_name = image_name.split(":")[0]

        request_url = f"/v1.0/{self.session.project_id}/manage/namespaces/{namespace}/" \
                      f"repositories/{image_name}/access-domains"
        body = JSONEncoder().encode({"deadline": "forever"})
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url, host=self.host, body=body)

    def is_shared_dli_image(self, namespace: str, image_name: str):
        if ":" in image_name:
            image_name = image_name.split(":")[0]
        request_url = f"/v1.0/{self.session.project_id}/manage/namespaces/{namespace}/" \
                      f"repositories/{image_name}/is-shared"
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)

    def submit_spark_batch_job(self, batch_job_info: SparkJobInfo, queue_name: str = None, wait: bool = True):
        batch_job_body = batch_job_info.get_request_body(queue_name=queue_name)
        body = JSONEncoder().encode(batch_job_body)
        request_url = f'/v2.0/{self.session.project_id}/batches'
        resp = auth_by_apig(self.session, constant.HTTPS_POST, request_url, body=body, host=self.host)
        spark_batch_job = SparkBatchJob(self, resp)
        job_id = spark_batch_job.job_id
        logging.info("Current DLI job id is: %s", job_id)

        count_starting = 0
        count_running = 0
        while wait:
            job_status = spark_batch_job.get_job_status()
            if job_status == "success":
                self._process_job_completed(job_status,
                                            spark_batch_job.duration,
                                            spark_batch_job.job_name,
                                            spark_batch_job.job_id)
                break
            if job_status == "starting":
                count_starting = self._process_job_uncompleted(job_status, count_starting)
            elif job_status == "running":
                count_running = self._process_job_uncompleted(job_status, count_running)
            else:
                logging.warning("Job [ %s ] [ %s ] status is {job_status}, please check log.",
                                spark_batch_job.job_name, spark_batch_job.job_id)
                break
            count_total = count_starting + count_running
            if count_total > int(constant.MAXIMUM_RETRY_TIMES):
                logging.warning("Reach the maximum start times, the current status is %s", job_status)
                break

        return spark_batch_job

    @staticmethod
    def _process_job_uncompleted(status, count):
        if count == 0:
            logging.info(status)
        time.sleep(min(constant.QUERY_TRAIN_STATUS_PERIOD, 5))
        return count + 1

    @staticmethod
    def _process_job_completed(status, duration, job_name, job_id):
        logging.info(status)
        if duration == 0:
            return

        sec = duration / 1000
        minu, seconds = divmod(sec, 60)
        hours, minutes = divmod(minu, 60)
        duration_format = "%02d:%02d:%02d" % (hours, minutes, seconds)
        logging.info(f"Spark job [ %s ] [ %s ] duration is %s.", job_name, job_id, duration_format)

    def get_batch_state(self, batch_id: str):
        """
        Get Spark batch job status from dli server

        :param batch_id: batch job id
        :return: str Status include 'starting','running','dead','success','recovering'

        """
        request_url = f"/v2.0/{self.session.project_id}/batches/{batch_id}/state"
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)

    def get_batch_log(self, batch_id: str, size: int = None, _from: int = None, log_type="driver", index=0):
        """
        Get Spark batch job driver log from dli server

        :param batch_id: batch job id
        :param _from: log start line number
        :param size: log length size
        :param log_type: log type, default "driver"
        :param index: log index, default 0
        :return: list[str]

        """
        request_url = f"/v2.0/{self.session.project_id}/batches/{batch_id}/log"
        query = {}
        if _from is not None:
            query.update({"from": _from})
        if size is not None:
            query.update({"size": size})
        if log_type is not None:
            query.update({"type": log_type})
        if index is not None:
            query.update({"index": index})
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def cancel_spark_batch_job(self, batch_id: str):
        """

        :param str batch_id: ID of a spark batch job returned after a spark batch job is submitted.
        :return:
        """
        if batch_id is None:
            raise ValueError("No spark batch job in progress, cancel spark batch job failed")
        request_url = f"/v2.0/{self.session.project_id}/batches/{batch_id}"
        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url, host=self.host)

    def list_spark_batch_job(self, **kwargs):
        request_url = f"/v2.0/{self.session.project_id}/batches"
        query = {}
        for k, v in kwargs.items():
            if v is None:
                continue
            if k == "_from":
                k = "from"
            query[k] = v

        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def get_spark_batch_job_info(self, batch_id: str):
        request_url = f"/v2.0/{self.session.project_id}/batches/{batch_id}"
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)

    def get_queue_list(self, queue_type: str = "all", tags: str = None,
                       with_charge_info: bool = False, with_priv: bool = False,
                       page_size: int = 20, current_page: int = 1):
        """
        :param queue_type: the type of dli queues
        :param tags: query queues by tags
        :param with_charge_info: whether to return charging information
        :param with_priv: whether to return permission information
        :param page_size: the number of rows of results displayed per page
        :param current_page: current page number
        """
        request_url = f"/v1.0/{self.session.project_id}/queues"
        query = {"queue_type": queue_type,
                 "with-charge-info": with_charge_info,
                 "with-priv": with_priv,
                 "page-size": page_size,
                 "current-page": current_page}
        if tags is not None:
            query.update({"tags": tags})

        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query, host=self.host)

    def get_queue_detail_by_name(self, queue_name: str):
        request_url = f"/v1.0/{self.session.project_id}/queues/{queue_name}"
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)

    def get_resource_list(self, kind: str = None, tags: str = None):
        request_url = f"/v2.0/{self.session.project_id}/resources"
        query = {}
        if kind is not None:
            query["kind"] = kind
        if tags is not None:
            query["tags"] = tags
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def get_resource_info_by_name(self, resource_name: str, group: str = None):
        request_url = f"/v2.0/{self.session.project_id}/resources/{resource_name}"
        query = {}
        if group is not None:
            query["group"] = group
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def upload_jar_resource(self, paths: List[str], group: str):
        request_url = f"/v2.0/{self.session.project_id}/resources/jars"
        body = dict()
        body["paths"] = paths
        body["group"] = group
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url,
                            body=JSONEncoder().encode(body), host=self.host)

    def upload_pyfile_resource(self, paths: List[str], group: str):
        request_url = f"/v2.0/{self.session.project_id}/resources/pyfiles"
        body = dict()
        body["group"] = group
        body["paths"] = paths
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url,
                            body=JSONEncoder().encode(body), host=self.host)

    def upload_file_resource(self, paths: List[str], group: str):
        request_url = f"/v2.0/{self.session.project_id}/resources/files"
        body = dict()
        body["paths"] = paths
        body["group"] = group
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url,
                            body=JSONEncoder().encode(body), host=self.host)

    def upload_resource(self, paths: List[str], group: str, kind: str = "file",
                        is_async: bool = True, tags: List[Dict] = None):
        request_url = f"/v2.0/{self.session.project_id}/resources"
        body = dict()
        body["kind"] = kind
        body["paths"] = paths
        body["group"] = group
        body["is_async"] = is_async
        if tags is not None:
            body["tags"] = tags
        return auth_by_apig(self.session, constant.HTTPS_POST, request_url,
                            body=JSONEncoder().encode(body), host=self.host)

    def delete_resource_by_name(self, resource_name: str, group: str = None):
        request_url = f"/v2.0/{self.session.project_id}/resources/{resource_name}"
        body = dict()
        if group is not None:
            body["group"] = group

        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url,
                            body=JSONEncoder().encode(body) or None, host=self.host)
