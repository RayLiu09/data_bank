"""Constants of modelarts sdk."""
import os
import sys
import stat

AKSK_AUTH = 'aksk'
ROMA_AUTH = 'roma'
HTTPS_GET = 'GET'
HTTPS_POST = 'POST'
HTTPS_DELETE = 'DELETE'
HTTPS_PUT = 'PUT'
ISO_TIME_FORMAT = '%m%d-%H%M%S'
JSON_TYPE = 'json'

ROMA_PROJECT_ID = 'roma_project_id'
ROMA_CONTENT_TYPE = 'application/json;charset=utf8'

MODELARTS_CONFIG_PATH = '~/.modelarts/config.json'

SUPPORTED_REGION = ['cn-north-1', 'cn-north-2', 'cn-north-4', 'cn-north-5',
                    'cn-north-7', 'cn-northeast-1', 'cn-north-9',
                    'cn-east-2', 'cn-south-1', 'ap-southeast-1', 'cn-east-3',
                    'ap-southeast-3', 'cn-hangzhou-1', 'eu-west-0']

JOB_STATE = ['JOBSTAT_UNKNOWN', 'JOBSTAT_INIT', 'JOBSTAT_IMAGE_CREATING',
             'JOBSTAT_IMAGE_FAILED',
             'JOBSTAT_SUBMIT_TRYING',
             'JOBSTAT_SUBMIT_FAILED', 'JOBSTAT_DELETE_FAILED',
             'JOBSTAT_WAITING', 'JOBSTAT_RUNNING',
             'JOBSTAT_KILLING',
             'JOBSTAT_COMPLETED', 'JOBSTAT_FAILED', 'JOBSTAT_KILLED',
             'JOBSTAT_CANCELED', 'JOBSTAT_LOST',
             'JOBSTAT_SCALING', 'JOBSTAT_SUBMIT_MODEL_FAILED', 'JOBSTAT_DEPLOY_SERVICE_FAILED',
             'JOBSTAT_CHECK_INIT', 'JOBSTAT_CHECK_RUNNING', 'JOBSTAT_CHECK_RUNNING_COMPLETED',
             'JOBSTAT_CHECK_FAILED']

ROMA_JOB_WAITING_STATUS_CODE = 1000

ROMA_JOB_WAITING_STATUS = 'JOB_WAITING'

CHECK_ROMA_WAITING_JOB_STATUS_INTERVAL = 5

ROMA_TRAIN_JOB_DEFAULT_PRIORITY = 1

LOCAL_TRAIN_TYPE = 'local'

LOCAL_TRAIN_DIR = "~/modelarts-python-sdk/local_train"

APP_CREATE_Y_PARAMS = {'application_name', 'application_version', 'source_type', 'source_location',
                       'initial_config'}

APP_CREATE_N_PARAMS = {'description', 'workspace_id', 'cmd', 'deployment_constraints', 'specification',
                       'market_flag'}

MODEL_CREATE_PARAMS = {'model_name', 'model_version', 'source_location',
                       'source_job_id', 'source_job_version',
                       'source_type', 'model_type', 'model_algorithm',
                       'description', 'execution_code', 'input_params',
                       'output_params', 'dependencies', 'model_metrics',
                       'apis', 'runtime', 'install_type', 'model_docs',
                       'initial_config', 'dynamic_load_mode', 'prebuild',
                       'asynchrony'}

MODEL_INDEX_PARAMS = {'model_name', 'model_version', 'model_status',
                      'description', 'offset', 'limit', 'sort_by',
                      'order'}

SERVICE_DEPLOY_PARAMS = {'service_name', 'description', 'infer_type', 'vpc_id',
                         'subnet_network_id', 'asynchrony',
                         'security_group_id', 'configs', 'cluster_id',
                         'pool_name', 'schedule'}

SERVICE_INDEX_PARAMS = {'service_id', 'service_name', 'infer_type', 'offset',
                        'limit', 'sort_by', 'order', 'model_id',
                        'service_status'}

LOCAL_INFER_LOG = "~/log/local_infer_log/"

OBS_HEAD_FORMAT = 'obs://'

S3_HEAD_FORMAT = 's3://'

ANACONDA_DIR = "ANACONDA_DIR"

DEFAULT_ANACONDA_DIR = "/home/ma-user/anaconda" + \
                       sys.version.split()[0].split(".")[0]

DEFAULT_ENVIRONMENT_PATH = os.path.join(os.environ.get(
    ANACONDA_DIR, DEFAULT_ANACONDA_DIR), "envs/")

ENVIRONMENT_PATH_ENV_NAME = "ENVIRONMENT-PREFIX-PATH"

LOCK_DIR = "locks"

ENVIRONMENT_INSTALL_LOCK = "install_modelarts_conda"

DOCKER_IMAGE_BUILD_DIR = "/home/ma-user/work/"

DEFAULT_PIP_CONFIG_PATH = "/home/ma-user/.pip/pip.conf"

USER_PIP_CONFIG_PATH = "USER_PIP_CONFIG_PATH"

DOCKER_IMAGE_BUILD_SUCC = "success"

DOCKER_IMAGE_BUILD_MAX_TIME = 300

INFER_PIP_INSTALLER = "pip"

INFER_PACKAGE_RESTRAINT_DICT = {'EXACT': '==', 'ATLEAST': '>=', 'ATMOST': '<='}

INFER_INSTALL_TYPE = ["real-time", "edge", "batch"]
# For these AI frameworks and their versions of infer,
INFER_SUPPORT_RUNTIME_DICT = {
    'TensorFlow': {
        'python2.7': {'1.8': 'python2.7', '1.13': 'tf1.13-python2.7-cpu', '1.13-gpu': 'tf1.13-python2.7-gpu'},
        'python3.6': {'1.8': 'python3.6', '1.13': 'tf1.13-python3.6-cpu', '1.13-gpu': 'tf1.13-python3.6-gpu'},
        'python3.7': {'2.1': 'tf2.1-python3.7', '1.13': 'tf1.13-python3.7-cpu', '1.13-gpu': 'tf1.13-python3.7-gpu'}
    },
    'MXNet': {
        'python2.7': {'1.2': 'python2.7'},
        'python3.6': {'1.2': 'python3.6'},
        'python3.7': {'1.2': 'python3.7'}
    },
    'Caffe': {
        'python2.7': {'1.0': 'python2.7', '1.0-cpu': 'python2.7-cpu', '1.0-gpu': 'python2.7-gpu'},
        'python3.6': {'1.0': 'python3.6', '1.0-cpu': 'python3.6-cpu', '1.0-gpu': 'python3.6-gpu'},
        'python3.7': {'1.0': 'python3.7', '1.0-cpu': 'python3.7-cpu', '1.0-gpu': 'python3.7-gpu'}
    },
    'Spark_MLlib': {
        'python2.7': {'2.3': 'python2.7'},
        'python3.6': {'2.3': 'python3.6'}
    },
    'Scikit_Learn': {
        'python2.7': {'0.20': 'python2.7'},
        'python3.6': {'0.20': 'python3.6'}
    },
    'XGBoost': {
        'python2.7': {'0.80': 'python2.7'},
        'python3.6': {'0.80': 'python3.6'}
    },
    'PyTorch': {
        'python2.7': {'1.0': 'python2.7'},
        'python3.6': {'1.0': 'python3.6',
                      '1.4': 'python3.6',
                      '1.5': 'python3.6',
                      '1.6': 'python3.6',
                      '1.7': 'python3.6',
                      '1.8': 'python3.6',
                      '1.9': 'python3.6',
                      },
        'python3.7': {'1.0': 'python3.7',
                      '1.4': 'pytorch1.4-python3.7',
                      '1.5': 'python3.7',
                      '1.6': 'python3.7',
                      '1.7': 'python3.7',
                      '1.8': 'python3.7',
                      '1.9': 'python3.7'
                      }
    }
}
INFER_RUNTIME_TO_ENVIRONMENT = {
    'TensorFlow': {
        'python2.7': {'pip_packages': ['tensorflow==1.8.0', 'tensorflow-serving-api==1.13.0'],
                      'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['tensorflow==1.8.0', 'tensorflow-serving-api==1.13.0'],
                      'conda_packages': ['python=3.6.2']},
        'tf1.13-python2.7-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=2.7']},
        'tf1.13-python2.7-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=2.7']},
        'tf1.13-python3.6-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=3.6.2']},
        'tf1.13-python3.6-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=3.6.2']},
        'tf1.13-python3.7-gpu': {'pip_packages': ['tensorflow-gpu==1.13.2'], 'conda_packages': ['python=3.7']},
        'tf1.13-python3.7-cpu': {'pip_packages': ['tensorflow==1.13.2'], 'conda_packages': ['python=3.7']},
        'tf2.1-python3.7': {'pip_packages': ['tensorflow==2.1'], 'conda_packages': ['python=3.7']}
    },
    'MXNet': {
        'python2.7': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=3.6.2']},
        'python3.7': {'pip_packages': ['mxnet==1.2.1', 'mxnet-model-server==0.3'],
                      'conda_packages': ['python=3.7']}
    },
    'Caffe': {  # caffe does not support local infer, we only record runtimes
        'python2.7': {}, 'python3.6': {}, 'python3.7': {},
        'python2.7-gpu': {}, 'python3.6-gpu': {}, 'python3.7-gpu': {},
        'python2.7-cpu': {}, 'python3.6-cpu': {}, 'python3.7-cpu': {}
    },
    'Spark_MLlib': {
        'python2.7': {'pip_packages': ['pyspark==2.3.2'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['pyspark==2.3.2'], 'conda_packages': ['python=3.6.2']}
    },
    'Scikit_Learn': {
        'python2.7': {'pip_packages': ['scikit-learn==0.20.0'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['scikit-learn==0.20.0'], 'conda_packages': ['python=3.6.2']}
    },
    'XGBoost': {
        'python2.7': {'pip_packages': ['xgboost==0.80'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['xgboost==0.80'], 'conda_packages': ['python=3.6.2']}
    },
    'PyTorch': {
        'python2.7': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=2.7']},
        'python3.6': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=3.6.2']},
        'python3.7': {'pip_packages': ['torch==1.0.0', 'torchvision==0.2.1'], 'conda_packages': ['python=3.7']},
        'pytorch1.4-python3.7': {'pip_packages': ['torch==1.4.0', 'torchvision==0.5.0'],
                                 'conda_packages': ['python=3.7']}
    },
    'Custom': {}
}

INFER_FRAMEWORK_ALIAS = {
    "tensorflow": ["tensorflow", "tensorflow-gpu"],
    "spark_mllib": ["pyspark"],
    "pytorch": ["torch"],
    "scikit_learn": ["scikit-learn"],
    "mxnet": ["mxnet-cu90", "mxnet"]
}

MODEL_LOCAL_LOCATION = "LOCAL_SOURCE"

MODEL_OBS_LOCATION = "OBS_SOURCE"

MODEL_IMAGE_LOCATION = "IMAGE_SOURCE"

MODEL_SOURCE_LOCATIONS_TYPE = {MODEL_LOCAL_LOCATION, MODEL_OBS_LOCATION, MODEL_IMAGE_LOCATION}

MODEL_SOURCE_LOCATION = "source_location"

MODEL_ALGORITHM_PATTERN = u"^[a-z|A-Z][^&!'\\\"<>=\u4e00-\u9fa5]{0,35}$"

PACKAGE_PATTERN = u"^[^(|);&$?\"<>`!'=\u4e00-\u9fa5\\s]{1,256}$"

MODEL_NAME_PATTERN = u"^[a-zA-Z0-9\u4e00-\u9fa5-_]{1,64}$"

MODEL_VERSION_PATTERN = "^(\\d\\.|[1-9]\\d\\.){2}(\\d|([1-9]\\d))$"

MODEL_DESCRIPTION_PATTERN = "^[^&!'\\\"<>=]{1,100}$"

DOC_NAME_PATTERN = "^[^&!'\\\"<>=]{1,48}$"

DOC_URL_PATTERN = "http[s]?://[^/]+.+"

SOURCE_LOCATION_PATTERN = "http[s]?://[^/]+/.+"

ERR_MAX_LINE_NUM = 100

DOMAIN_PATTERN = u"(?=^.{3,255}$)^[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+.?$"

HTTP_STATUS_CODE_200 = 200

HTTP_STATUS_CODE_299 = 299

LOCAL_INFER_LOG_FILE_NAME = "log.txt"

MOUNT_DIR = "/home/ma-user/work"

UPLOAD_MODE = 'upload'

DIR_MODE = 'dir'

SEP = '/'

CREDENTIAL_PROFILES_FILE = 'CREDENTIAL_PROFILES_FILE'

AWS_CREDENTIAL_PROFILES_FILE = 'AWS_CREDENTIAL_PROFILES_FILE'

NB_USER = "NB_USER"

# for ascend training
NBSTART_HCCL_FILE_PATH = "/user/config/nbstart_hccl.json"

JOBSTART_HCCL_FILE_PATH = "/user/config/jobstart_hccl.json"

QUERY_TRAIN_STATUS_PERIOD = 30

TRAIN_OUTPUT_DATA_SYNC_PERIOD = 30

FILE_PERMISSION = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP  # 640

# Model parameters
ENGINE_TYPE_SET = {'pytorch', 'xgboost', 'scikit_learn', 'tensorflow', 'spark_mllib'}
MAXIMUM_RETRY_TIMES = 8000
JOB_DELETE_RETRY_TIMES = 5
JOB_STOP_RETRY_TIMES = 5
REQUEST_TIME_OUT = 30

CREATE_WAIT_SEC = 3
DEPLOY_WAIT_SEC = 3
LOCAL_INFER_PORT = 6060
MODEL_LOCAL_HOST = "127.0.0.1"
LOCAL_INFER_RETRY_TIMES = 10
LOCAL_INFER_WAIT_SEC = 1
USER_TRAFFIC_LIMIT = 150

DATA_TYPE_SET = {'json', 'files', 'images'}
IMAGE_LOCAL_HOST = "127.0.0.1:5205"
IMAGE_NAME = "custom-training-image"

IAM_REFRESH_TOKEN_BELOW_HOUR = 23.75

LIMIT_BUILDKIT_IMAGE_SIZE = 12 * 2 ** 30  # 12GB
LIMIT_BUILDKIT_IMAGE_LAYERS = 120
LIMIT_BUILDKIT_DISK_USAGE = 200
DISK_USAGE_RETRY_INTERVAL = 3
SWR_RETRY_INTERVAL = 5
SWR_RETRY_TIME = 3
LIMIT_USAGE_RATE = 0.8
BUILDKIT_MOUNT_PATH = "/etc/hosts"

X86_ARCH = "X86_64"
ARM_ARCH = "AARCH64"
VAILD_RESOURCE_CATEGORY = {"CPU", "GPU", "Ascend"}
