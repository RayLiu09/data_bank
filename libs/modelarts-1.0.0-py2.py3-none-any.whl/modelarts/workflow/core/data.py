import abc
import collections

from modelarts.workflow.core.entities import TransformType, Entity


class AbstractInputData(Entity):
    """

    """

    @abc.abstractmethod
    def is_need_consume(self):
        pass

    @abc.abstractmethod
    def ref(self):
        pass

    @abc.abstractmethod
    def type(self):
        pass


class AbstractData(AbstractInputData):

    def __init__(self, name: str):
        self.name = name

    def ref(self):
        return "$ref/data/{}".format(self.name)

    @abc.abstractmethod
    def get_snapshot(self) -> TransformType:
        """
        get snapshot of data
        Returns:
            TransformType
        """
        pass

    def is_need_consume(self):
        return False


class VariableConsumption:

    def __init__(self, output, step_name, output_name, variable):
        self.output = output
        self.step_name = step_name
        self.output_name = output_name
        self.variable = variable

    def consume(self):
        variable_value = self.output.variables.get(self.variable)
        if not variable_value:
            raise ValueError('variable {} is not exist, step name: {}, output name: {}'.format(
                self.variable, self.step_name, self.output_name))
        return variable_value

    def ref(self):
        return "$ref/consumptions/{}/{}/{}".format(self.step_name, self.output_name, self.variable)


class AbstractDataConsumption(AbstractInputData):

    def __init__(self, config, step_name, output_name):
        self.config = config
        self.step_name = step_name
        self.output_name = output_name

    @abc.abstractmethod
    def consume(self) -> AbstractData:
        raise NotImplementedError

    def ref(self):
        return "$ref/consumptions/{}/{}".format(self.step_name, self.output_name)

    def is_need_consume(self):
        return True

    def to_definition_json(self):
        pass


class AbstractDataPlaceholders(AbstractInputData):

    def __init__(self, name: str, delay: bool, required=True):
        AbstractDataPlaceholders._check_init_info(delay, required)
        self.name = name
        self.delay = delay
        self.required = required

    @abc.abstractmethod
    def is_set(self) -> bool:
        raise NotImplementedError

    @abc.abstractmethod
    def set_data(self, data):
        raise NotImplementedError

    @abc.abstractmethod
    def get_data_from_command_line(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def data(self) -> AbstractData:
        raise NotImplementedError

    @abc.abstractmethod
    def consume(self):
        pass

    def ref(self):
        return "$ref/data_requirements/{}".format(self.name)

    def get_snapshot(self):
        """
        get snapshot of data placeholders
        Returns:

        """
        return {
            "name": self.name,
            "data": self.data.get_snapshot()
        }

    @staticmethod
    def _check_init_info(delay, required):
        if not required and delay:
            raise ValueError("delay DataPlaceholder should be required")

    def is_need_consume(self):
        return True


class AbstractOutputConfig(abc.ABC):
    def __init__(self):
        self._is_skipped = None

    @property
    def is_skipped(self):
        return self._is_skipped

    @is_skipped.setter
    def is_skipped(self, is_skipped):
        self._is_skipped = is_skipped


class DataPlaceholderNotSet(Exception):
    pass


class DuplicateDataPlaceholder(Exception):
    pass


class DuplicateData(Exception):
    pass


class DataPlaceholdersDict(collections.UserDict):

    def check_ready(self):
        for data_placeholder in self.values():
            if not data_placeholder.is_set():
                raise DataPlaceholderNotSet("{} not ready".format(data_placeholder))

    def merge(self, data_placeholders):
        """
        Merge another DataPlaceholdersDict into the current object
        Args:
            data_placeholders (DataPlaceholdersDict): data to be merged

        Returns:
        """
        if not data_placeholders:
            return
        for data_placeholder in data_placeholders.values():
            self.add_data_placeholder(data_placeholder)

    def add_data_placeholder(self, data_placeholder):
        """

        Returns:

        """
        if not data_placeholder:
            return
        if data_placeholder.name in self and self[data_placeholder.name] != data_placeholder:
            raise DuplicateDataPlaceholder("data placeholder %s is repeated declared" % data_placeholder.name)
        self[data_placeholder.name] = data_placeholder

    def get_snapshot(self):
        """
        get snapshot of data placeholders
        Returns:

        """
        snapshot_result = []
        for data_placeholder in self.values():
            if not data_placeholder.is_set():
                continue
            snapshot_result.append(data_placeholder.get_snapshot())
        return snapshot_result


class DataDict(collections.UserDict):

    def merge(self, data_dict):
        """
        Merge another DataDict into the current object
        Args:
            data_dict (DataDict): data to be merged

        Returns:
        """
        if not data_dict:
            return
        for data in data_dict.values():
            self.add_data(data)

    def add_data(self, data):
        """

        Returns:

        """
        if not data:
            return
        if data.name in self and self[data.name] != data:
            raise DuplicateData("data %s is repeated declared" % data.name)
        self[data.name] = data

    def get_snapshot(self):
        """
        get snapshot of data
        Returns:

        """
        return [x.get_snapshot() for x in self.values()]
