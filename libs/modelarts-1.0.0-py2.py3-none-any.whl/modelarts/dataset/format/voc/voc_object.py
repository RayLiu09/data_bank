"""
Description: parse file of pascal voc format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""


class VocObject(object):
    """
        VOC contain source, object and so on.
        This class is used to VOC object. Object contains name, position and so on.
    """

    def __init__(
            self,
            name=None,
            properties=None,
            pose=None,
            truncated=None,
            occluded=None,
            difficult=None,
            confidence=None,
            position=None,
            parts=None,
            mask_color=None
    ):
        """
        Constructor for VOC Object

        :param name: object name
        :param properties: object properties
        :param pose: pose value
        :param truncated: an object marked as 'truncated' indicates that the bounding box specified for the object
                does not correspond to the full extent of the object.
                e.g. an image of a person from the waist up, or a view of a car extending outside the image.
                The truncated field being set to 1 indicates that the object is "truncated" in the image.
        :param occluded: an object marked as 'occluded' indicates that a significant portion of the object
                within the bounding box is occluded by another object.
                The occluded field being set to 1 indicates that the object is significantly occluded by another object.
                Participants are free to use or ignore this field as they see fit.
        :param difficult: an object marked as 'difficult' indicates that the object is considered difficult to
                recognize,for example an object which is clearly visible but unidentifiable without substantial
                use of context. Objects marked as difficult are currently ignored in the evaluation of the challenge.
                The difficult field being set to 1 indicates that the object has been annotated as "difficult",
                for example an object which is clearly visible but difficult to recognize
                without substantial use of context.
        :param confidence: Confidence for annotation that was annotated by machine, the value: 0 <= Confidence < 1,
                optional field.
        :param position: position can be point, line or others.
        :param parts: one object may have sub objects
        :param mask_color: mask color
        """
        self.__name = name
        self.__properties = properties
        self.__pose = pose
        self.__truncated = truncated
        self.__occluded = occluded
        self.__difficult = difficult
        self.__confidence = confidence
        self.__position = position
        self.__parts = parts
        self.__mask_color = mask_color

    @property
    def name(self):
        """
        :return: the object name, mandatory field
        """
        return self.__name

    @property
    def properties(self):
        """
        :return: the properties of object, mandatory field
        """
        return self.__properties

    @property
    def pose(self):
        """
        :return: the pose of object, optional field
        """
        return self.__pose

    @property
    def truncated(self):
        """
        :return: whether the object is truncated, optional field
        """
        return self.__truncated

    @property
    def occluded(self):
        """
        :return: whether the object is occluded, optional field
        """
        return self.__occluded

    @property
    def difficult(self):
        """
        :return: whether the object is difficult, optional field
        """
        return self.__difficult

    @property
    def confidence(self):
        """
        :return: confidence value of the object annotation, optional field
        """
        return self.__confidence

    @property
    def position(self):
        """
        :return: the pose of object, mandatory field
        """
        return self.__position

    @property
    def parts(self):
        """
        :return: subobjects, optional field
        """
        return self.__parts

    @parts.setter
    def parts(self, parts):
        self.__parts = parts

    @property
    def mask_color(self):
        """
        :return: mask color, optional field
        """
        return self.__mask_color
