import logging
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig, auth_by_roma_api
from modelarts.util.secret_util import auth_expired_handler

HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_PUT = constant.HTTPS_PUT


class _ServiceAPPApiAKSKImpl:
    def __init__(self, session, headers=None):
        """
        Initialize a ModelArts service app instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session
        self.headers = headers
        self.base_request_url = '/v1/' + self.session.project_id + '/app-auth'

    @auth_expired_handler
    def list_apps(self, **kwargs):
        """
        list apps according conditions
        Args:
            **kwargs: query args

        Returns: app list info

        """
        request_url = self.base_request_url + '/' + "apps"
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, query=kwargs, headers=self.headers)

    @auth_expired_handler
    def register_api_and_authorize_to_app(self, service_id, request_body):
        """
        Register the API and authorize the APP
        Args:
            service_id (str): The service ID
            request_body (dict): The request body

        Returns (dict):

        """
        request_url = self.base_request_url + '/' + service_id + "/apis/auths"
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_api(self, service_id):
        """
        Get api authorize info according to service ID
        Args:
            service_id (str): Service ID

        Returns (dict):

        """
        request_url = self.base_request_url + '/' + service_id + '/api-auths'
        return auth_by_apig(self.session,
                            constant.HTTPS_GET, request_url, headers=self.headers)

    @auth_expired_handler
    def update_authorize_app(self, service_id, api_id, request_body):
        """
        Update api authorize with apps
        Args:
            service_id (str): The service ID
            api_id (str): api ID from service
            request_body (dict): The request body

        Returns (dict):

        """
        request_url = self.base_request_url + '/' + service_id + "/apis/" + api_id + '/auths'
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_PUT, request_url, body=body_encode)


class _ServiceAPPApiROMAImpl:
    def __init__(self, session):
        """
        Initialize a ModelArts service app instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session

    @auth_expired_handler
    def list_apps(self, **kwargs):
        """
        list apps according conditions
        Args:
            **kwargs: query args

        Returns: app list info

        """
        request_url = "{host}/v1/{project_id}/app-auth/apps".format(
            host=self.session.host, project_id=self.session.project_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="list_service_apps",
                                params=kwargs
                                )

    @auth_expired_handler
    def register_api_and_authorize_to_app(self, service_id, request_body):
        """
        Register the API and authorize the APP
        Args:
            service_id (str): The service ID
            request_body (dict): The request body

        Returns (dict):

        """
        request_url = "{host}/v1/{project_id}/app-auth/{service_id}/apis/auths".format(
            host=self.session.host, project_id=self.session.project_id, service_id=service_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="register_api_and_authorize_to_app",
                                data=JSONEncoder().encode(request_body)
                                )

    @auth_expired_handler
    def get_api(self, service_id):
        """
        Get api authorize info according to service ID
        Args:
            service_id (str): Service ID

        Returns (dict):

        """
        request_url = "{host}/v1/{project_id}/app-auth/{service_id}/api-auths".format(
            host=self.session.host, project_id=self.session.project_id, service_id=service_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_api"
                                )

    @auth_expired_handler
    def update_authorize_app(self, service_id, api_id, request_body):
        """
        Update api authorize with apps
        Args:
            service_id (str): The service ID
            api_id (str): api ID from service
            request_body (dict): The request body

        Returns (dict):

        """
        request_url = "{host}/v1/{project_id}/app-auth/{service_id}/apis/{api_id}/auths".format(
            host=self.session.host, project_id=self.session.project_id, service_id=service_id, api_id=api_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_PUT,
                                intf_action="update_authorize_app",
                                data=JSONEncoder().encode(request_body)
                                )


class ServiceAPPClient:

    def __init__(self, session):
        """
        Class for Client which makes ModelArts service app calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        if session.auth == constant.AKSK_AUTH:
            self._app_impl = _ServiceAPPApiAKSKImpl(session)
        else:
            self._app_impl = _ServiceAPPApiROMAImpl(session)

    def register_api_and_authorize_to_app(self, service_id, apps):
        """
        Register the API and authorize the APP
        Args:
            service_id (str): The service ID
            apps (list): The list of app name

        Returns (dict):

        """
        app_list = []
        for app_name in apps:
            app_id = self.get_app_id(app_name=app_name)
            if not app_id:
                raise ValueError('The app {} is not exist'.format(app_name))
            app_list.append({"app_id": app_id})
        request_body = {
            "apps": app_list
        }
        resp = self._app_impl.register_api_and_authorize_to_app(service_id=service_id, request_body=request_body)
        for auth_result in resp.get("auth_result", []):
            if not auth_result.get("success", None):
                logging.error("api_id: %s, app_id: %s, reason: %s", auth_result.get("api_id", ""),
                              auth_result.get("app_id", ""), auth_result.get("reason", ""))
        return resp

    def get_app_id(self, app_name):
        """
        Get app ID according to app name
        Args:
            app_name (str): app name

        Returns (str): app ID

        """
        resp = self._app_impl.list_apps(app_name=app_name)
        for app in resp.get("apps", []):
            if app_name == app.get("app_name", ""):
                return app.get("app_id", "")
        return ""

    def get_api_id(self, service_id):
        """
        Get api ID from service
        Args:
            service_id (str): Service ID

        Returns (str): api ID

        """
        resp = self._app_impl.get_api(service_id=service_id)
        app_auth_api = resp.get("app_auth_api", None)
        if app_auth_api:
            return app_auth_api.get("api_id", "")
        return ""

    def update_authorize_app(self, service_id, api_id, apps):
        """
        Update api authorize with apps
        Args:
            service_id (str): The service ID
            api_id (str): api ID from service
            apps (list): The list of app name

        Returns (dict):

        """
        app_list = []
        for app_name in apps:
            app_id = self.get_app_id(app_name=app_name)
            if not app_id:
                raise ValueError('The app {} is not exist'.format(app_name))
            app_list.append({"app_id": app_id})
        request_body = {
            "apps": app_list
        }
        resp = self._app_impl.update_authorize_app(service_id=service_id, api_id=api_id, request_body=request_body)
        for auth_result in resp.get("auth_result", []):
            if not auth_result.get("success", None):
                logging.error("api_id: %s, app_id: %s, reason: %s", auth_result.get("api_id", ""),
                              auth_result.get("app_id", ""), auth_result.get("reason", ""))
        return resp
