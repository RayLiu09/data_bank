"""
Description: This file provides some common functions to process string
Author: ModelArts SDK Team
Date: 2021/11/01 - 2021/12/30
"""
import os

from modelarts.util.config import Config

HTTP_PREFIX = "http://"
HTTPS_PREFIX = "https://"


def contains_zh(s: str):
    """
    If a string containers chinese.
    :param s: a string to be judged
    :return: True of False
    """
    for c in s:
        if '\u4e00' <= c <= '\u9fa5':
            return True
    return False


def query_var(cfg_var, env_var=None, remove_prefix=False):
    """
    Query variable from config file or environment variables.
    :param cfg_var: query from config.ini
    :param env_var: query from environment variables
    :param remove_prefix: whether to remove protocol prefix
    """
    def _remove_prefix(_var, _remove_prefix=False):
        if not _remove_prefix:
            return _var
        if _var.startswith(HTTP_PREFIX):
            return _var.replace(HTTP_PREFIX, "")
        if _var.startswith(HTTPS_PREFIX):
            return _var.replace(HTTPS_PREFIX, "")
        return _var

    res_cfg = Config.getenv(cfg_var, default=None)
    if res_cfg is not None:
        return _remove_prefix(res_cfg, _remove_prefix=remove_prefix)
    if env_var is None:
        return None
    res_env = os.environ.get(env_var, None)
    return _remove_prefix(res_env, _remove_prefix=remove_prefix) if res_env is not None else None
