from modelarts.local.commons.loader_factory import ModelLoaderFactory

MODEL_TYPE = 'TensorFlow'


class ModelManager(object):
    model_loader = ModelLoaderFactory.get_instance(MODEL_TYPE)
    model_service = None

    @classmethod
    def load_service(cls, model):
        cls.model_service = cls.model_loader.load(model)
