class IAMException(Exception):
    def __init__(self, code=500, message=""):
        self.code = code
        self.message = message

    def __str__(self):
        return "err_code: {}, err_message: {}".format(self.code, self.message)
