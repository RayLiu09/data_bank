from modelarts import constant
from modelarts.config.auth import auth_by_apig
from modelarts.util.string_util import query_var


class CsmsSecretsClient:

    def __init__(self, session):
        self.session = session

        if not (self.session.access_key and self.session.secret_key and self.session.project_id):
            raise RuntimeError(
                "Failed to initialized ModelArts session, access key and secret key and project id are required")
        kms_host = query_var(cfg_var=f"KMS_{session.region_name}", env_var="KMS_ENDPOINT", remove_prefix=True)
        if kms_host is None:
            raise ValueError("KMS endpoint info is required for kms secret management.")
        self.host = kms_host

    def list_secrets(self, limit=50, marker=None, event_name=None):

        request_url = f"/v1/{self.session.project_id}/secrets"
        query = {}
        if limit is not None:
            query.update({"limit": limit})
        if marker is not None:
            query.update({"marker": marker})
        if event_name is not None:
            query.update({"event_name": event_name})

        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def list_secret_versions(self, secret_name, limit=50, marker=None):
        request_url = f"/v1/{self.session.project_id}/secrets/{secret_name}/versions"
        query = {}
        if limit is not None:
            query.update({"limit": limit})
        if marker is not None:
            query.update({"marker": marker})

        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=query or None, host=self.host)

    def get_secret_with_version_id(self, secret_name, version_id):
        request_url = f"/v1/{self.session.project_id}/secrets/{secret_name}/versions/{version_id}"

        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, host=self.host)
