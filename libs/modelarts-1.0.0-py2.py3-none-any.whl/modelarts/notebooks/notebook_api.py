import logging
from abc import ABCMeta, abstractmethod
from json import JSONEncoder

from .. import constant
from ..config.auth import auth_by_apig
from . notebook_def import Notebook


logging.getLogger().setLevel(logging.INFO)


class NotebookApi(metaclass=ABCMeta):
    """These Apis can interact with modelarts management service."""

    @abstractmethod
    def list_flavors(self, query_param=None):
        """Get flavors from modelarts notebook service
        :param query_param: query parameters like 'type' or 'name'
        """
        pass

    @abstractmethod
    def create(self, notebook):
        pass

    @abstractmethod
    def update(self, notebook_id, dew_secret_name=None):
        pass

    @abstractmethod
    def delete(self, notebook_id):
        pass

    @abstractmethod
    def get(self, notebook_id):
        pass

    @abstractmethod
    def list(self, params=None):
        pass

    @abstractmethod
    def start(self, notebook_id, duration=None, lease_type=None):
        pass

    @abstractmethod
    def stop(self, notebook_id):
        pass

    @abstractmethod
    def get_cluster_info(self, pool_id):
        pass


class NotebookApiAKSKImpl(NotebookApi):

    def __init__(self, session):
        super(NotebookApi, self).__init__()
        self._session = session

    def list_flavors(self, query_param=None):
        query_param = dict() if query_param else query_param
        # The feature of an image include 'NOTEBOOK' and 'DEFAULT' where the latter is used to create codelab.
        # We do not need display codelab images to users.
        request_url = "/v1/" + self._session.project_id + "/notebooks/flavors"
        resp = auth_by_apig(self._session, constant.HTTPS_GET, request_url, query=query_param)
        return resp

    def create(self, notebook: Notebook):
        body = {"flavor": notebook.flavor,
                "image_id": notebook.image_id,
                "name": notebook.name,
                "volume": {
                    "category": notebook.volume.category,
                    "ownership": notebook.volume.ownership,
                }}
        if notebook.volume.capacity:
            body["volume"].update({"capacity": notebook.volume.capacity})
        if notebook.volume.uri:
            body["volume"].update({"uri": notebook.volume.uri})
        if notebook.volume.volume_id:
            body["volume"].update({"id": notebook.volume.volume_id})
        if notebook.volume.dew_secret_name:
            body["volume"].update({"dew_secret_name": notebook.volume.dew_secret_name})
        if notebook.description:
            body.update({"description": notebook.description})
        if notebook.pool_id:
            body.update({"pool_id": notebook.pool_id})
        if notebook.workspace_id:
            body.update({"workspace_id": notebook.workspace_id})
        if notebook.lease:
            body["lease"] = {"duration": notebook.lease.duration, "type": notebook.lease.type}
        if notebook.endpoints:
            body["endpoints"] = []
            for endpoint in notebook.endpoints:
                endpoint_body = {"key_pair_names": endpoint.key_pair_names, "service": endpoint.service}
                if endpoint.allowed_access_ips:
                    endpoint_body.update({"allowed_access_ips": endpoint.allowed_access_ips})
                body["endpoints"].append(endpoint_body)
        if notebook.data_volumes:
            body["data_volumes"] = []
            for data_vol in notebook.data_volumes:
                data_vol_body = {"category": data_vol.category,
                                 "ownership": data_vol.ownership,
                                 "uri": data_vol.uri,
                                 "mount_path": data_vol.mount_path,
                                 "read_only": data_vol.read_only}
                if data_vol.volume_id:
                    data_vol_body.update({"id": data_vol.volume_id})
                if data_vol.dew_secret_name:
                    data_vol_body.update({"dew_secret_name": data_vol.dew_secret_name})

                body["data_volumes"].append(data_vol_body)
        if notebook.env_variables:
            body["env_variables"] = {}
            for env_var in notebook.env_variables:
                body["env_variables"].update({env_var.key: env_var.value})
        if notebook.node_selector:
            body.update({"node_selector": notebook.node_selector.get()})
        request_url = "/v1/" + self._session.project_id + "/notebooks"
        resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=JSONEncoder().encode(body))
        logging.info("Successfully create notebook %s.", notebook.name)
        return resp

    def update(self, notebook_id, dew_secret_name=None):
        request_url = "/v1/" + self._session.project_id + "/notebooks/" + notebook_id
        body = dict()
        if dew_secret_name:
            body.update({"dew_secret_name": dew_secret_name})
        return auth_by_apig(self._session, constant.HTTPS_PUT, request_url, body=JSONEncoder().encode(body))

    def delete(self, notebook_id):
        request_url = "/v1/" + self._session.project_id + "/notebooks/" + notebook_id
        resp = auth_by_apig(self._session, constant.HTTPS_DELETE, request_url)
        logging.info("Successfully delete notebook %s.", notebook_id)
        return resp

    def get(self, notebook_id):
        request_url = "/v1/" + self._session.project_id + "/notebooks/" + notebook_id
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url)

    def list(self, params=None):
        if not params:
            params = dict()
        request_url = "/v1/" + self._session.project_id + "/notebooks"
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url, query=params)

    def start(self, notebook_id, duration=None, lease_type=None):
        params = dict()
        if duration:
            params.update({"duration": duration})
        if lease_type:
            params.update({"type": lease_type})
        request_url = "/v1/" + self._session.project_id + "/notebooks/" + notebook_id + "/start"
        resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url, query=params)
        logging.info("Successfully start notebook %s", notebook_id)
        return resp

    def stop(self, notebook_id):
        request_url = "/v1/" + self._session.project_id + "/notebooks/" + notebook_id + "/stop"
        resp = auth_by_apig(self._session, constant.HTTPS_POST, request_url)
        logging.info("Successfully stop notebook %s", notebook_id)
        return resp

    def get_cluster_info(self, pool_id):
        request_url = "/v1/" + self._session.project_id + "/authoring/clusters/" + pool_id
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url)


def get_notebook_api_instance(session):
    return NotebookApiAKSKImpl(session)
