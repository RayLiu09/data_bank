# -*- coding: utf-8 -*
"""A class to manage conda environment dependencies."""
import re

from . import const

NAME = "name"
CHANNELS = 'channels'
DEPENDENCIES = 'dependencies'
PREFIX = 'prefix'
_VALID_CONDA_KEYS = [NAME, CHANNELS, DEPENDENCIES, PREFIX]
PIP = "pip"
PYTHON = "python"
DEFAULT_PYTHON_VERSION = "3.7.10"
VERSION_PATTERN = r'\d+\.(?:\d+\.)*\d+$'
VERSION_REGEX = re.compile(VERSION_PATTERN)


def get_package_name(package_name):
    """
    Get the package name without version and other information from the whole package name
    :param package_name: the whole package name
    :return package name
    """
    pattern = "[\[=|<|>|~|!]"
    return re.split(pattern, package_name)[0]


def get_package_version(version):
    """
    Get python package version
    :param version: package name
    """
    matched_group = VERSION_REGEX.search(version)
    if matched_group:
        return matched_group.group()
    return ""


def _remove_list_element(target_list, str_element, remove_flag=True):
    """
    when remove "$target", if "$target" or "$target==$version" should
    both be removed
    :param target_list: target list
    :param str_element: the element which will be added
    :return if remove the element successfully
    """
    if not target_list:
        return False
    if str_element in target_list:
        if remove_flag:
            target_list.remove(str_element)
        return True
    for e in target_list:
        if get_package_name(e) == get_package_name(str_element):
            if remove_flag:
                target_list.remove(e)
            return True
    return False


def _add_list_element(target_list, str_element, remove_flag=True):
    """
    add an element to target list
    :param target_list: target list
    :param str_element: element
    """
    exist_flag = _remove_list_element(target_list, str_element, remove_flag)
    # if remove str_element or str_element not in target
    if remove_flag or not exist_flag:
        target_list.append(str_element)


class CondaDependencies(object):
    """
    This oject is used to manage conda dependencies
    """

    def __init__(self, conda_dependencies_file_path=None):
        """
        Initialize conda environment dependency files.
        :param conda_dependencies_file_path: dependency files of conda environment.
        """
        self._channels = []
        self._pip_packages = []
        self._conda_packages = []
        if not conda_dependencies_file_path:
            self.set_python_version(DEFAULT_PYTHON_VERSION)
            return
        """conda_dependencies_file_path文件格式如下所示:

        name: base
        channels:
        - http://10.154.236.132:63997/conda-forge
        - defaults
        dependencies:
        - astroid=1.6.1=py36_0
        - astropy=2.0.3=py36h14c3975_0
        - pip:
            - configparser==3.7.3
            - easydict==1.7
            - enum34==1.1.10
            - esdk-obs-python==3.20.7.1
            - graphviz==0.8.1
            - gunicorn==19.8.1
            - modelarts==1.1.3
            - moxing-framework==1.17.3
            - opencv-python==3.4.0.12
            - prometheus-client==0.3.1
            - tables==3.4.2
        prefix: /home/ma-user/anaconda3
        """
        import yaml
        with open(conda_dependencies_file_path, "r") as f:
            conda_specification = yaml.safe_load(f)

        CondaDependencies._validate_dependencies_file(
            conda_specification)
        self._channels = conda_specification.get(CHANNELS, [])
        dependencies = conda_specification.get(DEPENDENCIES, [])
        for d in dependencies:
            if PIP in d and isinstance(d, dict):
                self._pip_packages = d.get(PIP)
            else:
                self._conda_packages.append(d)
        if not self._has_python_package():
            self.set_python_version(DEFAULT_PYTHON_VERSION)

    @staticmethod
    def create(channels=[], pip_packages=[], conda_packages=[]):
        """
        create a conda environment
        :para channels: list of sources of needed python packaged
        :para pip_packages: list of needed python packages installed by pip
        :para conda_packages: list of needed python packages installed by conda
        :return a conda environment
        """
        cd = CondaDependencies()
        for c in channels or []:
            cd.add_channel(c)
        for pip in pip_packages or []:
            cd.add_pip_package(pip)
        for conda in conda_packages:
            cd.add_package(conda)
        if not cd._has_python_package():
            cd.set_python_version(DEFAULT_PYTHON_VERSION)
        return cd

    @staticmethod
    def _validate_dependencies_file(yaml_content):
        """
        Validate the yaml file describing conda dependencies
        :param yaml_content: conda dependencies
        """
        if not isinstance(yaml_content, dict):
            raise Exception("Environment error: invalid YAML format")
        for key in yaml_content.keys():
            if str(key) not in _VALID_CONDA_KEYS:
                raise Exception(
                    "Environment error: unknown {} key in conda environment specification".format(str(key)))

    def add_channel(self, channel):
        """
        add a channel into the member variables
        :param channel: source channel
        """
        _add_list_element(self._channels, channel)

    def remove_channel(self, channel):
        return _remove_list_element(self._channels, channel)

    def add_package(self, conda_package):
        """
        add a conda package into the member variable
        :param conda_package: a package which shoule be installed by conda
        """
        _add_list_element(self._conda_packages, conda_package)

    def remove_package(self, conda_package):
        return _remove_list_element(self._conda_packages, conda_package)

    def add_pip_package(self, pip_package, remove_flag=True):
        """
        add a pip package into the member variables
        :param pip_package: a python package which should be installed by pip
        """
        _add_list_element(self._pip_packages, pip_package, remove_flag)

    def remove_pip_package(self, pip_package):
        return _remove_list_element(self._pip_packages, pip_package)

    def set_python_version(self, python_version):
        """
        set the python version for this conda environment
        :param python_version: python version
        """
        self.add_package("{}={}".format(PYTHON, python_version))

    def get_python_version(self):
        """
        Get python version
        :return python version
        """
        for p in self._conda_packages:
            if get_package_name(p) == PYTHON:
                return get_package_version(p)
        return ""

    def _has_python_package(self):
        """
        judge if the list of conda packages contanis a python package
        return true or false
        """
        for p in self._conda_packages:
            if get_package_name(p) == PYTHON:
                return True
        return False

    def get_framework_package(self, frameworks):
        """
        Get the AI framework package, including TensorFlow, MXNet, Caffe, Spark_MLlib, Scikit_Learn,
        XGBoost, PyTorch
        :param frameworks: AI frameworks
        """
        for framework in frameworks:
            for package in self._pip_packages:
                if framework == get_package_name(package).lower():
                    if ">=" in package or "<=" in package:
                        raise Exception("The AI framework version should be specified by '=='.")
                    return package
        return ""

    @property
    def channels(self):
        return self._channels

    @property
    def pip_packages(self):
        return self._pip_packages

    @property
    def conda_packages(self):
        return self._conda_packages

    @staticmethod
    def serialize_to_dict(conda):
        """
        put conda environment parameters into a dictionary
        {
            "channels": [
                 "conda-forge"
            ],
            "conda-packages": [
                 "python==3.6",
                 "tensofflow==2.1"
             ],
             "pip-packages": [
                 "Pillow==7.0.0"
            ]
        }
        """
        conda._channels.sort()
        conda._conda_packages.sort()
        # conda._pip_packages doesn't need to sort

        return {
            const.CHANNELS: conda._channels,
            const.CONDA_PACKAGES: conda._conda_packages,
            const.PIP_PACKAGES: conda._pip_packages,
        }

    @staticmethod
    def deserialize_from_dict(serialized_dict):
        """
        Deserialize a dictionary to a CondaDependencies object
        :param serialized_dict: a serialized dictionary
        :return a CondaDependencies object
        """
        cd = CondaDependencies()
        for channel in serialized_dict.get(const.CHANNELS, []):
            cd.add_channel(channel)
        for pip_package in serialized_dict.get(const.PIP_PACKAGES, []):
            cd.add_pip_package(pip_package)
        for conda_package in serialized_dict.get(const.CONDA_PACKAGES, []):
            cd.add_package(conda_package)
        return cd
