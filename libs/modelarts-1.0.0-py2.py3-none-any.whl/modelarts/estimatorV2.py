"""An estimator class for training of modelarts sdk."""
import linecache
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import json
from json import JSONEncoder

from . import constant
from .config.auth import auth_by_apig, auth_by_roma_estimatorv2_api
from .estimator_base import EstimatorBase, TrainingJobBase
from .notebook_mgmt import Notebook
from .session import Session
from .train_params import prepare_params_input, OutputData, TrainingFiles, prepare_params_output, TrainPolicy
from .notebooks.notebook_def import NodeSelector
from .util import notebook_util
from .util.secret_util import auth_expired_handler
from modelarts.util.string_util import query_var

logging.getLogger().setLevel(logging.INFO)
JOB_STATE = constant.JOB_STATE
HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_DELETE = constant.HTTPS_DELETE
HTTPS_PUT = constant.HTTPS_PUT
LOG_FORMAT = '<{} LOG>: {}'
SDK_LOG_HEAD = "SDK"
MS_BUILD_PROCESS_NUM_ENV_NAME = "MS_BUILD_PROCESS_NUM"
IS_ASCEND_910 = notebook_util.is_ascend910()
HIGH_PRIORITY = 3
MEDIUM_PRIORITY = 2
LOW_PRIORITY = 1
PRIORITY_LIST = [LOW_PRIORITY, MEDIUM_PRIORITY, HIGH_PRIORITY]
JOB_PRIORITY = "priority"
DEFAULT_NODE_TYPE = "rack"
LOG_MAX_SIZE_BYTES = 5242880  # 5M
LOG_FILE_FORMAT = "modelarts-job-{}-{}.log"
TRAINING_EXPERIMENT = "training_experiment_reference"


class Estimator(EstimatorBase):
    TRAIN_CONSOLE_TINY_3_REGIONS = ["cn-north-7", "cn-north-213", "cn-south-222"]

    def __init__(self,
                 session,
                 training_files=None,
                 outputs=None,
                 parameters=None,
                 env_variables=None,
                 train_instance_type=None,
                 train_instance_count=None,
                 framework_type=None,
                 framework_version=None,
                 log_url=None,
                 user_image_url=None,
                 uid=None,
                 non_swr_image=None,
                 local_code_dir=None,
                 working_dir=None,
                 user_command=None,
                 job_description=None,
                 job_id=None,
                 job_type=None,
                 environment=None,
                 volumes=None,
                 base_job_name=None,
                 policy=TrainPolicy.REG.value,
                 pool_id=None,
                 script_interpreter=None,
                 workspace_id=None,
                 experiment_name=None,
                 node_selector=None):
        """
        Initialize a ModelArts EstimatorV2 Object.
        :param session: session with authentication information
        :param training_files: instance of class TrainingFiles
        :param outputs: a list, output location of training job
        :param parameters: the run parameters of training job, which will be passed to training boot file.
                            It should be a list and each element is a dictionary containing only two members
                            whose keys are 'name' and value. For example,
                            [{"name": "dist", "value": True}, {"name": "epoc_num", "value": 2}]
        :param train_instance_count: the number of worker nodes
        :param train_instance_type: the flavor of worker node
        :param framework_type: engine specifications selected for training job
        :param framework_version: engine version selected for training job
        :param environment: this is an instance of modelarts.environment.Environment which is used in training debug
        :param env_variables: a dictionary contains environment variables
        :param non_swr_image: indicates whether to use swr image. When it is true, user_image_url should be filled with
                                the full image address
        :param local_code_dir: the absolute path to save source code in training job container
        :param working_dir: the work directory to execute source code in training job container
        :param experiment_name: the experiment name, indicating the set of jobs
        :param node_selector: run the job on the nodes of the specified label group.
                            For example: NodeSelector({"demo.com/test_key1": "test_value1", "test_key2": "test_value2"})
        """
        super(Estimator, self).__init__(
            session,
            train_instance_count,
            train_instance_type,
            base_job_name,
            parameters,
            framework_type,
            framework_version,
            log_url,
            user_image_url,
            user_command,
            job_description,
            job_id,
            job_type,
            workspace_id
        )
        self.__training_files = training_files
        self.__outputs = outputs if outputs is not None else []
        self.local_code_dir = local_code_dir
        self.uid = uid
        self.working_dir = working_dir
        self.non_swr_image = non_swr_image
        self.experiment_name = experiment_name
        self._current_experiment_name = None
        self.__is_efs = notebook_util.is_mount_efs()
        self.__attached_mount_dir = "/home/ma-user/modelarts"
        self.__script_interpreter = script_interpreter if script_interpreter is not None else sys.executable
        self.volumes = volumes
        self.policy = policy
        self.pool_id = pool_id
        self.node_selector = node_selector
        self.__env_variables = env_variables
        self.__using_nb_image = False
        self.__check_init_param()
        self._convert_run_parameters(parameters)
        self._convert_env_variables()
        if train_instance_type == constant.LOCAL_TRAIN_TYPE:
            if notebook_util.is_mul_kernel_image():
                raise Exception("CodeLab using multi-kernel image does not support training debug.")
            if self.local_code_dir is not None:
                logging.warning("Parameter local_code_dir is not supported in local training, which will be ignored. "
                                "[default code path: '%s']", os.path.join(self.__attached_mount_dir, 'user-job-dir'))
            if self.working_dir is not None:
                logging.warning("Parameter working_dir is not supported in local training, "
                                "which will be ignored. [default current work path: '%s']", os.getcwd())
            self.local_training = True
            self.trainingJob = _LocalTrainingJob(
                session=self.session,
                train_instance_count=train_instance_count,
                training_files=training_files,
                framework_type=framework_type,
                script_interpreter=self.__script_interpreter,
                parameters=self.parameters,
                log_url=log_url,
                is_efs=self.__is_efs,
                attached_mount_dir=self.__attached_mount_dir,
                env_variables=self.__env_variables
            )
        else:
            self.local_training = False
            self.trainingJob = TrainingJob(self.session)
        self.env_target = self.__init_environment_target(environment=environment)
        self.__structured_output = None

    def __check_init_param(self):
        """
        Check instance initialization parameters
        """
        self.__check_required_init_params()
        self.__check_non_required_init_params()

    def __check_required_init_params(self):
        """
        Check init params which are required.
        """
        if not isinstance(self.session, Session):
            raise TypeError("Parameter session should be type of modelarts.session.Session")
        if self.__training_files is not None and not isinstance(self.__training_files, TrainingFiles):
            raise TypeError("Parameter training_files should be type of modelarts.train_params.TrainingFiles")
        if self.train_instance_type is not None and not isinstance(self.train_instance_type, str):
            raise TypeError("Parameter train_instance_type should be a string.")
        if self.train_instance_count is not None and not isinstance(self.train_instance_count, int):
            raise TypeError("Parameter train_instance_count should be an integer.")
        if self.framework_type is not None and not isinstance(self.framework_type, str):
            raise TypeError("Parameter framework_type should be a string.")

    def __check_non_required_init_params(self):
        """
        Check init params which are not required.
        """
        if self.__outputs is not None:
            if not isinstance(self.__outputs, list):
                raise TypeError("Parameter outputs should be a list.")
            for data in self.__outputs:
                if not isinstance(data, OutputData):
                    raise TypeError("Each element of outputs should be of type modelarts.train_params.OutputData")
        self.__check_run_parameters()
        if self.volumes is not None and not isinstance(self.volumes, list):
            raise TypeError("Parameter volumes should be type of list.")
        if self.policy not in TrainPolicy.list():
            raise ValueError("Parameter policy should be one of {}.".format(TrainPolicy.list()))
        self.__check_init_string_params()
        if self.__env_variables and not isinstance(self.__env_variables, dict):
            raise TypeError("Parameter env_variables should be type of dict.")
        if self.node_selector and not isinstance(self.node_selector, NodeSelector):
            raise ValueError("The parameter 'node_selector' should be type of 'NodeSelector'.")

    def __check_run_parameters(self):
        """
        Check run parameters.
        """
        if self.parameters is None:
            return
        if not isinstance(self.parameters, list):
            raise TypeError("Parameter 'parameters' should be a list.")
        for para in self.parameters:
            if not isinstance(para, dict):
                raise TypeError("Each element of 'parameters' should be a dictionary.")
            if "name" not in para:
                raise TypeError("Each element of 'parameters' should be a dictionary and must contain key 'name'.")

    def __check_init_string_params(self):
        """
        Check init params which should be type of string
        """
        if self.base_job_name is not None and not isinstance(self.base_job_name, str):
            raise TypeError("Parameter base_job_name should be a string.")
        if self.framework_version is not None and not isinstance(self.framework_version, str):
            raise TypeError("Parameter framework_version should be a string.")
        if self.log_url is None:
            # For d910 remote training job, the training service will check the existence of log_url because the plog
            # and other system logs will miss without log_url. Therefore, for local training job, we check the log_url
            # too in order to maintain consistency.
            if self.train_instance_type == constant.LOCAL_TRAIN_TYPE and notebook_util.is_ascend910():
                raise ValueError("Parameter log_url is needed when running a d910 training job.")
        elif not isinstance(self.log_url, str):
            raise TypeError("Parameter log_url should be a string.")
        if self.user_image_url is not None and not isinstance(self.user_image_url, str):
            raise TypeError("Parameter user_image_url should be a string.")
        if self.user_command is not None and not isinstance(self.user_command, str):
            raise TypeError("Parameter user_command should be a string.")
        if self.job_description is not None and not isinstance(self.job_description, str):
            raise TypeError("Parameter job_description should be a string.")
        if self.job_id is not None and not isinstance(self.job_id, str):
            raise TypeError("Parameter job_id should be a string.")
        if self.job_type is not None and not isinstance(self.job_type, str):
            raise TypeError("Parameter job_type should be a string.")
        if self.pool_id is not None and not isinstance(self.pool_id, str):
            raise TypeError("Parameter pool_id should be a string.")

    def _convert_env_variables(self):
        if not self.__env_variables:
            return
        for k, v in self.__env_variables.items():
            if isinstance(v, (dict, list)):
                self.__env_variables[k] = json.dumps(v)

    def _convert_run_parameters(self, parameters):
        """
        Process the bool value in self.parameters
        :param parameters: run parameters which will be passed into boot file
        """
        self.parameters = []
        for para in parameters or []:
            # argparse in python does not support bool type directly like 'type=bool',
            # so we assume user employs action='store_true' to receive bool parameters in boot file.
            # Therefore, we only pass --name if value is True and pass nothing if value is False.
            if "value" in para:
                if isinstance(para["value"], bool):
                    if para["value"]:
                        self.parameters.append({"name": para["name"]})
                elif isinstance(para["value"], (dict, list)):
                    para["value"] = json.dumps(para["value"])
                    self.parameters.append(para)
                else:
                    # the value must be type of string
                    para["value"] = str(para["value"])
                    self.parameters.append(para)
            else:
                self.parameters.append(para)

    def __init_environment_target(self, environment=None):
        """
        Initialize a compute environment including local and V1
        :param environment: conda or docker environment
        """
        if environment is None:
            return None

        from .compute import RunConfig, LocalCompute, TrainV2Compute
        run_config = RunConfig(
            source_directory=self.code_dir,
            boot_file=self.boot_file,
            args=self.parameters,
            instance_count=self.train_instance_count,
            instance_type=self.train_instance_type,
            framework=self.framework_type)

        if self.train_instance_type == constant.LOCAL_TRAIN_TYPE:
            return LocalCompute(run_config=run_config,
                                environment=environment)
        else:
            return TrainV2Compute(run_config=run_config,
                                  environment=environment,
                                  estimator=self)

    def fit(self,
            inputs=[],
            dataset_id=None,
            dataset_version_id=None,
            data_source=None,
            wait=False,
            job_name=None,
            show_log=False,
            priority=None,
            experiment_name=None):
        """
        Train a model using the input training dataset.
        :param inputs: input data of training job
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param wait: whether wait the job completed or not
        :param job_name: job name
        :param show_log: bool, if need to show log
        :param priority: train job priority for roma, 3 2 1 is high middle low
        :param experiment_name: the experiment name, indicating the set of jobs
        :return: job object
        """
        if not isinstance(inputs, list):
            raise TypeError("inputs should be a list.")
        self._gen_job_name(job_name=job_name)

        self._current_experiment_name = experiment_name or self.experiment_name

        self.__check_framework_type()
        job_train_resp = self.submit_task(inputs, dataset_id, dataset_version_id, data_source, priority)
        return self.__post_create_job(job_train_resp, wait=wait, show_log=show_log)

    def __check_train_instance(self):
        """
        For remote and local training job, check whether framework type from user is supported by training service.
        """
        decidated_pool_specs = ["modelarts.pool.visual.xlarge",
                                "modelarts.pool.visual.2xlarge",
                                "modelarts.pool.visual.4xlarge",
                                "modelarts.pool.visual.8xlarge"]
        # The training service does not provide an api to query dedicated pools in hwc
        if self.pool_id and self.session.auth == constant.ROMA_AUTH:
            if self.train_instance_type and self.train_instance_type not in decidated_pool_specs:
                raise ValueError(f"Parameter 'train_instance_type' should be one of {decidated_pool_specs}")
            pool_info = self.get_job_pool_list(self.session)
            if "pools" not in pool_info:
                raise Exception("No decidated pools.")
            for pool in pool_info["pools"]:
                if pool["pool_id"] == self.pool_id:
                    return
            else:
                raise Exception(f"Cannot find pool {self.pool_id}.")
        # only check max_num in public flavor
        if self.pool_id is not None:
            return

        resp = self.get_spec_list(self.session)
        for flavor in resp["flavors"]:
            if flavor["flavor_id"] == self.train_instance_type:
                if self.train_instance_count > flavor["flavor_info"]["max_num"]:
                    raise Exception("The train instance count of {} cannot exceed {}.".
                                    format(self.train_instance_type, flavor["flavor_info"]["max_num"]))

    def __check_framework_type(self):
        """
        Check if the framework type from user is supported by training service.
        """
        # If user submits a customize image training job and uses customize command, framework_type is not needed.
        if self.user_image_url and self.user_command:
            return
        res = Estimator.get_engine_list(self.session)
        for engine in res['items']:
            if engine['engine_name'] == self.framework_type:
                break
        else:
            raise ValueError("Your framework_type {} is not supported.".format(self.framework_type))

    def __post_create_job(self, job_train_resp, wait=True, show_log=False):
        if self.train_instance_type and self.train_instance_type in constant.LOCAL_TRAIN_TYPE:
            return self.trainingJob
        if wait:
            if show_log:
                log_info = LOG_FORMAT.format(SDK_LOG_HEAD,
                                             "After the training job finished, the log will be printed out.")
                logging.warning(log_info)
            self.print_job_middle_state(job_train_resp)
        else:
            console_url = os.environ.get("MODELARTS_CONSOLE_ENDPOINT")
            if self.session.auth == constant.AKSK_AUTH and console_url:
                if self.session.region_name in Estimator.TRAIN_CONSOLE_TINY_3_REGIONS:
                    job_console_url = "{0}#/training/detail/{1}".format(
                        console_url, job_train_resp["metadata"].get("id", ""))
                else:
                    job_console_url = "{0}#/trainingJobBeta/{1}/detail".format(
                        console_url, job_train_resp["metadata"].get("id", ""))
                log_info = LOG_FORMAT.format(
                    SDK_LOG_HEAD, f"Submit training job successfully, please see more detail as {job_console_url}")
                logging.info(log_info)
        self.trainingJob.job_id = job_train_resp["metadata"].get("id", "")
        if show_log:
            self.get_training_log()
        return self.trainingJob

    def prepare_config(self,
                       inputs,
                       dataset_id,
                       dataset_version_id,
                       data_source):
        """
        Organize all needed parameters to a dict.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :return: job config
        """
        _config = dict()
        if self.working_dir is not None:
            if not os.path.isabs(self.working_dir):
                raise ValueError(f"The working_dir parameter must be an absolute path but got {self.working_dir}")
            _config['working_dir'] = self.working_dir
        if self.local_code_dir is not None:
            if not os.path.isabs(self.local_code_dir):
                raise ValueError(f"The local_code_dir parameter must be an absolute path but got {self.local_code_dir}")
            _config['local_code_dir'] = self.local_code_dir

        _config = self._prepare_params_engine(_config)

        self._prepare_params_code(_config)

        _config['parameters'] = self.parameters

        _config.update({"outputs": prepare_params_output(self.__outputs, local_run=False)})
        _config.update({"inputs": prepare_params_input(
            inputs,
            dataset_id,
            dataset_version_id,
            data_source,
            local_run=False
        )})
        _config["environments"] = self.__env_variables if self.__env_variables else {}
        # We add this environment variables only when user submits the training job using the d910 notebook image
        # after debugging in notebook
        if IS_ASCEND_910 and self.__using_nb_image and MS_BUILD_PROCESS_NUM_ENV_NAME not in _config["environments"]:
            _config["environments"].update({MS_BUILD_PROCESS_NUM_ENV_NAME: os.getenv(MS_BUILD_PROCESS_NUM_ENV_NAME)})

        return _config

    def _prepare_params_code(self, _config):
        """
        Set code dir and boot file for job config.
        """
        if self.__training_files:
            _config['code_dir'] = self.__training_files.get_code_dir(local_run=False)
            boot_file = self.__training_files.get_boot_file(local_run=False)
            if boot_file is None and (self.user_command is None or self.user_image_url is None):
                raise ValueError("Only when user_image_url and user_command are both used, "
                                 "you can omit boot_file.")
            if boot_file is not None:
                _config['boot_file'] = boot_file
        elif not (self.user_image_url and self.user_command):
            raise ValueError("Only when user_image_url and user_command are both used, "
                             "you can omit training_files.")

    def _prepare_params_engine(self, _config):
        """
        Set engine for job config.
        1. If user inputs user_image_url and user_command, this training job will use customize image and command.
        2. If user inputs framework_version and framework_type, this training job will use common images of
               modelarts training service.
        3. If user inputs user_image_url and framework_type, this training job will use customize image and
               preset command.
        4. If user inputs only framework_type, this training job will use the image of this notebook or devcontainer.
        5. If user inputs user_command without user_image_url and framework_version, this training job will use
              the image of this notebook or devcontainer and preset command.
        :param _config: check engine_id
        :return: _config['engine_id']
        """
        _config['engine'] = dict()
        if self.user_command:
            if self.user_image_url:
                _config['command'] = self.user_command
                _config['engine'].update({'image_url': self.user_image_url})
                if self.uid is not None:
                    _config['engine'].update({'run_user': self.uid})
                if self.non_swr_image:
                    _config['engine'].update({'non_swr_image': self.non_swr_image})
                return _config
            elif not self.framework_version and not self.user_image_url:
                _config['command'] = self.user_command
                _config['engine'].update({'image_url': self.__get_notebook_image(self.session)})
                return _config

        if self.framework_version:
            res = self.trainingJob.get_engine_list(self.session)
            for engine in res['items']:
                if engine['engine_name'] == self.framework_type and engine['engine_version'] == self.framework_version:
                    _config['engine'].update({'engine_id': engine['engine_id']})
            return _config
        _config['engine'].update({'engine_name': self.framework_type})
        if self.user_image_url:
            _config['engine'].update({'image_url': self.user_image_url})
            if self.uid is not None:
                _config['engine'].update({'run_user': self.uid})
            if self.non_swr_image:
                _config['engine'].update({'non_swr_image': self.non_swr_image})
            return _config

        _config['engine'].update({
            'image_url': self.__get_notebook_image(self.session),
            'script_interpreter': self.__script_interpreter
        })
        self.__using_nb_image = True
        # For training job running on ascend, the training service will start it using 1102 user by default.
        # But the user id of notebook is 1000, therefore the parameter run_user is required and the value is 1000.
        if IS_ASCEND_910:
            _config['engine']['run_user'] = str(notebook_util.get_ma_user_id())
        return _config

    @staticmethod
    def __get_notebook_image(session):
        # use the image of current notebook
        if notebook_util.is_mul_kernel_image():
            raise Exception("It is not supported to submit a training job which will use mul-kernel image. "
                            "Please input framework_version or user_image_url when initializing Estimator.")
        if notebook_util.is_kernel_gateway():
            raise Exception("It is not supported to submit a training job using the image of notebook after swithing "
                            "flavor. Please switch to the original flavor of your notebook.")
        notebook_info = Notebook(session).get_notebook_info()
        image_info = notebook_info.get("image")
        if image_info is None:
            raise ValueError("Missing image key in notebook info.")
        swr_img = image_info.get("swr_path")
        if swr_img is None:
            raise ValueError("Missing swr_path key in notebook image info.")
        return swr_img[swr_img.index("/") + 1:]

    def __upload_inputs_and_code(self, input_list):
        for data in input_list:
            if not data.need_upload(self.session, self.local_training):
                continue
            data.compress_and_upload(self.session)
        # Training files may not be needed if user submits a remote training job with customize image
        if (self.local_training and self.train_instance_count <= 1) \
                or not self.__training_files or not self.__training_files.need_upload():
            return
        self.__training_files.compress_upload(self.session)

    def _set_body(self, job_config):
        resource = {
            "policy": self.policy,
            "node_count": self.train_instance_count
        }
        if self.train_instance_type:
            resource['flavor_id'] = self.train_instance_type
        if self.pool_id:
            resource['pool_id'] = self.pool_id
            # Dedicated pool only supports "regular" and "auto"
            resource["policy"] = "regular"
            if self.policy == TrainPolicy.AUT.value:
                resource["policy"] = self.policy
        metadata = {
            "name": self._current_job_name,
            "description": self.job_description
        }
        if self.workspace_id is not None:
            metadata["workspace_id"] = str(self.workspace_id)
        body = {
            "kind": "job",
            "metadata": metadata,
            "algorithm": job_config,
            "spec": {
                "resource": resource
            }
        }
        # After training debug in notebook, we will submit a remote training job using the image of notebook.
        # And the format of some parameters will be different from other situations.
        # For example, path of boot file will not start with '/'. With the following flag, ROMA will verify these
        # different parameters with different rules.
        if self.__using_nb_image:
            body["metadata"].update({"annotations": {"notebook/verify": "true"}})
        return body

    def start_new(self,
                  inputs,
                  dataset_id,
                  dataset_version_id,
                  data_source,
                  priority=None):
        """
        Create a new training job from the estimator.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: training job object
        """
        self.__upload_inputs_and_code(inputs)
        if self.train_instance_type == constant.LOCAL_TRAIN_TYPE:
            return self.trainingJob.create_training_job(
                inputs,
                dataset_id,
                dataset_version_id,
                data_source,
                self.__outputs
            )
        else:
            self.__check_train_instance()
            _config = self.prepare_config(inputs, dataset_id, dataset_version_id, data_source)
            body = self._set_body(_config)
            # If the devcontainer mounts an efs and the user wants to submit remote training job using the image of
            # devcontainer, we add the efs information to the remote training job.
            if self.__using_nb_image:
                self._add_efs_volumes()
            if self.volumes:
                body["spec"]["volumes"] = self.volumes
            if self.log_url:
                body["spec"].update(
                    {"log_export_path":
                         {"obs_url": self.log_url,
                          "host_path": ""
                          }})

            if self.session.auth != constant.ROMA_AUTH and self.pool_id:
                if priority is not None:
                    body["spec"]["schedule_policy"] = {JOB_PRIORITY: priority}
                if self.node_selector:
                    body["spec"]["schedule_policy"]["required_affinity"] = {
                        "node_type": DEFAULT_NODE_TYPE,
                        "node_labels": self.node_selector.get()
                    }
            self._add_experiment_info(body)
            return self.trainingJob.create_training_job(self._remove_obs_head(body))

    def _add_experiment_info(self, body):
        if not self._current_experiment_name:
            return
        experiment_id = self.trainingJob.get_experiment_id_by_name(self._current_experiment_name)
        metadata = {}
        if experiment_id:
            metadata[TRAINING_EXPERIMENT] = {"id": experiment_id}
        else:
            metadata[TRAINING_EXPERIMENT] = {"name": self._current_experiment_name}
        body["metadata"].update(metadata)

    @staticmethod
    def _remove_obs_head(body):
        """
        The string 'obs:/' should be removed from obs path because of the following reasons:
        1. In cloud, the training service of v2 version provides old images which belongs to v1 version,
           and those images do not support the obs path beginning with 'obs:/'.
        2. In ROMA, the obs path beginning with 'obs:/' cannot be parsed correctly when looking up query training
           configuration information in UI after the training job completed.
        This function is just a temporary adaptation, so when the above two problems are resolved, it can be removed.
        :return: training parameters
        """
        # training codes
        if 'code_dir' in body['algorithm']:
            body['algorithm']['code_dir'] = body['algorithm']['code_dir'].replace('obs:/', '')
            if body['algorithm'].get("boot_file") is not None:
                body['algorithm']['boot_file'] = body['algorithm']['boot_file'].replace('obs:/', '')
        # training inputs
        for input_data in body["algorithm"]["inputs"]:
            # the training input may come from dataset service
            if "obs" in input_data["remote"]:
                input_data["remote"]["obs"]["obs_url"] = input_data["remote"]["obs"]["obs_url"].replace('obs:/', '')
        # outputs
        for output_data in body["algorithm"]["outputs"]:
            output_data["remote"]["obs"]["obs_url"] = output_data["remote"]["obs"]["obs_url"].replace('obs:/', '')
        # log_url
        if "log_export_path" in body["spec"]:
            body["spec"]["log_export_path"]["obs_url"] = body["spec"]["log_export_path"]["obs_url"].replace('obs:/', '')
        return body

    def _add_efs_volumes(self):
        """
        If this devcontainer mounts efs, add the efs info to volumes.
        """
        if not self.__is_efs:
            return
        if not self.volumes:
            self.volumes = []
        self.volumes.append(self.__generate_efs_volume())

    @staticmethod
    def __generate_efs_volume():
        """
        When efs, generate volume parameters
        :return: a dictionary containing efs information
        """
        volume = {"local_path": constant.MOUNT_DIR, "read_only": False}
        sys.path.append(os.getenv("SCC_CONF_DIR", "/usr/local/seccrypto"))
        from seccrypt import cryptography
        encrypted_nfs_path = os.getenv('EFS_MOUNT_PATH')
        if not encrypted_nfs_path:
            raise Exception("Failed to get EFS mount path")
        try:
            nfs_path = cryptography.decrypt(encrypted_nfs_path)
            volume["nfs_server_path"] = nfs_path
        except Exception:
            raise Exception(
                "Failed to decrypt information to get EFS mount path")
        return {"nfs": volume}

    def print_job_middle_state(self, job_train_resp):
        """
        Print Training Job Middle State.
        :param job_train_resp: contains job_name job_id
        :return: None
        """
        job_name = job_train_resp["metadata"].get("name", "")
        job_id = job_train_resp["metadata"].get("id", "")
        logging.info("Current training job id is: %s", job_id)

        count_init = 0
        count_running = 0
        count_queuing = 0
        count_downloading = 0
        count_waiting = 0
        while True:
            response, duration, job_id = self.get_job_state(job_id=job_id)
            if response == 'Completed':
                self.process_job_completed(response, duration, job_name)
                break
            elif response == 'Creating':
                count_init = self.process_job_uncompleted(response, count_init)
            elif response == 'Queuing':
                count_queuing = self.process_job_uncompleted(response, count_queuing)
            elif response == 'Downloading':
                count_downloading = self.process_job_uncompleted(response, count_downloading)
            elif response == 'Running':
                count_running = self.process_job_uncompleted(response, count_running)
            elif response == 'Csb_Waiting':
                count_waiting = self.process_job_uncompleted(response, count_waiting)
            elif response in ["Failed", "Terminating", "Terminated",
                              "CreateFailed", "Abnormal", "TerminatedFailed", "Lost"]:
                logging.info("Job [ %s ] status is %s, please check log", job_name, response)
                break

            count_total = count_init + count_running + count_queuing + count_downloading + count_waiting
            if count_total > int(constant.MAXIMUM_RETRY_TIMES):
                logging.info("Reach the maximum start times, "
                             "the current status is %s", response)
                break

    @classmethod
    def get_job_list(cls, session, **kwargs):
        """
        Get Training Job List.
        :param session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        return cls(session=session).trainingJob.get_job_list(session, **kwargs)

    def get_job_info(self, job_id=None):
        job_id = job_id if job_id is not None else self.job_id
        return self.trainingJob.get_job_info(job_id)

    def get_job_info_with_resource_flavor(self, job_id=None):
        job_id = job_id if job_id is not None else self.job_id
        return self.trainingJob.get_job_info_with_resource_flavor(job_id)

    def update_job_configs(self, description=None, priority=None):
        return self.trainingJob.update_job_configs(job_id=self.job_id, description=description, priority=priority)

    def get_job_log(self, task_id=None, **kwargs):
        return self.trainingJob.get_job_log(self.job_id, task_id, **kwargs)

    def get_formatted_job_log(self, task_id=None, **kwargs):
        log = self.trainingJob.get_job_log(self.job_id, task_id, **kwargs)
        logs = log.get("content", "").split("\n")
        log["content"] = logs
        return log

    def get_training_log(self, job_id=None, worker_id=0, local_path=None, interval=constant.QUERY_TRAIN_STATUS_PERIOD):
        """
        :param job_id: the training job you want to view the log
        :param local_path: where the log will saved to
        :param worker_id: the index of training worker for multi-machine training
        :param interval: the period of looking up the logs
        Get realtime log when running a remote training job.
        """
        if job_id is None:
            job_id = self.trainingJob.job_id
        if local_path is None:
            local_path = os.path.expanduser("~")
        local_path = os.path.abspath(local_path) + constant.SEP
        job_info = self.get_job_info(job_id)
        if "log_export_path" not in job_info["spec"]:
            raise Exception("Cannot find log files in obs for job {}.".format(job_id))

        log_file_name = "modelarts-job-{}-worker-{}.log".format(job_id, worker_id)
        log_obs_path = os.path.join("obs:/" + job_info["spec"]["log_export_path"]["obs_url"], log_file_name)
        completed_status = ["COMPLETED", "TERMINATED", "FAILED", "KILLED", "ABNORMAL"]
        cur_line_idx = 0
        local_log_path = os.path.join(local_path, log_file_name)
        log_info = LOG_FORMAT.format(SDK_LOG_HEAD, "Wait for the training job to generate logs.")
        logging.info(log_info)
        while True:
            status, duration, job_id = self.get_job_state(job_id)
            if not self.session.obs.is_obs_path_exists(log_obs_path):
                if status.upper() in completed_status:
                    raise Exception("Cannot find log file {} of job {} in obs.".format(log_obs_path, job_id))
                time.sleep(interval)
                continue
            self.session.obs.download_file(log_obs_path, local_path)
            linecache.clearcache()
            lines = linecache.getlines(local_log_path)[cur_line_idx:]
            for line in lines:
                logging.info(line.strip())
            cur_line_idx += len(lines)
            if status.upper() in completed_status:
                break
            time.sleep(interval)
        log_info = LOG_FORMAT.format(SDK_LOG_HEAD, f"The log of job {job_id} is saved in file {local_log_path}")
        logging.info(log_info)

    def get_job_metrics(self, task_id=None):
        return self.trainingJob.get_job_metrics(self.job_id, task_id)

    def get_job_event(self, job_id=None):
        return self.trainingJob.get_job_event(job_id)

    def get_job_state(self, job_id):
        """
        Get Specified Training Job State of job_id.
        :param job_id: job id
        :return:
        """
        res = self.trainingJob.get_job_info(job_id)
        secondary_phase = res['status']['secondary_phase']
        duration = res['status']['duration']
        new_job_id = res["metadata"]["id"] if res["metadata"]["id"] else job_id
        return secondary_phase, duration, new_job_id

    @classmethod
    def get_engine_list(cls, session):
        """
        Get Supported Engine List.
        """
        return cls(
            session=session).trainingJob.get_engine_list(
            session)

    @classmethod
    def get_framework_list(cls, session):
        """
        Get Supported Framework List.
        """
        return cls(
            session=session).trainingJob.get_framework_list(
            session)

    @classmethod
    def get_job_pool_list(cls, session):
        """
        Get pool List.
        """
        return cls(session=session).trainingJob.get_job_pool_list(session)

    @classmethod
    def control_job_by_id(cls, session, job_id, **kwargs):
        return cls(
            session=session).trainingJob.control_job(
            job_id, **kwargs)

    @classmethod
    def get_train_instance_types(cls, session):
        """
        Get Supported Train Instance Types.
        """
        return cls(session=session).trainingJob.get_train_instance_types(session)

    @classmethod
    def get_spec_list(cls, session, flavor_type=None):
        """
        Get Supported Spec List.
        """
        return cls(session=session).trainingJob.get_spec_list(session, flavor_type=flavor_type)

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, session, **kwargs):
        """
        Get Supported dataset.
        """
        return cls(
            session=session).trainingJob.get_datasets(
            session, **kwargs)

    @classmethod
    def delete_job_by_id(cls, session, job_id):
        return cls(session=session).trainingJob.delete_job(job_id)


class TrainingJob(TrainingJobBase):

    def __init__(self,
                 session,
                 job_id=None,
                 train_url=None,
                 inputs=None,
                 dataset_id=None,
                 dataset_version_id=None,
                 data_source=None):
        """
        Initialize a ModelArts Training Job instance.
        """
        super(TrainingJob, self).__init__(session,
                                          job_id,
                                          train_url,
                                          inputs,
                                          dataset_id,
                                          dataset_version_id,
                                          data_source)
        self.session = session
        if session.auth == constant.AKSK_AUTH:
            self._training_job = _TrainingJobApiAKSKImpl(session)
        elif session.auth == constant.ROMA_AUTH:
            self._training_job = _TrainingJobApiRomaImpl(session)
        else:
            raise ValueError(
                'Only support aksk authorization and roma authorization.')

    @classmethod
    def get_job_list(cls, session, **kwargs):
        """
        Get Training Job List.
        :param session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        return cls(
            session=session)._training_job.get_job_list(
            session, **kwargs)

    def get_job_info(self, job_id=None):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        response = self._training_job.get_job_info(job_id)
        return response

    def get_job_info_with_resource_flavor(self, job_id=None):
        """
        Get Training Job Info with resource flavor of Specified job_id.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        job_info = self._training_job.get_job_info(job_id)
        pool_id = job_info.get("spec", {}).get("resource", {}).get("pool_id", "")
        if not pool_id:
            return job_info
        flavor = self._training_job.get_pool_flavor(pool_id)
        if not flavor:
            logging.warning("flavor not found in the pool %s", pool_id)
            return job_info
        resource_flavor = self._training_job.get_resource_flavor(flavor)
        if not resource_flavor:
            logging.warning("resource flavor %s not found", flavor)
            return job_info
        job_info["spec"]["resource"].update({"flavor_info": resource_flavor.get("spec", {})})
        return job_info

    def get_job_log(self, job_id=None, task_id=None, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return:
        """
        task_id = task_id if task_id else "worker-0"
        job_id = self._check_job_id(job_id)
        try:
            log = self._training_job.get_job_log(job_id, task_id, **kwargs)
        except Exception as e:
            logging.warning("get job %s (task: %s) log from aom failed: %s", job_id, task_id, e)
            log_file_path = self._get_log_file_path(job_id, task_id)
            if not log_file_path:
                raise Exception("job %s (task: %s) log file is not exist", job_id, task_id)
            log = self.get_job_log_from_obs(log_file_path)
            if not log:
                raise Exception("get job %s (task: %s) log from obs %s failed", job_id, task_id, log_file_path)
        return log

    def _get_log_file_path(self, job_id, task_id):
        """
        Get log file obs path specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :return: log file obs path
        """
        job_info = self.get_job_info(job_id)
        log_directory = job_info.get("spec", {}).get("log_export_path", {}).get("obs_url", "")
        if not log_directory:
            return ""
        if not log_directory.startswith(constant.OBS_HEAD_FORMAT):
            log_directory = "{}{}".format(constant.OBS_HEAD_FORMAT, log_directory.lstrip(constant.SEP))
        log_file = LOG_FILE_FORMAT.format(job_id, task_id)
        return "{}{}".format(log_directory, log_file)

    @auth_expired_handler
    def get_job_log_from_obs(self, obs_path):
        """
        Get Training Job Log of Specified job_id and task_id from obs.
        :param obs_path: job log obs path
        :return: For example: {"full_size": 1024,
                               "current_size": 100,
                               "content": ""}
        """
        size_info = self.session.obs.get_objects_size(obs_path)
        content_size, content = self.session.obs.get_object(obs_path, LOG_MAX_SIZE_BYTES)
        return {"full_size": size_info.get(obs_path, ""), "current_size": content_size, "content": content}

    def get_formatted_job_log(self, job_id=None, task_id=None, **kwargs):
        log = self.get_job_log(job_id, task_id, **kwargs)
        logs = log.get("content", "").split("\n")
        log["content"] = logs
        return log

    def get_experiment_id_by_name(self, experiment_name):
        """
        Get experiment ID according to experiment name.
        """
        resp = self._training_job.get_experiment_by_name(experiment_name)
        experiments = resp.get("items", [])
        if not experiments:
            return ""
        for experiment in experiments:
            metadata = experiment.get("metadata", {})
            if not metadata:
                continue
            if metadata.get("name", "") == experiment_name:
                return metadata.get("id", "")
        return ""

    def get_job_metrics(self, job_id=None, task_id=None):
        """
        Get job metrics for training job.
        """
        task_id = task_id if task_id else "worker-0"
        job_id = self._check_job_id(job_id)
        return self._training_job.get_job_metrics(job_id, task_id)

    def get_job_event(self, job_id=None):
        """
        Get job event for training job.
        """
        job_id = self._check_job_id(job_id)
        return self._training_job.get_job_event(job_id)

    @classmethod
    def get_engine_list(cls, session):
        """
        Get Supported Engine List.
        """
        return cls(
            session=session)._training_job.get_engine_list(
            session)

    @classmethod
    def get_framework_list(cls, session):
        """
        Get Supported Framework List.
        """
        train_job = cls(session=session)
        engine_list = train_job._training_job.get_engine_list(session)
        return train_job._training_job.get_framework_list(session, engine_list)

    @classmethod
    def get_job_pool_list(cls, session):
        """
        Get pool List.
        """
        return cls(session=session)._training_job.get_job_pool_list(session)

    def update_job_configs(self, job_id=None, **kwargs):
        """
        Update training job configs by job id.
        :param kwargs: support 'description', 'priority'
        :return: None
        """
        job_id = self._check_job_id(job_id)
        if not kwargs:
            kwargs = dict()
        if 'description' not in kwargs or kwargs['description'] is None:
            kwargs.update({"description": ""})
        if JOB_PRIORITY in kwargs:
            if kwargs[JOB_PRIORITY] is None:
                kwargs.pop(JOB_PRIORITY)
            elif kwargs[JOB_PRIORITY] not in PRIORITY_LIST:
                raise ValueError(
                    f"Job priority value must be in {PRIORITY_LIST}, but {kwargs[JOB_PRIORITY]} has been specified")
            elif self.session.auth != constant.ROMA_AUTH:
                kwargs["spec"] = {"schedule_policy": {JOB_PRIORITY: kwargs[JOB_PRIORITY]}}
        self._training_job.update_job_configs(job_id=job_id, body=kwargs)

    def delete_job(self, job_id=None):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        job_id = self._check_job_id(job_id)
        self._training_job.delete_job(job_id)
        count = 0
        while True:
            job_list_resp = self._training_job.get_job_list(self.session)
            job_list = [item["metadata"]["id"]
                        for item in job_list_resp['items']]
            if job_id in job_list:
                count = count + 1
                time.sleep(3)
            else:
                logging.info('Successfully delete the job %s', job_id)
                break
            if count == int(constant.JOB_DELETE_RETRY_TIMES):
                logging.info('Job %s is not deleted after 15s, please check it '
                             'from UI', job_id)
                break
        if job_id is None:
            self.job_id = None

    def control_job(self, job_id=None, **kwargs):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        job_id = self._check_job_id(job_id)
        if not kwargs:
            kwargs = dict()
        if ('action_type' not in kwargs or
                kwargs['action_type'] not in ["terminate"]):
            kwargs.update({"action_type": "terminate"})
        self._training_job.control_job(job_id=job_id, body=kwargs)
        count = 0
        while True:
            res = self._training_job.get_job_info(job_id)
            phase = res['status']['phase']
            if phase == "Terminated":
                logging.info('Successfully stop the job %s', job_id)
                break
            else:
                count = count + 1
                time.sleep(3)
            if count == int(constant.JOB_STOP_RETRY_TIMES):
                logging.info('Job %s is not stop after 15s, please check it '
                             'from UI', job_id)
                break
        return self._training_job.get_job_info(job_id)

    @classmethod
    def get_train_instance_types(cls, session):
        """
        Get Supported Train Instance Types.
        """
        train_session = cls(session=session)
        spec_list = train_session._training_job.get_spec_list(session)
        return train_session._training_job.get_train_instance_types(session, spec_list)

    @classmethod
    def get_spec_list(cls, session, flavor_type=None):
        """
        Get Supported Spec List.
        """
        return cls(session=session)._training_job.get_spec_list(session, flavor_type=flavor_type)

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, session, **kwargs):
        """
        Get Supported dataset.
        """
        return cls(session=session)._training_job.get_datasets(session, **kwargs)


class _TrainingJobApiAKSKImpl(TrainingJob):

    def __init__(self, session):
        """
        Initialize a ModelArts Training Job instance when using AKSK auth.
        """
        self.session = session

    @classmethod
    @auth_expired_handler
    def get_job_list(cls, session, **kwargs):
        """
        Get Training Job List.
        :param session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        request_url = "/v2/{project_id}/training-job-searches".format(
            project_id=session.project_id)
        variable_name = locals()['kwargs']
        body_encode = JSONEncoder().encode(variable_name)
        return auth_by_apig(
            session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_info(self, job_id):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return: For example: {"metadata": {...},
                               "kind": "job",
                               "spec": {"resource": {...}, "log_export_path": {...}},
                               "status": {...}
                               "algorithm": {"inputs": [...], "outputs": [...], "engine": {...}, "policies": {...}}
                              }
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        return auth_by_apig(
            self.session, HTTPS_GET, request_url)

    @auth_expired_handler
    def get_pool_flavor(self, pool_id):
        """
        Get Pool Flavor.
        :param pool_id: pool ID
        :return: Pool flavor name
        """
        request_url = "/v2/{}/pools/{}".format(self.session.project_id, pool_id)
        pool_info = auth_by_apig(self.session, HTTPS_GET, request_url)
        spec_resources = pool_info.get("spec", {}).get("resources", [])
        if not spec_resources:
            return ""
        return spec_resources[0].get("flavor", "")

    @auth_expired_handler
    def get_resource_flavor(self, flavor):
        """
        Get Resource Flavor.
        :param flavor: flavor name
        :return: Resource flavor info, for example:
            {
                "metadata": {...},
                "kind": "ResourceFlavor",
                "spec": {"cpu": "", "memory": "", "gpu": {...}},
                "status": {...}
            }
        """
        request_url = "/v1/{}/resourceflavors".format(self.session.project_id)
        resource_flavors = auth_by_apig(self.session, HTTPS_GET, request_url)
        for item in resource_flavors.get("items", []):
            if item.get("metadata", {}).get("name", "") == flavor:
                return item
        return {}

    @classmethod
    @auth_expired_handler
    def get_spec_list(cls, session, flavor_type=None):
        """
        Get Supported Spec List.
        :param session: session
        :return:
        """
        request_url = "/v2/{project_id}/training-job-flavors".format(
            project_id=session.project_id)
        query = {}
        if flavor_type is not None:
            query["flavor_type"] = flavor_type
        return auth_by_apig(
            session, HTTPS_GET, request_url, query=query)

    @classmethod
    @auth_expired_handler
    def get_train_instance_types(cls, session, spec_info):
        """
        Get Supported Train Instance Types.
        :param session: session
        :param spec_info:
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        spec_list = []
        specs = spec_info['flavors']
        for spec in specs:
            spec_list.append({"instance_type": spec.get('flavor_id'), "instance_desc": spec.get('flavor_name')})
        return spec_list

    @classmethod
    @auth_expired_handler
    def get_engine_list(cls, session):
        """
        Get Supported Engine List.
        :param session: session
        :return: For example: {"total": 9,
                               "items": [{"engine_id": "tensorflow-cp36-1.13.1-v2",
                                          "engine_name": "TensorFlow",
                                          "engine_version": "TF-1.13.1-python3.6-v2",
                                          "v1_compatible": false},
                                         ...
                                         {"engine_id": "kungfu-0.2.2-tf-1.13.1-python3.6",
                                          "engine_name": "KungFu",
                                          "engine_version": "KF-0.2.2-TF-1.13.1-python3.6",
                                          "v1_compatible": false}
                                         ]
                               }
        """
        request_url = "/v2/{project_id}/training-job-engines".format(
            project_id=session.project_id)
        return auth_by_apig(
            session, HTTPS_GET, request_url)

    @classmethod
    @auth_expired_handler
    def get_framework_list(cls, session, engine_list):
        """
        Get Supported Framework List.
        :param session: session
        :param engine_list:
        :return:For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                              {'framework_type': 'TensorFlow',
                                  'framework_version': 'TF-1.4.0-python3.6'},
                              ...
                              {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = engine_list['items']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    @auth_expired_handler
    def get_job_pool_list(cls, session):
        """
        Get pool List.
        """
        request_url = "/v2/{project_id}/pools".format(project_id=session.project_id)
        return auth_by_apig(session, HTTPS_GET, request_url)

    @classmethod
    @DeprecationWarning
    @auth_expired_handler
    def get_datasets(cls, session, **kwargs):
        """
        Get Supported datasets.
        """
        request_url = '/v1/' + session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(
            session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs".format(
            project_id=self.session.project_id)
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_experiment_by_name(self, experiment_name):
        """
        Get experiment by name.
        :param experiment_name: request param
        :return:
        """
        request_url = "/v2/{project_id}/training-experiments".format(
            project_id=self.session.project_id)
        searches = "name:{}".format(experiment_name)
        query_args = {
            "sort_by": "update_time",
            "searches": searches
        }
        return auth_by_apig(
            self.session, HTTPS_GET, request_url, query=query_args)

    @auth_expired_handler
    def get_job_log(self, job_id, task_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return: For example: {"start_line": "1618891350486840192",
                               "lines": 50,
                               "end_line": "1618891353078423056",
                               "content": "Step 300,Training Accuracy 0.9298\nFinished!"}
        """
        variable_name = locals()['kwargs']
        request_url = "/v2/{project_id}/training-jobs/{job_id}/tasks/{task_id}/logs/preview".format(
            project_id=self.session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        query = {}
        params = {'base_line', 'lines', 'order'}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_apig(
            self.session, HTTPS_GET, request_url, query=query)

    @auth_expired_handler
    def update_job_configs(self, job_id, body):
        """
        Update training job configs by job id.
        :param body: body for update training job configs
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        auth_by_apig(
            self.session, HTTPS_PUT, request_url, body=body_encode)

    @auth_expired_handler
    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        auth_by_apig(
            self.session, HTTPS_DELETE, request_url)

    @auth_expired_handler
    def control_job(self, job_id, body):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/actions".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_job_metrics(self, job_id, task_id):
        """
        Get Training Job metrics of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :return: For example: {"metrics": [{"metric": "cpuUsage", "value": [1, 4.121]},
                                           {"metric": "memUsage",
                                               "value": [0, 0.024]},
                                           {"metric": "gpuUtil",
                                               "value": [0, 1]},
                                           {"metric": "gpuMemUsage", "value": [0, 1]}]}
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/metrics/{task_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        return auth_by_apig(self.session, HTTPS_GET, request_url)

    @auth_expired_handler
    def get_job_event(self, job_id):
        """
        Get Training Job event of Specified job_id and task_id.
        :param job_id: job id
        :return: For example: {"total": 2,
                                ......
                               "events": [{'time': '2023-02-02T16:56:13+08:00',
                                            'level': 'Info',
                                            'message': '[worker-0] Installing Python dependencies.'
                                          },
                                         ......
                                         ]}
        """
        request_url = "/v2/{project_id}/training-jobs/{training_job_id}/events".format(
            project_id=self.session.project_id,
            training_job_id=job_id)
        return auth_by_apig(self.session, HTTPS_GET, request_url)


class _TrainingJobApiRomaImpl(TrainingJob):

    def __init__(self, session):
        """
        Initialize a ModelArts Training Job instance when using Roma auth.
        """
        self.session = session

    @classmethod
    def get_job_list(cls, session, **kwargs):
        """
        Get Training Job List.
        :param session: session
        :param kwargs: support 'workspace_id', 'limit', 'offset', 'sort_by', 'order', 'filters'
        :return:
        """
        request_url = "/v2/{project_id}/training-job-searches".format(
            project_id=session.project_id)
        variable_name = locals()['kwargs']
        body_encode = JSONEncoder().encode(variable_name)
        return auth_by_roma_estimatorv2_api(
            session, HTTPS_POST, request_url, body=body_encode)

    def get_job_info(self, job_id):
        """
        Get Training Job Info of Specified job_id.
        :param job_id: job id
        :return: For example: {"metadata": {...},
                               "kind": "job",
                               "spec": {"resource": {...}, "log_export_path": {...}},
                               "status": {...}
                               "algorithm": {"inputs": [...], "outputs": [...], "engine": {...}, "policies": {...}}
                              }
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id, job_id=str(job_id))
        return auth_by_roma_estimatorv2_api(
            self.session, HTTPS_GET, request_url)

    @auth_expired_handler
    def get_experiment_by_name(self, experiment_name):
        """
        Get experiment by name.
        :param experiment_name: request param
        :return:
        """

        raise NotImplementedError

    @auth_expired_handler
    def get_pool_flavor(self, pool_id):
        """
        Get Pool Flavor.
        :param pool_id: pool ID
        :return: Pool flavor name
        """
        raise NotImplementedError

    @auth_expired_handler
    def get_resource_flavor(self, flavor):
        """
        Get Resource Flavor.
        :param flavor: flavor name
        :return: Resource flavor info, for example:
            {
                "metadata": {...},
                "kind": "ResourceFlavor",
                "spec": {"cpu": "", "memory": "", "gpu": {...}},
                "status": {...}
            }
        """
        raise NotImplementedError

    @classmethod
    def get_spec_list(cls, session, flavor_type=None):
        """
        Get Supported Spec List.
        :param session: session
        :return:
        """
        request_url = "/v2/{project_id}/training-job-flavors".format(
            project_id=session.project_id)
        query = {}
        if flavor_type is not None:
            query["flavor_type"] = flavor_type
        return auth_by_roma_estimatorv2_api(
            session, HTTPS_GET, request_url, query=query)

    @classmethod
    def get_train_instance_types(cls, session, spec_info):
        """
        Get Supported Train Instance Types.
        :param session: session
        :param spec_info:
        :return: For example: ['modelarts.vm.cpu.2u', 'modelarts.vm.gpu.v100NV32']
        """
        spec_list = []
        specs = spec_info['flavors']
        for spec in specs:
            spec_list.append({"instance_type": spec.get('flavor_id'), "instance_desc": spec.get('flavor_name')})
        return spec_list

    @classmethod
    def get_engine_list(cls, session):
        """
        Get Supported Engine List.
        :param session: session
        :return: For example: {"total": 9,
                               "items": [{"engine_id": "tensorflow-cp36-1.13.1-v2",
                                          "engine_name": "TensorFlow",
                                          "engine_version": "TF-1.13.1-python3.6-v2",
                                          "v1_compatible": false},
                                         ...
                                         {"engine_id": "kungfu-0.2.2-tf-1.13.1-python3.6",
                                          "engine_name": "KungFu",
                                          "engine_version": "KF-0.2.2-TF-1.13.1-python3.6",
                                          "v1_compatible": false}
                                         ]
                               }
        """
        request_url = "/v2/{project_id}/training-job-engines".format(
            project_id=session.project_id)
        return auth_by_roma_estimatorv2_api(
            session, HTTPS_GET, request_url)

    @classmethod
    def get_framework_list(cls, session, engine_list):
        """
        Get Supported Framework List.
        :param session: session
        :param engine_list:
        :return: For example: [{'framework_type': 'TensorFlow', 'framework_version': 'TF-1.4.0-python2.7'},
                               {'framework_type': 'TensorFlow',
                                   'framework_version': 'TF-1.4.0-python3.6'},
                               ...
                               {'framework_type': 'PyTorch', 'framework_version': 'PyTorch-1.0.0-python3.6'}]
        """
        framework_list = []
        engines = engine_list['items']
        for engine in engines:
            framework = {'framework_type': engine['engine_name'],
                         'framework_version': engine['engine_version']}
            framework_list.append(framework)
        return framework_list

    @classmethod
    def get_job_pool_list(cls, session):
        """
        Get pool List.
        """
        request_url = "/v2/{project_id}/pools".format(project_id=session.project_id)
        return auth_by_roma_estimatorv2_api(session, HTTPS_GET, request_url)

    @classmethod
    @DeprecationWarning
    def get_datasets(cls, session, **kwargs):
        """
        Get Supported datasets.
        """
        request_url = '/v1/' + session.project_id + '/datasets'
        variable_name = locals()['kwargs']
        params = {'offset', 'limit', 'sortBy', 'order', 'search_content',
                  'data_url'}
        query = {}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_roma_estimatorv2_api(
            session, HTTPS_GET, request_url, query=query)

    def create_training_job(self, body):
        """
        Create Training Job.
        :param body: request body
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs".format(
            project_id=self.session.project_id)
        body_encode = JSONEncoder().encode(body)
        return auth_by_roma_estimatorv2_api(
            self.session, HTTPS_POST, request_url, body=body_encode)

    def get_job_log(self, job_id, task_id, **kwargs):
        """
        Get Training Job Log of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :param kwargs: support 'base_line', 'lines', 'order'
        :return: For example: {"start_line": "1618891350486840192",
                               "lines": 50,
                               "end_line": "1618891353078423056",
                               "content": "Step 300,Training Accuracy 0.9298\nFinished!"}
        """
        variable_name = locals()['kwargs']
        request_url = "/v2/{project_id}/training-jobs/{job_id}/logs/{task_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        query = {}
        params = {'base_line', 'lines', 'order'}
        for param in params:
            if param in variable_name and variable_name[param]:
                query[param] = str(variable_name[param])
        return auth_by_roma_estimatorv2_api(
            self.session, HTTPS_GET, request_url, query=query)

    def update_job_configs(self, job_id, body):
        """
        Update training job configs by job id.
        :param body: body for update training job configs
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        auth_by_roma_estimatorv2_api(
            self.session, HTTPS_PUT, request_url, body=body_encode)

    def delete_job(self, job_id):
        """
        Delete Specified Training Job.
        :param job_id: job id
        :return: None
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        auth_by_roma_estimatorv2_api(
            self.session, HTTPS_DELETE, request_url)

    def control_job(self, job_id, body):
        """
        Control Specified Training Job.
        :param job_id: job id
        :return:
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/actions".format(
            project_id=self.session.project_id,
            job_id=str(job_id))
        body_encode = JSONEncoder().encode(body)
        return auth_by_roma_estimatorv2_api(
            self.session, HTTPS_POST, request_url, body=body_encode)

    def get_job_metrics(self, job_id, task_id):
        """
        Get Training Job metrics of Specified job_id and task_id.
        :param job_id: job id
        :param task_id: task id
        :return: For example: {"metrics": [{"metric": "cpuUsage", "value": [1, 4.121]},
                                           {"metric": "memUsage",
                                               "value": [0, 0.024]},
                                           {"metric": "gpuUtil",
                                               "value": [0, 1]},
                                           {"metric": "gpuMemUsage", "value": [0, 1]}]}
        """
        request_url = "/v2/{project_id}/training-jobs/{job_id}/metrics/{task_id}".format(
            project_id=self.session.project_id,
            job_id=str(job_id),
            task_id=str(task_id))
        return auth_by_roma_estimatorv2_api(
            self.session, HTTPS_GET, request_url)

    def get_job_event(self, job_id):
        """
        Get Training Job event of Specified job_id and task_id.
        :param job_id: job id
        :return: For example: {"total": 2,
                                ......
                               "events": [{'time': '2023-02-02T16:56:13+08:00',
                                            'level': 'Info',
                                            'message': '[worker-0] Installing Python dependencies.'
                                          },
                                         ......
                                         ]}
        """
        request_url = "/v2/{project_id}/training-jobs/{training_job_id}/events".format(
            project_id=self.session.project_id,
            training_job_id=job_id)
        return auth_by_roma_estimatorv2_api(self.session, HTTPS_GET, request_url)


class _LocalTrainingJob(object):
    """
    Train locally in current conda environment.
    """

    MAX_INTPUT_AND_OUTPUT_LEN = 8
    ATTACHED_NOTEBOOK_LOG_DIR = "/train-worker1-log"
    BOOT_STRAP_CMD = [
        "/home/ma-user/training/ma-training-toolkit", "bootstrap"]
    LOCAL_DISTRIBUTED_TRAIN_WORKER_NUM = 2
    LOCAL_SINGLE_TRAIN_WORKER_NUM = 1
    DISTRIBUTED_TRAIN_UNSUPPORTED_AI_ENGINES = ["dengine"]
    DISTRIBUTED_TRAIN_ASCEND910_NUM = 8

    def __init__(self,
                 session,
                 train_instance_count=None,
                 training_files=None,
                 framework_type=None,
                 script_interpreter=None,
                 parameters=None,
                 log_url=None,
                 is_efs=False,
                 attached_mount_dir=None,
                 env_variables=None):
        """
        :param session: session with authentication information
        :param training_files: instance of class TrainingFiles
        :param train_instance_count: the number of worker nodes
        :param parameters: the parameters of training job, which will be passed to training boot file
        :param framework_type: engine specifications selected for training jobs
        :param script_interpreter: path of script interpreter, which is used to execute training boot file
        :param log_url: an obs path, where the training log files will be uploaded to
        :param is_efs: if notebook mount efs storage
        :param attached_mount_dir: the path of the attached notebook to mount the PV
        :param env_variables: a dictionary contains environment variables
        """
        self.session = session
        self.__train_instance_count = train_instance_count
        self.__training_files = training_files
        if framework_type is None:
            raise ValueError("Parameter framework type is needed.")
        self.__framework_type = framework_type
        self.__script_interpreter = script_interpreter
        if self.__script_interpreter is not None and not isinstance(self.__script_interpreter, str):
            raise TypeError("Parameter script_interpreter should be a string.")
        self.__parameters = parameters
        self.__training_data = None
        self.__validate_parameters_for_distribute_train()
        self.__structured_input = None
        self.__structured_output = None
        self.__log_url = log_url
        self.environment_variable = None
        self.attached_notebook_id = None
        self.__is_efs = is_efs
        self.__attached_mount_dir = attached_mount_dir
        self.__env_var_from_user = env_variables if env_variables else {}
        self.job_id = str(uuid.uuid4())
        self.__add_train_environment_variable()

    def __add_train_environment_variable(self):
        """
        Add content to environment variables
        """
        self.train_environment_variables = {
            "S3_USE_HTTPS": "1",  # need to use https when accessing OBS
            "S3_VERIFY_SSL": "0",  # SSL verification is not required when accessing OBS
            "MA_HOME": "/home/ma-user",
            "MA_TASKGROUP_NAME": "worker",
            "SSHD_PORT": "22",
            "MA_PYTHON_VERSION": str(sys.version_info.major),  # python version, 3 or 2
            "MA_CUSTOM_IMAGE": "1"  # 1 means the image of training job is not from training
        }
        # address of obs
        if self.session.auth == constant.ROMA_AUTH:
            obs_endpoint = query_var(cfg_var=f"OBS_{self.session.region_name}",
                                     env_var="S3_ENDPOINT", remove_prefix=True)
            self.train_environment_variables["S3_ENDPOINT"] = obs_endpoint
        else:
            self.train_environment_variables["S3_ENDPOINT"] = "https://" + self.session.obs_server
        # AI framework type like pytorch or tensorflow
        self.train_environment_variables["MA_ENGINE_TYPE"] = self.__framework_type.lower()
        # job id, used to generate name of log file
        self.train_environment_variables["MA_VJ_NAME"] = self.job_id
        # the path of script interpreter which will be used to execute training script
        self.train_environment_variables["MA_SCRIPT_INTERPRETER"] = self.__script_interpreter
        # file where aksk is saved
        self.train_environment_variables["CREDENTIAL_PROFILES_FILE"] = notebook_util.get_credential_file()
        self.train_environment_variables["MA_PIP_HOST"] = os.environ.get("PIP_TRUSTED_HOST")  # IP of pip source
        self.train_environment_variables["MA_PIP_URL"] = os.environ.get("PIP_INDEX_URL")  # url of pip source
        # for ascend
        if IS_ASCEND_910:
            self.train_environment_variables["LD_LIBRARY_PATH"] = os.environ.get("LD_LIBRARY_PATH")
            self.train_environment_variables["RANK_TABLE_FILE_V_1_0"] = constant.JOBSTART_HCCL_FILE_PATH

    def __validate_parameters_for_distribute_train(self):
        """
        Check parameters for distribute training locally.
        """
        if self.__train_instance_count <= _LocalTrainingJob.LOCAL_SINGLE_TRAIN_WORKER_NUM:
            return
        if notebook_util.is_kernel_gateway():
            raise Exception("Distributed training debug is not supported after switching flavor. "
                            "Please switch to the original flavor.")
        if self.__framework_type.lower() in _LocalTrainingJob.DISTRIBUTED_TRAIN_UNSUPPORTED_AI_ENGINES:
            raise Exception("{} does not support distributed training.".format(self.__framework_type))
        if IS_ASCEND_910 and \
                notebook_util.get_ascend910_device_num() < _LocalTrainingJob.DISTRIBUTED_TRAIN_ASCEND910_NUM:
            raise Exception("The number of ascend 910 must be 8 in every worker for distributed training.")
        if self.__train_instance_count > _LocalTrainingJob.LOCAL_DISTRIBUTED_TRAIN_WORKER_NUM:
            raise ValueError("The parameter train_instance_count of local distributed cannot exceed {}.".
                             format(_LocalTrainingJob.LOCAL_DISTRIBUTED_TRAIN_WORKER_NUM))

    def create_training_job(self, inputs, dataset_id, dataset_version_id, data_source, outputs):
        """
        Create a local training job.
        :param inputs: input data of training job
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param outputs: output data of training job
        """
        if len(inputs) + len(outputs) > _LocalTrainingJob.MAX_INTPUT_AND_OUTPUT_LEN:
            raise Exception("The sum of the length of input and output cannot exceed {}".
                            format(_LocalTrainingJob.MAX_INTPUT_AND_OUTPUT_LEN))
        self.__structured_input = prepare_params_input(inputs, dataset_id, dataset_version_id, data_source)
        self.__structured_output = prepare_params_output(outputs)
        self._update_run_parameters(inputs)
        notebook = Notebook(self.session)
        if self.__train_instance_count > 1:
            # generate environment variable for attached notebook
            self.attached_notebook_id = self.__create_attached_notebook(notebook)
        try:
            # when authoring create the attached notebook, sdk downloads data
            self.__update_environment_variable()
            if not self.__init_training():
                return
            if self.__train_instance_count > 1:
                if not notebook.wait_attached_notebook_run():
                    self.create_log_dir(notebook)
                    return
            self.__start_training()
            if self.__train_instance_count > 1:
                self.create_log_dir(notebook)
        except Exception as e:
            raise e
        finally:
            self.clear_temp_resource()

    def __init_training(self):
        """
        Download train data from obs.
        """
        command = []
        command.extend(_LocalTrainingJob.BOOT_STRAP_CMD)
        command.append("init")
        command.append("file:/" + self.__training_files.get_code_dir(local_run=True))
        logging.info("Initializing training task")
        process = subprocess.Popen(command,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT,
                                   env=self.__local_train_env_variable)
        while process.poll() is None:
            line = process.stdout.readline().strip().decode("utf8")
            log_info = LOG_FORMAT.format("INIT", line)
            logging.info(log_info)
        if process.returncode == 0:
            logging.info("Successfully initialized the training task.")
            return True
        else:
            logging.error("Failed to initialize training task.")
            return False

    def __start_training(self):
        """
        Start training job using two-party library. This command will run training job and upload output and log to obs.
        """
        # train script
        logging.info("Start running the training task.")
        train_process = subprocess.Popen(self.__create_train_cmd(),
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT,
                                         env=self.__local_train_env_variable)
        # sync output and script
        upload_cmd = []
        upload_cmd.extend(_LocalTrainingJob.BOOT_STRAP_CMD)
        upload_cmd.append("upload")
        upload_process = subprocess.Popen(upload_cmd,
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.STDOUT,
                                          env=self.__local_train_env_variable)
        if train_process is not None:
            while train_process.poll() is None:
                line = train_process.stdout.readline().strip().decode("utf8")
                log_info = LOG_FORMAT.format("TRAINING", line)
                logging.info(log_info)
            if train_process.returncode == 0:
                logging.info("The training task runs successfully.")
            else:
                logging.error("Failed to run the training task.")
        if upload_process is not None:
            while upload_process.poll() is None:
                line = upload_process.stdout.readline().strip().decode("utf8")
                log_info = LOG_FORMAT.format("OUTPUTS", line)
                logging.info(log_info)
            if upload_process.returncode == 0:
                logging.info("Successfully upload output and logs.")
            else:
                logging.error("Failed to upload output and logs.")

    def __create_train_cmd(self):
        """
        Create train command of local training.
        :return: list, train command
        """
        boot_file = self.__training_files.get_boot_file(local_run=True)
        train_cmd = []
        train_cmd.extend(_LocalTrainingJob.BOOT_STRAP_CMD)
        train_cmd.append("run")
        train_cmd.append("--")
        train_cmd.append(boot_file)
        if self.__parameters:
            for para in self.__parameters:
                cur_para = f"--{para['name']}"
                if "value" in para:
                    cur_para = f"{cur_para}={para['value']}"
                train_cmd.append(cur_para)
        return train_cmd

    def __update_ma_outputs(self, environment_variable):
        """
        Update ma outputs
        :param environment_variable: environment variables
        :return: ma outputs, a dictionary
        """
        outputs = []
        outputs.extend(self.__structured_output)
        if self.__log_url:
            log_data = {
                "name": "log_url",
                "local_dir": environment_variable["MA_LOG_DIR"],
                "mode": "upload_periodically",
                "period": constant.TRAIN_OUTPUT_DATA_SYNC_PERIOD,
                "system_generated": True,
                "remote": {
                    "obs": {
                        "obs_url": self.__log_url
                    }
                }
            }
            outputs.append(log_data)
        return {"outputs": outputs}

    def __gen_environment_variable(self):
        """
        Generate environment variables for distributed training request.
        :return: a dictionary containing environment variable
        """
        ma_inputs = {"inputs": self.__structured_input}
        notebook_name = notebook_util.get_notebook_name()
        environment_variable = {
            "VC_TASK_INDEX": "1",  # the sequence number of attached notebook
            "VC_WORKER_HOSTS": "{0}.{0}-distributed,{0}-worker1.{0}-distributed".format(notebook_name),
            "SCC_CONFIG_PATH": "/home/ma-user/notebook/scc/conf/scc.conf",  # this file is used to decrypt aksk
            "MA_JOB_DIR": os.path.join(self.__attached_mount_dir, "user-job-dir"),  # where the training files are saved
            "MA_LOG_DIR": os.path.join(self.__attached_mount_dir, "log"),  # where the log files are saved
            "MA_MOUNT_PATH": self.__attached_mount_dir,  # where the storage disk is mounted
            "MA_NUM_HOSTS": "2",  # two workers in all
            "MA_INPUTS": JSONEncoder().encode(ma_inputs),  # Describe the training input data
            "VC_WORKER_NUM": "2",
            "MA_USER_ID": str(notebook_util.get_ma_user_id())
        }
        environment_variable.update(self.train_environment_variables)
        ma_outputs = self.__update_ma_outputs(environment_variable)
        environment_variable["MA_OUTPUTS"] = JSONEncoder().encode(ma_outputs)
        if IS_ASCEND_910:
            environment_variable[MS_BUILD_PROCESS_NUM_ENV_NAME] = os.getenv(MS_BUILD_PROCESS_NUM_ENV_NAME)
        if self.__env_var_from_user:
            raise Exception("Parameter 'env_variables' is not supported for local distributed training job.")
        return environment_variable

    def __update_environment_variable(self):
        """
        Update environment variable for notebook.
        """
        self.__tmp_termination_log_dir = tempfile.mkdtemp()
        self.__tmp_mount_dir = tempfile.mkdtemp()
        environment_variable = os.environ
        environment_variable.update({
            "MA_LOG_DIR": os.path.join(self.__tmp_mount_dir, "log"),
            "MA_MOUNT_PATH": self.__tmp_mount_dir,
            "VC_TASK_INDEX": "0",
            "SCC_CONFIG_PATH": os.getenv("SCC_CONFIG_PATH", "/usr/local/seccrypto/kmc.conf"),
        })
        environment_variable.update(self.train_environment_variables)
        # The working directory of remote training job is '/home/ma-user/modelarts/user-job-dir', we simulate here
        self.__training_files.copy_code_dir()
        environment_variable["MA_JOB_DIR"] = self.__training_files.REMOTE_TRAINING_JOB_WORKING_DIR
        environment_variable["MA_INPUTS"] = JSONEncoder().encode({"inputs": self.__structured_input})
        ma_outputs = self.__update_ma_outputs(environment_variable)
        environment_variable["MA_OUTPUTS"] = JSONEncoder().encode(ma_outputs)
        if IS_ASCEND_910:
            environment_variable["MA_CURRENT_HOST_IP"] = os.getenv("MY_HOST_IP")
        notebook_name = notebook_util.get_notebook_name()
        if self.__train_instance_count == 1:
            environment_variable["MA_NUM_HOSTS"] = "1"
            environment_variable["VC_WORKER_NUM"] = "1"
            environment_variable["VC_WORKER_HOSTS"] = "{0}.{0}-distributed".format(notebook_name)
            if IS_ASCEND_910:
                environment_variable["RANK_TABLE_FILE_V_1_0"] = constant.NBSTART_HCCL_FILE_PATH
            # Only single node training job supports customize environment variables
            environment_variable.update(self.__env_var_from_user)
        else:
            environment_variable["MA_NUM_HOSTS"] = "2"
            environment_variable["VC_WORKER_NUM"] = "2"
            environment_variable["VC_WORKER_HOSTS"] = \
                "{0}.{0}-distributed,{0}-worker1.{0}-distributed".format(notebook_name)
        self.__local_train_env_variable = environment_variable

    def __gen_distributed_train_notebook_request_body(self, environment_variable):
        """
        Generate request body of creating creating an attached notebook.
        :param environment_variable environment variable of distributed training request
        """
        # only when training code dir is compressed, code_dir_name is not None
        if self.__training_files.code_dir_name:
            boot_file = os.path.join(environment_variable["MA_JOB_DIR"],
                                     self.__training_files.code_dir_name,
                                     self.__training_files.get_boot_file(local_run=False))
        else:
            # for efs
            boot_file = self.__training_files.get_boot_file(local_run=True)
        code_dir = self.__training_files.get_code_dir(local_run=False)
        return {
            "type": "DISTRIBUTED_TRAIN",
            "distributed_train_req": {
                "code_dir": code_dir,
                "boot_file": boot_file,
                "parameters": self.__parameters if self.__parameters else [],
                "env_variables": environment_variable
            }
        }

    def __create_attached_notebook(self, notebook):
        """
        Create an attached notebook.
        :param notebook: an instance of Notebook, which can be used to CRUD attached notebook
        """
        environment_variable = self.__gen_environment_variable()
        attached_notebooks = notebook.list_attached_notebook()
        # there should be one attached notebook for now
        if len(attached_notebooks["data"]):
            logging.info("Already exist an distributed training worker. Deleting it.")
        for dt_notebook in attached_notebooks["data"]:
            _LocalTrainingJob.__clear_attached_notebook(notebook, dt_notebook['id'])
        response = notebook.create_attached_notebook(
            self.__gen_distributed_train_notebook_request_body(environment_variable))
        return response["id"]

    def create_log_dir(self, notebook):
        """
        Create work dir for the attached notebook.
        :param notebook: an instance of Notebook
        """
        notebook.wait_attached_notebook_finish()
        if not os.path.exists(_LocalTrainingJob.ATTACHED_NOTEBOOK_LOG_DIR):
            raise Exception("No log dir {}, please create a new notebook".
                            format(_LocalTrainingJob.ATTACHED_NOTEBOOK_LOG_DIR))
        log_dir = os.path.join(_LocalTrainingJob.ATTACHED_NOTEBOOK_LOG_DIR, "dt-" + self.attached_notebook_id)
        os.mkdir(log_dir)
        logging.info("You can check the training job log of another distributed training worker in %s", log_dir)

    def clear_temp_resource(self):
        """
        Clear temporary resources.
        """
        self.__clear_tmp_dir()

    @classmethod
    def __clear_attached_notebook(cls, notebook, attached_notebook_id):
        """
        Clear attached notebook resources.
        :param notebook: an instance of Notebook
        :param attached_notebook_id: attached notebook id
        """
        log_dir = os.path.join(cls.ATTACHED_NOTEBOOK_LOG_DIR, attached_notebook_id)
        if os.path.exists(log_dir):
            os.remove(log_dir)
        notebook.delete_attached_notebook(attached_notebook_id)

    def __clear_tmp_dir(self):
        """
        Clear temporary dir.
        """
        if self.__tmp_termination_log_dir and os.path.exists(self.__tmp_termination_log_dir):
            shutil.rmtree(self.__tmp_termination_log_dir)
        if self.__tmp_mount_dir and os.path.exists(self.__tmp_mount_dir):
            shutil.rmtree(self.__tmp_mount_dir)
        self.__training_files.clear_tmp_code_dir()

    def _update_run_parameters(self, inputs):
        """
        If the training data is saved in notebook and obs_path is not provided, name of input data will be missed.
        Therefore, 'name=local_path' will be added to run parameters.
        """
        for input_data in inputs:
            if input_data.drop_this_input() and input_data.name and input_data.local_path:
                self.__parameters.append({"name": input_data.name, "value": input_data.local_path})
