# -*- coding: utf-8 -*
"""Classes to construct training environment."""
import json
import os
import threading
import uuid

from . import const
from .conda_env import CondaDependencies, get_package_name, get_package_version
from .docker_env import DockerEnv
from modelarts import constant


class Environment(object):
    """Conda and docker environment implementation."""

    def __init__(self, name, **kwargs):
        """
        Initialize an environment, including conda or docker environment.
        :param name: environment.
        :param kwargs: Create environment body params
        """
        super(Environment, self).__init__()
        self.name = name
        self.version = None
        self.conda = CondaDependencies()
        self.docker = DockerEnv()
        self.environment_variables = dict()
        self.author = None

    def __str__(self):
        return "name: {}\nversion:{}".format(self.name, self.version)

    def __repr__(self):
        return json.dumps(Environment.serialize_to_dict(self), indent=4)

    def clone(self, new_name):
        """
        Clone a environment
        :param new_name: name of cloned environment
        :return cloned environment
        """
        if not new_name:
            raise Exception("New environment name is required")
        env = Environment.deserialize_from_dict(
            Environment.serialize_to_dict(self))
        env.name = new_name
        env.version = None
        env.author = None
        return env

    def register(self, replace=True):
        env_client = get_env_client()
        if env_client and hasattr(env_client, "register"):
            return env_client.register(self, replace)
        else:
            raise Exception(
                "Failed to register for invalid environment client")

    @staticmethod
    def get(name, version=None):
        env_client = get_env_client()
        if env_client and hasattr(env_client, "get"):
            return env_client.get(name, version)
        else:
            raise Exception(
                "Failed to get for invalid environment client")

    @staticmethod
    def list():
        env_client = get_env_client()
        if env_client and hasattr(env_client, "list"):
            return env_client.list()
        else:
            raise Exception(
                "Failed to list for invalid environment client")

    @staticmethod
    def delete(name, version=None):
        env_client = get_env_client()
        if env_client and hasattr(env_client, "delete"):
            return env_client.delete(name, version)
        else:
            raise Exception(
                "Failed to delete for invalid environment client")

    @staticmethod
    def from_pip_requirements(name, file_path):
        """
        Create an environment object created from a pip requirements file.
        """
        env = Environment(name=name)
        with open(file_path) as f:
            for line in f.readlines():
                env.conda.add_pip_package(line.strip())
        return env

    @staticmethod
    def from_conda_specification(name, file_path):
        """Create environment object from an environment specification YAML file.

        # sharing-an-environment
        See https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html
        """
        cd = CondaDependencies(file_path)
        env = Environment(name=name)
        env.conda = cd
        return env

    @staticmethod
    def from_existing_conda_environment(name, conda_environment_name):
        """
        Create a conda environment from the yaml file of the existing
        conda environment with same name
        """
        cmd_str = "conda env list|awk '{print $1}'"
        with os.popen(cmd_str) as all_conda_envs:
            for conda_env in all_conda_envs.readlines():
                if conda_environment_name == conda_env.strip():
                    break
            else:
                raise Exception("No conda environment named {} found".format(
                    conda_environment_name))
        tmpfile = "{}.yaml".format(uuid.uuid4())
        cmd = [
            "conda", "env", "export", "--no-builds", "-n",
            conda_environment_name, ">", tmpfile
        ]
        os.system(" ".join(cmd))
        env = Environment.from_conda_specification(name, tmpfile)
        if os.path.isfile(tmpfile):
            os.remove(tmpfile)
        return env

    @staticmethod
    def add_pip_wheel(file_path, overwrite=False):
        return

    @staticmethod
    def serialize_to_dict(env):
        """after environment serialized, it looks dict-like as below:
        {
          "name": "env-name",
          "version": "v1",
          "author": "user1",
          "environment-variables": {
              "env-var1": "value1",
              "env-var2": "value2"
          }
          "conda": {
             "channels": [
                 "conda-forge"
             ],
             "conda-packages": [
                 "python==3.6",
                 "tensorflow==2.1"
             ],
             "pip-packages": [
                 "Pillow==7.0.0"
             ]
          }
          "docker": {
              "image_name": "{swr_endpoint}/env/tensorflow:2.1-env",
              "Dockerfile": "FROM ubuntu:18.04\n ..."
          }
        }
        """
        return {
            "conda": CondaDependencies.serialize_to_dict(env.conda),
            "docker": DockerEnv.serialize_to_dict(env.docker),
            "environment-variables": env.environment_variables,
            "name": env.name,
            "version": env.version or "v1",
            "author": env.author or ""
        }

    @staticmethod
    def deserialize_from_dict(serialized_dict):
        """
        Create an environment form a dictionary which is serialized from an environment
        :param serialized_dict: a serialized dictionary
        :return environment
        """
        env = Environment(serialized_dict.get("name", ""))
        env.author = serialized_dict.get("author") or None
        env.environment_variables = serialized_dict.get(
            "environment-variables", {})
        env.conda = CondaDependencies.deserialize_from_dict(
            serialized_dict.get("conda", {}))
        env.docker = DockerEnv.deserialize_from_dict(
            serialized_dict.get("docker", {}))
        return env

    @staticmethod
    def save(env, path, overwrite=False):
        """
        Serializing the environment to a dictionary and save it in a file
        :param env: a conda or docker environment
        :param path: file path
        :param overwrite: if overwrite this file
        """
        if not os.path.isdir(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.isfile(path) and not overwrite:
            raise Exception(
                "{} exists and you can try to overwrite it by set overwrite=true".format(path))
        with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                               constant.FILE_PERMISSION), "w") as f:
            json.dump(Environment.serialize_to_dict(env), f, indent=4)

    @staticmethod
    def load(path):
        """
        Load a file and generate a environment from it.
        :param path: file path
        :return an environment
        """
        with open(path, "r") as env_str:
            env_dict = json.load(env_str)
        return Environment.deserialize_from_dict(env_dict)

    @staticmethod
    def diff(registered_env, env, package_from="docker_env"):
        """
        Check the diff list of python packages from registered_env as required by env
        :param registered_env: registered environment
        :param env: an environment
        :param package_from: packages from what environment
        :return different packages
        """
        diffs = []

        # issue: version information of all python packages in registered_env must be
        # recorded as the specific version installed in conda env or docker image. otherwise
        # version maybe mismatch in some case
        registered_env_packages = []
        if package_from == "conda_env":
            registered_env_packages.extend(registered_env.conda.conda_packages)
            registered_env_packages.extend(registered_env.conda.pip_packages)
        elif package_from == "docker_env":
            registered_env_packages.extend(
                registered_env.docker.packages.get("conda", []))
            registered_env_packages.extend(
                registered_env.docker.packages.get("pip", []))
        packages = {}
        for p in registered_env_packages:
            packages[get_package_name(p)] = get_package_version(p)

        env_packages = []
        env_packages.extend(env.conda.conda_packages)
        env_packages.extend(env.conda.pip_packages)

        def _match_version(spec, version):
            from semantic_version import Spec, Version
            try:
                return Spec(spec).match(Version.coerce(version))
            except Exception:
                # handle the invalid version schema case
                return False

        for p in env_packages:
            p_name = get_package_name(p)
            p_version_requirement = p[len(p_name):]
            if p_name in packages and _match_version(p_version_requirement, packages[p_name]):
                continue
            else:
                diffs.append(p_name)
        return diffs


class EnvClientBase(object):
    name = "base"

    def register(self, env, replace=False):
        raise NotImplementedError()

    def get(self, name, version=None):
        raise NotImplementedError()

    def list(self):
        raise NotImplementedError()

    def delete(self, name, version=None):
        raise NotImplementedError()


class LocalEnvClient(EnvClientBase):
    _lock = threading.Lock()
    name = "local"

    def __new__(cls, *args, **kwargs):
        with LocalEnvClient._lock:
            if not hasattr(cls, "_instance"):
                LocalEnvClient._instance = super(
                    LocalEnvClient, cls).__new__(cls)
        return LocalEnvClient._instance

    def __init__(self, storage_directory=None, *args, **kwargs):
        if storage_directory:
            self._storage_directory = storage_directory
        else:
            self._storage_directory = (os.environ.get(
                const.LOCAL_ENV_STORAGE_DIRECTORY_ENV_NAME) or
                const.DEFAULT_LOCAL_ENV_STORAGE_DIRECTORY)
        if not os.path.exists(self._storage_directory):
            os.mkdir(self._storage_directory)
        if not os.path.isdir(self._storage_directory):
            raise Exception(
                "Local environment storage path '{}' is not a valid directory".format(
                    self._storage_directory))

    def list(self):
        """
        List all the environment images from storage directory
        :return all environments
        """
        all_env = []
        env_files = os.listdir(self._storage_directory)

        # Each released image of ModelArts train and inference system will has an
        # Environment counterpart released in SDK, which can be reused here
        ma_storage_directory = (os.environ.get(
            const.LOCAL_MA_ENV_STORAGE_DIRECTORY_ENV_NAME) or
            const.DEFAULT_LOCAL_MA_ENV_STORAGE_DIRECTORY)
        if os.path.isdir(ma_storage_directory):
            env_files.extend(os.listdir(ma_storage_directory))

        for env_file in env_files:
            path = os.path.join(self._storage_directory, env_file)
            if not os.path.isfile(path):
                continue
            try:
                env = Environment.load(path)
                all_env.append(env)
            except Exception:
                print("Warning: '{}' is not a valid Environment file".format(path))
                continue
        return all_env

    def get(self, name, version=None):
        """
        Get an existing environment filter by name and version from a list
        :return an existing environment
        """
        all_env = self.list()
        for env in all_env:
            if env.name != name:
                continue
            if not version or version == env.version:
                return env
        return None

    def delete(self, name, version=None):
        """
        Only custom Environment can be deleted; prohibit deleting ModelArts official
        released Environments
        :param name: environment name
        :param version: environment version
        :return if delete specific environment
        """
        env_files = os.listdir(self._storage_directory)
        deleted = False
        for env_file in env_files:
            path = os.path.join(self._storage_directory, env_file)
            if not os.path.isfile(path):
                continue
            try:
                env = Environment.load(path)
                if env.name != name:
                    continue
                if not version:
                    os.remove(path)
                    deleted = True
                    continue
                if version == env.name:
                    os.remove(path)
                    return True
            except Exception:
                print("Warning: '{}' is not a valid Environment file".format(path))
                continue
        return deleted

    def register(self, env, replace=False):
        """
        Register a environment
        :param env: environment
        :param replace: if overwrite the registered file
        """
        env_path = os.path.join(self._storage_directory,
                                "{}.json".format(env.name))
        Environment.save(env, env_path, replace)
        return True


ENV_CLIENT_MAP = {
    LocalEnvClient.name: LocalEnvClient,
}

DEFALT_ENV_CLIENT = LocalEnvClient.name


def get_env_client(name=None):
    # TODO: support env client configuration based on configuration file
    client_name = name or DEFALT_ENV_CLIENT
    client_class = ENV_CLIENT_MAP.get(client_name)

    if client_class:
        return client_class()
    else:
        return None
