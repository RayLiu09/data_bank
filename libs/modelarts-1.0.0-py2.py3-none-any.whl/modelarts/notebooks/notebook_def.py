from enum import Enum


class Notebook(object):

    def __init__(self, flavor, name, volume, description=None, pool_id=None, workspace_id=None, lease=None,
                 endpoints=None, image_id=None, image_url=None, data_volumes=None, environ_vars=None,
                 node_selector=None):
        self.flavor = flavor
        self.name = name
        self.volume = volume
        self.description = description
        self.pool_id = pool_id
        self.workspace_id = workspace_id
        self.lease = lease
        if endpoints and not isinstance(endpoints, list):
            raise ValueError("The parameter 'endpoints' should be list.")
        self.endpoints = endpoints
        if not image_id and not image_url:
            raise ValueError("The parameter 'image_id' and 'image_url' cannot be null at the same time.")
        self.image_id = image_id
        self.image_url = image_url
        if data_volumes and not isinstance(data_volumes, list):
            raise ValueError("The parameter 'data_volumes' should be type of list.")
        self.data_volumes = data_volumes
        if environ_vars:
            if not isinstance(environ_vars, list):
                raise ValueError("The parameter 'environ_vars' should be type of list.")
            for env_var in environ_vars:
                if not isinstance(env_var, EnvironVar):
                    raise ValueError("Every element of parameter 'environ_vars' should be type of 'EnvironVar'.")
        self.env_variables = environ_vars
        if node_selector and not isinstance(node_selector, NodeSelector):
            raise ValueError("The parameter 'node_selector' should be type of 'NodeSelector'.")
        self.node_selector = node_selector


class Volume(object):

    def __init__(self, category, ownership, capacity=None, uri=None, volume_id=None, dew_secret_name=None):
        self.category = category
        self.ownership = ownership
        self.capacity = capacity
        self.uri = uri
        self.volume_id = volume_id
        self.dew_secret_name = dew_secret_name


class DataVolume(Volume):

    def __init__(self, category, mount_path, uri, volume_id=None, read_only=False, capacity=None, dew_secret_name=None,
                 ownership="DEDICATED"):
        super().__init__(category, ownership, capacity, uri, volume_id, dew_secret_name)
        self.mount_path = mount_path
        self.read_only = read_only


class Lease(object):

    def __init__(self, duration, lease_type=None):
        self.duration = duration
        self.type = lease_type
        if not lease_type:
            self.type = "TIMING"


class Endpoint(object):

    def __init__(self, key_pair_names: list, service=None, allowed_access_ips=None):
        if not key_pair_names:
            raise ValueError("The parameter 'key_pair_names' should not be empty.")
        self.key_pair_names = key_pair_names
        if service:
            if service.upper() not in NotebookService.list():
                raise ValueError(f"The parameter 'service' should be one of {NotebookService.list()}")
            self.service = service
        else:
            self.service = NotebookService.NOTEBOOK_SERVICE.value
        if allowed_access_ips and not isinstance(allowed_access_ips, list):
            raise ValueError(f"The parameter 'allowed_access_ips' should be of type list.")
        self.allowed_access_ips = allowed_access_ips


class EnvironVar(object):

    def __init__(self, key: str, value: str):
        self.key = key
        self.value = value


class NodeSelector(object):
    """
    Node selector of notebook create request.
    This class controls the scheduling of instances to specific nodes, example:
    node_selector = NodeSelector({"test": "test"})
    notebook = Notebook(flavor="modelarts.vm.cpu.2u",
                    description="test",
                    name="notebook-demo",
                    lease=Lease(duration=3600000),
                    volume=Volume(category="EVS", capacity=5, ownership="MANAGED"),
                    image_id="e1a07296-22a8-4f05-8bc8-e936c8e54099",
                    node_selector=node_selector)
    """

    def __init__(self, items):
        """
        Initialize NodeSelector, example:
        NodeSelector({"demo.com/test_key1": "test_value1", "test_key2": "test_value2"})
        :param items: node labels
        """
        if not isinstance(items, dict):
            raise ValueError("The init parameter should be type of dict.")
        self.items = items

    def add(self, key: str, value: str):
        self.items[key] = value

    def remove(self, key):
        if key in self.items.keys():
            del self.items[key]

    def get(self):
        return self.items


class NotebookService(Enum):
    SSH_SERVICE = "SSH"
    NOTEBOOK_SERVICE = "NOTEBOOK"

    @staticmethod
    def list():
        return [x.value for x in NotebookService]
