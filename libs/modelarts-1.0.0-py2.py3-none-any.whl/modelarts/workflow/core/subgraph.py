from typing import Sequence

from modelarts.workflow.core.entities import Entity, TransformType

from modelarts.workflow.core.steps import Step
from modelarts.workflow.util.validators import check_name


class Subgraph(Entity):
    """
    """

    def __init__(self,
                 name: str,
                 steps: Sequence[Step] = None):
        """
        Args:
            name: subgraph name
            steps: subgraph steps list
        """
        Subgraph._check_init_info(name=name, steps=steps)
        self.name = name
        self.steps = steps

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "steps": [step.name for step in self.steps],
        }
        return result

    @staticmethod
    def _check_init_info(name, steps):
        check_name(name)
        if steps is None:
            raise ValueError('subgraph steps is empty or none')
