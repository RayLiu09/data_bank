import os
import socket

import psutil


def get_env_var_setting(env_var_name):
    '''
    Returns specified environment variable value. If it does not exist,
    returns a default value

    :param env_var_name: environment variable name
    :param default_value: default value to be returned if a variable does not exist
    :return: environment variable value
    '''
    try:
        env_var_value = os.environ[env_var_name]
    except Exception:
        raise Exception("no such properties config %s" % env_var_name)

    return env_var_value


def get_hostname():
    return socket.gethostname()


def get_listen_ports_from_pid(pid):
    connections = psutil.Process(pid).connections(kind='tcp')

    if len(connections) == 0:
        raise Exception('%s has no listen port', pid)

    return list(map(lambda x: x.laddr.port, connections))


def get_all_listen_ports_from_pid(pid):
    ports = []
    parent = psutil.Process(pid)
    for child in parent.children(recursive=True):
        connections = psutil.Process(child.pid).connections(kind='tcp')
        if len(connections) > 0:
            ports.extend(list(map(lambda x: x.laddr.port, connections)))

    if len(ports) == 0:
        raise Exception('%s has no listen port', pid)

    return ports


def check_port_is_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(2)
        result = sock.connect_ex(('127.0.0.1', port))
        if result != 0:
            raise Exception('port %s is not open' % port)
