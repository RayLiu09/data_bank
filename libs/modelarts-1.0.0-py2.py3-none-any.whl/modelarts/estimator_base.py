import logging
import os
import shlex
import subprocess
import time
from abc import ABCMeta
from datetime import datetime, timedelta

from . import constant
from .model import Model

logging.getLogger().setLevel(logging.INFO)
LOCAL_TRAIN_DIR = os.path.expanduser(constant.LOCAL_TRAIN_DIR)


class EstimatorBase(metaclass=ABCMeta):

    def __init__(self,
                 session,
                 train_instance_count=None,
                 train_instance_type=None,
                 base_job_name=None,
                 parameters=None,
                 framework_type=None,
                 framework_version=None,
                 log_url=None,
                 user_image_url=None,
                 user_command=None,
                 job_description=None,
                 job_id=None,
                 job_type=None,
                 workspace_id=None):
        """
        Initialize a ModelArts Estimator Object.
        """
        self.session = session
        self.train_instance_count = train_instance_count
        self.train_instance_type = train_instance_type
        self.base_job_name = base_job_name
        self._current_job_name = None
        self.parameters = parameters or []
        self.framework_type = framework_type
        self.framework_version = framework_version
        self.log_url = log_url
        self.user_image_url = user_image_url
        self.user_command = user_command
        self.job_description = job_description if job_description else ""
        self.job_id = job_id
        self.workspace_id = workspace_id
        self.job_type = job_type if job_type else "train"
        self.auth = session.auth
        if not self.auth == constant.ROMA_AUTH:
            self.access_key = session.access_key
            self.secret_key = session.secret_key
            self.host = session.host
            self.project_id = session.project_id
            self.inputs = None
            self.dataset_id = None
            self.dataset_version_id = None
            self.data_source = None
            self.model = None

    def _gen_job_name(self, job_name=None):
        """
        Get job name for training job.
        :param job_name: job name for training job
        :return: job name
        """
        if job_name:
            self._current_job_name = job_name
        else:
            if self.base_job_name:
                base_name = self.base_job_name
            else:
                beijing_date = (datetime.now() + timedelta(hours=8)).strftime(
                    constant.ISO_TIME_FORMAT)
                base_name = 'job-' + beijing_date

            self._current_job_name = base_name
        return self._current_job_name

    def submit_task(self,
                    inputs=None,
                    dataset_id=None,
                    dataset_version_id=None,
                    data_source=None,
                    priority=None):
        """
        Submit a new training job from the estimator.
        :param inputs: dataset from obs
        :param dataset_id: dataset_id of ModelArts
        :param dataset_version_id: dataset_version_id of ModelArts
        :param data_source: data_source of ModelArts
        :param priority: priority of train job
        :return: training job object
        """
        if self.env_target is None:
            job_train_resp = self.start_new(inputs,
                                            dataset_id,
                                            dataset_version_id,
                                            data_source,
                                            priority)
            return job_train_resp
        return self.env_target.submit(self._current_job_name)

    def get_waiting_job_state(self, job_train_resp, wait):
        """
        For roma, the job maybe wait for a while and then submit to hc
        :param job_train_resp: response of submitting training job
        :param wait: whether wait the job completed or not
        :return response of get waiting job info
        """
        count_total = 0
        if self.session.auth == constant.ROMA_AUTH and wait:
            version_uid = job_train_resp['version_uid']
            while True:
                if 'status' in job_train_resp and job_train_resp['status'] == constant.ROMA_JOB_WAITING_STATUS_CODE:
                    if count_total == 0:
                        print(constant.ROMA_JOB_WAITING_STATUS)
                    count_total += 1
                    if count_total > int(constant.MAXIMUM_RETRY_TIMES):
                        raise Exception("Reach the maximum waiting times, please check training job in roma.")
                    time.sleep(constant.CHECK_ROMA_WAITING_JOB_STATUS_INTERVAL)
                    job_train_resp = self.trainingJob.get_waiting_job_info(version_uid)
                    job_train_resp = job_train_resp['jobVersionInfo']
                else:
                    break
        return job_train_resp

    def save_training_output(self, inputs=None, dataset_id=None, dataset_version_id=None,
                             data_source=None, wait=False, job_train_resp=None):
        if wait:
            self.print_job_middle_state(job_train_resp)
        self.trainingJob.train_url = self.output_path
        self.inputs = inputs
        self.dataset_id = dataset_id
        self.dataset_version_id = dataset_version_id
        self.data_source = data_source
        self.trainingJob.inputs = self.inputs
        self.trainingJob.dataset_id = self.dataset_id
        self.trainingJob.dataset_version_id = self.dataset_version_id
        self.trainingJob.data_source = self.data_source

    def local_train(self, inputs):
        args = ''
        app_url = self.code_dir
        boot_file_url = self.boot_file
        if not app_url:
            raise ValueError('Parameter code_dir is needed')
        if not boot_file_url:
            raise ValueError('Parameter boot_file is needed')
        train_url = self.output_path
        hyperparameters = self.parameters
        for index, parameters in enumerate(hyperparameters):
            arg = f"--{parameters['label']}={parameters['value']}"
            if index > 0:
                args += " "
            args += arg

        os.makedirs(LOCAL_TRAIN_DIR, exist_ok=True)
        self.session.download_data(app_url, LOCAL_TRAIN_DIR)
        self.session.download_data(inputs, LOCAL_TRAIN_DIR)
        local_inputs_path = LOCAL_TRAIN_DIR + '/' + \
                            inputs.rstrip('/').split('/')[-1]
        local_boot_file_path = LOCAL_TRAIN_DIR + '/' + \
                               app_url.rstrip('/').split('/')[-1] + '/' + \
                               boot_file_url.split(app_url)[-1]

        data_url = " --data_url=%s/" % local_inputs_path
        args += data_url

        train_url = " --train_url=s3://%s" % train_url.lstrip('/')
        args += train_url

        logging.info("Args is %s", args)

        command = 'python %s %s' % (local_boot_file_path, args)
        cmd = shlex.split(command)
        p = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
        log_file = LOCAL_TRAIN_DIR + '/' + self._current_job_name + '_stdout.log'
        while p.poll() is None:
            line = p.stdout.readline()
            line = line.strip()
            if line:
                print(format(line))
                with os.fdopen(os.open(log_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                       constant.FILE_PERMISSION), "w") as f:
                    f.write(format(line))
        if p.returncode == 0:
            logging.info('Local training task succeed')
        else:
            logging.info('Local training task failed')
        if self.log_url:
            self.session.upload_data(self.log_url, log_file)
        os.remove(log_file)

    @staticmethod
    def process_job_completed(response, duration, job_name):
        logging.info(response)
        sec = duration / 1000
        minu, seconds = divmod(sec, 60)
        hours, minutes = divmod(minu, 60)
        duration_format = "%02d:%02d:%02d" % (hours, minutes, seconds)
        logging.info("Job [ %s ] duration is %s", job_name, duration_format)

    @staticmethod
    def process_job_uncompleted(response, count):
        if count == 0:
            logging.info(response)
        time.sleep(constant.QUERY_TRAIN_STATUS_PERIOD)
        return count + 1

    def delete_job(self, job_id=None):
        job_id = job_id if job_id else self.job_id
        return self.trainingJob.delete_job(job_id)

    def create_model(self, **kwargs):
        """
        Creating model interface.
        :param kwargs: create model body params
        :return: model instance
        """
        self.model = Model(self.session, **kwargs)
        return self.model

    def deploy_predictor(self, **kwargs):
        """
        Deploying model service interface.
        :param kwargs: deploying predictor body params
        :return: predictor
        """
        if self.model is None:
            model_id = kwargs['configs'][0]['model_id']
            self.model = Model(self.session, model_id=model_id)

        deploy_model_resp = self.model.deploy_predictor(**kwargs)
        return deploy_model_resp

    def deploy_transformer(self, **kwargs):
        """
        Deploying model service interface.
        :param kwargs: deploying transformer body params
        :return: transformer
        """
        if self.model is None:
            model_id = kwargs['configs'][0]['model_id']
            self.model = Model(self.session, model_id=model_id)

        deploy_model_resp = self.model.deploy_transformer(**kwargs)
        return deploy_model_resp

    def delete(self, job_id, model_id, service_id):
        self.delete_job(job_id)
        if self.model is None:
            self.model = Model(self.session, model_id=model_id)
        self.model.delete_model_endpoint(model_id=model_id,
                                         service_id=service_id)


class TrainingJobBase(object):

    def __init__(self, modelarts_session, job_id=None, train_url=None, inputs=None, dataset_id=None,
                 dataset_version_id=None, data_source=None):
        """
        Initialize a ModelArts Training Job instance.
        """
        self.modelarts_session = modelarts_session
        self.job_id = job_id
        self.train_url = train_url
        self.inputs = inputs
        self.dataset_id = dataset_id
        self.dataset_version_id = dataset_version_id
        self.data_source = data_source
        self._training_job = None

    def _check_job_id(self, job_id):
        if not job_id and not self.job_id:
            raise ValueError('Parameter job_id is needed')
        return job_id if job_id else self.job_id

    def create_training_job(self, body):
        """
        Create Training Job.
        """
        return self._training_job.create_training_job(body)
