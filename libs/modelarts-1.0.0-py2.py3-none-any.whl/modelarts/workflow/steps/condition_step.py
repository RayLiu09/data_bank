import uuid
import logging

from modelarts.workflow.core.steps import Step, StepTypeEnum, StepState
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.steps.condition import Condition


class _ConditionInput(CommonInput):
    def __init__(self, data):
        """
        The input of ConditionStep
        Args:
            data (Condition): Condition instance object
        """
        super(_ConditionInput, self).__init__(name='condition-input-{}'.format(uuid.uuid4().hex), data=data)


class ConditionStep(Step):

    def __init__(
            self,
            name,
            conditions,
            if_then_steps=None,
            else_then_steps=None,
            title=None,
            description=None,
            depend_steps=None
    ):
        """
        Conditional step for Workflow to support conditional branching in the execution of steps
        Args:
            name (str): name of step
            conditions (Union(Condition, List[Condition])): A or a list of Condition
            if_then_steps (Union(str, List[str])): A set of steps that must be run when the conditions result is true
            else_then_steps (Union(str, List[str])): A set of steps that must be run when the conditions result is false
            title (str): title info of ConditionStep
            description (str): Description info of ConditionStep
            depend_steps (Union(Step, List[Step])): A or a list of step which this `ConditionStep` depends on

        Returns:

        """
        if not isinstance(conditions, list):
            conditions = [conditions]
        ConditionStep._check_conditions_type(conditions)
        super(ConditionStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.CONDITION,
            inputs=[_ConditionInput(data=condition) for condition in conditions],
            title=title,
            description=description,
            depend_steps=depend_steps
        )
        self.conditions = conditions
        if if_then_steps and not isinstance(if_then_steps, list):
            if_then_steps = [if_then_steps]
        if else_then_steps and not isinstance(else_then_steps, list):
            else_then_steps = [else_then_steps]
        self.if_then_steps = if_then_steps
        self.else_then_steps = else_then_steps
        self._result = None

    @staticmethod
    def _check_conditions_type(conditions):
        for condition in conditions:
            if not isinstance(condition, Condition):
                raise ValueError('The data type from conditions is must be Condition. '
                                 'But provided: {}'.format(type(condition)))

    def to_definition_json(self) -> TransformType:
        """
        Serialize ConditionStep information into json format
        Returns (dict): serialized result

        """
        depend_steps_json = self.depend_step_names
        json_result = {
            "name": self.name,
            "type": self.step_type.value,
            "title": self.title,
            "conditions": [condition.ref() for condition in self.conditions],
            "depend_steps": depend_steps_json,
        }
        if self.if_then_steps:
            json_result["if_then_steps"] = self.if_then_steps
        if self.else_then_steps:
            json_result["else_then_steps"] = self.else_then_steps

        return json_result

    def build_client(self, session):
        """
        Build a client for obs service calls
        Args:
            session (Session): building interactions with cloud service.

        Returns:

        """
        super(ConditionStep, self).build_client(session)

    def create_instance(self) -> (bool, str):
        if self.obs_client is None:
            raise ValueError("The client of ConditionStep {} is None, "
                             "please use the <build_client> method to initialize the client".format(self.name))
        result = True
        for condition_input in self.inputs.values():
            condition = condition_input.data
            result = result and condition.is_satisfied(client=self.obs_client)
        logging.debug("The condition calculation result of ConditionStep %s is %s", self.name, result)
        self._result = result
        return True, uuid.uuid4().hex

    def update_instance_state(self):
        self.set_state(StepState.Completed)

    def stop_instance(self) -> (bool, str):
        return True, "success"

    def get_skip_steps(self):
        """
        Get the list of steps that need to be skipped
        Returns (List[str]): The list of step names

        """
        return self.else_then_steps if self._result else self.if_then_steps

    @property
    def result(self):
        """
        Get the result of all condition comparisons in ConditionStep
        Returns (bool): result of all condition comparisons

        """
        return self._result
