import attr
import logging
from enum import Enum

from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.core.steps import Step, StepTypeEnum, StepState, AbstractOutput
from modelarts.workflow.core.data import AbstractOutputConfig
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.data.dataset import Dataset, DatasetPlaceholder, DatasetConsumption, DatasetClient
from modelarts.workflow.core.serialize import serialize
from modelarts.workflow.core.serialize import prepare_for_properties
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.data.obs import OBSPath, OBSConsumption, OBSPlaceholder
from modelarts.workflow.data.label_task import LabelTask, LabelTaskPlaceholder, LabelTaskConsumption, LabelTaskTypeEnum
from modelarts.workflow.data.data_selector import DataConsumptionSelector


IMPORT_TASK_STATE_MAPPING = {
    "QUEUING": StepState.Pending,
    "STARTING": StepState.Running,
    "RUNNING": StepState.Running,
    "COMPLETED": StepState.Completed,
    "FAILED": StepState.Failed,
    "NOT_EXIST": StepState.Failed
}


class ImportTypeEnum(Enum):
    DIR = "dir"
    MANIFEST = "manifest"


class DataOriginTypeEnum(Enum):
    """
    Imported data source type
    """
    OBS = "obs"
    DWS = "dws"
    DLI = "dli"
    RDS = "rds"
    MRS = "mrs"
    INFERENCE = "inference"


class AnnotationFormatEnum(Enum):
    """
    Annotation format name enum
    """
    MA_IMAGE_CLASSIFICATION_V1 = "ModelArts image classification 1.0"
    MA_IMAGENET_V1 = "ModelArts imageNet 1.0"
    MA_PASCAL_VOC_V1 = "ModelArts PASCAL VOC 1.0"
    YOLO = "YOLO"
    MA_IMAGE_SEGMENTATION_V1 = "ModelArts image segmentation 1.0"
    MA_TEXT_CLASSIFICATION_COMBINE_V1 = "ModelArts text classfication combine 1.0"
    MA_TEXT_CLASSIFICATION_V1 = "ModelArts text classfication 1.0"
    MA_AUDIO_CLASSIFICATION_DIR_V1 = "ModelArts audio classfication dir 1.0"


class LabelTypeEnum(Enum):
    """
    Label type enum
    """
    IMAGE_CLASSIFICATION = 0
    OBJECT_DETECTION = 1
    VIDEO_ANNOTATION = 1
    IMAGE_SEGMENTATION = 3
    TEXT_CLASSIFICATION = 100
    NAMED_ENTITY_RECOGNITION = 101
    TEXT_TRIPLE_ENTITY = 101
    TEXT_TRIPLE_RELATION = 102
    AUDIO_CLASSIFICATION = 200
    SPEECH_CONTENT = 201
    SPEECH_SEGMENTATION = 202


@attr.s
@serialize
class LabelFormat:
    """
    Attributes:
        label_type (str): types of tags for text classification
        text_label_separator (str): separator between label and label
        text_sample_separator (str): separator between text and label
    """
    label_type = attr.ib(default="1", validator=attr.validators.instance_of(str))
    text_label_separator = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))
    text_sample_separator = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))


@attr.s
@serialize
class AnnotationFormatParameters:
    """
    Attributes:
        difficult_only (bool): whether to import only difficult cases, default is False
        label_separator (str): separator between label and label, the default is comma separation
        sample_label_separator (str): separator between text and label
        included_labels (List[Label]): import a sample containing the specified label
    """
    difficult_only = attr.ib(default=False, validator=attr.validators.instance_of(bool))
    label_separator = attr.ib(default=",", validator=attr.validators.instance_of(str))
    sample_label_separator = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))
    included_labels = attr.ib(default=None, validator=attr.validators.instance_of((type(None), list)))


@attr.s
@serialize
class AnnotationFormatConfig:
    """
    Attributes:
        format_name (AnnotationFormatEnum): name of label format
        scene (LabelTaskTypeEnum): DatasetImport scene
        parameters (AnnotationFormatParameters): parameters of label format
    """
    format_name = attr.ib(default=None, validator=attr.validators.instance_of(AnnotationFormatEnum))
    scene = attr.ib(default=None, validator=attr.validators.instance_of((type(None), LabelTaskTypeEnum)))
    parameters = attr.ib(default=None, validator=attr.validators.instance_of((type(None), AnnotationFormatParameters)))

    def __attrs_post_init__(self):
        if self.scene:
            self.scene = self.scene.name


@attr.s
@serialize
class ImportDataInfo:
    """
    Attributes:
        annotation_format_config (List[AnnotationFormatConfig]): configuration parameters of the imported label format
        excluded_labels (List[Label]): do not import samples containing the specified tags
        import_annotated (bool): whether to import annotated samples from the original dataset
                                to the pending confirmation, default is False
        import_annotations (bool): whether to import tags, default is True
        import_origin (DataOriginTypeEnum): type of data source, default is obs
        import_samples (bool): whether to import samples, default is True
        import_type (ImportTypeEnum): import method, can only be dir or manifest, default is dir
        included_labels (List[Label]): import samples containing the specified tags
        label_format (LabelFormat): Label format information, this parameter is only used for text datasets
        with_column_header (bool): valid for csv, indicating whether the first row is a column name,
                            with_column_header is True means skipping the first row
    """
    annotation_format_config = attr.ib(default=None,
                                       validator=attr.validators.instance_of((type(None), list)))
    excluded_labels = attr.ib(default=None, validator=attr.validators.instance_of((type(None), list)))
    import_annotated = attr.ib(default=False, validator=attr.validators.instance_of(bool))
    import_annotations = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    import_origin = attr.ib(default=DataOriginTypeEnum.OBS, validator=attr.validators.instance_of(DataOriginTypeEnum))
    import_samples = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    import_type = attr.ib(default=ImportTypeEnum.DIR, validator=attr.validators.instance_of(ImportTypeEnum))
    included_labels = attr.ib(default=None, validator=attr.validators.instance_of((type(None), list)))
    label_format = attr.ib(default=None, validator=attr.validators.instance_of((type(None), LabelFormat)))
    with_column_header = attr.ib(default=False, validator=attr.validators.instance_of(bool))


@serialize
@attr.s
class Label:
    """
    Attributes:
        name (Union[str, Placeholder]): name of label
        property (dict): List of properties of the label
        type (LabelTypeEnum): the type of label
    """
    name = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    property = attr.ib(default=None, validator=attr.validators.instance_of((dict, type(None))))
    type = attr.ib(default=None, validator=attr.validators.instance_of((LabelTypeEnum, type(None))))


class DatasetImportInput(CommonInput):

    def __init__(self, name, data):
        """
        The input of DatasetImportStep
        Args:
            name (str): The name of DatasetImportInput
            data (Union[Dataset, DatasetConsumption, DatasetPlaceholder, OBSPath, OBSConsumption, OBSPlaceholder,
                    LabelTask, LabelTaskPlaceholder, LabelTaskConsumption, DataConsumptionSelector]):
                The input data type must be related to dataset, obs or label task
        """
        self._check_data(data)
        super(DatasetImportInput, self).__init__(name=name, data=data)

    @staticmethod
    def _check_data(data):
        data_type_tuple = (Dataset, DatasetConsumption, DatasetPlaceholder, OBSPath, OBSConsumption, OBSPlaceholder,
                           LabelTask, LabelTaskPlaceholder, LabelTaskConsumption, DataConsumptionSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of DatasetImportInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class DatasetImportConfig(AbstractOutputConfig):
    """
    """

    def __init__(self):
        super(DatasetImportConfig, self).__init__()
        self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, data):
        self._data = data

    def data_consumption(self, step_name, output_name, data_type):
        if data_type == "label_task":
            return LabelTaskConsumption(self, step_name, output_name)
        elif data_type == "dataset":
            return DatasetConsumption(self, step_name, output_name)
        else:
            raise ValueError('The data type of DatasetImportOutput must be dataset or label_task. '
                             'But provided: {}'.format(data_type))


class DatasetImportOutput(AbstractOutput):
    def __init__(self, name):
        """
        The output of DatasetImportStep
        Args:
            name (str): The name of DatasetImportOutput
        """
        super().__init__(name)
        self._step_name = ""
        self.config = DatasetImportConfig()

    @property
    def step_name(self):
        return self._step_name

    @step_name.setter
    def step_name(self, value):
        self._step_name = value

    def as_input(self):
        """
        Get the AbstractDataConsumption object, which is used for data transfer between multiple Steps
        Returns (AbstractDataConsumption):

        """
        return self.config.data_consumption(step_name=self.step_name, output_name=self.name, data_type=self.data_type)

    def set_data_to_config(self, data):
        """
        Set the data to the output config
        Args:
            data (Union[Dataset, LabelTask]): A label task or dataset

        Returns:

        """
        self.config.data = data

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": self.data_type
        }
        return result

    def set_to_skip(self):
        self.config.is_skipped = True


class DatasetImportStep(Step):
    def __init__(
        self,
        name,
        inputs,
        outputs,
        properties=None,
        title=None,
        description=None,
        policy=None,
        depend_steps=None
    ):
        """
        Construct a DatasetImportStep for dataset DatasetImport
        Args:
            name (str): The name of step
            inputs (List[DatasetImportInput]): A or a list of DatasetImportInput instance
            outputs (DatasetImportOutput): output of step
            properties (ImportDataInfo):
            title (str): title info of DatasetImportStep
            description (str): Description info of DatasetImportStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union[Step, List[Step]]): A or a list of step which this `DatasetImportStep` depends on
        """
        DatasetImportStep._check_inputs_and_outputs(inputs=inputs, outputs=outputs)
        import_properties = DatasetImportStep._prepare_properties(properties)
        outputs.data_type = DatasetImportStep.output_data_type(inputs)
        super(DatasetImportStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.DATASET_IMPORT,
            properties=import_properties,
            inputs=inputs,
            outputs=outputs,
            title=title,
            description=description,
            policy=policy,
            depend_steps=depend_steps
        )
        self._import_data_info = properties
        self._dataset_id = None
        self._data = None

    def build_client(self, session):
        super(DatasetImportStep, self).build_client(session)
        self.client = DatasetClient(session=session)

    @staticmethod
    def output_data_type(inputs):
        tuple_dataset = (Dataset, DatasetConsumption, DatasetPlaceholder)
        declared_data = DatasetImportStep._get_declared_data(inputs)
        if isinstance(declared_data, tuple_dataset):
            return "dataset"
        else:
            return "label_task"

    def create_instance(self) -> (bool, str):
        input_list = list(self.inputs.values())
        obs, data = DatasetImportStep._get_data(input_list)
        if isinstance(data, Dataset):
            self._dataset_id = data.id
            logging.info("The DatasetImportStep %s is importing data into dataset %s", self.name, data.dataset_name)
            task_id = self.client.import_data(
                path=obs.obs_path, dataset_id=data.id, import_data_info=self._import_data_info)
        else:
            self._dataset_id = data.dataset_id
            logging.info("The DatasetImportStep %s is importing data into label task %s", self.name, data.task_name)
            task_id = self.client.import_data(path=obs.obs_path, dataset_id=data.dataset_id,
                                              import_data_info=self._import_data_info, label_task_id=data.task_id)
        self._data = data
        return True, task_id

    @staticmethod
    def _get_data(input_list):
        if isinstance(input_list[0].data, OBSPath):
            return input_list[0].data, input_list[1].data
        else:
            return input_list[1].data, input_list[0].data

    @staticmethod
    def _get_declared_data(input_list):
        tuple_obs = (OBSPath, OBSConsumption, OBSPlaceholder)
        if isinstance(input_list[0].declared_data, tuple_obs):
            return input_list[1].declared_data
        else:
            return input_list[0].declared_data

    def update_instance_state(self):
        import_task_state = self.client.get_import_task_state(self._dataset_id, self.instance_id)
        step_state = StepStateMapping.get_step_state(import_task_state, IMPORT_TASK_STATE_MAPPING)
        if step_state == StepState.Completed:
            self._set_data_to_output()
        self.set_state(step_state)

    def stop_instance(self) -> (bool, str):
        return True, "success"

    @staticmethod
    def _check_inputs_and_outputs(inputs, outputs):
        tuple_import_data = (Dataset, DatasetConsumption, DatasetPlaceholder, LabelTask, LabelTaskPlaceholder,
                             LabelTaskConsumption)
        tuple_obs = (OBSPath, OBSConsumption, OBSPlaceholder)
        if not isinstance(inputs, list):
            raise TypeError("The inputs of DatasetImportStep must be list")
        if len(inputs) != 2:
            raise ValueError("The DatasetImportStep only allows two inputs")
        data_first = inputs[0].declared_data
        data_second = inputs[1].declared_data
        if not ((isinstance(data_first, tuple_obs) and isinstance(data_second, tuple_import_data)) or
                (isinstance(data_first, tuple_import_data) and isinstance(data_second, tuple_obs))):
            raise TypeError("The input data must be one OBS relevant and the other label task or dataset relevant")
        if not isinstance(outputs, DatasetImportOutput):
            raise TypeError(
                'The output of DatasetImportStep must be DatasetImportOutput. But provided: {}'.format(type(outputs)))

    @staticmethod
    def _prepare_properties(properties):
        if properties is not None:
            return prepare_for_properties(properties)
        return {}

    def _set_data_to_output(self):
        output = list(self.outputs.values())[0]
        output.set_data_to_config(self._data)
