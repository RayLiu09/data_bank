"""
Description: Cloud OBS and ROMA OBS management using roma s3 API
and obs client
Author: ModelArts SDK Team
Date: 2021/07/01 - 2021/07/29
"""

import hashlib
import multiprocessing as mp
import threading as thead
import operator
import os
import queue
import sys
from abc import ABCMeta, abstractmethod

from tqdm import tqdm

from modelarts import constant
from . import constant as obs_constant

file_md5_dict = {}
is_linux_system = sys.platform.lower().startswith(obs_constant.LINUX_SYSTEM)


class OBSApiBase(metaclass=ABCMeta):
    """ OBS API Base
    """

    def __init__(self, ):
        pass

    @abstractmethod
    def upload_file(self, src_local_file, dst_obs_dir):
        """ upload local file to obs path
        :param src_local_file: source local file path, e.g. c://programs/obs.py"
        :param dst_obs_dir: destination obs directory, e.g. obs://bucket_name/obs_dir/"
        :return:
        """
        pass

    @abstractmethod
    def upload_dir(self, src_local_dir, dst_obs_dir, keep_last_dir):
        """ upload local directory to obs path
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        pass

    @abstractmethod
    def download_file(self, src_obs_file, dst_local_dir):
        """ download obs file to local path
        :param src_obs_file: source obs file
        :param dst_local_dir: destination local directory
        """
        pass

    @abstractmethod
    def download_dir(self, src_obs_dir, dst_local_dir, keep_last_dir):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        pass

    @abstractmethod
    def increment_download_dir(self, src_obs_dir, dst_local_dir, increment_files, keep_last_dir):
        """ download obs directory to local path incrementally
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param increment_files: list of increment files to be download, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        pass

    @abstractmethod
    def increment_upload_dir(self, src_local_dir, dst_obs_dir, increment_files, keep_last_dir):
        """ upload local directory to obs path incrementally
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param increment_files: list of increment files to be upload, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        pass

    @abstractmethod
    def copy(self, src_path, dst_path, keep_last_dir):
        """ Transfer data between OBS and Local. Support download from OBS or upload to OBS;
            Support transter files or directory
        :param src_path: obs path or local path
        :param dst_path: obs path or local path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        pass

    @abstractmethod
    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        :param obs_file:
        :return: bool, True or False
        """
        pass

    @abstractmethod
    def del_obs_file(self, obs_file):
        """ delete obs object(file)
        :param obs_file: obs object(file)
        :return:
        """
        pass

    @abstractmethod
    def del_obs_dir(self, obs_dir):
        """ delete obs objects(directory)
        :param obs_dir: obs objects(directory)
        :return:
        """
        pass

    @abstractmethod
    def is_obs_path_exists(self, obs_path):
        """ check whether the obs path exists
        :param obs_path: obs directory or obs file
        :return: bool, True or False
        """
        pass

    @abstractmethod
    def is_obs_directory(self, obs_path):
        """ check whether the obs path is directory
        :param obs_path:
        :return: bool, True or False
        """
        pass

    @abstractmethod
    def list_all_objects(self, obs_path, is_list_whole_objects=True):
        """ get all objects in obs directory
        :param obs_path: obs directory which should starts with obs:/ and ends with /
        :param is_list_whole_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        """
        pass

    @abstractmethod
    def is_bucket_exists(self, bucket_name):
        """ check obs bucket exists
        :param bucket_name: bucket name
        """
        pass

    @abstractmethod
    def list_buckets(self):
        """ list obs buckets
        """
        pass

    @abstractmethod
    def create_obs_bucket(self, bucket_name, region_name):
        """ create obs bucket
        :param bucket_name: bucket name
        :param region_name: region name of the bucket
        """
        pass

    @abstractmethod
    def make_obs_dir(self, obs_dir):
        """ make obs directory
        :param obs_dir: obs directory which should starts with obs://
        """
        pass

    @classmethod
    def check_parent_path(cls, parent_path, child_path_list):
        """ check whether file in child_path_list is sub-file of parent_path
        :param parent_path: src_local_path
        :param child_path_list: destination obs directory path
        """
        for child_path in child_path_list:
            if os.path.exists(child_path):
                child_path_replaced_sep = cls.update_path_sep(
                    os.path.abspath(child_path)
                )
                if len(child_path_replaced_sep.split(parent_path, 1)) == 1:
                    raise Exception(f'the increment file {child_path_replaced_sep} is not sub-file of {parent_path}')

    @classmethod
    def check_list_type(cls, increment_files):
        """ check whether the type of increment files is list
        :param increment_files: list of increment files to be downloaded or uploaded,
        e.g. ['./dir1/file1', './dir2/file2', ...]
        """
        if not isinstance(increment_files, list):
            raise Exception(f'the type of {increment_files} should be list, but got {type(increment_files)}')

    @classmethod
    def check_obs_head_format(cls, obs_path):
        """ whether the obs path head is correct format
        :param obs_path: format example: obs://bucket_name/dir/file.py
                          illegal format: obs://bucket_name, obs:///
        :return: true or false
        """
        # identify obs_path head is "obs://"
        current_obs_head_content = obs_path[slice(len(constant.OBS_HEAD_FORMAT))]
        is_head_legal = operator.eq(current_obs_head_content, constant.OBS_HEAD_FORMAT)
        if not is_head_legal:
            error_reason = "Illegal obs head format {}, correct format is {}".format(obs_path, constant.OBS_HEAD_FORMAT)
            cls.handle_exception_logs(error_reason)

    @classmethod
    def check_obs_dir_head_tail(cls, obs_dir):
        """
        :param obs_dir: obs directory
        :return:
        """
        cls.check_obs_head_format(obs_dir)
        if not obs_dir.endswith('/'):
            error_reason = "Illegal obs dir format {}, which should end with '/'".format(obs_dir)
            cls.handle_exception_logs(error_reason)

    @classmethod
    def check_obs_file_head_tail(cls, obs_file):
        """
        :param obs_file: obs file
        :return:
        """
        cls.check_obs_head_format(obs_file)
        if obs_file.endswith('/'):
            error_reason = "Illegal obs dir format {}, which should not end with '/'".format(obs_file)
            cls.handle_exception_logs(error_reason)

    @classmethod
    def extract_obs_dir_and_filename(cls, obs_path):
        """ extract last fir path form string obs_path
        :param obs_path: format example:
        obs://bucket_name/dir1/dir2/file.py  obs://bucket_name/dir1/dir2/
        :return: dir_path, filename,
        format: {dir1/dir2, file.py} or {dir1/dir2, ''}
        """
        bucket_name = cls.extract_bucket_name(obs_path)
        bucket_dir_path = obs_path.split("{}{}/".format(constant.OBS_HEAD_FORMAT, bucket_name), 1)[-1]
        dir_path, file_name = os.path.split(bucket_dir_path)
        return dir_path, file_name

    @classmethod
    def extract_bucket_name(cls, obs_path):
        """ extract bucket name form string obs_path
        :param obs_path:  obs_path,
        format example: obs://bucket_name/dir/file.py or obs://bucket_name/dir/
        :return: bucket_name
        """
        cls.check_obs_head_format(obs_path)
        bucket_name = obs_path[len(constant.OBS_HEAD_FORMAT):].split(constant.SEP, 1)[0]
        # check bucket name legality, ""
        if bucket_name.strip() == '':
            error_reason = "Illegal bucket path format {},correct format " \
                           "is obs://bucket_name/file.txt".format(obs_path)
            cls.handle_exception_logs(error_reason)
        return bucket_name

    @classmethod
    def split_obs_path(cls, obs_path):
        """ extract obs bucket name and obs object key of a obs file path
        :param obs_path: obs file path
        format example: obs://bucket_name/dir/file.py or obs://bucket_name/dir/
        :return: bucket_name and object key
        """
        bucket_name = cls.extract_bucket_name(obs_path)
        object_key = obs_path.split(bucket_name, 1)[-1].lstrip(constant.SEP)
        return bucket_name, object_key

    @classmethod
    def get_local_dir_file_path_list(cls, local_dir_path):
        """
        :param local_dir_path: local directory path
        :return: file_path list, integral path
        """
        local_file_path_list = []
        for (dir_path, dir_names, file_names) in os.walk(local_dir_path):
            for filename in file_names:
                local_file_path = cls.update_path_sep(
                    os.path.join(dir_path, filename)
                )
                local_file_path_list.append(local_file_path)

        return local_file_path_list

    @classmethod
    def extract_integral_dst_obs_dir(cls, src_local_file, src_local_dir,
                                     dst_obs_far_dir):
        """
        :param src_local_file:  integral local file path,
        e.g. c://dir1/dir2/dir3/dir4/file.py, included by src_local_dir
        :param src_local_dir:  e.g c://dir1/dir2
        :param dst_obs_far_dir:  obs://bucket_name/obs_dir1/obs_dir2
        :return: illegal destination obs directory path
        obs://bucket_name/obs_dir1/obs_dir2/dir3/dir4/
        """
        src_local_file_replaced_sep = cls.update_path_sep(src_local_file)
        src_local_dir_replaced_sep = cls.update_path_sep(src_local_dir)

        # e.g C:/dir1/dir2/dir3/test.py -> dir3/test.py
        local_dir_prefix = src_local_file_replaced_sep.split(src_local_dir_replaced_sep, 1)[-1]

        # e.g obs://bucket_name/dir_name/ -> obs://bucket_name/dir_name/dir3/test.py
        dst_obs_file = cls.update_path_sep(os.path.join(dst_obs_far_dir, local_dir_prefix))

        # e.g obs://bucket_name/dir_name/dir3/test.py -> obs://bucket_name/dir_name/dir3
        file_path, file_name = os.path.split(dst_obs_file)

        # e.g obs://bucket_name/dir_name/dir3 -> obs://bucket_name/dir_name/dir3/
        dst_obs_dir = cls.add_suffix_slash(file_path)
        return dst_obs_dir

    @classmethod
    def make_local_dirs(cls, local_dir):
        """ make sure local dir exists
        :param local_dir: local dir integral path, .e.g. c://dir1/dir2
        :return:
        """
        if local_dir:
            os.makedirs(local_dir, exist_ok=True)

    @classmethod
    def is_local_file(cls, local_file):
        """
        :param local_file: local file path
        :return: True or False
        """
        if not os.path.isfile(local_file):
            error_reason = "The local file {} does not exist.".format(local_file)
            cls.handle_exception_logs(error_reason)

        return os.path.isfile(local_file)

    @classmethod
    def is_local_dir(cls, local_dir):
        """
        :param local_dir: local directory path
        :return:  bool, True of False
        """
        if not os.path.isdir(local_dir):
            error_reason = "The local dir {} does not exist".format(local_dir)
            cls.handle_exception_logs(error_reason)
        return os.path.isdir(local_dir)

    @classmethod
    def handle_exception_logs(cls, error_reason):
        """
        :param error_reason: error reason
        :return:
        """
        raise Exception(error_reason)

    @classmethod
    def get_integral_dst_obs_dir(cls, src_local_file, src_local_dir, dst_obs_far_dir_path):
        """
        :param src_local_file:
        :param src_local_dir:
        :param dst_obs_far_dir_path:
        :return:
        """
        src_local_file_split = src_local_file.split(src_local_dir, 1)[-1].rsplit(constant.SEP, 1)
        if len(src_local_file_split) > 1:
            src_local_file_left = src_local_file_split[0]
            src_local_file_fix = src_local_dir + src_local_file_left + constant.SEP + src_local_file_split[1]
            integral_dst_obs_dir = cls.extract_integral_dst_obs_dir(
                src_local_file_fix, src_local_dir,
                dst_obs_far_dir_path)
        else:
            integral_dst_obs_dir = cls.extract_integral_dst_obs_dir(
                src_local_file, src_local_dir,
                dst_obs_far_dir_path)
        return integral_dst_obs_dir

    @classmethod
    def get_dst_file_name(cls, src_path, dst_path):
        """ get the file name of dst_path
        :param src_path:
        :param dst_path:
        :return: destination file directory and file name
        e.g. if src_path == './dir1/file1' and dst_path == './dir2/',      return None, None
             if src_path == './dir1/file1' and dst_path == './dir2/file1', return './dir2', None
             if src_path == './dir1/file1' and dst_path == './dir2/file2', return './dir2', 'file2'
        """
        if dst_path.endswith(constant.SEP):
            return None, None
        dst_file_dir, dst_file_name = os.path.split(dst_path)
        src_file_dir, src_file_name = os.path.split(src_path)
        dst_file_dir += constant.SEP
        if dst_file_name == src_file_name:
            return dst_file_dir, None
        else:
            return dst_file_dir, dst_file_name

    @classmethod
    def check_obs_path_legal(cls, obs_path, transfer_mode, file_mode):
        """ check whether the obs path legal
        :param obs_path: obs directory or obs file
        :param transfer_mode: download or upload mode
        :param file_mode: file or dir
        """
        if '\\' in obs_path:
            raise Exception(f'{obs_constant.WINDOWS_PATH_SEP_WARN}, got {obs_path}')
        if transfer_mode not in [obs_constant.DOWNLOAD_MODE, constant.UPLOAD_MODE]:
            raise ValueError(f'transfer_mode only support {constant.UPLOAD_MODE} and {obs_constant.DOWNLOAD_MODE},'
                             f' but got {transfer_mode}')
        if file_mode not in [obs_constant.FILE_MODE, constant.DIR_MODE]:
            raise ValueError(f'file_mode only support {obs_constant.FILE_MODE} and {constant.DIR_MODE},'
                             f' but got {file_mode}')
        if transfer_mode == obs_constant.DOWNLOAD_MODE and file_mode == obs_constant.FILE_MODE:
            cls.check_obs_file_head_tail(obs_path)
        else:
            cls.check_obs_dir_head_tail(obs_path)

    @classmethod
    def check_local_path_legal(cls, local_path, transfer_mode, file_mode):
        """ check whether the local path legal
        :param local_path: local directory or local file
        :param transfer_mode:  download or upload
        :param file_mode: file or dir
        """
        if file_mode == constant.DIR_MODE and not local_path.endswith(constant.SEP):
            raise Exception(f"your local path is {local_path}, must end with /")
        if transfer_mode == constant.UPLOAD_MODE:
            if file_mode == obs_constant.FILE_MODE:
                cls.is_local_file(local_path)
            elif file_mode == constant.DIR_MODE:
                cls.is_local_dir(local_path)
            else:
                raise ValueError(f'file_mode only support {obs_constant.FILE_MODE} and {constant.DIR_MODE},'
                                 f' but got {file_mode}')
        elif transfer_mode == obs_constant.DOWNLOAD_MODE:
            cls.make_local_dirs(local_path)
        else:
            raise ValueError(
                f'transfer_mode only support {constant.UPLOAD_MODE} and {obs_constant.DOWNLOAD_MODE},'
                f' but got {transfer_mode}')

    @classmethod
    def check_increment_files(cls, src_local_dir, increment_files):
        """ check the legality of increment files
        :param src_local_dir: source local directory
        :param increment_files: list of increment files to be download or upload, ['./dir1/file1', './dir2/file2', ...]
                                if not specified, files in src_local_dir will be return
        :return:
        """
        cls.check_list_type(increment_files)
        cls.check_parent_path(src_local_dir, increment_files)

    @classmethod
    def get_increment_files(cls, src_local_dir):
        """ check the legality of increment files, get increment files
        :param src_local_dir: source local directory
        :return: files to be transfered
        """
        return cls.get_local_dir_file_path_list(src_local_dir)

    @classmethod
    def get_increment_upload_files(cls, increment_files):
        """ get files to be uploaded based on md5
        :param increment_files: list of increment files to be upload, ['./dir1/file1', './dir2/file2', ...]
        :return: files to be upload, list type
        """
        object_key_and_md5 = {file_name: cls.local_file_md5(file_name) for file_name in increment_files}
        upload_files_list = cls.get_increment_transfer_files(object_key_and_md5, constant.UPLOAD_MODE)
        return upload_files_list

    @classmethod
    def get_increment_download_files(cls, bucket_name, increment_files_attr):
        """  get files to be downloaded based on md5
        :param bucket_name: bucket name
        :param increment_files_attr:  objects attribute, dict type.
                e.g. {object1_key:{'size':object1_size, 'md5':object1_md5}, ...}
        :return: dict of obs object key and size, e,g, {'object1_key':'object1_size', ...}
        """
        increment_files_attr = {cls.update_path_sep(
            os.path.join(constant.OBS_HEAD_FORMAT, bucket_name, file_name)): object_attr
                                for file_name, object_attr in increment_files_attr.items()}

        download_files_size_dict = cls.get_increment_transfer_files(increment_files_attr, obs_constant.DOWNLOAD_MODE)
        return download_files_size_dict

    @classmethod
    def get_increment_transfer_files(cls, increment_files_attr, mode):
        """ get files for increment transfer
        :param increment_files_attr: dict type, e.g. {object1_key:object1_md5, ...}
        :param mode: download or upload
        :return: list of files or dict of object key and it's size
        """
        increment_files = [] if mode == constant.UPLOAD_MODE else {}
        for file_path, object_attr in increment_files_attr.items():

            file_md5, file_size = (
                object_attr.get('md5'), object_attr.get('size'),) if mode == obs_constant.DOWNLOAD_MODE else (
                object_attr, None,)
            if file_path.endswith(constant.SEP) or not (file_path not in file_md5_dict or
                                                        file_md5 != file_md5_dict[file_path]):
                continue

            file_md5_dict[file_path] = file_md5
            if mode == constant.UPLOAD_MODE:
                increment_files.append(file_path)
            else:
                increment_files[file_path] = file_size
        return increment_files

    @classmethod
    def add_suffix_slash(cls, path):
        """ keep path endswith sep '/'
        :param path: obs path or local path
        :return: path after add suffix /
        """
        if not path.endswith(constant.SEP):
            path += constant.SEP
        return path

    @classmethod
    def get_bucket_info_for_download_dir(cls, obs_path):
        """ get bucket information for download obs directory
        :param obs_path:
        :return: bucket_name, bucket directory path
        """
        bucket_name = cls.extract_bucket_name(obs_path)
        bucket_dir_path, _ = cls.extract_obs_dir_and_filename(obs_path)
        bucket_dir_path_add_slash = cls.add_suffix_slash(bucket_dir_path)
        return bucket_name, bucket_dir_path_add_slash

    @classmethod
    def update_path_sep(cls, path):
        """ replace windows sep "\\" with '/'
        :param path: obs path or local path
        :return:
        """
        if not is_linux_system:
            return path.replace(os.sep, constant.SEP)
        return path

    @classmethod
    def concat_dirs(cls, dst_dir, src_last_dir, keep_last_dir):
        """ concat source directory and destination last directory
        :param dst_dir: source directory, e.g. 'dir1/dir2'
        :param src_last_dir: destination last directory, e.g. 'dir4' of 'dir3/di4'
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return: new destination directory, e.g. 'dir1/dir2/dir4' if keep_last_dir == True else 'dir1/dir2'
        """
        if keep_last_dir:
            src_dir_replaced_sep = cls.update_path_sep(
                os.path.join(dst_dir, src_last_dir, '')
            )
        else:
            src_dir_replaced_sep = dst_dir
        return src_dir_replaced_sep

    @classmethod
    def get_upload_files_list(cls, src_local_dir, dst_obs_dir, src_local_file_list, keep_last_dir):
        """ get source and destination file list for upload
        :param src_local_dir: source local directory
        :param dst_obs_dir: destination obs directory
        :param src_local_file_list: source local file list
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return: source local file list, destination obs file list
        """
        local_dir_name = os.path.basename(os.path.normpath(src_local_dir))
        dst_obs_far_dir_path = cls.concat_dirs(dst_obs_dir, local_dir_name, keep_last_dir)
        dst_obs_file_list = []
        for src_local_file in src_local_file_list:
            integral_dst_obs_dir = cls.extract_integral_dst_obs_dir(
                src_local_file, src_local_dir, dst_obs_far_dir_path)
            dst_obs_file_list.append(integral_dst_obs_dir)
        return src_local_file_list, dst_obs_file_list

    @classmethod
    def get_download_files_list(cls, src_obs_dir, dst_local_dir, bucket_dir_path, objects_key_and_size,
                                keep_last_dir):
        """ get source and destination file list for download
        :param src_obs_dir: source obs directory
        :param dst_local_dir: destination local directory
        :param bucket_dir_path: obs bucket directory path
        :param objects_key_and_size: type: dict, e.g. {objects1: size1, objects2: size2, ... }
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return: list of source obs file, list of destination local file, list of obs file size
        """
        dst_dir_name = bucket_dir_path if bucket_dir_path == '' else os.path.split(os.path.normpath(src_obs_dir))[1]
        dst_local_dir_replaced_sep = cls.concat_dirs(dst_local_dir, dst_dir_name, keep_last_dir)
        new_src_obs_file_list, new_dst_local_dir_list, new_src_obs_object_size_list = [], [], []

        for obs_src_file, obs_object_size in objects_key_and_size.items():
            if src_obs_dir in obs_src_file:
                prefix_dir, prefix_file = os.path.split(
                    obs_src_file.split(src_obs_dir, 1)[-1])
                new_dst_local_dir = cls.update_path_sep(
                    os.path.join(dst_local_dir_replaced_sep, prefix_dir, '')
                )
                new_src_obs_file_list.append(obs_src_file)
                new_dst_local_dir_list.append(new_dst_local_dir)
                new_src_obs_object_size_list.append(obs_object_size)
        return new_src_obs_file_list, new_dst_local_dir_list, new_src_obs_object_size_list

    @classmethod
    def do_transfer(cls, transfer_job):
        """ upload or download using multiprocess.pool
        :param transfer_job: class type, is comprised of transfer_func and transfer_kwargs
        """
        transfer_func = transfer_job.transfer_func
        transfer_kwargs = transfer_job.kwargs

        mode = transfer_kwargs.get('mode')
        silence = transfer_kwargs.get('silence')
        if 'src_file_list' not in transfer_kwargs:
            raise ValueError('parameters src_file_list is expected in transfer job')
        num_files = len(transfer_kwargs.get('src_file_list'))

        copy_queue = mp.Manager().Queue(num_files)
        completed_queue = mp.Manager().Queue()
        for i in range(num_files):
            copy_queue.put(i)

        threads = max(min(obs_constant.DEFAULT_THREADS, num_files), 1) if mode != obs_constant.INCREMENT_MODE else 1
        proc = thead.Thread if not is_linux_system else mp.Process
        processes = []
        if not silence:
            listen = proc(target=cls.listener, args=(completed_queue, num_files,))
            listen.start()
        for i in range(threads):
            p = proc(target=cls._copy_queue, args=(transfer_func, copy_queue, completed_queue, transfer_kwargs,))
            processes.append(p)
            p.start()

        for p in processes:
            p.join()

        if not silence:
            completed_queue.put(None)
            listen.join()

    @classmethod
    def listener(cls, completed_queue, file_num):
        """ upload or download using multiprocess.pool
        :param completed_queue: record transfered files, used for update progress bar
        :param file_num: the number of files
        """
        pbar = tqdm(total=file_num)
        for _ in iter(completed_queue.get, None):
            pbar.update()
        pbar.refresh()
        pbar.n = file_num

    @classmethod
    def _copy_queue(cls, transfer_func, copy_queue, completed_queue, transfer_kwargs):
        """ upload or download using multiprocess.pool
        :param transfer_func: source path
        :param transfer_kwargs: parameters for transfer_func
        :param copy_queue: queue for recording the number of files
        :param completed_queue: record transfered files, used for update progress bar
        """
        while True:
            try:
                if copy_queue.empty():
                    break
                file_idx = copy_queue.get(timeout=1)
            except queue.Empty:
                continue
            object_size = None if transfer_kwargs.get('file_size_list') is None else \
                transfer_kwargs.get('file_size_list')[file_idx]
            transfer_func(transfer_kwargs.get('src_file_list')[file_idx],
                          transfer_kwargs.get('dst_file_list')[file_idx],
                          object_size, check_file=False)
            completed_queue.put(file_idx)

    @classmethod
    def get_local_file_size(cls, src_local_file):
        """ get size of local file
        :param src_local_file: source local file
        :return: file size
        """
        return os.path.getsize(src_local_file)

    @classmethod
    def local_file_md5(cls, file_path):
        m = hashlib.md5()
        with open(file_path, 'rb') as f:
            while True:
                data = f.read(4096)
                if not data:
                    break
                m.update(data)

        return m.hexdigest()

    @classmethod
    def _get_sub_objects(cls, specified_objects, objects_size):
        if not specified_objects:
            return None

        sub_objects_size, error_objects = {}, []
        for object_key in specified_objects:
            if object_key.endswith('/'):
                continue
            if object_key in objects_size:
                sub_objects_size[object_key] = objects_size.get(object_key)
            else:
                error_objects.append(object_key)
        if error_objects:
            raise Exception("Got error obs file in specified_objects, "
                            f"see {error_objects} for detailed error objects")
        return sub_objects_size


class TransferJob:
    def __init__(self, transfer_func, **kwargs):
        self.transfer_func = transfer_func
        self.kwargs = kwargs
