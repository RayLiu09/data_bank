#!/bin/bash

current_path=$(cd `dirname $0`;pwd)
model_path=$1
service_port=$2

py_file_num=$(ls ${model_path}/*.py | wc -l)
service_file=$(ls ${model_path}/*.py)

if [ ${py_file_num} -ge 2 ]; then
  service_file='${model_path}/customize_service.py'
fi

worker_timeout=120

if [ -n "${MODELARTS_WORKER_TIMEOUT}" ]; then
  worker_timeout=${MODELARTS_WORKER_TIMEOUT}
fi

worker_num=1

if [ -n "${MODELARTS_WORKER_NUM}" ]; then
  worker_num=${MODELARTS_WORKER_NUM}
fi

worker_threads=5

if [ -n "${MODELARTS_WORKER_THREADS}" ]; then
  worker_threads=${MODELARTS_WORKER_THREADS}
fi

log_file=${model_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

export MODEL_SERVER_ARGS="--model_path=${model_path} --model_name=serve --service_file=${service_file}"
cd ${current_path} && gunicorn -w ${worker_num} --threads ${worker_threads} -t ${worker_timeout} -b 0.0.0.0:${service_port} app:app | tee ${log_file}
