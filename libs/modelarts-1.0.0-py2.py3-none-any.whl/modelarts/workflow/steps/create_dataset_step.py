from typing import List
import logging
import attr

from modelarts.workflow.core.serialize import serialize
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.client.dataset_client import DatasetClient
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.core.serialize import prepare_for_properties
from modelarts.workflow.core.steps import Step, StepTypeEnum, StepState, AbstractOutput
from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.data.dataset import DataTypeEnum, DatasetConfig, Dataset, DATASET_STATE_MAPPING
from modelarts.workflow.data.obs import OBSPath, OBSConsumption, OBSPlaceholder, OBSOutputConfig
from modelarts.workflow.steps.dataset_import_step import ImportTypeEnum
from modelarts.workflow.data.data_selector import DataConsumptionSelector


DATA_SOURCE_TYPE_MAPPING = {
    "obs": 0,
    "dws": 1,
    "dli": 2,
    "rds": 3,
    "mrs": 4,
    "ai_gallery": 5,
    "inference": 6
}


@serialize
@attr.s
class SchemaField:
    """
    Attributes:
        name (str): column name
        schema_id (int): schema ID
        field_type (str): field type
        description (str): description info
    """
    name = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))
    schema_id = attr.ib(default=None, validator=attr.validators.instance_of((type(None), int)))
    field_type = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))
    description = attr.ib(default=None, validator=attr.validators.instance_of((type(None), str)))


@serialize
@attr.s
class ImportConfig:
    """
    Attributes:
        annotation_format_config (List[AnnotationFormatConfig]): configuration parameters of the imported label format
        import_annotations (bool): whether to import tags, default is True
        import_type (ImportTypeEnum): import method, can only be dir or manifest, default is dir
    """
    annotation_format_config = attr.ib(default=None,
                                       validator=attr.validators.instance_of((type(None), list)))
    import_annotations = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    import_type = attr.ib(default=ImportTypeEnum.DIR, validator=attr.validators.instance_of(ImportTypeEnum))


@serialize
@attr.s
class DatasetProperties:
    """
    Attributes:
        dataset_name (Union[str, Placeholder]): dataset name
        dataset_format (int): dataset format, 0: file type 1: table type
        data_type (DataTypeEnum): the data type of dataset
        description (str): description info
        import_data (bool): whether to import data
        work_path_type (int): dataset output path type
        schema (List[SchemaField]): the schema info of dataset
        import_config (ImportConfig): data import configuration

    """
    dataset_name = attr.ib(validator=attr.validators.instance_of((str, Placeholder)))
    dataset_format = attr.ib(default=0, validator=attr.validators.instance_of(int))
    data_type = attr.ib(default=DataTypeEnum.FREE_FORMAT,
                        validator=attr.validators.instance_of((type(None), DataTypeEnum)))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    import_data = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    work_path_type = attr.ib(default=0, validator=attr.validators.instance_of(int))
    schema = attr.ib(default=None, validator=attr.validators.instance_of((type(None), list)))
    import_config = attr.ib(default=None, validator=attr.validators.instance_of((type(None), ImportConfig)))


class CreateDatasetInput(CommonInput):
    def __init__(self, name, data):
        """

        Args:
            name (str): the name of CreateDatasetInput
            data (Union[OBSPath, OBSConsumption, OBSPlaceholder, DataConsumptionSelector]):
                    data source for creating dataset
        """
        self._check_input_data(data=data)
        super(CreateDatasetInput, self).__init__(name=name, data=data)

    def to_request(self):
        if isinstance(self.data, OBSPath):
            return self.data.obs_path
        else:
            raise TypeError("The data source is not supported")

    @staticmethod
    def _check_input_data(data):
        data_type_tuple = (OBSPath, OBSConsumption, OBSPlaceholder, DataConsumptionSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of CreateDatasetInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class CreateDatasetOutput(AbstractOutput):
    def __init__(self, name, config):
        """

        Args:
            name (str): the name of CreateDatasetOutput
            config (OBSOutputConfig): currently only OBSOutputConfig is supported
        """
        self._check_output_config(config=config)
        super().__init__(name)
        self.config = config
        self._dataset_config = DatasetConfig()

    def as_input(self):
        return self._dataset_config.data_consumption(step_name=self.step_name, output_name=self.name)

    def set_data_to_config(self, dataset):
        self._dataset_config.data = dataset

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "dataset"
        }
        return result

    @classmethod
    def _check_output_config(cls, config):
        if not isinstance(config, OBSOutputConfig):
            raise TypeError('The data type of CreateDatasetOutput must be OBSOutputConfig. '
                            'But provided: {}'.format(type(config)))

    def to_request(self):
        if isinstance(self.config.obs_path, Placeholder):
            return self.config.obs_path.value
        elif isinstance(self.config.obs_path, Storage):
            if self.config.obs_path.path is None:
                raise ValueError('The path of Storage {} is None'.format(
                    self.config.obs_path.name))
            return self.config.obs_path.path
        else:
            return self.config.obs_path

    def set_to_skip(self):
        self._dataset_config.is_skipped = True


class CreateDatasetStep(Step):

    def __init__(
        self,
        name,
        inputs,
        outputs,
        properties,
        title=None,
        description=None,
        policy=None,
        depend_steps=None
    ):
        """
        Construct a CreateDatasetStep for create dataset
        Args:
            name (str): The name of step
            inputs (Union[CreateDatasetInput, List[CreateDatasetInput]]): A or a list of CreateDatasetInput instance
            outputs (CreateDatasetOutput): A CreateDatasetOutput instance
            properties (DatasetProperties): Related properties needed to create a dataset
            title (str): title info of CreateDatasetStep
            description (str): Description info of CreateDatasetStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union[Step, List[Step]]): A or a list of step which this `CreateDatasetStep` depends on
        """
        CreateDatasetStep._checkout_init_info(inputs=inputs, outputs=outputs)
        properties_dic = CreateDatasetStep._process_properties(properties=properties, outputs=outputs)
        super(CreateDatasetStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.CREATE_DATASET,
            inputs=inputs,
            outputs=outputs,
            title=title,
            description=description,
            properties=properties_dic,
            policy=policy,
            depend_steps=depend_steps
        )
        self._dataset_properties = properties
        self._dataset_name = None

    def build_client(self, session):
        self.client = DatasetClient(session=session)

    def create_instance(self):
        dataset_properties = self._dataset_properties.serialize()
        self._dataset_name = dataset_properties.get("dataset_name", "")
        dataset_id = self.client.dataset_exists(self._dataset_name)
        if dataset_id:
            return True, dataset_id
        request_body = self._to_request(dataset_properties)
        logging.info("The CreateDatasetStep %s is creating dataset %s", self.name, self._dataset_name)
        dataset_id = self.client.create_dataset(request_body=request_body)
        return True, dataset_id

    def update_instance_state(self):
        if self.instance_id is None:
            raise ValueError('No instance of CreateDatasetStep {}'.format(self.name))
        logging.debug("The CreateDatasetStep %s is updating the state, and current state is %s", self.name, self.state)
        dataset_state = self.client.get_dataset_state(self.instance_id)
        step_state = StepStateMapping.get_step_state(str(dataset_state), DATASET_STATE_MAPPING)
        self.set_state(step_state)
        if step_state == StepState.Completed:
            self._set_data_to_output()

    def stop_instance(self):
        return True, "success"

    def _set_data_to_output(self):
        if self.instance_id is None:
            raise ValueError('No instance of CreateDatasetStep {}'.format(self.name))
        dataset = Dataset(dataset_name=self._dataset_name)
        dataset.id = self.instance_id
        if len(self.outputs) != 1:
            raise ValueError("Only one output of CreateDatasetStep is allowed")
        output = list(self.outputs.values())[0]
        output.set_data_to_config(dataset)

    @staticmethod
    def _process_properties(properties, outputs):
        if not properties.import_config:
            properties.import_config = ImportConfig(import_annotations=False)
        properties_dic = prepare_for_properties(properties)
        properties_dic["work_path"] = outputs.config.obs_path
        return properties_dic

    def _to_request(self, dataset_properties):
        if len(self.outputs) != 1:
            raise ValueError("Only one output of CreateDatasetStep is allowed")
        output = list(self.outputs.values())[0]
        dataset_properties["work_path"] = output.to_request()
        dataset_properties["data_sources"] = [
            {"data_path": step_input.to_request(),
             "data_type": DATA_SOURCE_TYPE_MAPPING.get(step_input.data_type())} for step_input in self.inputs.values()]
        return dataset_properties

    def _serialize_inputs(self):
        return [job_input.to_request() for job_input in self.inputs.values()]

    @staticmethod
    def _checkout_init_info(inputs, outputs):
        if not isinstance(inputs, List):
            inputs = [inputs]
        for element in inputs:
            if not isinstance(element, CreateDatasetInput):
                raise TypeError("The type of CreateDatasetStep input must be CreateDatasetInput. "
                                "But provided:{}".format(type(element)))
        if not isinstance(outputs, CreateDatasetOutput):
            raise TypeError("The type of CreateDatasetStep output must be CreateDatasetOutput. "
                            "But provided: {}".format(outputs))
