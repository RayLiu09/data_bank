"""
Description: file utils for read or write file
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""
from modelarts.dataset.format.manifest.constants import PREFIX_S3, S3, SEPARATOR, NEWLINE_CHARACTER, S3A, PREFIX_S3A, \
    OBS, PREFIX_OBS
from obs import AppendObjectContent


def is_local(path):
    """
    return whether is local path
    :param path: file path
    :return: true if the path is local path, false if the path isn't local path
    """
    if path is None:
        raise ValueError('path is None')
    lower_path = str(path).lower()
    if lower_path.startswith(S3) or lower_path.startswith(OBS) or lower_path.startswith(S3A):
        return False
    return True


def parser_path(path):
    """
    parser the path and return bucket_name and file_name
    :param path: the file path
    :return: bucket_name and file_name
    """
    lower_path = str(path).lower()
    if lower_path.startswith(S3):
        base_url = str(path)[len(PREFIX_S3):]
    elif lower_path.startswith(S3A):
        base_url = str(path)[len(PREFIX_S3A):]
    elif lower_path.startswith(OBS):
        base_url = str(path)[len(PREFIX_OBS):]
    else:
        raise Exception("Only support s3 and s3a! Don't support " + path)
    split_array = base_url.split(SEPARATOR)
    bucket_name = split_array[0]
    file_name = SEPARATOR.join(split_array[1:])
    return bucket_name, file_name


def read(path, obs_client):
    """
    read data from OBS and return the binary of file
    :param path: the file path
    :param obs_client: obs client
    :return:  result buffer
    """
    lower_path = str(path).lower()
    if lower_path.startswith(S3) or lower_path.startswith(S3A) or lower_path.startswith(OBS):
        bucket_name, file = parser_path(path)
        resp = obs_client.get_object(bucket_name=bucket_name, object_key=file, load_stream_in_memory=True)
        if resp.status >= 300:
            raise Exception("Failed, status: " + str(resp.status) + ", errorCode: " + str(resp.errorCode)
                            + ", errorMessage: " + resp.errorMessage + " reason: " + resp.reason)
        return resp.body.buffer
    else:
        raise ValueError("Only support s3 now!")


def save(manifest_json, path, session, saveMode="w"):
    """
    read data from OBS and return the binary of file

    :param manifest_json: manifest json list
    :param path: the file path
    :return:
    """
    obs_client = session.obs_client
    lower_path = str(path).lower()
    if is_local(lower_path) is False:
        bucket_name, file = parser_path(path)
        if saveMode.__eq__("w"):
            write_object(bucket_name=bucket_name, object_key=file, manifest_json=manifest_json, obs_client=obs_client)
        elif saveMode.__eq__("a"):
            append_object(bucket_name=bucket_name, object_key=file, manifest_json=manifest_json, obs_client=obs_client)
        else:
            raise Exception("Only support write 'w' and append 'a'!")
        session.get_obs_client().close()
    else:
        raise ValueError("Only support s3 now!")


def write_object(bucket_name, object_key, manifest_json, obs_client):
    resp = obs_client.put_file(
        bucket_name=bucket_name,
        object_key=object_key,
        content=NEWLINE_CHARACTER.join(manifest_json)
    )
    if resp.status >= 300:
        raise Exception("Failed, status: " + str(resp.status) + ", errorCode: " + str(resp.erro)
                        + ", errorMessage: " + resp.errorMessage + " reason: " + resp.reason)


def append_object(bucket_name, object_key, manifest_json, obs_client):
    content = AppendObjectContent()
    resp = obs_client.get_object_metadata(bucket_name=bucket_name, object_key=object_key)
    if resp.status < 300:
        content.position = resp.body.nextPosition
    for line in manifest_json:
        content.content = f"{line}\n"
        resp = obs_client.append_object(bucket_name=bucket_name, object_key=object_key, content=content)
        if resp.status >= 300:
            raise Exception("Failed, status: " + str(resp.status) + ", errorCode: " + str(resp.errorCode)
                            + ", errorMessage: " + resp.errorMessage + " reason: " + resp.reason)
        content.position = resp.body.nextPosition
