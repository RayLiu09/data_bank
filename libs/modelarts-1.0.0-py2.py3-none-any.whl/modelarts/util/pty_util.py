import os
import sys
import tty
import select
import fcntl
import termios
import pty
import shlex
import struct
from threading import Thread
from subprocess import Popen


class PtyProcess:
    """
    Launch a subprocess in a pseudo terminal (pty), and interact with both the process and its pty
    """
    CTRL_C = b"\x03"
    CTRL_D = b"\x04"

    def __init__(self, command, dimensions=(24, 80)):
        self.command = command
        self.return_code = None
        self.kill_signal = False
        # save for recovery original environment
        self.old_tty = termios.tcgetattr(sys.stdin)
        self.output = None
        # set stdin to raw mode
        tty.setraw(sys.stdin.fileno())

        master_fd, slave_fd = pty.openpty()
        self.set_pty_size(master_fd, *dimensions)
        self.proc = Popen(shlex.split(self.command),
                          preexec_fn=os.setsid,
                          stdin=slave_fd,
                          stdout=slave_fd,
                          stderr=slave_fd,
                          universal_newlines=True)
        self.capture_thread = Thread(target=self.capture_tty, args=(master_fd,))
        self.capture_thread.setDaemon(True)
        self.capture_thread.start()

    @property
    def exit_status(self):
        return self.proc.poll()

    @staticmethod
    def set_pty_size(fd, rows, cols):
        TIOCSWINSZ = getattr(termios, 'TIOCSWINSZ', -2146929561)
        size = struct.pack('HHHH', rows, cols, 0, 0)
        fcntl.ioctl(fd, TIOCSWINSZ, size)

    def capture_tty(self, master_fd):
        """
        tty output watcher
        """
        try:
            while self.is_alive():
                if self.kill_signal:
                    break
                # Important: select should set timeout value, which can exit successfully when finished.
                r, w, e = select.select([sys.stdin, master_fd], [], [], 0.1)
                if sys.stdin in r:
                    d = os.read(sys.stdin.fileno(), 10240)
                    # exit building precess when press ctrl+c or ctl+d
                    if d in [self.CTRL_C, self.CTRL_D]:
                        print("\033[93m Keyboard Interrupt \033[0m")
                        break
                    os.write(master_fd, d)
                elif master_fd in r:
                    # deal with tty output
                    self.output = os.read(master_fd, 10240)
                    if self.output:
                        os.write(sys.stdout.fileno(), self.output)
        finally:
            # recover original terminal env
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_tty)
            self.proc.kill()

    def is_alive(self):
        return self.proc.poll() is None

    def close(self):
        self.kill_signal = True
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_tty)
        self.proc.kill()

    def readline(self):
        if self.output is not None:
            line = self.output.decode().rstrip()
            self.output = None
            return line
        return self.output
