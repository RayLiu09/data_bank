"""
Description: Used to get notebook information.
Author: ModelArts SDK Team
Date: 2020/05/14 - 2021/06/30
"""
import json
import os
import re
import socket
import subprocess
from functools import wraps

from modelarts import constant

NOTEBOOK_HOSTNAME = "HOSTNAME"
CREDENTIAL_PROFILES_FILE = "CREDENTIAL_PROFILES_FILE"
NOTEBOOK_HOST_NAME_PATTERN = r"(^notebook-([a-zA-Z0-9]+|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]))\." \
                             r"([A-Za-z0-9]+|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])"
KERNEL_GATEWAY_HOST_NAME_PATTERN = r"(^kg-([a-zA-Z0-9]+|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]))\." \
                                   r"([A-Za-z0-9]+|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])"
OLD_MA_USER_ID = 1000
SINGLE_KERNEL_IMAGE_CONDA_ENV_MAX_NUM = 7


def get_notebook_name():
    """
    Get notebook name.
    :return: notebook name
    """
    hostname = socket.getfqdn(socket.gethostname())
    notebook_match = re.match(NOTEBOOK_HOST_NAME_PATTERN, hostname)
    if notebook_match:
        return notebook_match.group(1)
    kernel_gateway_match = re.match(KERNEL_GATEWAY_HOST_NAME_PATTERN, hostname)
    if kernel_gateway_match:
        return kernel_gateway_match.group(1)
    raise Exception("Wrong hostname, please restart this notebook.")


def get_notebook_id():
    """
    Get notebook name from environment variables.
    """
    notebook_name = get_notebook_name()
    try:
        return notebook_name.split("-", 1)[1]
    except Exception as e:
        raise Exception("hostname {} in environment variable is not correct, "
                        "error={}".format(notebook_name, e))


def get_credential_file():
    """
    Get value of environment variable CREDENTIAL_PROFILES_FILE.
    :return: value of environment variable CREDENTIAL_PROFILES_FILE
    """
    credential_file = os.environ.get(CREDENTIAL_PROFILES_FILE)
    if credential_file is None:
        raise Exception("No CREDENTIAL_PROFILES_FILE in environment variable.")
    return credential_file


def is_mount_efs():
    """
    Judge if notebook mount efs
    :return: True or False
    """
    return True if os.environ.get("EFS_MOUNT_PATH") else False


def get_ma_user_id():
    """
    Get user_id of user ma_user
    :return: user_id
    """
    import pwd
    return pwd.getpwnam('ma-user')[2]


def get_image_id():
    """
    Get image id of cur notebook from environment variable
    :return: image id
    """
    return os.environ.get("IMAGE_ID")


def is_mul_kernel_image():
    """
    Check if this notebook is using mul kernel image.
    :return: True or False
    """
    extra_info_num = 4
    if is_ascend910():
        cmd = "/home/{}/miniconda3/bin/conda info --env".format(os.getenv("NB_USER"))
    else:
        cmd = "{}/bin/conda info --env".format(os.getenv("ANACONDA_DIR"))
    env_info = subprocess.getoutput(cmd).split('\n')
    env_num = len(env_info) - extra_info_num
    # there are SINGLE_KERNEL_IMAGE_CONDA_ENV_MAX_NUM + 1 kernels in the the image of codelab
    return env_num > SINGLE_KERNEL_IMAGE_CONDA_ENV_MAX_NUM


def is_kernel_gateway():
    """
    Check if this notebook is using kernel gateway.
    :return: True or False
    """
    hostname = socket.getfqdn(socket.gethostname())
    kernel_gateway_match = re.match(KERNEL_GATEWAY_HOST_NAME_PATTERN, hostname)
    return kernel_gateway_match is not None


def is_ascend910():
    """
    Check if this notebook is using ascend
    :return: True or False
    """
    return "SOC_VERSION" in os.environ and os.getenv("SOC_VERSION") == "Ascend910A"


def get_ascend910_device_num():
    """
    Get the number of d910
    :return: int
    """
    rank_table_dict = get_rank_table_file(constant.NBSTART_HCCL_FILE_PATH)
    # only one server for every notebook in nbstart_hccl.json
    return len(rank_table_dict["server_list"][0]["device"])


def get_ascend910_distribute_server_num():
    """
    Get the ascend 910 server num of distributed training.
    :return: int
    """
    rank_table_dict = get_rank_table_file(constant.JOBSTART_HCCL_FILE_PATH)
    # only one server for every notebook in nbstart_hccl.json
    return int(rank_table_dict["server_count"])


def get_rank_table_file(file_path):
    """
    :param file_path: get rank table file of d910
    :return: a dictionary
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError("cannot find rank table file {}.".format(file_path))
    with open(file_path, 'r') as f:
        rank_table_dict = json.load(f)
    return rank_table_dict


def is_notebook_environ():
    """
    check if it is ma_notebook environment
    :return: True or False
    """
    return True if (constant.CREDENTIAL_PROFILES_FILE in os.environ or constant.AWS_CREDENTIAL_PROFILES_FILE
                    in os.environ) and constant.NB_USER in os.environ else False


def is_roma_notebook():
    return os.environ.get('IS_ROMA') and os.environ.get('IS_ROMA').lower() == 'true'


def _is_devserver_environ():
    return True if ("CREDENTIAL_PROFILES_FILE" in os.environ or "AWS_CREDENTIAL_PROFILES_FILE"
                    in os.environ) and "DEV_SERVER_ID" in os.environ else False


def roma_notebook_operation_handler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if is_roma_notebook():
            raise ValueError(f"Roma does not support {func.__name__} operation.")
        return func(*args, **kwargs)
    return wrapper


def is_notebook_execution():
    try:
        from IPython import get_ipython
    except ImportError:
        return False
    try:
        _name = get_ipython().__class__.__name__
        # Jupyter notebook or qt console
        if _name == "ZMQInteractiveShell":
            return True
        # Python interpreter or IPython in terminal
        else:
            return False
    except NameError:
        return False


def collect_env():
    env_refer = dict(Notebook="0",
                     Terminal="1",
                     HWC="A",
                     Roma="B",
                     DevServer="C",
                     VM="D")

    env_info = env_refer["Notebook"] if is_notebook_execution() else env_refer["Terminal"]
    exec_env = env_refer["VM"]
    if is_roma_notebook():
        exec_env = env_refer["Roma"]
    elif _is_devserver_environ():
        exec_env = env_refer["DevServer"]
    elif is_notebook_environ():
        exec_env = env_refer["HWC"]

    env_info = f"{env_info}&{exec_env}"
    return env_info  # 0&A -> Notebook&HWC
