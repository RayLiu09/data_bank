"""
Dataset SDK for ModelArts dataset management.
"""

import json
import os
import tempfile
import time
import warnings

from modelarts import constant
from modelarts.dataset import dataset_constant
from modelarts.dataset.csv_handler import CsvReader
from modelarts.dataset.dataset_impl import DatasetApiAKSKImpl, ManagedStorage


class Dataset(object):
    """
    A ModelArts Dataset that can create dataset, get dataset information and list,
    update dataset, delete dataset, publish dataset version, get dataset verion information and list,
    get structured dataset schema, batch read the specified version of structured dataset,
    import dataset and export dataset.
    """

    def __init__(self, session, dataset_id=None, headers=None):
        """
        Initialize a ModelArts Dataset, determine the dataset authorize type.
        :param session: Building interactions with Cloud service
        :param dataset_id: dataset id
        """
        if constant.AKSK_AUTH != session.auth:
            raise Exception("Only AK SK authentication supported.")
        self.session = session
        self.dataset_id = dataset_id
        if not self.session.security_token:
            self.dataset_instance = DatasetApiAKSKImpl(self.session, headers)
        else:
            self.dataset_instance = DatasetApiAKSKImpl(self.session)

    def __check_dataset_id(self, dataset_id=None):
        """
        check and get valid dataset id.
        :param dataset_id: dataset id
        :return: dataset id
        """
        if not dataset_id and not self.dataset_id:
            raise ValueError("Dataset id is needed.")
        return dataset_id if dataset_id else self.dataset_id

    @staticmethod
    def __check_field(schema_field):
        """
        check field parameters of schema when creating structured dataset.
        :param schema_field: each field of schema
        """
        if any(key not in ['schema_id', 'name', 'type'] for key in schema_field):
            raise ValueError("schema_id, name, type is needed in each field of schema.")

    @classmethod
    def get_dataset_list(cls, session, offset=None, limit=None, dataset_type=None):
        """
        get dataset list.
        :param session: Building interactions with Cloud service
        :return: response of getting dataset list, including dataset total number and dataset list
        """
        warnings.warn("get_dataset_list is deprecated, use list_datasets", DeprecationWarning)
        dataset = Dataset(session)
        return dataset.__get_dataset_list_by_instance(offset=offset, limit=limit, dataset_type=dataset_type)

    def __get_dataset_list_by_instance(self, offset, limit, dataset_type):
        """
        get dataset list by dataset instance with one authorize type.
        :return: response of getting dataset list
        """
        warnings.warn("__get_dataset_list_by_instance is deprecated, use __list_datasets_by_instance",
                      DeprecationWarning)
        return self.dataset_instance.get_dataset_list(offset, limit, dataset_type)

    @classmethod
    def list_datasets(cls, session, dataset_type=None, dataset_name=None, **kwargs):
        """
        create dataset.
        :param session: Building interactions with Cloud service.
        :param dataset_type: dataset type
        :param dataset_name: dataset name
        :return: dict of list datasets response
        """
        dataset = Dataset(session)
        return dataset.__list_datasets_by_instance(dataset_type=dataset_type, dataset_name=dataset_name, **kwargs)

    def __list_datasets_by_instance(self, dataset_type=None, dataset_name=None, **kwargs):
        if dataset_type:
            kwargs['dataset_type'] = dataset_type
        return self.dataset_instance.list_datasets(dataset_name=dataset_name, **kwargs)

    @classmethod
    def create_dataset(cls, session, dataset_name=None, data_type=None, data_sources=None, work_path=None, **kwargs):
        """
        create dataset decoupled
        :param session: Building interactions with Cloud service
        :param dataset_name: String, the name of dataset
        :param data_type: String, data type of dataset, optional value:[IMAGE, TEXT, AUDIO, VIDEO, TABLE, PLAIN]
        :param data_sources: Dictionary of
            - 'type': data source type,
            - 'path': the obs path of data,
            - 'annotation_config': the annotation format info about data
        :param work_path: Dictionary, work path of dataset
            - 'type': work path type
            - 'path': obs path of dataset
        :param kwargs: Optional arguments, such as
            - dataset_type: Integer, the type of dataset
            - schema: List(Optional), the schema info of table dataset
            - description: String(Optional), the description info of dataset
        """
        create_dataset_body = dict()
        if dataset_name is None:
            raise ValueError('The dataset_name should not be None.')
        create_dataset_body['dataset_name'] = dataset_name
        dataset_type = kwargs.get(dataset_constant.DATASET_DATASET_TYPE)
        if data_type is None and dataset_type is None:
            raise ValueError('The data_type should not be None.')
        if data_type is not None:
            Dataset.__check_data_type(data_type)
            create_dataset_body['data_type'] = dataset_constant.DATA_TYPE_DICT.get(data_type.upper())
        if dataset_type is not None:
            create_dataset_body['dataset_type'] = dataset_type

        if Dataset.__is_table(dataset_type, data_type):
            create_dataset_body['dataset_format'] = 1
            schema = kwargs.get("schema")
            if schema is None:
                raise ValueError("The schema should not be None while data_type is TABLE.")
            create_dataset_body['schema'] = schema
            create_dataset_body['import_data'] = dataset_constant.DATASET_BOOLEAN_TRUE
        else:
            create_dataset_body['dataset_format'] = 0
        create_dataset_body['data_sources'] = Dataset.__build_data_sources(data_sources)
        create_dataset_body['import_config'] = Dataset.__build_import_config(data_sources)

        Dataset.__check_work_path(work_path)
        create_dataset_body['work_path_type'] = work_path.get(dataset_constant.DATASET_WORK_PATH_TYPE)
        create_dataset_body['work_path'] = work_path.get(dataset_constant.DATASET_WORK_PATH_PATH)

        labels = kwargs.get("labels")
        if dataset_constant.DATASET_TYPE_TRIPLET == dataset_type:
            Dataset.__check_labels(labels)
            create_dataset_body['labels'] = labels
        create_dataset_body['description'] = kwargs.get("description")
        dataset = Dataset(session)
        return dataset.dataset_instance.create_dataset(create_dataset_body)

    @classmethod
    def __check_data_type(cls, data_type):
        if data_type.upper() not in dataset_constant.DATA_TYPE_LIST:
            raise ValueError(
                "The data_type is invalid, it should be in {}, but is \'{}\'".format(
                    dataset_constant.DATA_TYPE_LIST,
                    data_type))

    @classmethod
    def __check_work_path(cls, work_path):
        if work_path is None:
            raise ValueError('The work_path should not be None.')
        if not isinstance(work_path, dict):
            raise ValueError('The work_path should be a dict.')
        if work_path.get(dataset_constant.DATASET_WORK_PATH_TYPE) is None:
            raise ValueError('The \'type\' of work_path should not be None.')
        if work_path.get(dataset_constant.DATASET_WORK_PATH_PATH) is None:
            raise ValueError('The \'path\' of work_path should not be None.')

    @classmethod
    def __check_labels(cls, labels):
        if labels is None:
            raise ValueError('The labels should not be None.')
        if not isinstance(labels, list):
            raise ValueError('The labels should be list.')

    @classmethod
    def __build_data_sources(cls, data_sources):
        data_source_list = []
        if data_sources is None:
            raise ValueError('The data_sources should not be None.')
        if isinstance(data_sources, list):
            for data_source in data_sources:
                datasource = Dataset.__build_data_source(data_source)
                data_source_list.append(datasource)
        elif isinstance(data_sources, dict):
            datasource = Dataset.__build_data_source(data_sources)
            data_source_list.append(datasource)
        return data_source_list

    @classmethod
    def __build_data_source(cls, data_sources):
        source = dict()
        source['data_type'] = Dataset.__build_data_type(data_sources)
        source['data_path'] = Dataset.__build_data_path(data_sources)
        source['content_info'] = data_sources.get("content_info")
        if data_sources.get(dataset_constant.DATASET_WITH_COLUMN_HEADER) is not None:
            source['with_column_header'] = "true" if data_sources.get(
                dataset_constant.DATASET_WITH_COLUMN_HEADER) else "false"
        return source

    @classmethod
    def __is_table(cls, dataset_type=None, data_type=None):
        if dataset_type is not None and dataset_constant.DATASET_TYPE_TABULAR == dataset_type:
            return True
        if data_type is not None and dataset_constant.DATA_TYPE_TABLE == data_type.upper():
            return True
        return False

    @classmethod
    def __build_import_config(cls, data_sources):
        import_config = dict()
        if data_sources is None or isinstance(data_sources, list):
            return import_config
        data_path = Dataset.__build_data_path(data_sources)
        import_config['import_type'] = Dataset.__build_import_type(data_path)
        import_config['import_path'] = data_path

        if data_sources.get("annotation_config") is not None:
            import_config['import_annotations'] = dataset_constant.DATASET_BOOLEAN_TRUE
            annotation_format_config = list()
            annotation_format_config.append(data_sources.get("annotation_config"))
            import_config['annotation_format_config'] = annotation_format_config
        else:
            import_config['import_annotations'] = dataset_constant.DATASET_BOOLEAN_FALSE

        return import_config

    @classmethod
    def __build_data_path(cls, data_sources):
        if data_sources.get(dataset_constant.DATASET_DATA_SOURCE_PATH) is not None:
            return data_sources.get(dataset_constant.DATASET_DATA_SOURCE_PATH)
        else:
            return data_sources.get(dataset_constant.DATASET_DATA_SOURCE_DATA_PATH)

    @classmethod
    def __build_data_type(cls, data_sources):
        if data_sources.get(dataset_constant.DATASET_DATA_SOURCE_TYPE) is not None:
            return data_sources.get(dataset_constant.DATASET_DATA_SOURCE_TYPE)
        else:
            return data_sources.get(dataset_constant.DATASET_DATA_SOURCE_DATA_TYPE)

    @classmethod
    def __build_import_type(cls, path):
        if path is not None and path.endswith(dataset_constant.DATASET_IMPORT_OBS_MANIFEST):
            return dataset_constant.DATASET_IMPORT_OBS_MANIFEST
        else:
            return dataset_constant.DATASET_IMPORT_OBS_DIR

    @classmethod
    def delete_dataset(cls, session, dataset_id):
        """
        delete dataset.
        :param session: Building interactions with Cloud service
        :param dataset_id: dataset id
        :return: response of deleting dataset
        """
        dataset = Dataset(session, dataset_id)
        return dataset.__delete_dataset_by_id(dataset_id)

    @classmethod
    def get_dataframe(cls, session, dataset_name, version_name):
        dataset_id = cls._get_dataset_id(session, dataset_name)
        version_id = cls._get_version_id(session, dataset_id, version_name)
        if not version_id:
            raise ValueError("Version is invalid.")
        dataset = Dataset(session, dataset_id)
        reader = dataset.create_reader(version_id=version_id)
        dataframe = reader.read_full_data()
        reader.close()
        dataset_info = dataset.get_dataset_info()
        # dataframe.columns = list(map(lambda item: item['name'], dataset_info['schema']))
        dataframe.columns = [item['name'] for item in dataset_info['schema']]
        return dataframe

    @classmethod
    def _get_dataset_id(cls, session, dataset_name):
        page_no = 0

        while True:
            dataset_list_resp = Dataset.get_dataset_list(session, offset=page_no, limit=10,
                                                         dataset_type=dataset_constant.DATASET_TYPE_TABULAR)
            dataset_list = dataset_list_resp['datasets']

            if not dataset_list:
                return None
            page_no += 1

            for dataset_item in dataset_list:
                if dataset_item["dataset_name"] == dataset_name:
                    return dataset_item["dataset_id"]

    @classmethod
    def _get_version_id(cls, session, dataset_id, version_name):
        dataset = Dataset(session, dataset_id=dataset_id)
        version_list = dataset.get_version_list()
        version_id = None
        for version_item in version_list["versions"]:
            _version_name = version_item["version_name"]
            if _version_name == version_name:
                version_id = version_item["version_id"]
                break
        return version_id

    @classmethod
    def publish_dataset(cls, session, dataframe, dataset_name, version_name, obs_bucket, obs_path, description=""):
        """
        create dataset
        :param dataset_name:
        :param version_name:
        :param obs_bucket:
        :param obs_path:
        :param dataframe:
        :param description:
        :return:
        """

        if not obs_path.endswith("/"):
            obs_path = obs_path + "/"

        if obs_path.startswith("/"):
            obs_path = obs_path[1:]

        # save csv in local
        local_tmp_path = os.path.join(tempfile.gettempdir(), "temp_local_{}".format(str(round(time.time()))))
        os.mkdir(local_tmp_path)
        local_tmp_csv = os.path.join(local_tmp_path, "result.csv")
        dataframe.to_csv(local_tmp_csv, index=False)

        # create dataset
        dataset_type = dataset_constant.DATASET_TYPE_TABULAR
        managed = False
        work_path_type = 0
        work_path = "/{}/{}".format(obs_bucket, obs_path)
        schema = cls._generate_schema_for_dataset(dataframe)
        create_resp = cls.create_dataset(session=session,
                                         dataset_name=dataset_name,
                                         dataset_type=dataset_type,
                                         schema=schema,
                                         storage=ManagedStorage(managed, work_path, work_path_type),
                                         description=description)
        if "dataset_id" not in create_resp:
            raise Exception("Create dataset:{} error, resp is {}".format(dataset_name, json.dumps(create_resp)))
        dataset_id = create_resp['dataset_id']

        # import data to dataset
        dataset_instance = Dataset(session=session, dataset_id=dataset_id)

        dataset_instance.import_data(path=local_tmp_csv, format="csv", with_column_header=True,
                                     is_from_local=True)

        dataset_instance.release_dataset_version(version_name=version_name, version_format="csv")

    def __delete_dataset_by_id(self, dataset_id):
        """
        delete dataset by dataset instance with one authorize type.
        :return: response of deleting dataset
        """
        dataset_id = self.__check_dataset_id(dataset_id)
        return self.dataset_instance.delete_dataset(dataset_id)

    def update_dataset(self, dataset_name=None, description=None):
        """
        update structured dataset.
        :param dataset_name: dataset name
        :param description: dataset description
        :return: response of updating dataset
        """
        dataset_id = self.__check_dataset_id()
        update_dataset_body = dict()
        if dataset_name:
            update_dataset_body['dataset_name'] = dataset_name
        if description:
            update_dataset_body['description'] = description
        return self.dataset_instance.update_dataset(dataset_id, update_dataset_body)

    def get_dataset_info(self):
        """
        get dataset information
        :return: response of getting dataset information
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_dataset_info(dataset_id)

    def list_versions(self):
        """
        get dataset version list
        :return: response of getting dataset version list
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_version_list(dataset_id)

    def create_version(self, name=None, version_format=None, label_task_type=None, label_task_id=None, **kwargs):
        """
        create dataset version
        :param name: String(Optional), version name of dataset
        :param version_format: String(Optional), create version format, supporting Default
        :param label_task_type: Integer(Optional), the label task type of dataset version
        :param label_task_id: String(Optional), the label-task id,
                label_task_id is required while create version for label-task
        :param description: String(Optional), dataset version description
        :return: dict, response of creating dataset version, include version_id
        """
        dataset_id = self.__check_dataset_id()
        self.__check_label_task_type(label_task_type=label_task_type)
        create_version_body = self.__build_create_version_body(name, version_format, label_task_type, label_task_id,
                                                               **kwargs)

        return self.dataset_instance.release_dataset_version(dataset_id, create_version_body)

    def __check_label_task_type(self, label_task_type):
        dataset_resp = self.get_dataset_info()
        dataset_type = dataset_resp.get(dataset_constant.DATASET_TYPE)
        if dataset_type is None and label_task_type is None:
            raise ValueError("The param \'label_task_type\' is required.")
        return True

    def __build_create_version_body(self, name=None, version_format=None, label_task_type=None, label_task_id=None,
                                    **kwargs):
        create_version_body = dict()
        if name is not None:
            create_version_body['version_name'] = name
        if version_format is not None:
            create_version_body['version_format'] = version_format
        if label_task_type is not None:
            create_version_body['label_task_type'] = label_task_type
        if label_task_id is not None:
            create_version_body['label_task_id'] = label_task_id
        if kwargs.get("description") is not None:
            create_version_body['description'] = kwargs.get("description")
        return create_version_body

    def get_version_info(self, version_id):
        """
        get dataset version information
        :param version_id: version id
        :return: response of getting dataset version information
        """
        dataset_id = self.__check_dataset_id()
        if not version_id:
            raise ValueError("version_id should not be None.")
        return self.dataset_instance.get_version_info(dataset_id, version_id)

    def delete_version(self, version_id):
        """
        delete dataset version
        :param version_id: version id
        :return: None
        """
        dataset_id = self.__check_dataset_id()
        if not version_id:
            raise ValueError("version_id should not be None.")
        return self.dataset_instance.delete_version(dataset_id, version_id)

    def get_version_list(self):
        """
        get dataset version list
        :return: response of getting dataset version list
        """
        warnings.warn("get_version_list is deprecated, use list_versions", DeprecationWarning)
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_version_list(dataset_id)

    def release_dataset_version(self, version_name=None, version_format=None, description=None):
        """
        create dataset version
        :param version_name: version name
        :param version_format: create version format, supporting Default and CarbonData
        :param description: dataset version description
        :return: response of creating dataset version
        """
        warnings.warn("release_dataset_version is deprecated, use create_version", DeprecationWarning)
        dataset_id = self.__check_dataset_id()
        create_version_body = dict()
        if version_name:
            create_version_body['version_name'] = version_name
        if version_format:
            create_version_body['version_format'] = version_format
        if description:
            create_version_body['description'] = description
        return self.dataset_instance.release_dataset_version(dataset_id, create_version_body)

    def create_reader(self, version_id, batch=1):
        """
        create reader to get specified version data of dataset
        """
        dataset_id = self.__check_dataset_id()

        if not version_id:
            raise ValueError("Version id is needed.")
        version_info = self.dataset_instance.get_version_info(dataset_id, version_id)
        data_path = version_info['data_path']
        version_format = version_info['version_format']
        with_column_header = version_info['with_column_header']
        schema = self.dataset_instance.get_schema(dataset_id)

        if version_format.upper() == dataset_constant.DATASET_VERSION_FORMAT_CSV.upper() or \
                version_format.upper() == dataset_constant.DATASET_VERSION_FORMAT_DEFAULT.upper():
            reader = CsvReader(self.session, data_path, batch, schema, with_column_header)
        else:
            raise Exception("Unsupported versoin format: {}, only support {}.".format(
                version_format, dataset_constant.DATASET_VERSION_FORMAT_CSV))
        return reader

    def list_samples(self, version_id=None, **kwargs):
        """
        list sample preview, currently previewing 100 rows
        :param version_id: version id
        :return: structured dataset sample preview
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.list_samples(dataset_id, version_id, **kwargs)

    def get_sample_info(self, sample_id):
        """
        get sample info by sample_id
        :param sample_id: sample id
        :return: response of sample infl
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_sample_info(dataset_id, sample_id)

    def delete_samples(self, samples):
        """
        delete dataset samples by sample_id
        :param samples: a list of sample_id
        :return: list of sample_id that failed to delete
        """
        if (samples is None) or (type(samples) is not list):
            raise ValueError("samples should be list and not be None.")
        delete_samples_body = dict()
        delete_samples_body['samples'] = samples
        dataset_id = self.__check_dataset_id()
        self.dataset_instance.delete_samples(dataset_id, delete_samples_body)

    def get_schema(self):
        """
        get dataset schema.
        :return: structured dataset schema
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_schema(dataset_id)

    def list_import_tasks(self):
        """
        list dataset import tasks
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.list_import_tasks(dataset_id)

    def import_data(self, path=None, annotation_config=None, **kwargs):
        """
        create import task for dataset
        :param path: String, import data path, supporting OBS path and local path
        :param annotation_config: Dictionary, the annotation config of import task
        :param kwargs: Optional arguments. such as:
            - with_colume_header: valid for csv, indicating whether the first row is a column name,
                                with_column_header is True means skipping the first row
            - is_from_local: import data from obs or local, is_from_local is True means importing from local path
        :return: import task info
        """
        if path is None:
            raise ValueError('The path should not be None.')
        dataset_id = self.__check_dataset_id()
        import_type = kwargs.get("import_type")
        is_from_local = False if kwargs.get(dataset_constant.DATASET_IS_FROM_LOCAL) is None else kwargs.get(
            dataset_constant.DATASET_IS_FROM_LOCAL)
        if is_from_local:
            path = path.replace("\\", "/")
            desc_dataset_resp = self.dataset_instance.get_dataset_info(dataset_id=dataset_id)
            inner_work_path = desc_dataset_resp['inner_work_path']
            upload_temp_path = inner_work_path + dataset_constant.IMPORT_DATASET_TEMP_DIRECTORY_PREFIX + \
                               str(round(time.time() * 1000)) + "/"
            try:
                self.session.upload_data(upload_temp_path, path)
            except Exception:
                self.__delete_obs_directory(upload_temp_path)
                raise Exception("Failed to upload local path {} to OBS {}.".format(upload_temp_path, path))
            path = upload_temp_path
            import_type = "dir"
        import_type = Dataset._build_import_type(import_type, path)
        import_data_body = dict()
        import_data_body['import_path'] = path
        import_data_body['import_type'] = import_type
        if annotation_config is None:
            import_data_body['import_annotations'] = dataset_constant.DATASET_BOOLEAN_FALSE
        else:
            import_data_body['import_annotations'] = dataset_constant.DATASET_BOOLEAN_TRUE
            import_data_body['annotation_format_config'] = Dataset._build_annotation_format_config(annotation_config)
        with_column_header = kwargs.get(dataset_constant.DATASET_WITH_COLUMN_HEADER)
        if with_column_header is not None:
            import_data_body['with_column_header'] = "true" if with_column_header else "false"
        return self.dataset_instance.import_data(dataset_id, import_data_body)

    @staticmethod
    def _build_import_type(import_type, path):
        if import_type is None:
            if path.endswith(".manifest"):
                import_type = dataset_constant.DATASET_IMPORT_OBS_MANIFEST
            else:
                import_type = dataset_constant.DATASET_IMPORT_OBS_DIR
        return import_type

    @staticmethod
    def _build_annotation_format_config(annotation_config):
        annotation_format_config = list()
        if isinstance(annotation_config, dict):
            annotation_format_config.append(annotation_config)
        elif isinstance(annotation_config, list):
            annotation_format_config = annotation_config
        else:
            raise ValueError("The annotation_config is invalid.")
        return annotation_format_config

    def __delete_obs_directory(self, obs_path):
        """
        delete obs directory and its files
        :param obs_path: obs path
        """
        bucket_name = obs_path[1:obs_path.find("/", 1)]
        object_name = obs_path[obs_path.find("/", 1) + 1:]
        object_list = self.session.obs_client.list_all_objects(bucket_name, object_name)
        for objects in object_list:
            delete_objects_resp = self.session.obs_client.obs_client.deleteObject(bucket_name, objects)
            if delete_objects_resp.status > 300:
                raise Exception("Delete files existed in bucket failed, "
                                "error message is {}".format(delete_objects_resp.errorMessage))

    def get_import_task_info(self, task_id):
        """
        query import task
        :param task_id: import data task id
        :return: response of querying import task
        """
        dataset_id = self.__check_dataset_id()
        if not task_id:
            raise ValueError('The task_id is required.')
        return self.dataset_instance.get_import_task_info(dataset_id, task_id)

    def list_export_tasks(self):
        """
        list dataset export tasks
        """
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.list_export_tasks(dataset_id)

    def export_data(self, path, **kwargs):
        """
        export data to target path
        """
        dataset_id = self.__check_dataset_id()
        export_data_body = dict()
        if not path:
            raise ValueError('The path is required.')
        export_data_body['path'] = path
        with_column_header = kwargs.get("with_column_header")
        if with_column_header:
            export_data_body['with_column_header'] = "true" if with_column_header else "false"
        dataset_info = self.get_dataset_info()
        if dataset_info.get("data_type") is not None:
            export_data_body['data_type'] = dataset_info.get("data_type")
        return self.dataset_instance.export_data(dataset_id, export_data_body)

    def get_export_task_info(self, task_id):
        """
        query export task
        :param task_id: export data task id
        :return: response of querying export task
        """
        dataset_id = self.__check_dataset_id()
        if not task_id:
            raise ValueError('The task_id is required.')
        return self.dataset_instance.get_export_task_info(dataset_id, task_id)

    @classmethod
    def list_label_tasks(cls, session, dataset_id=None, **kwargs):
        """
        get label task list
        :param session: Building interactions with Cloud service.
        :param dataset_id: the dataset id, we can get all label tasks while dataset_id is None
        :param task_type: the type of label task
        """
        dataset = Dataset(session)
        return dataset.dataset_instance.list_label_tasks(dataset_id=dataset_id, **kwargs)

    def create_label_task(self, task_name=None, task_type=None, **kwargs):
        """
        create a label task for dataset
        :param task_name: the name of label task
        :param task_type: the type of label task
        """
        if task_name is None:
            raise ValueError('The task_name is required.')
        if task_type is None:
            raise ValueError('The task_type is required.')
        create_label_task_body = self.__build_create_label_task_body(task_name=task_name, task_type=task_type, **kwargs)
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.create_label_task(dataset_id, create_label_task_body)

    def get_label_tasks(self, is_workforce_task=None, **kwargs):
        dataset_id = self.__check_dataset_id()
        if is_workforce_task is not None:
            kwargs['is_workforce_task'] = is_workforce_task
        return self.dataset_instance.list_label_tasks(dataset_id=dataset_id, **kwargs)

    @classmethod
    def __build_create_label_task_body(cls, task_name=None, task_type=None, **kwargs):
        create_label_task_body = dict()
        create_label_task_body['task_name'] = task_name
        create_label_task_body['task_type'] = task_type
        for key, value in kwargs.items():
            if value is not None:
                create_label_task_body[key] = value
        return create_label_task_body

    def get_label_task_info(self, task_id=None):
        """
        get information of label task
        :param task_id: the id of label task
        """
        if not task_id:
            raise ValueError('The task_id is required.')
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.get_label_task_info(dataset_id, task_id)

    def delete_label_task(self, task_id=None):
        """
        delete a label task of dataset
        :param task_id: the id of label task
        """
        if not task_id:
            raise ValueError('The task_id is required.')
        dataset_id = self.__check_dataset_id()
        return self.dataset_instance.delete_label_task(dataset_id, task_id)

    @staticmethod
    def _generate_schema_for_dataset(df):
        dtype_transform_dict = {
            "int64": "int",
            "float64": "float",
            "bool": "boolean",
            "object": "string"
        }
        schema = []
        index = 0
        for column in df.columns:
            dtype = df[column].dtypes
            dtype = dtype_transform_dict[str(dtype)]
            schema_item = {
                "schema_id": index,
                "name": column,
                "type": dtype
            }
            schema.append(schema_item)
            index += 1
        return schema
