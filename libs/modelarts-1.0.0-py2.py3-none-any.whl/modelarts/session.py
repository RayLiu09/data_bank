import hashlib
import json
import logging
import os
import re
import urllib3

from .config import auth
from .util.obs_util import OBS
from .util.config import Config
from . import constant
from .util.secret_util import auth_expired_handler, read_ak_sk_from_secret
from .obs_mgmt import OBSManagement
from modelarts.util.string_util import query_var
from modelarts.util.file_utils import load_config_yaml

urllib3.disable_warnings()
logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')
LOGGER.setLevel(logging.INFO)
MODELARTS_CONFIG = os.getenv("MODELARTS_CONFIG", constant.MODELARTS_CONFIG_PATH)
HTTP_PREFIX = "http://"
HTTPS_PREFIX = "https://"


class Session(object):
    """Manage interactions with the cloud services needed.
    This class provides convenient methods for manipulating other services,
    such as iam auth, operation in OBS.
    """

    hcs_environment_valid = False
    ROMA_HOST = Config.getenv("ROMA_MA_HOST", strict=False, default=None)

    def __init__(self, config_file=None, account=None, username=None, password=None,
                 access_key=None, secret_key=None, security_token=None,
                 region_name=None, project_id=None, project_name=None,
                 app_id=None, app_token=None, w3_account=None, w3_password=None):
        """
        Initialize a ModelArts ``Session``.
        :param config_file: this parameter will be used if nothing is provided in pc
        :param username: username of iam user
        :param password: password of iam user
        :param access_key: temporary or permanent access key
        :param secret_key: temporary or permanent secret key
        :param security_token: used for temporary aksk
        :param region_name: region such as cn-north-1
        :param account: account of iam user
        :param project_id: when user inputs ak and sk not in notebook, project_id should be provided
        :param app_id: app id for roma
        :param app_token: app token for roma
        :param w3_account: w3 account for cloud user in roma
        :param w3_password: w3 password for cloud user in roma
        :param project_name: used to get token and project id by iam api when user inputs username and password
        """
        self.user_id = None
        self.security_token = security_token
        self.host = None
        self.region_name = region_name if region_name is not None else None

        if app_id and w3_account or app_token and w3_password:
            self._init_roma(region_name, app_id, app_token, w3_account, w3_password)
        else:
            self._init_config_file(config_file)
            self._init_username_password(account, username, password)
            self._init_region_name(region_name)
            self._init_domain_name()
            self._init_aksk(access_key, secret_key, username, password, config_file, project_name)
            self._init_obs_client()
            self.auth = constant.AKSK_AUTH
            self._init_project_id(project_id)

    def _init_roma(self, region_name, app_id, app_token, w3_account, w3_password):
        """
        :param region_name: region name
        :param app_id: app_id of roma application
        :param app_token: app_token of roma application
        :param w3_account: w3 account
        :param w3_password: w3 password
        """
        self.auth = constant.ROMA_AUTH
        self.host = Session.ROMA_HOST
        if self.host is None:
            raise ValueError("Roma Session is not supported.")
        self.project_id = constant.ROMA_PROJECT_ID

        region_name = region_name if region_name else os.environ.get("REGION_NAME")
        if not region_name:
            raise ValueError('Parameter region_name is needed.')
        self.region_name = region_name

        self.headers = {
            "Content-Type": constant.ROMA_CONTENT_TYPE,
            "Region": region_name,
            "App-ID": app_id,
            "W3-Account": w3_account
        }
        if app_token:
            self.headers["App-Token"] = app_token
        if w3_password:
            self.headers["W3-Password"] = w3_password

        # use sdk with notebook in roma
        if self._is_notebook_environ():
            access_key, secret_key, security_token, _ = read_ak_sk_from_secret()
            obs_endpoint = query_var(cfg_var="OBS_" + self.region_name, env_var="S3_ENDPOINT", remove_prefix=True)
            self.obs = OBSManagement(server=obs_endpoint,
                                     ak=access_key,
                                     sk=secret_key,
                                     security_token=security_token,
                                     region_name=self.region_name)
        # use sdk with pc in roma
        elif app_id and app_token:
            self.obs = OBSManagement(app_id=app_id, app_token=app_token, region_name=region_name)
        else:
            print("Warning: roma obs management can not operate, it need app_id and app_token.")
            self.obs = None

    def _init_obs_client(self):
        self.obs_client = OBS(server=self.obs_server,
                              ak=self.access_key,
                              sk=self.secret_key,
                              security_token=self.security_token)
        self.obs = OBSManagement(server=self.obs_server,
                                 ak=self.access_key,
                                 sk=self.secret_key,
                                 security_token=self.security_token,
                                 region_name=self.region_name)

    def _get_aksk_by_username(self, project_name):
        """
        Get aksk from username and password
        :param project_name: used to get token and project id by iam api
        """
        # The project name used to get token from iam should start with region_name or equal to region_name
        project_name = project_name if project_name else self.region_name
        project_name = project_name if project_name.startswith(self.region_name) else \
            self.region_name + "_" + project_name
        token, project_id = auth.authorize_by_token(username=self.username,
                                                    password=self.password,
                                                    account=self.account,
                                                    project_name=project_name,
                                                    endpoint=self.iam_server)
        res = auth.get_temporary_aksk_without_agency(token, self.iam_server)
        self.access_key = res.json()['credential']['access']
        self.secret_key = res.json()['credential']['secret']
        self.security_token = res.json()['credential']['securitytoken']
        self.project_id = project_id

    def _init_config_file(self, config_file):
        """
        :param config_file: ~/.modelarts/config.json
        """
        if config_file is not None:
            logging.warning("config_file is deprecated and will be removed in a future release. "
                            "Please use config_yaml.")
        if config_file:
            self.config_file = config_file
        elif os.path.exists(os.path.expanduser(MODELARTS_CONFIG)):
            self.config_file = os.path.expanduser(MODELARTS_CONFIG)
        else:
            self.config_file = None

    def _init_region_name(self, region_name):
        """
        Init region name
        :param region_name: region name
        :return:
        """
        if region_name:
            self.region_name = region_name
        elif "REGION_NAME" in os.environ:
            self.region_name = os.environ["REGION_NAME"]
        elif "S3_REGION" in os.environ:
            self.region_name = os.environ["S3_REGION"]
        else:
            if self.config_file is None or not os.path.exists(self.config_file):
                return

            with open(self.config_file) as f:
                config_json = json.load(f)
                self.region_name = config_json['clusters'][0]['cluster']['region']

    def _init_domain_name(self):
        """
        Init domain name for iam, obs and modelarts
        """
        # hsc environment, without notebook to use sdk
        if self.hcs_environment_valid:
            if os.environ.get("S3_ENDPOINT") or os.environ.get("OBS_ENDPOINT"):
                self.obs_server = remove_protocol(os.environ.get("S3_ENDPOINT") or os.environ.get("OBS_ENDPOINT"))
            if os.environ.get("IAM_ENDPOINT"):
                self.iam_server = remove_protocol(os.environ.get("IAM_ENDPOINT"))
            if os.environ.get("MODELARTS_ENDPOINT"):
                self.host = remove_protocol(os.environ.get("MODELARTS_ENDPOINT"))
        elif self._is_devserver_environ():
            self.obs_server = remove_protocol(os.environ.get("OBS_ENDPOINT") or os.environ.get("S3_ENDPOINT"))
            self.iam_server = remove_protocol(os.environ.get("IAM_ENDPOINT"))
            self.host = remove_protocol(os.environ.get("MODELARTS_ENDPOINT"))
        elif self._is_train_environ():
            self.obs_server = remove_protocol(os.environ.get("S3_ENDPOINT"))
        elif self._is_notebook_environ() and os.environ.get('IAM_ENDPOINT') is not None:
            self.obs_server = remove_protocol(os.environ.get("S3_ENDPOINT"))
            self.iam_server = remove_protocol(os.environ["IAM_ENDPOINT"])
            if "MODELARTS_ENDPOINT" in os.environ:
                self.host = remove_protocol(os.environ["MODELARTS_ENDPOINT"])
            else:
                self.host = remove_protocol(self.obs_server.replace("obs", "modelarts"))
        elif self.region_name in constant.SUPPORTED_REGION and not Config.is_empty():
            self.obs_server = Config.getenv("OBS_" + self.region_name)
            self.iam_server = Config.getenv("IAM_" + self.region_name)
            self.host = Config.getenv("MODELARTS_" + self.region_name)
        else:
            raise ValueError('Unrecognized region name of {}'.format(self.region_name))

    def _init_username_password(self, account, username, password):
        """
        :param account: iam account
        :param username: iam username
        :param password: iam password
        :return:
        """
        if password and (account or username):
            self.config_file_auth = False
            self.account = account
            self.username = username
            self.password = password
        else:
            if self.config_file is None or not os.path.exists(self.config_file):
                return

            self.config_file_auth = True
            with open(self.config_file) as f:
                config_json = json.load(f)
                user_info = config_json['users'][0]['user']
                self.account = user_info['account'] if 'account' in user_info else None
                self.username = user_info['username']
                self.password = user_info['password']

    def _init_aksk(self, access_key, secret_key, username, password, config_file, project_name):
        """
        Init aksk. There are four conditions in all.
        1. user input ak sk
        2. user input usename and password or config file
        3. user did not provide any information and use sdk in notebook
        4. user did not provide any information and use sdk in PC
        :param access_key: access key of user
        :param secret_key: secret key of user
        :param config_file: config file containing user name and password
        :param project_name: used to get token and project id by iam api when user inputs username and password
        """
        if access_key and secret_key:
            self.access_key = access_key
            self.secret_key = secret_key
        elif username and password or config_file:
            self._get_aksk_by_username(project_name)
        elif self._is_notebook_environ() or self._is_train_environ() or self._is_devserver_environ():
            self.access_key, self.secret_key, self.security_token, self.user_id = read_ak_sk_from_secret()
        else:
            self._get_aksk_by_username(project_name)

    def _init_project_id(self, project_id):
        """
        :param project_id: iam project_id
        :return:
        """
        if project_id:
            self.project_id = project_id
        elif "PROJECT_ID" in os.environ:
            if self._is_train_environ():
                # MA_IAM_PROJECT_ID is real PROJECT_ID in training env
                self.project_id = os.environ.get("MA_IAM_PROJECT_ID")
            else:
                self.project_id = os.environ["PROJECT_ID"]
        elif "project_id" in os.environ:
            self.project_id = os.environ["project_id"]
        if not self.project_id:
            raise Exception('project_id is required for init session')

    @staticmethod
    def _is_notebook_environ():
        """  Check if it is ma_notebook environment
        :return: True or False
        """
        return True if "NB_USER" in os.environ else False

    @staticmethod
    def _is_train_environ():
        """  Check if it is ma_train environment
        :return: True or False
        """
        return "AWS_SHARED_CREDENTIALS_FILE" in os.environ or "MA_JOB_DIR" in os.environ

    @staticmethod
    def _is_devserver_environ():
        """
        Check if sdk is used in vm and used to manage devcontainers
        :return: True or False
        """
        return True if ("CREDENTIAL_PROFILES_FILE" in os.environ or "AWS_CREDENTIAL_PROFILES_FILE"
                        in os.environ) and "DEV_SERVER_ID" in os.environ else False

    @classmethod
    def is_aksk_environ(cls):
        """ Judge if there is aksk information in the current environment.
        :return: True or False
        """
        return cls._is_notebook_environ() or cls._is_train_environ() or cls._is_devserver_environ()

    @staticmethod
    def set_domain(name, value):
        """
        Set value to environment variable.
        :param name: environment variable name.
        :param value: environment variable value.
        """
        if value is None:
            return

        if not value:  # empty string
            raise ValueError(f"Parameter {name} can not be empty.")

        if not value.startswith(HTTPS_PREFIX):
            if value.startswith(HTTP_PREFIX):
                raise ValueError(f"Parameter {value} should start with https.")
            value = f"{HTTPS_PREFIX}{value}"
        domain = value.split("//")[1]
        if re.match(constant.DOMAIN_PATTERN, domain):
            os.environ[name] = domain
        else:
            raise ValueError(f"Please input valid value of param {value}.")

    @classmethod
    def set_endpoint_from_config(cls, config_path, default_region=None, display=True):
        """
        Set sdk related service endpoints to environment variable from config file.
        :param config_path: the path of the config file.
        :param display: display successful info or not.
        """
        configs = load_config_yaml(config_path, default_region=default_region)
        display_name = configs.pop("display_name", None)
        cls.set_endpoint(**configs)
        if display_name is not None and display:
            logging.info("Successfully set up endpoint for %s.", display_name)
        return configs

    @classmethod
    def set_endpoint(cls, iam_endpoint: str = None, obs_endpoint: str = None,
                     modelarts_endpoint: str = None, region_name: str = None,
                     swr_endpoint: str = None, dli_endpoint: str = None,
                     console_endpoint: str = None, **kwargs):
        """
        Set sdk related service endpoint to environment variable.
        :param iam_endpoint: iam endpoint.
        :param obs_endpoint: obs endpoint.
        :param swr_endpoint: swr endpoint.
        :param dli_endpoint: dli endpoint
        :param console_endpoint: modelarts console endpoint
        :param modelarts_endpoint: modelarts endpoint.
        :param region_name: region name.
        """
        cls.set_domain('IAM_ENDPOINT', iam_endpoint)
        cls.set_domain('S3_ENDPOINT', obs_endpoint)
        cls.set_domain('OBS_ENDPOINT', obs_endpoint)
        cls.set_domain('MODELARTS_ENDPOINT', modelarts_endpoint)
        cls.set_domain("MODELARTS_CONSOLE_ENDPOINT", console_endpoint)
        cls.set_domain("DLI_ENDPOINT", dli_endpoint)
        if region_name:
            os.environ['REGION_NAME'] = region_name
        else:
            raise ValueError("region_name is invalid: {}.".format(region_name))

        cls.hcs_environment_valid = True
        if swr_endpoint is None:
            return

        if "swr-api" in swr_endpoint:
            cls.set_domain('IMAGE_REPO_URL', swr_endpoint.replace("swr-api", "swr"))
            cls.set_domain('SWR_ENDPOINT', swr_endpoint)
        elif "swr." in swr_endpoint:
            cls.set_domain('IMAGE_REPO_URL', swr_endpoint)
            cls.set_domain('SWR_ENDPOINT', swr_endpoint.replace("swr.", "swr-api."))
        else:
            cls.set_domain('IMAGE_REPO_URL', swr_endpoint)
            cls.set_domain('SWR_ENDPOINT', swr_endpoint)

    @auth_expired_handler
    def get_obs_client(self):
        """ Get OBS client for OBS operation
        :return: OBS client
        """
        return self.obs_client.get_obs_client()

    @auth_expired_handler
    def create_bucket(self, bucket):
        """ Create OBS bucket to use in relevant ModelArts interactions.
        :param bucket:
        :return: str: obs bucket
        """
        return self.obs_client.create_bucket(bucket_name=bucket,
                                             location=self.region_name)

    @auth_expired_handler
    def default_bucket(self, bucket=None):
        """
        Return the name of the default OBS bucket to use
        in relevant ModelArts interactions.
        :param bucket: obs bucket
        :return: str: The name of the default bucket,
        which is of the form: ``auto-job-{timestamp}``.
        """
        if bucket:
            return self.obs_client.create_bucket(bucket_name=bucket,
                                                 location=self.region_name)
        else:
            project_id_md5 = hashlib.md5(
                self.project_id.encode('utf-8')).hexdigest()[:8]
            default_bucket = 'modelarts-{}-{}'.format(self.region_name,
                                                      project_id_md5)
            return self.obs_client.create_bucket(bucket_name=default_bucket,
                                                 location=self.region_name)

    @auth_expired_handler
    def upload_data(self, bucket_path, path):
        """
        Upload local file or directory to obs.
        :param bucket_path: obs bucket path
        :param path: local file path, such as /opt/test/a.txt
        :return:
        """
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if isinstance(path, list):
            self.obs_client.put_multi_objects(bucket_path=bucket_path,
                                              local_file_paths=path)
        elif isinstance(path, str):
            if not os.path.exists(path):
                raise Exception("Path " + path + " does not exist!")
            if os.path.isdir(path):
                self.obs_client.put_directory(bucket_path=bucket_path,
                                              local_directory_path=path)
            elif os.path.isfile(path):
                self.obs_client.put_object(bucket_path=bucket_path,
                                           local_file_path=path)
            print(
                "Successfully upload file %s to OBS %s" % (path, bucket_path))
        else:
            raise Exception('local path should be list or string')

    @auth_expired_handler
    def download_data(self, bucket_path, path, subfiles_mode=False):
        """
        :param bucket_path: obs bucket path
        :param path: local file path, such as /opt/test/a.txt
        :param subfiles_mode: whether download files of directory or not
        :return:
        """
        if not os.path.exists(path) and not os.path.exists(
                os.path.abspath(os.path.dirname(path))):
            raise Exception("Path " + path + " does not exist!")
        is_directory = bucket_path.endswith('/')
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if is_directory:
            object_name = bucket_path.split('/', 1)[1] + '/'
            obs_objects = self.obs_client.list_all_objects(
                bucket_path.split('/', 1)[0], object_name)
            is_exist = any(obj.startswith(object_name) for obj in obs_objects)
            if not is_exist:
                raise Exception(
                    "OBS bucket path does not exist, please check it! ")

            bucket_path = bucket_path.rstrip('/')
            local_storage_path = path.rstrip('/')
            if not subfiles_mode:
                local_storage_path = local_storage_path + '/' + \
                                     bucket_path.split('/')[-1]
            self.obs_client.download_directory(bucket_path=bucket_path,
                                               local_storage_path=local_storage_path)
        else:
            self.obs_client.download_object(bucket_path=bucket_path,
                                            local_file_path=path)
        print("Successfully download file %s from OBS to local %s" % (
            bucket_path, path))

    @auth_expired_handler
    def delete_bucket(self, bucket):
        """
        :param bucket: obs bucket
        :return:
        """
        if self.obs_client.delete_objects(bucket):
            self.obs_client.delete_bucket(bucket)

    @auth_expired_handler
    def create_directory(self, bucket, directory):
        """
        :param bucket: obs bucket
        :param directory: local directory, such as /opt/test
        :return:
        """
        self.obs_client.create_directory(bucket, directory)


def remove_protocol(endpoint):
    """
    Remove protocol in endpoint
    :param endpoint: endpoint to be processed
    """
    if endpoint is None:
        return endpoint

    if endpoint.startswith(HTTPS_PREFIX):
        return endpoint[len(HTTPS_PREFIX):]
    elif endpoint.startswith(HTTP_PREFIX):
        return endpoint[len(HTTP_PREFIX):]
    else:
        return endpoint


def get_default_endpoint(default_region=None):
    if default_region is None:
        default_region = os.environ.get("REGION_NAME")
    if default_region is None:
        return dict()
    iam_endpoint = query_var(cfg_var=f"IAM_{default_region}", env_var="IAM_ENDPOINT")
    obs_endpoint = query_var(cfg_var=f"OBS_{default_region}", env_var="S3_ENDPOINT")
    modelarts_endpoint = query_var(cfg_var=f"MODELARTS_{default_region}", env_var="MODELARTS_ENDPOINT")
    swr_endpoint = query_var(cfg_var=f"SWR_{default_region}", env_var="SWR_ENDPOINT")
    dli_endpoint = query_var(cfg_var=f"DLI_{default_region}", env_var="DLI_ENDPOINT")
    console_endpoint = query_var(cfg_var=f"CONSOLE_HWC", env_var="MODELARTS_CONSOLE_ENDPOINT")
    return dict(iam_endpoint=iam_endpoint,
                obs_endpoint=obs_endpoint,
                modelarts_endpoint=modelarts_endpoint,
                swr_endpoint=swr_endpoint,
                console_endpoint=console_endpoint,
                dli_endpoint=dli_endpoint
                )
