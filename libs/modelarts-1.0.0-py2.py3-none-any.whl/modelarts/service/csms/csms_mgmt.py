import json
from concurrent.futures import ThreadPoolExecutor, as_completed

from .csms_client import CsmsSecretsClient

DEFAULT_THREAD_NUMS = 4


class CsmsManagement:

    def __init__(self, session):
        self.session = session
        self.csms_client = CsmsSecretsClient(session)

    @classmethod
    def get_version_ids_list(cls, version_ids):
        version_id_list = []

        if not version_ids:
            return version_id_list
        if isinstance(version_ids, str):
            version_id_list.append(version_ids)
        elif isinstance(version_ids, list):
            version_id_list += version_ids
        else:
            raise TypeError(
                f"Got error type '{type(version_ids)}' of version_ids, 'list' or 'str' type is required.")

        return version_id_list

    @classmethod
    def sort_secrets_by_version_id(cls, secrets):
        def get_num_from_version_id(version_id):
            try:
                return int(version_id.lstrip("v"))
            except ValueError as e:
                raise e

        return sorted(secrets, key=lambda x: get_num_from_version_id(x.get("version_id")), reverse=True)

    def list_secrets(self, limit=50, marker=None, event_name=None):
        resp = self.csms_client.list_secrets(limit, marker, event_name)

        secret_name_list = []
        if "secrets" not in resp or not isinstance(resp.get("secrets"), list):
            return secret_name_list

        for secret_meta_info in resp.get("secrets"):
            if secret_meta_info.get("name") is not None:
                secret_name_list.append(secret_meta_info.get("name"))
        return secret_name_list

    def list_secret_versions(self, secret_name, limit=50, marker=None):
        return self.csms_client.list_secret_versions(secret_name, limit, marker)

    def get_all(self, secret_name, version_id=None):
        """ get all secret key-value pair with specific secret_name
        :secret_name string: secret name
        :version_id string | list: version id or list of version id, default is None. if a specific version id was set,
        only query key-value pairs under the version id. otherwise, query key-value pairs under all version ids.
        Candidate version ids can be queried by list_secret_versions.

        :return: e.g. [{"version_id": "v1", "secrets": {"key": "value", ...}}, ...]
        """
        version_id_list = CsmsManagement.get_version_ids_list(version_id)

        if not version_id_list:
            version_metadatas = self.list_secret_versions(secret_name)
            version_id_list = [version_meta.get("id") for version_meta in
                               version_metadatas.get("version_metadatas", [])]

        secrets = []
        with ThreadPoolExecutor(max_workers=DEFAULT_THREAD_NUMS) as executor:
            job_list = []

            for vid in version_id_list:
                future = executor.submit(self.csms_client.get_secret_with_version_id, secret_name, vid)
                job_list.append(future)

            for future in as_completed(job_list):

                secret_metadata = future.result().get("version", {})
                query_version_id = secret_metadata.get("version_metadata", {}).get("id")
                if query_version_id:
                    secret = {"version_id": query_version_id or vid,
                              "secrets": json.loads(secret_metadata.get("secret_string"))}
                    secrets.append(secret)

            return CsmsManagement.sort_secrets_by_version_id(secrets)

    def get(self, secret_name, secret_key, version_id='latest'):
        """ get secret value with specific secret_name, secret_key and version_id
        :secret_name string: secret name
        :secret_key string: secret_key
        :version_id string: version_id, default is 'latest'.
                            Candidate version ids can be queried by list_secret_versions.

        :return: secret value, string type
        """
        if not isinstance(version_id, str):
            raise TypeError(f"Got error type '{type(version_id)}' of version_id, string type is required")

        # csms client does not support query specific secret key, so get all key-value pairs firstly
        secrets = self.get_all(secret_name, version_id)
        if secrets:
            return secrets[0].get("secrets", {}).get(secret_key)
        return None
