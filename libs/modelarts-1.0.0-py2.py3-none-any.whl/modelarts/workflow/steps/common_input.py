from abc import ABC

from modelarts.workflow.core.data import AbstractData, AbstractDataPlaceholders, AbstractDataConsumption
from modelarts.workflow.core.steps import AbstractInput
from modelarts.workflow.data.obs import OBSPath
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.data.data_selector import DataConsumptionSelector


class CommonInput(AbstractInput, ABC):
    def __init__(self, name, data):
        """

        Args:
            name (str): input name
            data (AbstractInputData): input data, type is AbstractInputData
        """
        super(CommonInput, self).__init__(name)
        self._declared_data = data
        self._actual_data = None

    def to_definition_json(self):
        result = {
            "name": self.name,
            "data": self._declared_data.ref(),
            "type": self.data_type()
        }
        return result

    def data_type(self):
        return self._declared_data.type()

    def get_snapshot(self):
        return {
            "name": self.name,
            "data": self._actual_data.get_snapshot()
        }

    def evaluate(self):
        if isinstance(self._declared_data, (AbstractDataPlaceholders, AbstractDataConsumption, DataConsumptionSelector)):
            self._actual_data = self._declared_data.consume()
        else:
            self._actual_data = self._declared_data
        self._evaluate_path()

    def _evaluate_path(self):
        if isinstance(self._actual_data, OBSPath):
            if isinstance(self._actual_data.obs_path, Storage):
                self._actual_data.obs_path = self._actual_data.obs_path.path

    @property
    def data(self):
        return self._actual_data

    def extract_data_placeholder(self):
        if isinstance(self._declared_data, AbstractDataPlaceholders):
            return self._declared_data
        return None

    def extract_data(self):
        if isinstance(self._declared_data, AbstractData):
            return self._declared_data
        return None

    @property
    def declared_data(self):
        return self._declared_data
