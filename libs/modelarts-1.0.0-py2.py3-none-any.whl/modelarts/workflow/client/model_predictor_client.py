import abc

from modelarts.model import (
    ModelApiAKSKImpl,
    ModelApiROMAImpl,
    LocalModel,
)
from modelarts.predictor import (
    PredictorApiAKSKImpl,
    PredictorApiROMAImpl,
    LocalPredictor,
)
from modelarts.constant import (
    AKSK_AUTH
)
from modelarts.workflow.resource.workspace import Workspace


class ModelPredictorClient(abc.ABC):
    """
    Class for Client which makes ModelArts service calls.

    Args:
        session : building interactions with cloud service.
        environment: a conda virtual environment
        is_publish: set True to import this model in the model management
        is_local_service: set True to deploy local service
        port: the local service port
        model_local_path: the model local path
    """
    def __init__(self, session, environment=None, is_publish=True,
                 is_local_service=False, port=None, model_local_path=None):
        self.model_instance = None
        self.session = session
        self.environment = environment
        self.__get_model_instance(environment, is_publish)
        self.__get_predictor_instance(is_local_service, port, model_local_path)

    def __get_model_instance(self, environment, is_publish):
        if is_publish:
            if self.session.auth == AKSK_AUTH:
                self.model_instance = ModelApiAKSKImpl(self.session, environment)
            else:
                self.model_instance = ModelApiROMAImpl(self.session, environment)
        else:
            self.model_instance = LocalModel(self.session, environment)

    def __get_predictor_instance(self, is_local_service, port, model_local_path):
        if is_local_service:
            self.predictor_instance = LocalPredictor(port, model_local_path)
        else:
            if self.session.auth == AKSK_AUTH:
                self.predictor_instance = PredictorApiAKSKImpl(self.session, service_id=None)
            else:
                self.predictor_instance = PredictorApiROMAImpl(self.session, service_id=None)

    def create_modelarts_model(self, create_model_body):
        if not create_model_body:
            raise ValueError("create_model_body is empty")
        create_model_body["workspace_id"] = Workspace.instance().workspace_id
        self.model_instance.create_model_body = create_model_body
        resp = self.model_instance.create_modelarts_model()
        model_id = resp.get("model_id") or resp.get("_model_id")
        if model_id is None:
            raise KeyError("the response has no model_id field")
        return model_id

    def get_model_list(self, **kwargs):
        return self.model_instance.get_model_list(workspace_id=Workspace.instance().workspace_id, **kwargs)

    def get_model_id(self, model_name, model_version):
        resp = self.get_model_list(model_name=model_name)
        # if the count of model with model_name is equal to 0
        if resp.get("count") == 0:
            raise ValueError("There is no model with the model name: {} ".format(model_name))
        # else the count of model with model_name is not equal to 0
        else:
            model_id = None
            for item_dict in resp.get("models"):
                if item_dict.get("model_name") == model_name \
                        and item_dict.get("model_version") == model_version:
                    model_id = item_dict.get("model_id")
            if not model_id:
                raise ValueError("There is no model with the model name: {}, model version: "
                                 "{}".format(model_name, model_version))
            return model_id

    def get_model_info(self, model_id):
        if not model_id:
            raise ValueError("model_id is empty")
        return self.model_instance.get_model_info_list(model_id=model_id)

    def get_model_specific_info(self, model_id, param):
        if param is None:
            raise ValueError("the param is null")
        resp = self.get_model_info(model_id)
        param_value = resp.get(param)
        if param_value is None:
            raise KeyError("the response has no {} field".format(param))
        return param_value

    def get_model_state(self, model_id):
        state = self.get_model_specific_info(model_id, "model_status")
        return state

    def get_model_name(self, model_id):
        model_name = self.get_model_specific_info(model_id, "model_name")
        return model_name

    def deploy_service(self, deploy_service_body):
        if not deploy_service_body:
            raise ValueError("deploy_service_body is empty")
        deploy_service_body["workspace_id"] = Workspace.instance().workspace_id
        self.model_instance.deploy_service_body = deploy_service_body
        self.model_instance.deploy_modelarts_predictor()
        service_id = self.model_instance.service_id
        if service_id is None:
            raise KeyError("the response has no service_id field")
        return service_id

    def update_service(self, service_id, request_body):
        if not service_id:
            raise ValueError("service_id is empty")
        if not request_body:
            raise ValueError("request_body is empty")
        self.predictor_instance.update_service_config(service_id, **request_body)

    def get_service_info(self, service_id):
        if not service_id:
            raise ValueError("service_id is empty")
        self.model_instance.service_id = service_id
        return self.model_instance._get_service_info()

    def get_service_specific_info(self, service_id, param):
        if param is None:
            raise ValueError("the param is null")
        resp = self.get_service_info(service_id)
        param_value = resp.get(param)
        if param_value is None:
            raise KeyError("the response has no {} field".format(param))
        return param_value

    def get_service_state(self, service_id):
        state = self.get_service_specific_info(service_id, "status")
        return state

    def get_service_name(self, service_id):
        service_name = self.get_service_specific_info(service_id, "service_name")
        return service_name

    def get_service_access_addresses(self, service_id):
        access_addresses = {}
        service_info = self.get_service_info(service_id)
        access_addresses["access_address"] = service_info.get("access_address", "")
        service_config = service_info.get("config", [])
        if service_config:
            access_addresses["cluster_inner_access_address"] = service_config[0].get("cluster_inner_access_address", "")
        return access_addresses


class ApiException(Exception):
    def __init__(self, code=500, message=""):
        self.code = code
        self.message = message

    def __str__(self):
        return "err_code: {}, err_message: {}".format(self.code, self.message)
