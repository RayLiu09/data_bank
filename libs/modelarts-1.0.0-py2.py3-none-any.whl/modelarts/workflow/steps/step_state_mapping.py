from modelarts.workflow.core.state import StepState


class StepStateMapping:
    """
    Instance state to step state transition
    """
    @staticmethod
    def get_step_state(instance_state, mapping_dic):
        """
        get step state according to instance state and mapping dict
        Args:
            instance_state (str): instance state
            mapping_dic (Dict): mapping of instance state to step state

        Returns: step state

        """
        if not instance_state or not mapping_dic:
            raise ValueError("Neither instance_state nor mapping_dic are allowed to be empty!")
        step_state = mapping_dic.get(instance_state)
        return StepState.Failed if step_state is None else step_state
