"""
Description: This script is provided to toolkit to manage v2 training job.
Author: ModelArts SDK Team
"""

import argparse
import ast
import logging
import sys

from modelarts.scripts.util import get_session
from modelarts.estimatorV2 import Estimator

logging.getLogger().setLevel(logging.INFO)
QUERY_TRAIN_FLAVORS_ACTION = "query_flavor"
STOP_TRAIN_JOB_ACTION = "stop_job"


def query_train_flavors(session):
    """
    Query train flavors and print it. The toolkit can read it from stdout.
    :param session: modelarts session including authentication information
    """
    train_flavors = Estimator.get_spec_list(session)
    if "flavors" not in train_flavors:
        logging.info("flavor_list:")
        return
    flavor_list = []
    for flavor in train_flavors["flavors"]:
        flavor_list.append({"train_instance_type": flavor["flavor_id"],
                            "max_train_instance_count": flavor["flavor_info"]["max_num"]})
    logging.info("flavor_list:%s", flavor_list)


def parse_input_parameters(args_param):
    """
    Parse user input parameters
    :return: a structure contains all the parameters
    """
    parser = argparse.ArgumentParser(description="This script is used for toolkit to manage training v2 job.")
    # 1. These parameters are used for session initialization
    parser.add_argument("--region_name", type=str, required=True)
    parser.add_argument("--is_roma", type=ast.literal_eval, required=True)
    # for hwc session initialization
    parser.add_argument("--access_key", type=str, required=False)
    parser.add_argument("--secret_key", type=str, required=False)
    # for roma session initialization
    parser.add_argument("--w3_account", type=str, required=False)
    parser.add_argument("--app_id", type=str, required=False)
    parser.add_argument("--app_token", type=str, required=False)

    # 2. This parameter is used to decide which action will be executed. All the supported actions are:
    # query_flavor: query which flavors are supported by training
    # stop_job: stopping the training job
    parser.add_argument("--action", type=str, required=True, help="one of ['query_flavor', 'stop_job']")

    # 3. job_id
    parser.add_argument("--job_id", type=str, required=False)

    return parser.parse_args(args_param)


if __name__ == "__main__":
    args = parse_input_parameters(sys.argv[1:])
    session = get_session(args)
    # submit training job
    if args.action == QUERY_TRAIN_FLAVORS_ACTION:
        query_train_flavors(session)
    elif args.action == STOP_TRAIN_JOB_ACTION:
        Estimator.control_job_by_id(session=session, job_id=args.job_id)
    else:
        logging.info("Not supported action.")
