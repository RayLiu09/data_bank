"""
A ModelArts Model can create model, deploy model service, get model info and list,and delete model.
"""
import time
import sys
import os
import re
import io
import json
import uuid
import copy
import shutil
import subprocess
from datetime import datetime, timedelta
from abc import ABCMeta, abstractmethod
from json import JSONEncoder
import tempfile

import requests
from requests import RequestException
from semantic_version import Version

from .predictor import Predictor
from .config.auth import auth_by_apig, auth_by_roma_api
from .util.config import Config
from .util.secret_util import auth_expired_handler
from .environment import Environment
from .environment.conda_env import CondaDependencies, get_package_name, get_package_version
from . import constant
from .compute import CondaEnv
from .config.model_config import Dependencies
from .util import file_utils
from modelarts.util.string_util import query_var


class Model(object):
    """
    A ModelArts Model that can be created model, deployed model service,
    got model info and list, and deleted model and service endpoint.
    """

    def __init__(self, session, model_id=None, publish=True, environment=None, wait=True,
                 source_location_type=constant.MODEL_OBS_LOCATION, **kwargs):
        """
        Initialize a model, determine the model authorize type.
        :param session: Building interactions with Cloud service.
        :param model_id: model in ModelArts.
        :param publish: if publish this model, False for local model
        :param environment: a conda virtual environment
        :param kwargs: Create model body params
        """
        self.service_id = None
        self.model_instance = None
        self.session = session
        self.model_id = model_id
        self.publish = publish
        self.wait = wait
        source_location = kwargs.get("source_location")
        if source_location is not None and source_location.startswith(constant.OBS_HEAD_FORMAT):
            kwargs["source_location"] = source_location.replace(constant.OBS_HEAD_FORMAT, "/")
        self.environment = environment
        model_type = kwargs.get("model_type")
        if model_type == "Image":
            source_location_type = constant.MODEL_IMAGE_LOCATION
        self.source_location_type = source_location_type

        self.__model_id_verify(kwargs)
        self.__get_model_instance(environment, publish)

        if model_id is None and kwargs != {}:
            self.__create_model(kwargs, source_location_type)

    def __model_id_verify(self, model_params):
        """
        Verify model id.
        """
        if self.model_id is not None and model_params != {}:
            raise Exception(
                "The model_id and model_params can't input at same time for "
                "initializing model instance.")
        if self.model_id is None and model_params == {}:
            raise Exception("The model_id or model_params must input one for "
                            "initializing model instance.")

    def __get_model_instance(self, environment, publish):
        """
        Get a model instance according to the user authentication method.
        :param environment: a conda virtual environment
        :param publish: if publish this model.
        """
        if publish:
            self.model_instance = ModelApiAKSKImpl(self.session, environment) \
                if self.session.auth == constant.AKSK_AUTH else ModelApiROMAImpl(self.session, environment)
        else:
            self.model_instance = LocalModel(self.session, environment)

    def __set_model_attribute(self, model_params):
        """ set model attribute, model parameters
        :param model_params: model params
        """

        def get_value(_model_params, params):
            return _model_params[params] if params in _model_params else None

        self.model_name = get_value(model_params, 'model_name')
        self.model_version = get_value(model_params, 'model_version')
        self.source_location = get_value(model_params, 'source_location')
        self.source_job_id = get_value(model_params, 'source_job_id')
        self.source_job_version = get_value(model_params, 'source_job_version')
        self.source_type = get_value(model_params, 'source_type')
        self.model_type = get_value(model_params, 'model_type')
        self.description = get_value(model_params, 'description')
        self.execution_code = get_value(model_params, 'execution_code')
        self.input_params = get_value(model_params, 'input_params')
        self.output_params = get_value(model_params, 'output_params')
        self.dependencies = get_value(model_params, 'dependencies')
        self.model_metrics = get_value(model_params, 'model_metrics')
        self.apis = get_value(model_params, 'apis')

    def __create_model(self, model_params, source_location_type):
        """ creating model interface
        :return: dict: model_id that creating successfully
        """
        self.model_instance.check_model_params(self.session.region_name, model_params, source_location_type)
        if self.model_instance.publish:
            self.__model_create_resp = self.model_instance.create_modelarts_model(wait=self.wait)
            self.model_id = self.model_instance.model_id
            model_info_list_resp = self.get_model_info(model_id=self.model_id)
            self.__set_model_attribute(model_params=model_info_list_resp)
        else:
            self.model_instance.create_modelarts_model(wait=self.wait)
            self.model_id = self.model_instance.model_id
            print("Create local model successfully, model_id is:" + self.model_id)

    def deploy_predictor(self, **kwargs):
        """ Deploying model predictor interface
        :param kwargs: Deploying predictor body params
        :returns: dict: service_id that creating successfully
        """
        self.model_instance.check_params(self.session.region_name, **kwargs)
        model_deploy_resp = self.model_instance.deploy_modelarts_predictor(wait=kwargs.get("wait", True))
        self.service_id = self.model_instance.service_id
        return model_deploy_resp

    @classmethod
    def configure_tf_infer_environ(cls, device_type):
        """Configure tensorflow8 local inference environment
        :param device_type: GPU or CPU
        """
        if device_type in {'CPU', 'GPU'}:

            current_path = os.path.split(os.path.realpath(__file__))[0]
            config_envs = r"bash {basepath}/local/tensorflow8/" \
                          r"tf_local_infer_envs.sh {type} &".format(
                basepath=current_path, type=device_type)
            os.system(config_envs)

            flag_file = "{basepath}/local/tensorflow8/.configure.flag".format(
                basepath=current_path)
            configure_times = 0

            print("Configuring tensorflow8 local inference environment ... ")
            while not os.path.isfile(flag_file):
                configure_times = configure_times + 1
                time.sleep(float(constant.LOCAL_INFER_WAIT_SEC))
                if configure_times == int(constant.LOCAL_INFER_RETRY_TIMES):
                    if os.path.isfile(flag_file):
                        os.remove(flag_file)
                    raise Exception(
                        "fail to configure tensorflow8 local inference "
                        "environment, check your device.")

            if os.path.isfile(flag_file):
                os.remove(flag_file)
            print(
                "Successfully configure tensorflow8 local inference environment")
        else:
            raise Exception("please input right device type, GPU or CPU")

    @classmethod
    def deploy_local_predictor(cls, model_location, engine_type, model_envs):
        """ using local model location, to deploy service
        :param model_location: model location
        :param engine_type: engine type
        :param model_envs: model environment
        """
        if not os.path.exists(os.path.realpath(model_location)):
            raise FileNotFoundError(f"Parameter model_location {model_location} does not exist.")

        def curl_local_service(local_ip):
            local_url = "http://" + local_ip + '/health'
            try:
                requests.get(local_url, timeout=4,
                             proxies={"http": None, "https": None})
                return True
            except RequestException:
                return False

        if engine_type.lower() not in constant.ENGINE_TYPE_SET:
            raise Exception(
                "The engine %s does not support local inference, "
                "please choose one of %s" % (
                    engine_type.lower(),
                    constant.ENGINE_TYPE_SET))
        for key, value in model_envs.items():
            os.environ[key] = value

        current_path = os.path.split(os.path.realpath(__file__))[0]
        stop_port = r"bash {basepath}/local/stop_port.sh  {port}".format(
            basepath=current_path,
            port=constant.LOCAL_INFER_PORT)
        os.system(stop_port)

        if engine_type.lower() in {'xgboost', 'scikit_learn'}:
            if engine_type.lower() == 'xgboost':
                engine_type = 'XGBoost'
            if engine_type.lower() == 'scikit_learn':
                engine_type = 'Scikit_Learn'

            infer_run = r"bash {basepath}/local/{engine}/run.sh {location}" \
                        r" {port} {model_type} &".format(basepath=current_path,
                                                         engine='xgboost_sklearn',
                                                         location=model_location,
                                                         port=constant.LOCAL_INFER_PORT,
                                                         model_type=engine_type)
        else:
            infer_run = r"bash {basepath}/local/{engine}/run.sh {location}" \
                        r" {port} &".format(basepath=current_path,
                                            engine=engine_type.lower(),
                                            location=model_location,
                                            port=constant.LOCAL_INFER_PORT)
        os.system(infer_run)
        local_deploy_times = 0
        local_service_ip = constant.MODEL_LOCAL_HOST + ":" + str(
            constant.LOCAL_INFER_PORT)
        local_log_path = os.path.expanduser(constant.LOCAL_INFER_LOG)
        print("Deploying the local service ...")
        while not curl_local_service(local_service_ip):
            print("Reconnecting...")
            local_deploy_times = local_deploy_times + 1
            time.sleep(float(constant.LOCAL_INFER_WAIT_SEC))
            if local_deploy_times == int(constant.LOCAL_INFER_RETRY_TIMES):
                raise Exception(
                    "Deploy local service abnormal, please check the service "
                    "log %s" % local_log_path)
        print("Successfully deployed the local service.")

    def deploy_transformer(self, **kwargs):
        """  Deploying model transformer interface
        :param kwargs: Deploying predictor body params
        :return: dict: service_id that creating successfully
        """
        return self.deploy_predictor(**kwargs)

    @classmethod
    def get_model_list(cls, session, **kwargs):
        """ return user's current models information, dict type
        :param session:  session with cloud service
        :param kwargs: index params
        :return:  model list
        """
        model_instance = ModelApiAKSKImpl(session) if session.auth == constant.AKSK_AUTH else ModelApiROMAImpl(session)
        return model_instance.get_model_list(**kwargs)

    @classmethod
    def get_model_object_list(cls, session, is_show=True, **kwargs):
        """ return user's current models object,  Model type
        :param session: session with cloud service
        :param is_show: whether output in console
        :param kwargs: index params
        :return: model list
        """
        index_surplus_set = set(kwargs.keys()) - constant.MODEL_INDEX_PARAMS
        if len(index_surplus_set) != 0:
            raise ValueError('The input params: %s for model '
                             'index is surplus' % index_surplus_set)
        model_object_list = []
        model_list_info = Model.get_model_list(session, **kwargs)
        model_init_count = 0

        for one_model in model_list_info['models']:
            model_object_list.append(Model(session, one_model['model_id']))
            model_init_count = model_init_count + 1
            if model_init_count > int(constant.USER_TRAFFIC_LIMIT):
                break
        if is_show:
            print(json.dumps(model_list_info, indent=1))

        return model_object_list

    @classmethod
    def get_model_by_id(cls, session, model_id):
        """ return model object of model_id
        :param session:  session with cloud service
        :param model_id: model id
        :return: model object
        """
        return Model(session, model_id)

    @classmethod
    def delete_model_by_id(cls, session, model_id):
        """ delete model object by model_id
        :param session: session with cloud service
        :param model_id: model id
        """
        model_instance = Model(session, model_id)
        model_instance.delete_model(model_id=model_id)

    def get_model_info(self, model_id=None):
        """ return model information list of the
        input model_id or the last created model
        :param model_id: model id
        :return: model information
        """
        if model_id is None:
            model_id = self.model_id
        return self.model_instance.get_model_info_list(model_id=model_id)

    def delete_model_endpoint(self, model_id=None, service_id=None):
        """ delete model and service which deploy from the model
        :param model_id: model id
        :param service_id: service id
        """
        if model_id is None or service_id is None:
            model_id = self.model_id
            service_id = self.service_id

        if service_id is None:
            raise ValueError('The model %s is not deployed as a service, '
                             'can not delete the model endpoint.' % model_id)

        self.model_instance.delete_model_endpoint(model_id=model_id,
                                                  service_id=service_id)

    def delete_model(self, model_id=None):
        """ delete model
        :param model_id: model id
        """
        if model_id is None:
            model_id = self.model_id
        resp = self.model_instance.delete_model(model_id=model_id)
        if self.publish:
            if self.session.auth == constant.AKSK_AUTH or \
                    self.session.auth == constant.ROMA_AUTH:
                if len(resp['delete_success_list']) == 1:
                    print("Successfully delete the model %s ." % model_id)
                else:
                    print(resp['delete_failed_list'][0]['error_msg'])

            else:
                if len(resp.delete_success_list) == 1:
                    print("Successfully delete the model %s ." % model_id)
                else:
                    print(resp.delete_failed_list[0]['error_msg'])

    def get_service_id(self):
        """get service id of service that the current model object deployed
        """
        return self.service_id

    def get_model_id(self):
        """ get model id of the model object
        """
        return self.model_id

    def delete_service(self, service_id=None):
        """ delete local or service
        :return:
        """
        if service_id is None:
            service_id = self.service_id
        return self.model_instance.delete_service(service_id=service_id)

    def publish_model(self, obs_location=None):
        """
        Publish a local model.
        :param obs_location: obs path.
        """
        if self.model_instance.publish:
            raise Exception("This model has been published.")
        local_model_instance = self.model_instance
        model_param = copy.deepcopy(local_model_instance.create_model_body)
        try:
            self.model_instance.prepare_publish_model_param(obs_location, self.source_location_type)
            self.__get_model_instance(self.environment, True)
            self.__create_model(local_model_instance.create_model_body, constant.MODEL_OBS_LOCATION)
        except Exception:
            local_model_instance.create_model_body = model_param
            self.model_instance = local_model_instance
            raise
        else:
            self.publish = True
            print("Successfully publish a model and model id is " + self.model_id)

    def validate_config_json(self):
        """
        Validate config.json.
        """
        if not self.publish:
            model_instance = self.model_instance
            config_json_path = os.path.join(model_instance.create_model_body['source_location'], 'config.json')
            config_json_content = model_instance.get_config_json_content(config_json_path)
            if config_json_content is None:
                raise Exception("No such file {}.".format(config_json_path))
            else:
                self.model_instance.validate_config_json(config_json_content)


class ModelApiBase(metaclass=ABCMeta):
    """ A ModelArts Model that can be created model,
    deployed model service and delete model endpoint.
    """

    def __init__(self, session, environment=None, publish=True):
        """
        Initialize a ModelArts Model instance.
        """
        self.current_path = os.path.split(os.path.realpath(__file__))[0]
        self.session = session
        self.environment = environment
        self.publish = publish
        self.matched_runtime = None
        self.env_builder = CondaEnv()
        self.tmp_local_path = None
        self.free_port = None
        self.original_source_location = None
        self.local_predictor = None
        self.is_local = False
        self.model_id = None
        self.service_id = None

    def check_model_params(self, region_name, model_param, source_location_type):
        """
        Check creating model params.
        :param region_name: region name.
        :param model_param: parameters to create a model.
        :param source_location_type: source location type.
        """
        config_set = set(model_param.keys()) - constant.MODEL_CREATE_PARAMS
        if len(config_set) == 0:
            self.__prepare_model_files(model_param, source_location_type)
            self.__generate_model_params(region_name, model_param, source_location_type)
            if source_location_type != constant.MODEL_IMAGE_LOCATION:
                self.__convert_environment()
        else:
            raise ValueError('The input params: %s for creating model '
                             'is surplus' % config_set)

    @staticmethod
    def get_config_json_content(config_json_path):
        """
        Get the content of config.json
        :param config_json_path: path of config.json.
        :return content of config.json or None
        """
        if not os.path.exists(config_json_path):
            return None
        config_json_content = None
        with open(config_json_path, 'r') as f:
            try:
                config_json_content = json.load(f)
            except json.JSONDecodeError as err:
                raise ValueError("config.json is not a valid json file. Error is: {}".format(err))
        return config_json_content

    def get_runtime(self, config_json_content):
        """
        Get runtime from user input or config.json file
        :param config_json_content: content of config.json
        :return runtime
        """
        runtime = None
        if 'runtime' in self.create_model_body:
            runtime = self.create_model_body['runtime']
        if config_json_content is not None:
            if self.is_not_empty('runtime', config_json_content):
                if runtime is None:
                    runtime = config_json_content['runtime']
        return runtime

    def get_dependencies(self, config_json_content):
        """
        Get dependencies from user input or config.json file
        :param config_json_content: content of config.json
        :return dependencies
        """
        dependencies = None
        if 'dependencies' in self.create_model_body:
            dependencies = self.create_model_body['dependencies']
        if config_json_content is not None:
            if self.is_not_empty('dependencies', config_json_content):
                # if no dependencies in user input, use it from config.json
                if dependencies is None:
                    dependencies = config_json_content['dependencies']
        return dependencies

    def convert_environment_to_runtime(self, model_type):
        """
        Convert the conda environment to runtime
        :param model_type: AI model type, for example, TensorFlow, PyTorch
        """
        cd = self.environment.conda
        python_version = Version.coerce(cd.get_python_version())
        python_version_str = "{}.{}".format(python_version.major, python_version.minor)
        python_str = "python" + python_version_str
        if python_str not in constant.INFER_SUPPORT_RUNTIME_DICT[model_type]:
            raise Exception("Wrong python version in your conda_packages. See supported python versions of {} "
                            "as below: {}".format(model_type, constant.INFER_SUPPORT_RUNTIME_DICT[model_type].keys()))
        ai_framework_alias = [model_type.lower()]
        if model_type.lower() in constant.INFER_FRAMEWORK_ALIAS:
            ai_framework_alias = constant.INFER_FRAMEWORK_ALIAS[model_type.lower()]
        model_package = cd.get_framework_package(ai_framework_alias)
        model_package_version = Version.coerce(get_package_version(model_package))
        model_package_version_str = "{}.{}".format(model_package_version.major, model_package_version.minor)
        model_str = model_package_version_str
        if "gpu" in get_package_name(model_package):
            model_str = model_package_version_str + '-' + 'gpu'
        supported_versions = set()
        if model_str not in constant.INFER_SUPPORT_RUNTIME_DICT[model_type][python_str]:
            for version in constant.INFER_SUPPORT_RUNTIME_DICT[model_type][python_str].keys():
                supported_versions.add(model_type + '-' + re.findall(r"\d+\.?\d*", version)[0])
            raise Exception("Wrong {} version in your pip_packages. See supported {} versions of {} as bellow: {}"
                            .format(model_type, model_type, python_str, supported_versions))
        self.matched_runtime = constant.INFER_SUPPORT_RUNTIME_DICT[model_type][python_str][model_str]

    def convert_environment_to_dependencies(self):
        """
        Convert environment to dependencies.
        """
        dependencies = []
        packages = []
        for package in self.environment.conda.pip_packages:
            package_name = get_package_name(package)
            if package_name.lower() == self.create_model_body['model_type'].lower():
                continue
            package_version = get_package_version(package)
            if ">=" in package:
                restraint = "ATLEAST"
            elif "<=" in package:
                restraint = "ATMOST"
            elif "==" in package:
                restraint = "EXACT"
            else:
                restraint = ""

            _package = {
                "package_name": package_name,
                "package_version": package_version,
                "restraint": restraint
            }
            dependencies.append({
                "installer": "pip",
                "packages": [_package]
            })
            packages.append(_package)

        if len(packages) >= 1:
            self.create_model_body['dependencies'] = dependencies

    def __if_config_json_exist_in_obs(self, obs_path):
        """
        If config.json file exists in obs path.
        """
        obs_path = obs_path if obs_path.startswith(constant.OBS_HEAD_FORMAT) else "obs:/" + obs_path
        file_list = self.session.obs.list_all_objects(obs_path)
        for file in file_list:
            if os.path.basename(file) == "config.json":
                return True
        return False

    def __if_environment_runtime_exists(self):
        """
        Environment and runtime/dependencies cannot appear simultaneously.
        """
        # get runtime and dependencies
        runtime = None
        if 'runtime' in self.create_model_body:
            runtime = self.create_model_body['runtime']
        dependencies = None
        if 'dependencies' in self.create_model_body:
            dependencies = self.create_model_body['dependencies']
        # verify environment
        if self.environment and (runtime or dependencies):
            raise Exception("User should input either environment or runtime/dependencies.")

    def __set_default_runtime(self):
        """
        Set default runtime
        """
        if is_python3():
            self.create_model_body["runtime"] = "python3.6"
        else:
            self.create_model_body["runtime"] = "python2.7"
        if self.create_model_body["model_type"] == "TensorFlow":
            if is_python3():
                self.create_model_body["runtime"] = "tf1.13-python3.6-cpu"
            else:
                self.create_model_body["runtime"] = "tf1.13-python2.7-cpu"

    def __if_environment_runtime_null(self):
        """
        Environment and runtime cannot be empty simultaneously.
        """
        if self.environment is not None or 'runtime' in self.create_model_body:
            return
        source_location = self.__source_location
        config_json_local_path = os.path.join(source_location, 'config.json')
        if self.publish:
            config_json_path = os.path.join(source_location, 'config.json')
            config_json_local_path = ""
            if self.__if_config_json_exist_in_obs(config_json_path):
                config_json_local_dir = os.path.join(tempfile.gettempdir(), str(uuid.uuid4()))
                os.makedirs(config_json_local_dir, exist_ok=True)
                config_json_local_path = os.path.join(config_json_local_dir, 'config.json')
                config_json_path = config_json_path if config_json_path.startswith(constant.OBS_HEAD_FORMAT) else \
                    "obs:/" + config_json_path
                self.session.obs.download_file(config_json_path, config_json_local_dir)
        config_json_content = self.get_config_json_content(config_json_local_path)
        runtime = self.get_runtime(config_json_content)
        if self.environment is None and runtime is None:
            self.__set_default_runtime()

    def __convert_environment(self):
        """
        Convert conda environment to runtime and dependencies.
        """
        self.__if_environment_runtime_exists()
        self.__if_environment_runtime_null()
        if self.environment is not None:
            if self.create_model_body["model_type"] != "Custom":
                self.convert_environment_to_runtime(self.create_model_body["model_type"])
            # convert environment to runtime and dependencies
            if self.publish:
                if self.matched_runtime is not None:
                    self.create_model_body['runtime'] = self.matched_runtime
                self.convert_environment_to_dependencies()

    @staticmethod
    def __get_bucket_prefix(obs_path):
        """
        Get bucket name from an obs path.
        """
        if obs_path.startswith('/'):
            obs_path = obs_path[1:]
        # in case no '/' in the string
        if not obs_path.endswith('/'):
            obs_path = obs_path + '/'
        obs_path_list = obs_path.split('/', 1)
        return obs_path_list[0], obs_path_list[1]

    def __prepare_model_files(self, model_param, source_location_type):
        """
        Prepare the model files to create a model.
        """
        if source_location_type not in constant.MODEL_SOURCE_LOCATIONS_TYPE:
            raise Exception("Parameter source_location_type should be one of {}.".
                            format(constant.MODEL_SOURCE_LOCATIONS_TYPE))
        if constant.MODEL_SOURCE_LOCATION not in model_param or \
                len(model_param[constant.MODEL_SOURCE_LOCATION]) == 0:
            raise ValueError("Parameter source_location is required.")
        source_location = model_param[constant.MODEL_SOURCE_LOCATION]
        self.original_source_location = source_location
        if source_location_type == constant.MODEL_OBS_LOCATION:
            obs_source_location = source_location if source_location.startswith(constant.OBS_HEAD_FORMAT) else \
                "obs:/" + source_location
            file_list = self.session.obs.list_all_objects(obs_source_location, False)
            if not file_list or len(file_list) <= 1:
                raise Exception("No model files in obs path {}.".format(source_location))
            # when model files saved in OBS, we need to download them if creating a local model.
            if not self.publish:
                self.tmp_local_path = "{}/model_{}/".format(os.path.expanduser("~"), str(uuid.uuid4()))
                os.makedirs(self.tmp_local_path, exist_ok=True)
                if not source_location.endswith('/'):
                    source_location += '/'
                self.session.download_data(source_location, self.tmp_local_path, subfiles_mode=True)
                model_param[constant.MODEL_SOURCE_LOCATION] = self.tmp_local_path
        elif source_location_type == constant.MODEL_LOCAL_LOCATION:
            model_param[constant.MODEL_SOURCE_LOCATION] = os.path.realpath(source_location)
            source_location = model_param[constant.MODEL_SOURCE_LOCATION]
            file_list = os.listdir(source_location)
            if not file_list:
                raise Exception("No model files in local path {}.".format(source_location))
            if self.publish:
                bucket_name = self.session.default_bucket()
                beijing_date = (datetime.now() + timedelta(hours=8)).strftime(
                    constant.ISO_TIME_FORMAT)
                model_pos = 'model-' + beijing_date
                base_bucket_path = '/' + bucket_name + '/' + model_pos
                self.session.upload_data(base_bucket_path, source_location)
                print("Successfully upload model files from {} to obs path {}.".
                      format(source_location, base_bucket_path))
                local_directory = source_location.rstrip('/')
                file_name = os.path.split(local_directory)[-1]
                model_param[constant.MODEL_SOURCE_LOCATION] = os.path.join(base_bucket_path, file_name)
        else:
            if not self.publish:
                raise ValueError(f"Unsupported source location type for {source_location_type}.")

    @staticmethod
    def __splice_obs_url(region_name, params):
        """ convert custom path to obs path format
        :param params: the model parameters
        :return: obs format path
        """
        if len(params) == 0:
            raise ValueError('The current obs path is null. ')
        if params[0] == '/':
            params = params[1:]

        if region_name in constant.SUPPORTED_REGION and not Config.is_empty():
            obs_domain = Config.getenv("OBS_" + region_name)
        else:
            obs_domain = os.getenv("S3_ENDPOINT")
        if obs_domain is None:
            raise ValueError("OBS endpoint info is required for building models.")
        return "https://{}.{}/{}".format(params.split("/", 1)[0],
                                         obs_domain,
                                         params.split("/", 1)[1])

    def __source_location_verify(self, region_name):
        """
        Verify source location
        :param region_name: region name
        """
        if self.publish:
            self.create_model_body['source_location'] = \
                self.__splice_obs_url(region_name, self.create_model_body['source_location'])
            if self.create_model_body['source_location'][-1] == "/":
                self.create_model_body['source_location'] = \
                    self.create_model_body['source_location'][:-1]
            if not re.match(constant.SOURCE_LOCATION_PATTERN, self.create_model_body["source_location"]):
                raise ValueError("Param source location match canonical {} failed.".
                                 format(constant.SOURCE_LOCATION_PATTERN))

        print("The model source location is " + self.create_model_body[
            'source_location'])

    def __add_execution_code(self, region_name):
        """
        add execution code from input params to model body struct
        :param region_name: region name
        """
        if 'execution_code' in self.create_model_body:
            self.create_model_body['execution_code'] = self.create_model_body['execution_code']
            if self.publish:
                self.create_model_body['execution_code'] = \
                    self.__splice_obs_url(region_name, self.create_model_body['execution_code'])

    def __model_type_verify(self):
        """
        Verify model type.
        """
        if 'model_type' not in self.create_model_body or len(self.create_model_body["model_type"]) == 0:
            raise ValueError('The model_type is required')

    def __generate_model_params(self, region_name, model_params, source_location_type):
        """ Processing and generating the model create parameters:
            [model_name, model_version, source_location, model_type, execution_code]
        :param: model_params: the model parameters
        """
        self.create_model_body = model_params
        dynamic_load_mode = self.create_model_body.get('dynamic_load_mode')
        prebuild = self.create_model_body.get('prebuild', None)
        model_type = self.create_model_body.get('model_type')
        if dynamic_load_mode is not None and dynamic_load_mode != "Single":
            raise ValueError("Custom model type only supports 'Single' dynamic local mode")
        if dynamic_load_mode is None and model_type == "Custom":
            self.create_model_body['dynamic_load_mode'] = "Single"
        if prebuild is None:
            self.create_model_body['prebuild'] = True
        if 'model_name' not in model_params:
            current_date = (datetime.now() + timedelta(hours=8)).strftime(
                constant.ISO_TIME_FORMAT)
            self.create_model_body['model_name'] = 'model-' + current_date
            print("Model name is %s " % self.create_model_body['model_name'])

        if 'model_version' not in model_params:
            self.create_model_body['model_version'] = '0.0.1'

        self.__source_location = self.create_model_body.get("source_location")

        if source_location_type != constant.MODEL_IMAGE_LOCATION:
            self.__source_location_verify(region_name)
        else:
            swr_host = query_var(cfg_var=f"SWR_{region_name}", env_var="SWR_ENDPOINT", remove_prefix=True)
            if swr_host is None:
                raise ValueError("SWR endpoint info is required for generating model params.")
            self.create_model_body["source_location"] = f"{swr_host}/{self.__source_location}"
        self.__model_type_verify()
        self.__add_execution_code(region_name)

        if "initial_config" in model_params:
            self.create_model_body['initial_config'] = str(model_params.get("initial_config"))

        if 'input_params' in model_params:
            self.create_model_body['input_params'] = self.__convert_params_format(
                model_params['input_params'])

        if 'output_params' in model_params:
            self.create_model_body['output_params'] = self.__convert_params_format(
                model_params['output_params'])

        if 'dependencies' in model_params:
            if isinstance(model_params['dependencies'][0], Dependencies):
                model_params['dependencies'] = [dep.convert_to_dict() for dep in
                                                model_params['dependencies']]

    def check_params(self, region_name, **kwargs):
        """ Checking the model parameters validity from console
        """
        if 'configs' in kwargs:
            config_set = set(kwargs.keys()) - constant.SERVICE_DEPLOY_PARAMS
            if len(config_set) == 0:
                self.__generate_service_params(region_name, kwargs)
            else:
                raise ValueError('The input params: %s for '
                                 'deploying service is surplus' % config_set)

    @staticmethod
    def __convert_params_format(params):
        """ convert_params_format
        :param params: params
        :return: dict format
        """
        params_format = []
        for put_param in params:
            one_param = dict()
            one_param['url'] = put_param.url
            one_param['param_name'] = put_param.param_name
            one_param['param_type'] = put_param.param_type
            one_param['protocol'] = put_param.protocol
            one_param['method'] = put_param.method

            if put_param.min is not None:
                one_param['min'] = put_param.min

            if put_param.max is not None:
                one_param['max'] = put_param.max

            if put_param.param_desc is not None:
                one_param['param_desc'] = put_param.param_desc

            params_format.append(one_param)

        return params_format

    @abstractmethod
    def create_modelarts_model(self, **kwargs):
        """ Creating model
            Returns: The model id that created successfully,
            will be used in deploying service.
        """
        pass

    def __generate_service_params(self, region_name, service_params):
        """ Processing and generating the model service parameters:
            [service_name, infer_type, vpc_id, config(dict)]
        :param service_params: The model service parameters
        """
        self.deploy_service_body = service_params

        if 'service_name' not in service_params:
            current_date = (datetime.now() + timedelta(hours=8)).strftime(
                constant.ISO_TIME_FORMAT)
            self.deploy_service_body[
                'service_name'] = 'service-' + current_date
        print("Service name is %s" % self.deploy_service_body['service_name'])

        if 'infer_type' not in service_params:
            self.deploy_service_body['infer_type'] = 'real-time'

        if 'workspace_id' not in service_params:
            self.deploy_service_body['workspace_id'] = '0'

        if 'vpc_id' in service_params and ('subnet_network_id'
                                           not in service_params or
                                           'security_group_id'
                                           not in service_params):
            raise ValueError('subnet_network_id and security_group_id '
                             'are required when using vpc_id')

        if 'schedule' in service_params:
            schedule = []
            schedule_value = {
                "type": service_params['schedule'][0].op_type,
                "duration": service_params['schedule'][0].duration,
                "time_unit": service_params['schedule'][0].time_unit
            }
            schedule.append(schedule_value)
            self.deploy_service_body['schedule'] = schedule

        if 'configs' in service_params:
            self.__add_config_in_service(region_name, service_params)
        else:
            raise ValueError('The configs are required.')

    def __add_config_in_service(self, region_name, service_params):
        """
        Process configs in service_params.
        """
        config_value = []
        if hasattr(service_params['configs'][0],
                   'req_uri'):  # batch config
            for service_config in service_params['configs']:
                one_config = dict()
                one_config['model_id'] = service_config.model_id
                one_config['specification'] = service_config.specification
                one_config[
                    'instance_count'] = service_config.instance_count
                one_config['src_path'] = self.__splice_obs_url(region_name,
                                                               service_config.src_path)
                one_config['dest_path'] = self.__splice_obs_url(region_name,
                                                                service_config.dest_path)
                one_config['req_uri'] = service_config.req_uri
                one_config['mapping_type'] = service_config.mapping_type

                if service_config.mapping_rule is not None:
                    one_config[
                        'mapping_rule'] = service_config.mapping_rule
                if service_config.envs is not None:
                    one_config['envs'] = service_config.envs
                config_value.append(one_config)

        elif hasattr(service_params['configs'][0],
                     'weight'):  # real-time config
            for service_config in service_params['configs']:
                one_config = dict()
                one_config['model_id'] = service_config.model_id
                one_config['specification'] = service_config.specification
                one_config[
                    'instance_count'] = service_config.instance_count
                one_config['weight'] = service_config.weight

                if service_config.envs is not None:
                    one_config['envs'] = service_config.envs
                config_value.append(one_config)
        else:
            raise ValueError("The input configs are wrong.")

        self.deploy_service_body['configs'] = config_value
        self.deploy_service_body['config'] = self.deploy_service_body.pop(
            "configs")

    @abstractmethod
    def deploy_modelarts_predictor(self, **kwargs):
        """ Deploying model predictor
        """
        pass

    @abstractmethod
    def delete_model_endpoint(self, model_id, service_id):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
        :param model_id: model id
        :param service_id: service id
        """
        pass

    @staticmethod
    def is_reach_maximum_times(max_attempt_times):
        """
        :param max_attempt_times:
        :return: True or False
        """
        if max_attempt_times > int(constant.MAXIMUM_RETRY_TIMES):
            return True
        else:
            return False

    @abstractmethod
    def get_model_list(self):
        """ User model list
        """
        pass

    @abstractmethod
    def get_model_info_list(self):
        """ model information.
        """
        pass

    @abstractmethod
    def _get_service_list(self):
        """ User service list
        """
        pass

    @abstractmethod
    def _get_service_info(self):
        """ the service information
        """
        pass

    @abstractmethod
    def delete_model(self, model_id):
        """ delete model endpoint
        :param model_id: model id
        """
        pass

    @abstractmethod
    def delete_service(self, service_id):
        """ delete service endpoint
        :param service_id: service id
        """
        pass

    def stop_local_service(self):
        """ stop local service port
        """
        stop_port = r"bash {basepath}/local/stop_port.sh  {port}".format(
            basepath=self.current_path,
            port=self.free_port)
        os.system(stop_port)

    @staticmethod
    def _curl_local_service(local_ip):
        """ curl local ip
        :param local_ip: local ip:port, for local predict
        :return:  whether exist, True or False
        """
        local_url = "http://" + local_ip + '/health'
        try:
            requests.get(local_url, timeout=3,
                         proxies={"http": None, "https": None})
            return True
        except RequestException:
            return False

    @staticmethod
    def _close_proxy():
        """ close current environment proxy in local infer case
        """
        os.environ["http_proxy"] = ""
        os.environ["https_proxy"] = ""
        os.environ["HTTP_PROXY"] = ""
        os.environ["HTTPS_PROXY"] = ""

    @staticmethod
    def _choose_tf_version(runtime):
        """ choose tensorflow local inference version
        """
        if "tf1.13" in runtime:
            return "tensorflow13"
        if "tf2.1" in runtime:
            return "tensorflow21"
        return "tensorflow8"

    def _choose_engine_run(self, engine_type, runtime, conda_env_path, model_local_path, free_port):
        """
        According engine type, run the local service script
        :param engine_type: modelarts infers AI engine type
        :param runtime: used to choose tensorflow version
        :param conda_env_path: conda environment path
        :param model_local_path: the location where model files saved
        """
        if not os.path.exists(os.path.realpath(model_local_path)):
            raise FileNotFoundError(f"Parameter model_local_path {model_local_path} does not exist.")

        self._close_proxy()
        if engine_type.lower() == 'tensorflow':
            infer_run = r"source activate {conda_path} && export PYTHONPATH=$PYTHONPATH:{location} &&" \
                        r" bash {basepath}/local/{engine}/run.sh {location} {port} &".\
                format(conda_path=conda_env_path,
                       basepath=self.current_path,
                       engine=self._choose_tf_version(runtime),
                       location=model_local_path,
                       port=free_port)
            if not os.path.exists(f"{self.current_path}/local/{self._choose_tf_version(runtime)}"):
                raise ValueError(f"TF engine {self._choose_tf_version(runtime)} is not supported.")

        elif engine_type.lower() == 'xgboost':
            infer_run = r"source activate {conda_path} && export PYTHONPATH=$PYTHONPATH:{location} &&" \
                        r"bash {basepath}/local/xgboost_sklearn/run.sh {location} {port} {model_type} &".\
                format(conda_path=conda_env_path,
                       basepath=self.current_path,
                       location=model_local_path,
                       port=free_port,
                       model_type="XGBoost")

        elif engine_type.lower() == 'scikit_learn':
            infer_run = r"source activate {conda_path} && export PYTHONPATH=$PYTHONPATH:{location} &&" \
                        r"bash {basepath}/local/xgboost_sklearn/run.sh {location} {port} {model_type} &".\
                format(conda_path=conda_env_path,
                       basepath=self.current_path,
                       location=model_local_path,
                       port=free_port,
                       model_type="Scikit_Learn")

        else:
            infer_run = r"source activate {conda_path} && export PYTHONPATH=$PYTHONPATH:{location} &&" \
                        r"bash {basepath}/local/{engine}/run.sh {location} {port} &".\
                format(conda_path=conda_env_path,
                       basepath=self.current_path,
                       engine=engine_type.lower(),
                       location=model_local_path,
                       port=free_port)
        self.sub_process = subprocess.Popen(infer_run, shell=True, stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT)

    def __wait_for_finished(self, local_service_ip, model_local_path):
        print("local_service_port is %s" % local_service_ip)
        print("Deploying the local service ...")
        local_deploy_times = 0
        while not self._curl_local_service(local_service_ip):
            local_deploy_times = local_deploy_times + 1
            time.sleep(float(constant.LOCAL_INFER_WAIT_SEC))
            if local_deploy_times == int(constant.LOCAL_INFER_RETRY_TIMES):
                break
        if self._curl_local_service(local_service_ip):
            print("Successfully deployed the local service. You can check the log in {}".
                  format(model_local_path + constant.LOCAL_INFER_LOG_FILE_NAME))
            return True
        else:
            stream_stdout = io.TextIOWrapper(self.sub_process.stdout, encoding='utf-8')
            print("Failed to deploy the local service. See error message as below:")
            line_num = 0
            while True:
                line = str(stream_stdout.readline()).strip()
                line_num = line_num + 1
                if line is not None and len(line) > 0:
                    print(line)
                else:
                    break
                if line_num > constant.ERR_MAX_LINE_NUM:
                    break
            self.sub_process.kill()
            return False

    def __stop_previous_predictor(self):
        """
        Stop previous local predictor.
        """
        if self.local_predictor is not None:
            self.local_predictor.delete_service()
            local_service_ip = constant.MODEL_LOCAL_HOST + ":" + \
                               str(self.local_predictor.predictor_instance.port)
            while self._curl_local_service(local_service_ip):
                time.sleep(float(constant.LOCAL_INFER_WAIT_SEC))
            self.local_predictor = None
            self.free_port = None

    def deploy_local_service(self, engine_type, model_envs, runtime, conda_env_path, model_local_path):
        """ local create and  deploy model, using model files and model envs
        :param engine_type: include caffe, tensorrt, pytorch, hiai, tfserving
        :param model_envs: model environment variables
        :param runtime: used to choose tensorflow version
        :param conda_env_path: conda environment path
        :param model_local_path: the location where model files saved
        """
        if engine_type.lower() not in constant.ENGINE_TYPE_SET:
            raise Exception(
                "The engine %s does not support local inference, please choose "
                "one of %s" % (engine_type.lower(),
                               constant.ENGINE_TYPE_SET))
        self.__stop_previous_predictor()
        self.free_port = str(file_utils.find_available_port())
        # check state of deploy local service
        local_service_ip = constant.MODEL_LOCAL_HOST + ":" + str(self.free_port)
        # export environment variable and run infer
        for key, value in model_envs.items():
            os.environ[key] = value
        if not model_local_path.endswith('/'):
            model_local_path = model_local_path + '/'
        self._choose_engine_run(engine_type, runtime, conda_env_path, model_local_path, self.free_port)
        return self.__wait_for_finished(local_service_ip, model_local_path)

    def convert_dependencies_to_conda_env(self, dependencies, runtime):
        """
        Convert param dependencies to conda environment
        :param dependencies: dependencies from user input
        :param runtime: runtime of inference
        """
        pip_packages = []
        if dependencies is not None:
            for dep in dependencies:
                # for now, infer only supports pip installer
                if dep["installer"] == constant.INFER_PIP_INSTALLER:
                    packages = dep["packages"]
                    for package in packages:
                        package_name = package["package_name"]
                        package_version = package["package_version"]
                        restraint = package["restraint"]
                        pip_package = package_name
                        if package_version != "":
                            pip_package = package_name + constant.INFER_PACKAGE_RESTRAINT_DICT[restraint] + \
                                          package_version
                        pip_packages.append(pip_package)
        model_type = self.create_model_body['model_type']
        conda_packages = []
        if runtime is not None:
            if runtime in constant.INFER_RUNTIME_TO_ENVIRONMENT[model_type].keys():
                runtime_packages = constant.INFER_RUNTIME_TO_ENVIRONMENT[model_type][runtime]
                conda_packages.extend(runtime_packages['conda_packages'])
                pip_packages.extend(runtime_packages['pip_packages'])
        # if dependencies is None, env only set default
        env = Environment(model_type + "-1.0.0")
        cd = CondaDependencies.create(pip_packages=pip_packages, conda_packages=conda_packages)
        env.conda = cd
        self.environment = env

    def deploy_published_model_locally(self, model_info_resp):
        """
        Deploy a published model locally.
        """
        engine_type = model_info_resp['model_type']
        model_envs = self.deploy_service_body["config"][0]["envs"] \
            if "envs" in self.deploy_service_body["config"][0] else {}
        runtime = model_info_resp['runtime']
        if self.environment is None:
            dependencies = model_info_resp["dependencies"]
            self.convert_dependencies_to_conda_env(dependencies, runtime)
        # create a conda environment
        self.add_packages_for_local_infer(runtime)
        conda_env_path = self.env_builder.build(self.environment)
        # download model files from OBS
        source_location = model_info_resp['source_location']
        model_bucket_path = "/{}/".format(
            source_location.split("//", 1)[1].split('.')[0] + source_location.split(".com", 1)[1])
        model_local_path = "{}/modelarts/model_location/model_id_{}/".format(
            os.path.expanduser("~"), model_info_resp['model_id'])
        print("model_local_path is %s" % model_local_path)
        os.makedirs(model_local_path, exist_ok=True)
        self.session.download_data(model_bucket_path, model_local_path, subfiles_mode=True)
        local_service_flag = self.deploy_local_service(engine_type, model_envs, runtime,
                                                       conda_env_path, model_local_path)
        if local_service_flag:
            self.service_id = None
            self.is_local = True
            self.local_predictor = Predictor(self.session, self.service_id,
                                             is_local=self.is_local, port=self.free_port)
            return self.local_predictor

    def add_packages_for_local_infer(self, runtime):
        """
        Add some necessary packages.
        """
        engine_type = self.create_model_body['model_type'].lower()
        prefix_path = os.path.split(os.path.realpath(__file__))[0]
        if engine_type == 'tensorflow':
            requirement_path = r"{basepath}/local/{engine}".format(
                basepath=prefix_path, engine=self._choose_tf_version(runtime))
            if not os.path.exists(requirement_path):
                raise ValueError(f"TF engine {self._choose_tf_version(runtime)} is not supported.")
        elif engine_type == 'xgboost' or engine_type == 'scikit_learn':
            requirement_path = r"{basepath}/local/xgboost_sklearn".format(basepath=prefix_path)
        else:  # pytorch
            requirement_path = r"{basepath}/local/{engine}".format(
                basepath=prefix_path, engine=engine_type)
        requirement_txt = os.path.join(requirement_path, "requirements.txt")
        pip_packages = self.environment.conda
        with open(requirement_txt, 'r') as f:
            lines = f.readlines()
            for line in lines:
                pip_packages.add_pip_package(line.strip(), False)

    @staticmethod
    def is_not_empty(element, target):
        """
        Check if an element is in a list or dict.
        """
        if element not in target:
            return False
        elif target[element] is None:
            raise ValueError("Parameter {} is None.".format(element))
        elif len(target[element]) == 0:
            return False
        return True


def is_python3():
    """
    Check if this kernel is python3.
    """
    if sys.version > '3':
        return True
    return False


def is_str(param):
    if is_python3():
        if isinstance(param, str):
            return True
    else:
        if isinstance(param, str):
            return True
    return False


class LocalModel(ModelApiBase):
    """
    A model that can be created and deployed locally
    """

    def __init__(self, session, environment=None):
        """
        Initialize a local model.
        :param session: Building interactions with Cloud service.
        :param environment: environment for local model
        """
        ModelApiBase.__init__(self, session, environment, False)
        self.session = session
        self.conda_env_path = None
        self.config_json_runtime = None
        self.local_model_files = None

    def __validate_apis(self, config_json_content):
        """
        Validate apis in config.json.
        """
        if not self.is_not_empty('apis', config_json_content):
            raise Exception("apis in config.json is null or empty.")
        apis = config_json_content['apis']
        if not isinstance(apis, list):
            raise ValueError("apis should be a list.")
        for api in apis:
            if self.is_not_empty('protocol', api):
                protocol = api['protocol']
                if protocol != 'http' and protocol != 'https':
                    raise Exception("Parameter protocol in apis is not valid.")
            if not self.is_not_empty('method', api):
                raise Exception("Parameter method is null or empty in apis.")
            else:
                method = api['method']
                if method.upper() != 'GET' and method.upper() != 'POST':
                    raise Exception("Unsupported request method.")
            if not self.is_not_empty('url', api):
                raise Exception("Parameter url is null or empty in apis.")
            elif api['url'] != '/':
                raise Exception("Parameter url should be '/' in apis.")
            if 'request' not in api or not isinstance(api['request'], dict):
                raise Exception("Parameter request is null or not a dictionary in apis.")
            if 'response' not in api or not isinstance(api['response'], dict):
                raise Exception("Parameter response is null or not a dictionary in apis.")

    def __validate_config_json(self, config_json_content):
        """
        Check the format of config.json
        """
        self.__required_param_verify('model_algorithm', constant.MODEL_ALGORITHM_PATTERN, config_json_content)

        supported_model_types = constant.INFER_RUNTIME_TO_ENVIRONMENT.keys()
        if not self.is_not_empty('model_type', config_json_content):
            raise Exception("Parameter model_type is null or empty!")
        elif config_json_content['model_type'] not in supported_model_types:
            raise Exception("Parameter model_type is not valid!")
        if self.create_model_body['model_type'] != config_json_content['model_type']:
            raise Exception("Parameter model_type in config.json is not same as that user input!")
        if "metrics" in config_json_content and not isinstance(config_json_content["metrics"], dict):
            raise Exception("Parameter metrics should be null or a dictionary.")
        self.__validate_apis(config_json_content)

        if 'swr_location' in config_json_content:
            raise Exception("Only Image model type can configure swr location.")
        if 'health' in config_json_content:
            raise Exception("Only Image model type can configure health.")

        if "runtime" in config_json_content:
            self.__validate_runtime(config_json_content["runtime"])
            self.config_json_runtime = config_json_content["runtime"]
        if "dependencies" in config_json_content:
            self.__validate_dependencies(config_json_content["dependencies"])

    def validate_config_json(self, config_json_content):
        """
        Validate config.json.
        """
        try:
            self.__validate_config_json(config_json_content)
        except Exception as e:
            print("config.json is not valid: {}".format(str(e)))
            raise
        else:
            print("Validate config.json successfully.")

    def create_modelarts_model(self, **kwargs):
        """
        Create a model locally.
        """
        if not os.path.exists(os.path.join(self.create_model_body['source_location'], 'customize_service.py')):
            print("**Warning**: customize_service.py does not exist, your inference task may fail. "
                  "You can add it to directory {} to be applied when deploy predictor.".
                  format(self.create_model_body['source_location']))
        self.__verify_model_params()
        config_json_content = self.get_config_json_content(os.path.join(
            self.create_model_body['source_location'], 'config.json'))
        if config_json_content is None:
            print("**Warning**: config.json does not exist, and your inference task may fail. "
                  "You can add it to directory {} and validate it using method 'validate_config_json' of "
                  "'modelarts.model.Model' object, for example,\n"
                  "    model.validate_config_json()".
                  format(self.create_model_body['source_location']))
        else:
            self.validate_config_json(config_json_content)
        dependencies = self.get_dependencies(config_json_content)
        runtime = self.get_runtime(config_json_content)
        if self.environment is None:
            self.convert_dependencies_to_conda_env(dependencies, runtime)
        self.local_model_files = file_utils.get_files_modify_time(self.create_model_body['source_location'])
        self.model_id = str(uuid.uuid4())
        return self.model_id

    def __verify_model_params(self):
        """
        Check user input parameters.
        """
        if self.create_model_body["model_type"] == "Caffe":
            raise ValueError("Local model does not support caffe.")
        self.__required_param_verify("model_name", constant.MODEL_NAME_PATTERN, self.create_model_body)
        self.__required_param_verify("model_version", constant.MODEL_VERSION_PATTERN, self.create_model_body)
        self.__source_type_verify()
        self.__non_required_param_verify("description", constant.MODEL_DESCRIPTION_PATTERN, self.create_model_body)
        self.__non_required_param_verify("model_algorithm", constant.MODEL_ALGORITHM_PATTERN, self.create_model_body)
        self.__install_type_verify()
        self.__guide_docs_verify()
        if "runtime" in self.create_model_body:
            self.__validate_runtime(self.create_model_body["runtime"])
        if "dependencies" in self.create_model_body:
            self.__validate_dependencies(self.create_model_body["dependencies"])

    @staticmethod
    def __required_param_verify(param_name, pattern, target):
        """
        Verify required param format.
        :param param_name: param name
        :param pattern: validation pattern
        :param target: where the param exists
        """
        if param_name not in target or target[param_name] is None or len(target[param_name]) == 0:
            raise ValueError("Parameter {} is null or empty.".format(param_name))
        if not is_str(target[param_name]):
            raise ValueError("Parameter {} should be a string.".format(param_name))
        if not re.match(pattern, target[param_name]):
            raise ValueError("Parameter {} is not valid.".format(param_name))

    @staticmethod
    def __non_required_param_verify(param_name, pattern, target):
        """
        Verify required param format.
        :param param_name: param name
        :param pattern: validation pattern
        :param target: where the param exists
        """
        if param_name in target:
            if target[param_name] is None:
                raise ValueError("Parameter {} is null.".format(param_name))
            if not is_str(target[param_name]):
                raise ValueError("Parameter {} should be a string.".format(param_name))
            if len(target[param_name]) == 0:
                return
            if not re.match(pattern, target[param_name]):
                raise ValueError("Parameter {} is not valid.".format(param_name))

    def __guide_docs_verify(self):
        """
        Verify guide docs.
        """
        if 'model_docs' not in self.create_model_body or len(self.create_model_body['model_docs']) == 0:
            return
        model_docs = self.create_model_body['model_docs']
        if not isinstance(model_docs, list):
            raise ValueError("Parameter model_docs should be a list.")
        if len(model_docs) > 3:
            raise ValueError("Model docs can't more than 3.")
        for doc in model_docs:
            self.__required_param_verify("doc_name", constant.DOC_NAME_PATTERN, doc)
            self.__required_param_verify("doc_url", constant.DOC_URL_PATTERN, doc)

    def __install_type_verify(self):
        """
        Verify install type.
        """
        if "install_type" not in self.create_model_body or len(self.create_model_body["install_type"]) == 0:
            return
        install_types = self.create_model_body["install_type"]
        if not isinstance(install_types, list):
            raise ValueError("Parameter install_type should be a list.")
        for install_type in install_types:
            if install_type not in constant.INFER_INSTALL_TYPE:
                raise ValueError("Invalid install_type: {}.".format(install_type))

    def __source_type_verify(self):
        """
        Verify source type.
        """
        if "source_type" in self.create_model_body:
            raise ValueError("User should not input source type.")

    def __validate_runtime(self, runtime):
        """
        Validate runtime parameters
        :param runtime: runtime
        """
        model_type = self.create_model_body['model_type']
        if runtime not in constant.INFER_RUNTIME_TO_ENVIRONMENT[model_type].keys():
            raise ValueError("Runtime is not supported. Please check it.")

    def __validate_dependencies(self, dependencies):
        """
        Verify dependencies
        """
        restraint_values = constant.INFER_PACKAGE_RESTRAINT_DICT.keys()
        for dependency in dependencies:
            if not self.is_not_empty('installer', dependency):
                raise Exception("No installer in dependencies")
            installer = dependency['installer']
            if installer != constant.INFER_PIP_INSTALLER:
                raise Exception("Only support pip installer in dependencies.")

            if not self.is_not_empty('packages', dependency):
                raise Exception("No packages in dependencies.")
            packages = dependency['packages']
            if not isinstance(packages, list):
                raise Exception("packages in dependencies should be a list.")
            for pkg in packages:
                self.__required_param_verify('package_name', constant.PACKAGE_PATTERN, pkg)
                self.__non_required_param_verify('package_version', constant.PACKAGE_PATTERN, pkg)
                restraint_exist = self.is_not_empty('restraint', pkg)
                version_exist = self.is_not_empty('package_version', pkg)
                if (version_exist and not restraint_exist) or (not version_exist and restraint_exist):
                    raise Exception("restraint and package_version should appear simultaneously in dependencies.")
                elif restraint_exist:
                    restraint = pkg['restraint']
                    if restraint not in restraint_values:
                        raise Exception("Invalid restraint {} in dependencies.".format(restraint))

    def deploy_modelarts_predictor(self, **kwargs):
        """
        Deploy service wit a local model.
        """
        # deploy the local model locally
        if self.deploy_service_body["config"][0]["specification"] != "local":
            raise Exception("This model is not published, and you can publish it by method 'publish_model', "
                            "for example:\n model.publish_model()")
        # create the conda environment
        if 'runtime' in self.create_model_body:
            runtime = self.create_model_body['runtime']
        elif self.matched_runtime is not None:
            runtime = self.matched_runtime
        else:
            runtime = self.config_json_runtime

        self.add_packages_for_local_infer(runtime)
        self.conda_env_path = self.env_builder.build(self.environment)
        engine_type = self.create_model_body['model_type']
        model_envs = self.deploy_service_body["config"][0]["envs"] \
            if "envs" in self.deploy_service_body["config"][0] else {}
        local_service_flag = self.deploy_local_service(engine_type, model_envs, runtime, self.conda_env_path,
                                                       self.create_model_body[constant.MODEL_SOURCE_LOCATION])
        if local_service_flag:
            self.is_local = True
            self.local_predictor = Predictor(self.session, self.service_id, is_local=self.is_local, port=self.free_port,
                                             model_local_path=self.create_model_body[constant.MODEL_SOURCE_LOCATION])
            return self.local_predictor

    @staticmethod
    def is_temp_file(file_name):
        """
        Filter out temporary files.
        :param file_name: file name
        :return true or false
        """
        if file_name.endswith(constant.LOCAL_INFER_LOG_FILE_NAME) or file_name.endswith("__pycache__"):
            return True
        return False

    def prepare_publish_model_param(self, obs_path=None, source_location_type=None):
        """
        Prepare the params to publish a model.
        """
        upload_file_list = []
        file_map = file_utils.get_files_modify_time(self.create_model_body['source_location'])
        source_location = self.create_model_body['source_location']
        if source_location_type == constant.MODEL_LOCAL_LOCATION:
            obs_location = obs_path
            if obs_path is None:
                beijing_date = (datetime.now() + timedelta(hours=8)).strftime(
                    constant.ISO_TIME_FORMAT)
                model_pos = 'model-' + beijing_date
                base_bucket_name = self.session.default_bucket()
                obs_location = '/' + base_bucket_name + '/' + model_pos
            for key, value in file_map.items():
                if not self.is_temp_file(key):
                    upload_file_list.append(key)
        else:
            obs_location = self.original_source_location
            for key, value in file_map.items():
                if key not in self.local_model_files:
                    if not self.is_temp_file(key):
                        upload_file_list.append(key)
                elif value != self.local_model_files[key]:
                    upload_file_list.append(key)
        self.session.upload_data(obs_location, upload_file_list)
        self.create_model_body['source_location'] = obs_location
        print("Model files were saved in local path {}, you can delete them manually".format(source_location))

    def delete_model_endpoint(self, model_id, service_id):
        pass

    def get_model_list(self):
        pass

    def get_model_info_list(self):
        pass

    def _get_service_list(self):
        pass

    def _get_service_info(self):
        pass

    def delete_model(self, model_id):
        """
        Deleting the models files.
        :param model_id: model id
        """
        deactivate = r"source deactivate {conda_path}".format(conda_path=self.conda_env_path)
        os.system(deactivate)
        if self.tmp_local_path is not None:
            if os.path.exists(self.tmp_local_path):
                shutil.rmtree(self.tmp_local_path)
                print("Successfully delete the model files in path {}.".format(self.tmp_local_path))
        return model_id

    def delete_service(self, service_id):
        pass


class ModelApiAKSKImpl(ModelApiBase):
    """ A ModelArts Model that can be created model, deployed model
    service and delete model endpoint.
    """

    def __init__(self, session, environment=None):
        """ Initialize a ModelArts Model instance.
        :param session:  session with cloud service
        """
        ModelApiBase.__init__(self, session, environment, True)

    @auth_expired_handler
    def create_modelarts_model(self, wait=True, **kwargs):
        """ Creating model
        :return: The model id that created successfully,
        will be used in deploying service.
        """
        request_url = '/v1/' + self.session.project_id + '/models'
        create_model_body = JSONEncoder().encode(self.create_model_body)

        model_create_resp = auth_by_apig(self.session,
                                         constant.HTTPS_POST,
                                         request_url, '',
                                         create_model_body)
        self.model_id = model_create_resp['model_id']
        count_status_query_times = 0
        print_status_flag = True
        if not wait:
            model_query_resp = self.get_model_info_list()

        while wait:
            count_status_query_times += 1
            model_query_resp = self.get_model_info_list()
            if ModelApiBase.is_reach_maximum_times(count_status_query_times):
                print(
                    "Reach the maximum status query times, the current status is %s" %
                    model_query_resp['model_status'])
                break

            if model_query_resp['model_status'] in ["published", "failed", "building_failed"]:
                print(model_query_resp['model_status'])
                break

            else:
                if print_status_flag:
                    print_status_flag = False
                    print(model_query_resp['model_status'])
                time.sleep(float(constant.CREATE_WAIT_SEC))

        return model_query_resp

    @auth_expired_handler
    def deploy_modelarts_predictor(self, wait=True, **kwargs):
        """ Deploying model predictor
        :return: Predictor.
        """
        specifications = [item["specification"] for item in
                          self.deploy_service_body["config"]]
        if len(specifications) == 1 and "local" in specifications:
            model_id = self.deploy_service_body["config"][0]["model_id"]
            model_info_resp = self.get_model_info_list(model_id=model_id)
            return self.deploy_published_model_locally(model_info_resp)

        if "local" in specifications:
            raise Exception("Please check your specification.")

        request_url = '/v1/' + self.session.project_id + '/services'
        create_service_body = JSONEncoder().encode(self.deploy_service_body)
        service_deploy_resp = auth_by_apig(self.session, constant.HTTPS_POST,
                                           request_url, '',
                                           create_service_body)

        self.service_id = service_deploy_resp['service_id']
        previous_deploy_progress = 0
        count_status_query_times = 0
        while wait:
            service_query_resp = self._get_service_info()
            count_status_query_times += 1

            if ModelApiBase.is_reach_maximum_times(count_status_query_times):
                print("Reach the maximum service status query times, "
                      "the status is {}".format(service_query_resp['status']))
                break

            if service_query_resp['status'] == 'running':
                previous_deploy_progress = 100
                sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                sys.stdout.flush()
                print("\nDeploy finished")
                break

            elif service_query_resp['status'] == 'deploying' or \
                    service_query_resp['status'] == 'finished':
                if service_query_resp['progress'] > previous_deploy_progress:
                    previous_deploy_progress = service_query_resp['progress']
                    sys.stdout.write(
                        '\rDeploy progress: %s%%' % previous_deploy_progress)
                time.sleep(float(constant.DEPLOY_WAIT_SEC))

            else:
                raise Exception("Abnormal service id %s ,the status is %s " %
                                (
                                    self.service_id,
                                    service_query_resp['status']))

        return Predictor(self.session, self.service_id)

    def delete_model_endpoint(self, model_id, service_id):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
        :param model_id:  model id
        :param service_id: service id
        """
        if service_id and model_id is not None:
            self.delete_service(service_id=service_id)
            count_service_retry_times = 0
            while True:
                count_service_retry_times += 1
                if ModelApiBase.is_reach_maximum_times(
                        count_service_retry_times):
                    print("Can't get the service %s delete "
                          "information." % service_id)
                    break

                services_list = self._get_service_list()
                services = services_list['services']
                if service_id in [tmp['service_id'] for tmp in services]:
                    time.sleep(float(constant.DEPLOY_WAIT_SEC))
                else:
                    print('Successfully delete the service %s .' % service_id)
                    break

            self.delete_model(model_id=model_id)
            count_model_retry_times = 0
            while True:
                count_model_retry_times += 1
                if ModelApiBase.is_reach_maximum_times(count_model_retry_times):
                    print("Can't get the model %s delete information." % model_id)
                    break

                model_list = self.get_model_list()
                if model_id in [tmp['model_id'] for tmp in model_list['models']]:
                    time.sleep(float(constant.CREATE_WAIT_SEC))
                else:
                    print('Successfully delete the model %s .' % model_id)
                    break
        else:
            raise Exception("Both model_id and service_id must not be None.")

    @auth_expired_handler
    def get_model_list(self, **kwargs):
        """ get_model_list
        :param kwargs: index params
        :return: return User model list
        """
        request_url = '/v1/' + self.session.project_id + '/models'
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, query=kwargs)

    @auth_expired_handler
    def get_model_info_list(self, model_id=None):
        """ return model information.
        :param model_id: model id
        :return: model information
        """
        request_url = '/v1/' + self.session.project_id + '/models/'
        if model_id is None:
            model_id = self.model_id

        request_url = request_url + model_id
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, '')

    @auth_expired_handler
    def _get_service_list(self):
        """
        return User service list
        """
        request_url = '/v1/' + self.session.project_id + '/services'
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, '')

    @auth_expired_handler
    def _get_service_info(self):
        """ get_service_info
        :return: the service information
        """
        request_url = '/v1/' + self.session.project_id + \
                      '/services/' + self.service_id
        return auth_by_apig(self.session, constant.HTTPS_GET, request_url, '')

    @auth_expired_handler
    def delete_service(self, service_id):
        """ delete service
        :param service_id:  service id
        """
        if self.is_local:
            super(ModelApiAKSKImpl, self).stop_local_service()
        else:
            request_url = '/v1/{}/services/{}'.format(self.session.project_id, service_id)
            auth_by_apig(self.session, constant.HTTPS_DELETE, request_url, '')

    @auth_expired_handler
    def delete_model(self, model_id):
        """ Delete a model
        :param model_id: model id
        """
        request_url = '/v1/{}/models/{}'.format(self.session.project_id, model_id)
        return auth_by_apig(self.session, constant.HTTPS_DELETE, request_url, '')


class ModelApiROMAImpl(ModelApiBase):
    """ A ROMA ModelArts Model that can be created model,
    deployed model service and delete model endpoint.
    """

    def __init__(self, session, environment=None):
        """ Initialize a ModelArts Model instance.
        :param session:  session with cloud service
        """
        ModelApiBase.__init__(self, session, environment, True)

    def create_modelarts_model(self, wait=True, **kwargs):
        """ Creating model
        :return: The model id that created successfully,
        will be used in deploying service.
        """
        request_url = self.session.host + '/v1/' + \
                      self.session.project_id + '/models'
        body = json.loads(
            json.dumps(str(self.create_model_body).replace("\'", "\"")))
        model_create_resp = auth_by_roma_api(session=self.session,
                                             request_url=request_url,
                                             request_type=constant.HTTPS_POST,
                                             intf_action="create_modelarts_model",
                                             data=body)

        self.model_id = model_create_resp['model_id']
        count_status_query_times = 0
        print_status_flag = True
        if not wait:
            model_query_resp = self.get_model_info_list()

        while wait:
            count_status_query_times += 1
            model_query_resp = self.get_model_info_list()
            if ModelApiBase.is_reach_maximum_times(count_status_query_times):
                print("Reach maximum query times, the current status is %s" %
                      model_query_resp['model_status'])
                break

            if model_query_resp['model_status'] in ["published", "failed", "building_failed"]:
                print(model_query_resp['model_status'])
                break
            else:
                if print_status_flag:
                    print_status_flag = False
                    print(model_query_resp['model_status'])
                time.sleep(float(constant.CREATE_WAIT_SEC))

        return model_query_resp

    def deploy_modelarts_predictor(self, wait=True, **kwargs):
        """ Deploying model predictor
        :return: Predictor.
        """
        specifications = [item["specification"] for item in self.deploy_service_body["config"]]
        if len(specifications) == 1 and "local" in specifications:
            model_id = self.deploy_service_body["config"][0]["model_id"]
            model_info_resp = self.get_model_info_list(model_id=model_id)
            return self.deploy_published_model_locally(model_info_resp)

        if "local" in specifications:
            raise Exception("Please check your specification.")

        request_url = self.session.host + '/v1/' + \
                      self.session.project_id + '/services'
        body = json.loads(
            json.dumps(str(self.deploy_service_body).replace("\'", "\"")))
        service_deploy_resp = auth_by_roma_api(session=self.session,
                                               request_url=request_url,
                                               request_type=constant.HTTPS_POST,
                                               intf_action="deploy_modelarts_predictor",
                                               data=body)

        self.service_id = service_deploy_resp['service_id']
        previous_deploy_progress = 0
        count_status_query_times = 0
        while wait:
            service_query_resp = self._get_service_info()
            count_status_query_times += 1

            if ModelApiBase.is_reach_maximum_times(count_status_query_times):
                print("Reach maximum service query times, the status is %s" %
                      service_query_resp['status'])
                break

            if service_query_resp['status'] == 'running':
                previous_deploy_progress = 100
                sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                sys.stdout.flush()
                print("\nDeploy finished")
                break

            elif service_query_resp['status'] == 'deploying' or \
                    service_query_resp['status'] == 'finished':
                if service_query_resp['progress'] > previous_deploy_progress:
                    previous_deploy_progress = service_query_resp['progress']
                    sys.stdout.write(
                        '\rDeploy progress: %s%%' % previous_deploy_progress)
                time.sleep(float(constant.DEPLOY_WAIT_SEC))

            else:
                raise Exception("Abnormal service id %s ,the status is %s " %
                                (self.service_id, service_query_resp['status']))

        return Predictor(self.session, self.service_id)

    def delete_model_endpoint(self, model_id, service_id):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
        :param model_id:  model id
        :param service_id: service id
        """
        if service_id and model_id is not None:
            self.delete_service(service_id=service_id)
            count_service_retry_times = 0
            while True:
                count_service_retry_times += 1
                if ModelApiBase.is_reach_maximum_times(
                        count_service_retry_times):
                    print(
                        "Can't get the service %s delete information." % service_id)
                    break

                services_list = self._get_service_list()
                services = services_list['services']
                if service_id in [tmp['service_id'] for tmp in services]:
                    time.sleep(float(constant.DEPLOY_WAIT_SEC))
                else:
                    print('Successfully delete the service %s .' % service_id)
                    break

            self.delete_model(model_id=model_id)
            count_model_retry_times = 0
            while True:
                count_model_retry_times += 1
                if ModelApiBase.is_reach_maximum_times(
                        count_model_retry_times):
                    print(
                        "Can't get the model %s delete information." % model_id)
                    break

                model_list = self.get_model_list()

                if model_id in [tmp['model_id'] for tmp in
                                model_list['models']]:
                    time.sleep(float(constant.CREATE_WAIT_SEC))
                else:
                    print('Successfully delete the model %s .' % model_id)
                    break
        else:
            raise Exception("Both model_id and service_id must not be None.")

    def get_model_list(self, **kwargs):
        """ get_model_list
        :param kwargs: index params
        :return: return User model list
        """
        request_url = self.session.host + '/v1/' + \
                      self.session.project_id + '/models'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_model_list")

    def get_model_info_list(self, model_id=None):
        """ return model information.
        :param model_id: model id
        :return: model information
        """
        if model_id is None:
            model_id = self.model_id
        request_url = self.session.host + '/v1/' + \
                      self.session.project_id + '/models/' + model_id
        response = auth_by_roma_api(session=self.session,
                                    request_url=request_url,
                                    request_type=constant.HTTPS_GET,
                                    intf_action="get_model_info_list")
        return response

    def _get_service_list(self):
        """
        return User service list
        """
        request_url = self.session.host + '/v1/' + \
                      self.session.project_id + '/services'
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_list")

    def _get_service_info(self):
        """ get_service_info
        :return: the service information
        """
        request_url = self.session.host + '/v1/' + self.session.project_id + \
                      '/services/' + self.service_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_service_info")

    def delete_service(self, service_id):
        """ delete service
        :param service_id:  service id
        """
        if self.is_local:
            super(ModelApiAKSKImpl, self).stop_local_service()
        else:
            request_url = self.session.host + '/v1/' + self.session.project_id \
                          + '/services/' + service_id
            auth_by_roma_api(session=self.session, request_url=request_url,
                             request_type=constant.HTTPS_DELETE,
                             intf_action="delete_service")

    def delete_model(self, model_id):
        """ Delete a model
        :param model_id: model id
        """
        request_url = self.session.host + '/v1/' + self.session.project_id + \
                      '/models/' + model_id
        return auth_by_roma_api(session=self.session, request_url=request_url,
                                request_type=constant.HTTPS_DELETE,
                                intf_action="delete_model")
