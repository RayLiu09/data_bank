from enum import Enum


class SystemEnv(Enum):
    EXECUTION_CREATE_TIME = "execution_create_time"
    EXECUTION_UUID = "execution_uuid"
    WORKFLOW_UUID = "workflow_uuid"
    WORKFLOW_NAME = "workflow_name"
    WORKFLOW_RUN_COUNT = "workflow_run_count"
    WORKFLOW_GALLERY_CONTENT_ID = "workflow_gallery_content_id"
    WORKFLOW_GALLERY_CONTENT_VERSION = "workflow_gallery_version_id"

    def env(self) -> str:
        return "$ref/system_env/{}".format(self.value)
