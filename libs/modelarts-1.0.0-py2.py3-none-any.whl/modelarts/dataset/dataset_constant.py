IMPORT_DATASET_TEMP_DIRECTORY_PREFIX = "import_temp_"

IMPORT_DATASET_WAIT_INTERVAL_TIME = 1

LOCAL_TEMP_PATH = "/local_temp_"

DATASET_VERSION_FORMAT_CARBON = "CarbonData"

DATASET_VERSION_FORMAT_CSV = "CSV"

DATASET_VERSION_FORMAT_DEFAULT = "Default"

DATASET_TYPE_TABULAR = 400

DATASET_TYPE_TRIPLET = 102

DATASET_DATA_SOURCE_TYPE = "type"

DATASET_DATA_SOURCE_DATA_TYPE = "data_type"

DATASET_DATA_SOURCE_PATH = "path"

DATASET_DATA_SOURCE_DATA_PATH = "data_path"

DATASET_IS_FROM_LOCAL = "is_from_local"

DATASET_WITH_COLUMN_HEADER = "with_column_header"

DATASET_WORK_PATH_TYPE = "type"

DATASET_WORK_PATH_PATH = "path"

DATASET_BOOLEAN_TRUE = "true"

DATASET_BOOLEAN_FALSE = "false"

DATASET_IMPORT_OBS_DIR = "dir"

DATASET_IMPORT_OBS_MANIFEST = "manifest"

DATASET_DATASET_TYPE = "dataset_type"

DATASET_COLUMN_TYPE_DICT = {"boolean": bool, "Boolean": bool,
                            "float": float, "Float": float, "double": float, "Double": float,
                            "int": int, "Integer": int,
                            "String": str, "string": str}

DATA_TYPE_LIST = ["IMAGE", "TEXT", "AUDIO", "TABLE", "VIDEO", "PLAIN"]
DATA_TYPE_DICT = {"IMAGE": 0, "TEXT": 1, "AUDIO": 2, "TABLE": 4, "VIDEO": 6, "PLAIN": 9}
DATA_TYPE_TABLE = "TABLE"
DATASET_TYPE = "dataset_type"
IS_WORKFORCE_TASK = "is_workforce_task"
SORT_KEY = "sort_key"
SORT_DIR = "sort_dir"
TASK_TYPE = "task_type"
OFFSET = "offset"
LIMIT = "limit"
CHECK_RUNNING_TASK = "check_running_task"

URI_LABEL_TASK = "/label-tasks"
