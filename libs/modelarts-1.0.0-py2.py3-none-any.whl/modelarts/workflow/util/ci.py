import os
import re

from modelarts.workflow.util.git import get_source_repo_url, get_source_version, get_source_branch


def _get_repository_name(repo_url):
    match_str = re.search("(?<=/)[^/]+(?=.git$)", repo_url)
    if match_str is None:
        return None
    return match_str.group()


def _get_platform_name(repo_url):
    if repo_url.find(".devcloud.") != -1:
        return "devcloud"
    return None


def _get_devcloud_ci_metadata():
    """
        In the DevCloud platform, the following information can be obtained through env：
            'CLOUD_BUILD_REPO_URL': git report url
            'GIT_TAG': git tag name
            'GIT_COMMIT': git commit ID
            'INCREASENUM': build times, starting from 1 and increasing by 1 each time
            'BUILDNUMBER': build number, for example '20221124.2'
            'GIT_LOCAL_BRANCH': git local branch
            'PROJECT_ID': project ID
            'GIT_REPOSITORY_ID': git repository ID
            'BUILD_WORKSPACE_ID': build workspace ID
    """
    git_repository_name = _get_repository_name(os.environ.get("CLOUD_BUILD_REPO_URL", ""))
    if git_repository_name is None:
        return None

    metadata = {"project_id": os.environ.get("PROJECT_ID", None), "git_commit_id": os.environ.get("GIT_COMMIT", None),
                "git_tag": os.environ.get("GIT_TAG", None), "git_branch": os.environ.get("GIT_LOCAL_BRANCH", None),
                "git_repository_id": os.environ.get("GIT_REPOSITORY_ID", None),
                "build_workspace_id": os.environ.get("BUILD_WORKSPACE_ID", None),
                "build_job_name": os.environ.get("BUILDNUMBER", None),
                "increase_num": None if os.environ.get("INCREASENUM", None) is None else int(
                    os.environ.get("INCREASENUM")),
                "git_repository_name": git_repository_name}
    return {"devcloud": metadata}


def _get_local_ci_metadata():
    repo_url = get_source_repo_url()
    if repo_url is None:
        return None
    git_repository_name = _get_repository_name(repo_url)
    if git_repository_name is None:
        return None
    platform = _get_platform_name(repo_url)
    if platform is None:
        return None
    metadata = {
        "repository_name": git_repository_name,
        "git_commit_id": get_source_version(),
        "git_branch": get_source_branch(),
        "build_job_name": "local"
    }
    return {platform: metadata}


def get_ci_metadata():
    """
    Get build information for Devops platform.
    If used locally, the corresponding git commit id, branch and other information will be obtained
    Returns (dict): build information or local git info

    """
    repo_url = os.environ.get("CLOUD_BUILD_REPO_URL", None)
    if repo_url is not None:
        return _get_devcloud_ci_metadata()
    return _get_local_ci_metadata()
