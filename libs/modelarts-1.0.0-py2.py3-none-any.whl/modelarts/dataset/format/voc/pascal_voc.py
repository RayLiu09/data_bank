"""
Description: parse file of pascal voc format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

import codecs
import collections
import logging
import os
from xml.dom.minidom import Document
from xml.dom import minidom as xml_minidom

import defusedxml

from modelarts.dataset.format.manifest import constants
from modelarts.dataset.format.manifest.constants import OBJECT, NAME, POSE, TRUNCATED, OCCLUDED, DIFFICULT, CONFIDENCE
from modelarts.dataset.format.manifest.file_util import is_local, save
from modelarts.dataset.format.manifest.file_util import read
from modelarts.dataset.format.voc.source import Source
from modelarts import constant
from modelarts.dataset.format.voc.voc_object import VocObject
from modelarts.dataset.format.voc.voc_position import BNDBox, Circle, Polygon, Polyline, Point, Line, Dashed, \
    PositionType, shape_cases

logging.basicConfig(level=logging.INFO)

# 修补所有标准库XML解析器
defusedxml.defuse_stdlib()

def get_voc_annotation_file(data_set):
    data_objects = data_set.samples
    for data_object in data_objects:
        annotations = data_object.annotations
        for annotation in annotations:
            annotation_loc = annotation.annotation_loc
        if annotation.annotation_format != "PASCAL VOC":
            raise ValueError
        return annotation_loc


def build_position(doc, voc_object_element, position_type, feature):
    position_element = doc.createElement(position_type)
    voc_object_element.appendChild(position_element)
    try:
        shape_cases[position_type](doc, position_element, feature)
    except KeyError:
        point, line, dashed, bndbox, circle, polygon, polyline = PositionType.POINT.value, \
                                                                 PositionType.LINE.value, \
                                                                 PositionType.DASHED.value, \
                                                                 PositionType.BNDBOX.value,\
                                                                 PositionType.CIRCLE.value,\
                                                                 PositionType.POLYGON.value,\
                                                                 PositionType.POLYLINE.value
        logging.error("Error shape type: %s, object shape only can be %s, %s, %s, %s, %s, %s, %s",
                      position_type, point, line, dashed, bndbox, circle, polygon, polyline)


def generate_xml(file_name, xml_file_path, width=None, height=None, depth=None, voc_objects=None):
    """
    Write voc annotation to xml file.
    It will overwrite if the xml file path already exists.

    """
    doc = Document()

    # root element
    annotation_element = doc.createElement(constants.ANNOTATIONS)
    doc.appendChild(annotation_element)

    # folder
    folder_element = doc.createElement(constants.FOLDER_NAME)
    folder_element.appendChild(doc.createTextNode("Images"))
    annotation_element.appendChild(folder_element)

    # filename
    file_name_element = doc.createElement(constants.FILE_NAME)
    file_name_element.appendChild(doc.createTextNode(file_name))
    annotation_element.appendChild(file_name_element)

    # source
    source_element = doc.createElement(constants.SOURCE)
    annotation_element.appendChild(source_element)

    database_element = doc.createElement(constants.DATABASE)
    database_element.appendChild(doc.createTextNode("Unknown"))
    source_element.appendChild(database_element)

    # size
    size_element = doc.createElement(constants.SIZE)
    annotation_element.appendChild(size_element)

    width_element = doc.createElement(constants.WIDTH)
    width_element.appendChild(doc.createTextNode(str(width)))
    size_element.appendChild(width_element)

    height_element = doc.createElement(constants.HEIGHT)
    height_element.appendChild(doc.createTextNode(str(height)))
    size_element.appendChild(height_element)

    depth_element = doc.createElement(constants.DEPTH)
    depth_value = depth if depth is not None else 0
    depth_element.appendChild(doc.createTextNode(str(depth_value)))
    size_element.appendChild(depth_element)

    # segmented
    segmented_element = doc.createElement(constants.SEGMENTED)
    segmented_element.appendChild(doc.createTextNode("0"))
    annotation_element.appendChild(segmented_element)

    # voc objects
    generate_xml_objects(annotation_element, doc, voc_objects)

    with codecs.open(xml_file_path, 'w', encoding='utf-8') as f:
        f.write(doc.toprettyxml(indent='\t'))


def generate_xml_objects(annotation_element, doc, voc_objects):
    for voc_object in voc_objects:
        voc_object_element = doc.createElement(constants.OBJECT)
        annotation_element.appendChild(voc_object_element)

        # name
        name_element = doc.createElement(constants.NAME)
        name_element.appendChild(doc.createTextNode(str(voc_object.name)))
        voc_object_element.appendChild(name_element)

        # properties
        properties = voc_object.properties

        # pose
        if constants.POSE in properties:
            pose_element = doc.createElement(constants.POSE)
            pose_element.appendChild(doc.createTextNode(str(properties[constants.POSE])))
            voc_object_element.appendChild(pose_element)
            properties.pop(constants.POSE)

        # truncated
        if constants.TRUNCATED in properties:
            truncated_element = doc.createElement(constants.TRUNCATED)
            truncated_element.appendChild(doc.createTextNode(str(properties[constants.TRUNCATED])))
            voc_object_element.appendChild(truncated_element)
            properties.pop(constants.TRUNCATED)

        # difficult
        if constants.DIFFICULT in properties:
            difficult_element = doc.createElement(constants.DIFFICULT)
            difficult_element.appendChild(doc.createTextNode(str(properties[constants.DIFFICULT])))
            voc_object_element.appendChild(difficult_element)
            properties.pop(constants.DIFFICULT)

        # occluded
        if constants.OCCLUDED in properties:
            occluded_element = doc.createElement(constants.OCCLUDED)
            occluded_element.appendChild(doc.createTextNode(str(properties[constants.OCCLUDED])))
            voc_object_element.appendChild(occluded_element)
            properties.pop(constants.OCCLUDED)

        # position
        shape_name = properties[constants.SHAPE]
        feature = properties[constants.FEATURE]
        build_position(doc, voc_object_element, shape_name, feature)

        generate_xml_properties(doc, properties, voc_object_element)


def generate_xml_properties(doc, properties, voc_object_element):
    # custom attribute
    if properties is not None and len(properties) > 0:
        custom_attributes = []
        if constants.SECONDARY_LABELS in properties:
            secondary_labels_value = properties.get(constants.SECONDARY_LABELS)
            if isinstance(secondary_labels_value, dict):
                for secondary_label_key, secondary_label_value in secondary_labels_value.items():
                    custom_attributes.append({secondary_label_key: secondary_label_value})
            else:
                custom_attributes.append({constants.SECONDARY_LABELS: str(secondary_labels_value)})
            properties.pop(constants.SECONDARY_LABELS)

        # user-defined attributes do not start with @modelarts
        for property_key, property_value in properties.items():
            if not property_key.startswith(constants.INTERNAL_PROPERTY_KEY_PREFIX):
                custom_attributes.append({property_key: property_value})

        # attributes start with @modelarts added to properties
        modelarts_attributes = []
        if constants.CLOCKWISE_ANGLE in properties:
            modelarts_attributes.append({constants.CLOCKWISE_ANGLE: properties[constants.CLOCKWISE_ANGLE]})
            properties.pop(constants.CLOCKWISE_ANGLE)
        if constants.ROTATE_BACKGROUND in properties:
            modelarts_attributes.append({constants.ROTATE_BACKGROUND: properties[constants.ROTATE_BACKGROUND]})
            properties.pop(constants.ROTATE_BACKGROUND)

        # output custom attribute
        if len(custom_attributes) > 0 or len(modelarts_attributes) > 0:
            properties_element = doc.createElement(constants.VOC_PROPERTIES)
            for _custom_attribute in custom_attributes:
                property_element = doc.createElement(constants.VOC_PROPERTY)
                property_key_element = doc.createElement(constants.VOC_PROPERTY_KEY)
                property_value_element = doc.createElement(constants.VOC_PROPERTY_VALUE)
                property_key_element.appendChild(doc.createTextNode(str(list(_custom_attribute.keys())[0])))
                property_value_element.appendChild(doc.createTextNode(str(list(_custom_attribute.values())[0])))
                property_element.appendChild(property_key_element)
                property_element.appendChild(property_value_element)
                properties_element.appendChild(property_element)

            for _modelarts_attribute in modelarts_attributes:
                property_element = doc.createElement(constants.VOC_PROPERTY)
                property_key_element = doc.createElement(constants.VOC_PROPERTY_KEY)
                property_value_element = doc.createElement(constants.VOC_PROPERTY_VALUE)
                property_key_element.appendChild(doc.createTextNode(str(list(_modelarts_attribute.keys())[0])))
                property_value_element.appendChild(doc.createTextNode(str(list(_modelarts_attribute.values())[0])))
                property_element.appendChild(property_key_element)
                property_element.appendChild(property_value_element)
                properties_element.appendChild(property_element)

            voc_object_element.appendChild(properties_element)


def get_voc_object(object_element):
    """
    Parse DOM element of object to VOC object.

    """
    occluded, difficult, name, pose = None, None, None, None
    truncated, confidence, position = None, None, None
    properties = collections.OrderedDict()
    parts = []
    mask_color = None
    position_flag = False
    position_type = None

    for each in object_element.childNodes:
        if each.nodeName == constants.NAME:
            name = get_data(each.childNodes, OBJECT + " " + NAME + " can't be empty in VOC file!")
        elif each.nodeName == constants.VOC_PROPERTIES:
            properties = get_properties(each, properties)
        elif each.nodeName == constants.POSE:
            pose = get_data(each.childNodes, OBJECT + " " + POSE + " can't be empty in VOC file!")
        elif each.nodeName == constants.TRUNCATED:
            truncated = get_data(each.childNodes, OBJECT + " " + TRUNCATED + " can't be empty in VOC file!")
        elif each.nodeName == constants.OCCLUDED:
            occluded = get_data(each.childNodes, OBJECT + " " + OCCLUDED + " can't be empty in VOC file!")
        elif each.nodeName == constants.DIFFICULT:
            difficult = get_data(each.childNodes, OBJECT + " " + DIFFICULT + " can't be empty in VOC file!")
        elif each.nodeName == constants.CONFIDENCE:
            confidence = get_data(each.childNodes, OBJECT + " " + CONFIDENCE + " can't be empty in VOC file!")
        elif each.nodeName == PositionType.BNDBOX.value:
            position, position_flag, position_type = get_bndbox_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.POLYGON.value:
            position, position_flag, position_type = get_polygon_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.POLYLINE.value:
            position, position_flag, position_type = get_polyline_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.DASHED.value:
            position, position_flag, position_type = get_dashed_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.LINE.value:
            position, position_flag, position_type = get_line_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.CIRCLE.value:
            position, position_flag, position_type = get_circle_position(each, position_flag, position_type)
        elif each.nodeName == PositionType.POINT.value:
            position, position_flag, position_type = get_point_position(each, position_flag, position_type)
        elif each.nodeName == constants.PART:
            parts.append(get_voc_object(each))
        elif each.nodeName == constants.MASK_COLOR:
            mask_color = get_data(each.childNodes, OBJECT + " " + constants.MASK_COLOR + " can't be empty in VOC file!")
    return VocObject(name, properties, pose, truncated, occluded, difficult, confidence,
                     position, parts, mask_color)


def get_properties(object_child_element, properties):
    for properties_child_element_node in object_child_element.childNodes:
        properties_child_name = properties_child_element_node.nodeName
        if properties_child_name != "#text":
            if len(properties_child_element_node.childNodes) > 1:
                property_key, property_value = None, None
                for property_element in properties_child_element_node.childNodes:
                    property_child_name = property_element.nodeName
                    property_key, property_value = get_property(property_child_name, property_element, property_key,
                                                                property_value)
                if property_key is not None and property_value is not None:
                    properties[property_key] = property_value
            else:
                properties[properties_child_name] = get_data(properties_child_element_node.childNodes,
                                                             OBJECT + " " + constants.VOC_PROPERTIES + " " +
                                                             properties_child_name + " can't be empty in VOC file!")
    return properties


def get_property(property_child_name, property_element, property_key, property_value):
    if property_child_name != "#text":
        if property_child_name == constants.VOC_PROPERTY_KEY:
            property_key = get_data(property_element.childNodes,
                                    OBJECT + " " + constants.VOC_PROPERTIES + " " +
                                    constants.VOC_PROPERTY + " " + constants.VOC_PROPERTY_KEY +
                                    " can't be empty in VOC file!")
        if property_child_name == constants.VOC_PROPERTY_VALUE:
            property_value = get_data(property_element.childNodes,
                                      OBJECT + " " + constants.VOC_PROPERTIES + " " +
                                      constants.VOC_PROPERTY + " " + constants.VOC_PROPERTY_VALUE +
                                      " can't be empty in VOC file!")
    return property_key, property_value


def get_bndbox_position(object_child_element, position_flag, position_type):
    bndbox_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(bndbox_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.BNDBOX.value + " can't be empty in VOC file!")
    x_max, x_min, y_max, y_min = get_bndbox(bndbox_node_list)
    if x_min is not None and y_min is not None and x_max is not None and y_max is not None:
        position = BNDBox(int(x_min), int(y_min), int(x_max), int(y_max))
    else:
        raise Exception(
            OBJECT + " " + PositionType.BNDBOX.value + " should have xmin, ymin, xmax, ymax.")
    return position, True, PositionType.BNDBOX.value


def get_polygon_position(object_child_element, position_flag, position_type):
    polygon_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(polygon_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.POLYGON.value + " can't be empty in VOC file!")
    points_xy = {}
    for polygon_element in polygon_node_list:
        polygon_node_name = polygon_element.nodeName
        if polygon_node_name.startswith("x") or polygon_node_name.startswith("y"):
            points_xy[polygon_node_name] = int(polygon_element.childNodes[0].data)
    points = get_points(points_xy)
    if len(points) > 0:
        position = Polygon(points)
    else:
        raise Exception(OBJECT + " " + PositionType.POLYGON.value + " should have xn, yn.")
    return position, True, PositionType.POLYGON.value


def get_polyline_position(object_child_element, position_flag, position_type):
    polyline_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(polyline_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.POLYLINE.value + " can't be empty in VOC file!")
    points_xy = {}
    for polyline_element in polyline_node_list:
        polyline_node_name = polyline_element.nodeName
        if polyline_node_name.startswith("x") or polyline_node_name.startswith("y"):
            points_xy[polyline_node_name] = int(polyline_element.childNodes[0].data)
    points = get_points(points_xy)
    if len(points) > 0:
        position = Polyline(points)
    else:
        raise Exception(OBJECT + " " + PositionType.POLYLINE.value + " should have xn, yn.")
    return position, True, PositionType.POLYLINE.value


def get_dashed_position(object_child_element, position_flag, position_type):
    dashed_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(dashed_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.DASHED.value + " can't be empty in VOC file!")
    x1, x2, y1, y2 = get_dashed(dashed_node_list)
    if x1 is not None and y1 is not None and x2 is not None and y2 is not None:
        position = Dashed(int(x1), int(y1), int(x2), int(y2))
    else:
        raise Exception(
            OBJECT + " " + PositionType.DASHED.value + " should have x1, y1, x2, y2.")
    return position, True, PositionType.DASHED.value


def get_line_position(object_child_element, position_flag, position_type):
    line_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(line_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.LINE.value + " can't be empty in VOC file!")
    x1, x2, y1, y2 = get_line(line_node_list)
    if x1 is not None and y1 is not None and x2 is not None and y2 is not None:
        position = Line(int(x1), int(y1), int(x2), int(y2))
    else:
        raise Exception(
            OBJECT + " " + PositionType.LINE.value + " should have x1, y1, x2, y2.")
    return position, True, PositionType.LINE.value


def get_circle_position(object_child_element, position_flag, position_type):
    circle_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(circle_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.CIRCLE.value + " can't be empty in VOC file!")
    cx, cy, r = get_circle(circle_node_list)
    if cx is not None and cy is not None and r is not None:
        position = Circle(int(cx), int(cy), int(r))
    else:
        raise Exception(
            OBJECT + " " + PositionType.CIRCLE.value + " should have cx, cy, r.")
    return position, True, PositionType.CIRCLE.value


def get_point_position(object_child_element, position_flag, position_type):
    point_node_list = object_child_element.childNodes
    check_position(position_flag, position_type, object_child_element.nodeName)
    if len(point_node_list) < 2:
        raise Exception(OBJECT + " " + PositionType.POINT.value + " can't be empty in VOC file!")
    x, y = get_point(point_node_list)
    if x is not None and y is not None:
        position = Point(int(x), int(y))
    else:
        raise Exception(
            OBJECT + " " + PositionType.POINT.value + " should have x, y.")
    return position, True, PositionType.POINT.value


def get_point(point_node_list):
    x = None
    y = None
    for point_element in point_node_list:
        point_node_name = point_element.nodeName
        if point_node_name == constants.X:
            x = point_element.childNodes[0].data
        if point_node_name == constants.Y:
            y = point_element.childNodes[0].data
    return x, y


def get_circle(circle_node_list):
    cx = None
    cy = None
    r = None
    for circle_element in circle_node_list:
        circle_node_name = circle_element.nodeName
        if circle_node_name == constants.CX:
            cx = circle_element.childNodes[0].data
        if circle_node_name == constants.CY:
            cy = circle_element.childNodes[0].data
        if circle_node_name == constants.R:
            r = circle_element.childNodes[0].data
    return cx, cy, r


def get_line(line_node_list):
    x1, y1, x2, y2 = None, None, None, None
    for line_element in line_node_list:
        line_node_name = line_element.nodeName
        if line_node_name == constants.X1:
            x1 = line_element.childNodes[0].data
        if line_node_name == constants.Y1:
            y1 = line_element.childNodes[0].data
        if line_node_name == constants.X2:
            x2 = line_element.childNodes[0].data
        if line_node_name == constants.Y2:
            y2 = line_element.childNodes[0].data
    return x1, x2, y1, y2


def get_dashed(dashed_node_list):
    x1, y1, x2, y2 = None, None, None, None
    for dashed_element in dashed_node_list:
        dashed_node_name = dashed_element.nodeName
        if dashed_node_name == constants.X1:
            x1 = dashed_element.childNodes[0].data
        if dashed_node_name == constants.Y1:
            y1 = dashed_element.childNodes[0].data
        if dashed_node_name == constants.X2:
            x2 = dashed_element.childNodes[0].data
        if dashed_node_name == constants.Y2:
            y2 = dashed_element.childNodes[0].data
    return x1, x2, y1, y2


def get_points(points_xy):
    points = []
    for _xy_key in points_xy:
        if _xy_key.startswith("x") and ("y" + _xy_key[1:]) in points_xy:
            points.append(Point(points_xy[_xy_key], points_xy["y" + _xy_key[1:]], _xy_key, "y" + _xy_key[1:]))
        else:
            continue
        if _xy_key.startswith("y") and ("x" + _xy_key[1:]) in points_xy:
            points.append(Point(points_xy["x" + _xy_key[1:]], points_xy[_xy_key], "x" + _xy_key[1:], _xy_key))
        else:
            continue
    return points


def get_bndbox(bndbox_node_list):
    x_min, y_min, x_max, y_max = None, None, None, None
    for bndbox_element in bndbox_node_list:
        bndbox_node_name = bndbox_element.nodeName
        if bndbox_node_name == constants.X_MIN:
            x_min = bndbox_element.childNodes[0].data
        if bndbox_node_name == constants.Y_MIN:
            y_min = bndbox_element.childNodes[0].data
        if bndbox_node_name == constants.X_MAX:
            x_max = bndbox_element.childNodes[0].data
        if bndbox_node_name == constants.Y_MAX:
            y_max = bndbox_element.childNodes[0].data
    return x_max, x_min, y_max, y_min


def get_data(name_node_list, msg):
    if len(name_node_list) > 0:
        return name_node_list[0].data
    else:
        raise Exception(msg)


def parse_voc_annotation_file(xml_path):
    """
    Parse xml file to PascalVoc.

    :param xml_path: xml input path
    :return: instance of PascalVoc
    """
    if os.path.exists(xml_path):
        dom = xml_minidom.parse(xml_path)
        collection = dom.documentElement

        folder, file_name, source = None, None, None
        width, height, depth = None, None, None
        segmented, mask_source, voc_objects = None, None, None
        for child_element in collection.childNodes:
            # folder
            if child_element.nodeName == constants.FOLDER_NAME:
                folder_node_list = child_element.childNodes
                folder = get_data(folder_node_list, constants.FOLDER_NAME + " can't be empty in VOC file!")
            # filename
            elif child_element.nodeName == constants.FILE_NAME:
                file_name_node_list = child_element.childNodes
                file_name = get_data(file_name_node_list, constants.FILE_NAME + " can't be empty in VOC file!")
            # source
            elif child_element.nodeName == constants.SOURCE:
                source = get_source(child_element)

            # size
            elif child_element.nodeName == constants.SIZE:
                depth, height, width = get_size(child_element)
            # segmented
            elif child_element.nodeName == constants.SEGMENTED:
                segmented = get_data(child_element.childNodes, constants.SEGMENTED + " can't be empty in VOC file!")
            elif child_element.nodeName == constants.MASK_SOURCE:
                mask_source = get_data(child_element.childNodes, constants.MASK_SOURCE + " can't be empty in VOC file!")
            # objects
            elif child_element.nodeName == constants.OBJECT:
                if len(child_element.childNodes) <= 1:
                    raise Exception(OBJECT + " can't be empty in VOC file!")

                if voc_objects is None:
                    voc_objects = []
                voc_objects.append(get_voc_object(child_element))

        return PascalVoc(folder, file_name, source, width, height, depth, segmented, mask_source, voc_objects)


def get_size(child_element):
    for size_child_element in child_element.childNodes:
        if size_child_element.nodeName == constants.WIDTH:
            width = get_int_data(size_child_element.childNodes,
                                 constants.SIZE + " " + constants.WIDTH + " can't be empty in VOC file!")

        elif size_child_element.nodeName == constants.HEIGHT:
            height = get_int_data(size_child_element.childNodes,
                                  constants.SIZE + " " + constants.HEIGHT + " can't be empty in VOC file!")
        elif size_child_element.nodeName == constants.DEPTH:
            depth = get_int_data(size_child_element.childNodes,
                                 constants.SIZE + " " + constants.DEPTH + " can't be empty in VOC file!")
    return depth, height, width


def get_source(child_element):
    database = None
    annotation = None
    image = None
    for source_child_element in child_element.childNodes:
        if source_child_element.nodeName == constants.DATABASE:
            database_node_list = source_child_element.childNodes
            database = get_data_without_exception(
                database_node_list,
                constants.SOURCE + " " + constants.DATABASE + " is empty in VOC file.")

        elif source_child_element.nodeName == constants.ANNOTATIONS:
            annotation_node_list = source_child_element.childNodes
            annotation = get_data_without_exception(
                annotation_node_list,
                constants.SOURCE + " " + constants.ANNOTATIONS + " is empty in VOC file.")
        elif source_child_element.nodeName == constants.IMAGE:
            image_node_list = source_child_element.childNodes
            image = get_data_without_exception(
                image_node_list,
                constants.SOURCE + " " + constants.IMAGE + " is empty in VOC file.")
    source = Source(database, annotation, image)
    return source


def get_int_data(list, msg):
    if len(list) > 0:
        return int(list[0].data)
    else:
        raise Exception(msg)


def get_data_without_exception(list, msg):
    if len(list) > 0:
        return list[0].data
    else:
        logging.debug(msg)


def check_position(position_flag, position_type, object_child_node_name):
    if position_flag:
        if position_type == object_child_node_name:
            raise Exception("The number of %s %s can't more than one in one object or one part" %
                            (constants.OBJECT, position_type))
        else:
            raise Exception("The number of %s position type can't more than one in one object or one part, "
                            "there are %s and %s in the %s" %
                            (constants.OBJECT, position_type, object_child_node_name, constants.OBJECT))


def parse_xml_file(xml_file_path, session=None):
    if is_local(xml_file_path):
        try:
            return parse_voc_annotation_file(xml_file_path)
        except Exception as e:
            raise Exception(f"Can't parse the XML file, {str(e)}; The file is {xml_file_path}.")
    else:
        if session is None:
            raise ValueError("session can not be empty.")
        xml_b = read(xml_file_path, session.obs_client)
        local_tmp_xml_path = "./tmp.xml"
        with os.fdopen(os.open(local_tmp_xml_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                               constant.FILE_PERMISSION), "w") as f:
            f.write(xml_b.decode())
        try:
            pascal_voc = parse_voc_annotation_file(local_tmp_xml_path)
            if os.path.exists(local_tmp_xml_path):
                os.remove(local_tmp_xml_path)
            return pascal_voc
        except Exception as e:
            raise Exception(f"Can't parse the XML file, {str(e)}; The file is {xml_file_path}.")


class PascalVoc(object):
    def __init__(
            self,
            folder=None,
            file_name=None,
            source=None,
            width=None,
            height=None,
            depth=None,
            segmented=None,
            mask_source=None,
            voc_objects=None):
        """
        Constructor for PascalVoc

        :param folder: image folder
        :param file_name: image name
        :param source: include database for example The VOC2007 Database, annotation format for example PASCAL VOC2007,
                        image source for example flickr.
        :param width: image width
        :param height: image height
        :param depth: image depth
        :param segmented: whether the image is segmented
        :param mask_source: the path of mask source
        :param voc_objects: voc object contains the annotation of object detection
        """
        self.__folder = folder
        self.__file_name = file_name
        self.__source = source
        self.__width = width
        self.__height = height
        self.__depth = depth
        self.__segmented = segmented
        self.__mask_source = mask_source
        self.__voc_objects = voc_objects

    @property
    def folder(self):
        """
        :return: fold name, optional field
        """
        return self.__folder

    @property
    def file_name(self):
        """
        :return: file name, mandatory field
        """
        return self.__file_name

    @property
    def source(self):
        """
        :return: image source, optional field
        """
        return self.__source

    @property
    def width(self):
        """
        :return: image width, mandatory field
        """
        return self.__width

    @property
    def height(self):
        """
        :return: image height, mandatory field
        """
        return self.__height

    @property
    def depth(self):
        """
        :return: image depth, mandatory field
        """
        return self.__depth

    @property
    def segmented(self):
        """
        :return: whether image is segmented, optional field
        """
        return self.__segmented

    @property
    def mask_source(self):
        """
        :return: mask source path, optional field
        """
        return self.__mask_source

    @property
    def voc_objects(self):
        """
        :return: instance list of VocObject, mandatory field
        """
        return self.__voc_objects

    def save_xml(self, xml_file_path, save_mode='w', session=None):
        """
        write xml file to local or OBS

        :param xml_file_path: xml file output path
        :param save_mode: save mode, w means: write
        :param session: Session object.Manage interactions with the cloud services needed.
        :return: None
        """
        if is_local(xml_file_path) is False:
            if session is None:
                raise Exception("session can not be None.")
            else:
                xml_lines = []
                local_tmp_path = "./tmp.xml"
                generate_xml(
                    self.__file_name,
                    local_tmp_path,
                    width=self.__width,
                    height=self.__height,
                    depth=self.__depth,
                    voc_objects=self.__voc_objects)
                with open(local_tmp_path, 'r') as f:
                    for line in f.readlines():
                        xml_lines.append(line.strip('\n'))
                os.remove(local_tmp_path)
                save(xml_lines, xml_file_path, session, saveMode=save_mode)
        else:
            generate_xml(
                self.__file_name,
                xml_file_path,
                width=self.__width,
                height=self.__height,
                depth=self.__depth,
                voc_objects=self.__voc_objects)

    @classmethod
    def parse_xml(cls, xml_file_path, session=None):
        """
        Read xml file from local or OBS

        :param xml_file_path: xml file input path
        :param session: Session object.Manage interactions with the cloud services needed.
        :return: instance of PascalVoc
        """
        return parse_xml_file(xml_file_path, session)
