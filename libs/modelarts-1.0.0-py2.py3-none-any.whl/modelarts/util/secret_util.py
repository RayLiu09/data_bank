import configparser
import os
import requests
import json

from modelarts import constant
from .obs_util import OBS


class _Config(object):
    def __init__(self, secret_mount_path):
        self.config = configparser.ConfigParser()
        self.config.read(secret_mount_path)

    def get(self, key, default_value=None):
        try:
            sections = key.split('_', 1)
            value = self.config[sections[0]][sections[1]]
            return value
        except Exception:
            return default_value


def read_ak_sk_from_secret(instance=None, error=None):
    """ read access_key and secret_key from secret mount path
    Compatible with encrypted and unencrypted AKSK
    :return: access_key, secret_key
    """
    if os.environ.get('AWS_CREDENTIAL_PROFILES_FILE') is not None:
        secret_mount_path = os.environ['AWS_CREDENTIAL_PROFILES_FILE']
    elif os.environ.get('CREDENTIAL_PROFILES_FILE') is not None:
        secret_mount_path = os.environ['CREDENTIAL_PROFILES_FILE']
    elif os.environ.get('AWS_SHARED_CREDENTIALS_FILE') is not None:
        secret_mount_path = os.environ['AWS_SHARED_CREDENTIALS_FILE']
    else:
        raise Exception("No secret path exist in current environment.")

    config = _Config(secret_mount_path)

    access_key = config.get("default_access_key_id")
    secret_key = config.get("default_secret_access_key")
    # fix modelarts training env
    security_token = config.get("default_security_token") or config.get("default_session_token")
    if os.environ.get('AWS_SHARED_CREDENTIALS_FILE') is not None:
        security_token = config.get("default_session_token")
    user_id = config.get("default_user_id")
    # fix modelarts training env
    if user_id is None:
        user_id = os.environ.get("MA_IAM_USER_ID")

    if not access_key or not secret_key:
        raise Exception(
            "secret content is not integral, access_key or secret_key is null")

    if os.environ.get('AWS_CREDENTIAL_PROFILES_FILE') is None \
            and os.environ.get('AWS_SHARED_CREDENTIALS_FILE') is None:
        access_key, secret_key, security_token = decrypt_key_information(access_key, secret_key, security_token)

    if type(access_key) != str and type(secret_key) != str:
        access_key = access_key.encode("utf-8")
        secret_key = secret_key.encode("utf-8")

    if security_token and type(security_token) != str:
        security_token = security_token.encode("utf-8")

    if instance is not None and error is not None and \
            access_key == instance.access_key and \
            secret_key == instance.secret_key:
        raise Exception(error)

    return access_key, secret_key, security_token, user_id


def decrypt_key_information(access_key, secret_key, security_token=None):
    """
    :param access_key:
    :param secret_key:
    :return:
    """
    access_key = decrypt_ciphertext(access_key)
    secret_key = decrypt_ciphertext(secret_key)

    if security_token:
        security_token = decrypt_ciphertext(security_token)

    return access_key, secret_key, security_token


def decrypt_ciphertext(encrypted_value):
    """
    :param encrypted value
    :return: decrypted value
    """
    # decrypt through scc service from volume mount
    if os.getenv("MODELARTS_SCC_SERVICE_PORT"):
        proxies = {'http': None, 'https': None}
        headers = {
            "Content-Type": "application/json;charset=UTF-8"
        }
        body = {
            "action": "decrypt",
            "value": encrypted_value
        }
        request_url = "http://{}:{}/scc".format(constant.MODEL_LOCAL_HOST,
                                                os.getenv("MODELARTS_SCC_SERVICE_PORT"))
        res = requests.post(request_url, headers=headers, data=json.dumps(body), proxies=proxies)
        res_info = str(res.content, encoding="utf-8")
        if res.status_code != 200:
            raise Exception(res_info)
        return res_info

    # decrypt through cloud scc tool
    import sys
    sys.path.append(os.getenv("SCC_CONF_DIR", "/usr/local/seccrypto"))
    from seccrypt import cryptography
    return cryptography.decrypt(encrypted_value)


def auth_expired_handler(func):
    """" handle the access_key_id and secret_access_key in os.environ expired error
    """

    def wrapper(*args, **kwargs):
        if not args:
            raise Exception(
                "auth_expired_handler args is null, when decorates {}".format(
                    func))

        # for class method function
        if type(args[0]) == type and len(args) >= 2 and 'modelarts.session.Session' in str(type(args[1])):
            instance = args[1]

        # for class member function
        else:
            instance = args[0]

        for action in ['UPDATE', 'RETRY']:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if "CREDENTIAL_PROFILES_FILE" in os.environ and action == "UPDATE":

                    if 'modelarts.session.Session' in str(type(instance)):
                        access_key, secret_key, security_token, user_id = read_ak_sk_from_secret(instance, e)
                        instance.access_key = access_key
                        instance.secret_key = secret_key
                        instance.security_token = security_token
                        instance.user_id = user_id
                        instance.obs_client = OBS(server=instance.obs_server,
                                                  ak=instance.access_key,
                                                  sk=instance.secret_key,
                                                  security_token=instance.security_token)

                    elif '_TrainingJobApiAKSKImpl' in str(type(instance)):
                        access_key, secret_key, security_token, user_id = read_ak_sk_from_secret(instance.session, e)
                        instance.session.access_key = access_key
                        instance.session.secret_key = secret_key
                        instance.session.security_token = security_token
                        instance.session.user_id = user_id

                    else:
                        access_key, secret_key, security_token, user_id = read_ak_sk_from_secret(instance.session, e)
                        instance.session.access_key = access_key
                        instance.session.secret_key = secret_key
                        instance.session.security_token = security_token
                        instance.session.user_id = user_id
                    continue
                raise e

    return wrapper
