import uuid
import attr
import logging

from modelarts.workflow.core.placeholder import Placeholder, PlaceholderType
from modelarts.workflow.core.steps import Step, StepTypeEnum, StepState, AbstractOutput
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.data.dataset import Dataset, DatasetPlaceholder, DatasetConsumption, DatasetClient
from modelarts.workflow.core.serialize import serialize
from modelarts.workflow.core.serialize import prepare_for_properties
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.data.label_task import (
    LabelTask,
    LabelTaskPlaceholder,
    LabelTaskConfig,
    LabelTaskConsumption,
    LabelTaskTypeEnum
)
from modelarts.workflow.data.data_selector import DataConsumptionSelector

LABEL_TASK_STATE_MAPPING = {
    # 0: the label task is creating
    "0": StepState.Running,
    # 1: the label task is running
    "1": StepState.Completed,
    # 2: the label task is deleting
    "2": StepState.Running,
    # 3: the label task is deleted
    "3": StepState.Failed,
    # 4: the label task is abnormal
    "4": StepState.Failed,
    # 5: the label task is synchronizing
    "5": StepState.Running,
    # 6: the label task is publishing
    "6": StepState.Running
}


@serialize
@attr.s
class LabelTaskProperties:
    """
    Attributes:
        task_type (LabelTaskTypeEnum): label task type
        task_name (Union[str, Placeholder]): the name of label task
        labels (List[Label]): List of Label
        properties (dict): label task attributes
        auto_sync_dataset (bool):
            whether the labeling results of the labeling task are automatically synchronized to the dataset
        content_labeling (bool): Whether to turn on content annotation for speech segmentation annotation tasks
        description (str): the description message of label task
        sample_conditions (str): filter conditions for dataset samples
    """
    task_type = attr.ib(validator=attr.validators.instance_of(LabelTaskTypeEnum))
    task_name = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    labels = attr.ib(default=None, validator=attr.validators.instance_of((list, type(None))))
    properties = attr.ib(default=None, validator=attr.validators.instance_of((dict, type(None))))
    auto_sync_dataset = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    content_labeling = attr.ib(default=True, validator=attr.validators.instance_of(bool))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    sample_conditions = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))


class LabelingInput(CommonInput):

    def __init__(self, name, data):
        """
        The input of LabelingStep
        Args:
            name (str): The name of LabelingInput
            data (Union[Dataset, DatasetConsumption, DatasetPlaceholder, LabelTask, LabelTaskPlaceholder,
                    LabelTaskConsumption, DataConsumptionSelector]): The input data type must be related to
                                                                    dataset or label task
        """
        super(LabelingInput, self).__init__(name=name, data=data)

    @staticmethod
    def _check_data(data):
        data_type_tuple = (Dataset, DatasetConsumption, DatasetPlaceholder, LabelTask, LabelTaskPlaceholder,
                           LabelTaskConsumption, DataConsumptionSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of LabelingInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class LabelingOutput(AbstractOutput):
    def __init__(self, name):
        """
        The output of LabelingStep
        Args:
            name (str): The name of LabelingOutput
        """
        super().__init__(name)
        self.config = LabelTaskConfig()

    def as_input(self):
        """
        Get the AbstractDataConsumption object, which is used for data transfer between multiple Steps
        Returns (AbstractDataConsumption):

        """
        return self.config.data_consumption(step_name=self.step_name, output_name=self.name)

    def set_data_to_config(self, data):
        """
        Set the LabelTask data to the output config
        Args:
            data (LabelTask): A label task with task ID

        Returns:

        """
        self.config.data = data

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "label_task"
        }
        return result

    def set_to_skip(self):
        self.config.is_skipped = True


class LabelingStep(Step):
    def __init__(
        self,
        name,
        inputs,
        outputs,
        properties=None,
        title=None,
        description=None,
        policy=None,
        depend_steps=None
    ):
        """
        Construct a LabelingStep for dataset labeling
        Args:
            name (str): The name of step
            inputs (LabelingInput): A LabelingInput instance
            outputs (LabelingOutput): A LabelingOutput instance
            properties (LabelTaskProperties): Related properties needed to create a label task
            title (str): title info of LabelingStep
            description (str): Description info of LabelingStep
            depend_steps (Union[Step, List[Step]]): A or a list of step which this `LabelingStep` depends on
        """
        LabelingStep._check_valid(inputs=inputs, outputs=outputs, properties=properties)
        task_properties = LabelingStep._prepare_properties(properties)
        super(LabelingStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.LABELING,
            properties=task_properties,
            inputs=inputs,
            outputs=outputs,
            title=title,
            description=description,
            policy=policy,
            depend_steps=depend_steps
        )
        self._dataset_id = None
        self._label_task_req = properties

    def build_client(self, session):
        super(LabelingStep, self).build_client(session)
        self.client = DatasetClient(session=session)

    def create_instance(self) -> (bool, str):
        data = list(self.inputs.values())[0].data
        if isinstance(data, Dataset):
            task_name = self._label_task_req.task_name.value if \
                isinstance(self._label_task_req.task_name, Placeholder) else self._label_task_req.task_name
            if not task_name:
                task_name = "workflow_created_task_" + uuid.uuid4().hex
            if not self.client.label_task_exists(dataset_id=data.id, label_task_name=task_name):
                logging.info("The LabelingStep %s is creating label task %s", self.name, task_name)
                label_task_id = self.client.create_label_task(
                    dataset_id=data.id, label_task_req=self._label_task_req.serialize())
            else:
                label_task_id = self.client.get_label_task_id(dataset_id=data.id, label_task_name=task_name)
            self._dataset_id = data.id
            return True, label_task_id
        self._dataset_id = data.dataset_id
        return True, data.task_id

    def update_instance_state(self):
        label_task_state = self.client.get_label_task_state(
            dataset_id=self._dataset_id, label_task_id=self.instance_id)
        step_state = StepStateMapping.get_step_state(str(label_task_state), LABEL_TASK_STATE_MAPPING)
        if step_state == StepState.Completed:
            label_task_name = self.client.get_label_task_name(
                dataset_id=self._dataset_id, label_task_id=self.instance_id)
            logging.info("Please complete the labeling operation of labeling task <%s>, "
                         "the ID of the task is %s", label_task_name, self.instance_id)
            self._wait_input()
            self._set_data_to_output()
        self.set_state(step_state)

    def stop_instance(self) -> (bool, str):
        return True, "success"

    def _wait_input(self):
        Placeholder(
            name='{}-is_labeling_completed-{}'.format(self.name, uuid.uuid4().hex),
            placeholder_type=PlaceholderType.BOOL,
            description="Input 'true' after the labeling is completed"
        ).get_value_from_command_line()

    @staticmethod
    def _check_valid(inputs, outputs, properties):
        tuple_dataset = (Dataset, DatasetConsumption, DatasetPlaceholder)
        tuple_label_task = (LabelTask, LabelTaskPlaceholder, LabelTaskConsumption)
        if not isinstance(inputs, LabelingInput):
            raise TypeError('The input of LabelingStep must be LabelingInput. But provided: {}'.format(type(inputs)))
        if not isinstance(outputs, LabelingOutput):
            raise TypeError('The output of LabelingStep must be LabelingOutput. But provided: {}'.format(type(outputs)))
        if isinstance(inputs.declared_data, tuple_label_task) and properties is not None:
            raise ValueError("Properties must be empty when the labeling task is entered")
        if isinstance(inputs.declared_data, tuple_dataset) and properties is None:
            raise ValueError("Properties can not be empty when the dataset is entered")

    @staticmethod
    def _prepare_properties(properties):
        if properties is not None:
            return prepare_for_properties(properties)
        return {}

    def _set_data_to_output(self):
        output = list(self.outputs.values())[0]
        data = list(self.inputs.values())[0].data
        if isinstance(data, LabelTask):
            output.set_data_to_config(data)
        else:
            task_name = self.client.get_label_task_name(
                dataset_id=self._dataset_id, label_task_id=self.instance_id)
            label_task = LabelTask(dataset_name=data.dataset_name, task_name=task_name)
            label_task.dataset_id = self._dataset_id
            label_task.task_id = self.instance_id
            output.set_data_to_config(label_task)
