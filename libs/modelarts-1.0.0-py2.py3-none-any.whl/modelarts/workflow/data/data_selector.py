import ast

from modelarts.workflow.core.data import AbstractDataConsumption, AbstractInputData, AbstractDataPlaceholders, \
    TransformType, AbstractData
from modelarts.workflow.data.obs import OBSPath
from modelarts.workflow.data.dataset import Dataset


DATA_INPUT_FORMAT_MAPPING = {
    "dataset": "{'dataset_name': '******', 'version_name': '******'}",
    "obs": "{'obs_path': '******'}"
}


class DataConsumptionSelector(AbstractInputData):
    """
    Select a data from data_list as output, data_list only support AbstractDataConsumption type
    """
    def __init__(self, data_list):
        """
        Args:
            data_list (list[AbstractDataConsumption]): input AbstractDataConsumption list
        """
        DataConsumptionSelector._check_data_list(data_list)
        self.data_list = data_list

    def consume(self):
        for data in self.data_list:
            if not data.config.is_skipped:
                return data.consume()
        raise Exception("DataConsumptionSelector all input data are None")

    def type(self):
        return self.data_list[0].type()

    @staticmethod
    def _check_data_list(data_list):
        if not isinstance(data_list, list):
            raise TypeError('data_list only support list type, but provided: {}'.format(type(data_list)))
        data_type = None
        for data in data_list:
            if not isinstance(data, AbstractDataConsumption):
                raise TypeError('only support AbstractDataConsumption type, but provided: {}'.format(type(data)))
            if not data_type:
                data_type = data.type()
                continue
            if data_type != data.type():
                raise TypeError('data_list only supports the same data type')

    def is_need_consume(self):
        return True

    def to_definition_json(self):
        pass

    def ref(self):
        ref_list = ['{}/{}'.format(data.step_name, data.output_name) for data in self.data_list]
        return "$ref/consumptions/{}".format('[{}]'.format(','.join(ref_list)))


class DataSelector(AbstractDataPlaceholders):
    def __init__(self, name, data_type_list, delay=False, required=True):
        self._check_init(data_type_list=data_type_list)
        super(DataSelector, self).__init__(name, delay, required)
        self.data_type_list = data_type_list
        self._data = None
        self._dataset_client = None

    @property
    def dataset_client(self):
        return self._dataset_client

    @dataset_client.setter
    def dataset_client(self, dataset_client):
        self._dataset_client = dataset_client

    def _get_condition_json(self) -> TransformType:
        result = [{
            "attribute": "data_type",
            "operator": "in",
            "value": self.data_type_list,
        }]
        return result

    def to_definition_json(self) -> TransformType:
        result = {
            "name": self.name,
            "type": self.type(),
            "delay": self.delay,
            "conditions": self._get_condition_json()
        }

        if not self.required:
            result["required"] = False

        return result

    def type(self):
        return "data_selector"

    def is_set(self) -> bool:
        return self._data is not None

    def set_data(self, data):
        self._data = data

    def get_data_from_command_line(self):
        input_format_str = ""
        for data_type in self.data_type_list:
            input_format = DATA_INPUT_FORMAT_MAPPING[data_type]
            input_format_str = input_format_str + 'If the data type you need is {}, please input: {}\n'.format(
                data_type, input_format)
        param = input(
            'Please enter the DataSelector {} value according to data type:\n'
            '{}\n'.format(self.name, input_format_str))
        self.set_data(param)
        param_value = ast.literal_eval(param)
        if param_value.get("obs_path"):
            self.set_obs(param_value)
        if param_value.get("dataset_name"):
            self.set_dataset(param_value)

    def data(self) -> AbstractData:
        return self._data

    def consume(self):
        return self._data

    def set_dataset(self, param):
        if self.dataset_client is None:
            raise ValueError('The dataset_client is None of DataSelector {}'.format(self.name))
        dataset = Dataset(dataset_name=param["dataset_name"], version_name=param["version_name"])
        dataset.fill_id_and_version_id(dataset_client=self.dataset_client)
        return self.set_data(dataset)

    def set_obs(self, param):
        return self.set_data(OBSPath(param["obs_path"]))

    @staticmethod
    def _check_init(data_type_list):
        if not isinstance(data_type_list, list) or not data_type_list:
            raise ValueError("The data type list is abnormal")
        support_data_type = DATA_INPUT_FORMAT_MAPPING.keys()
        for data_type in data_type_list:
            if data_type in support_data_type:
                continue
            raise ValueError(
                "The data type must be in {}, but you provided {}".format(support_data_type, data_type))
