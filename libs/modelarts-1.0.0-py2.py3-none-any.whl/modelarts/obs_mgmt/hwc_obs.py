"""
Description: Cloud OBS management using roma s3 API and obs client
Author: ModelArts SDK Team
Date: 2021/07/01 - 2021/07/29
"""

import multiprocessing
import os
import sys
import threading
from urllib.parse import quote

from tenacity import retry, stop_after_attempt, wait_fixed
from obs import ObsClient, DeleteObjectsRequest, Object, CompleteMultipartUploadRequest, CompletePart, GetObjectHeader

from modelarts import constant
from modelarts.util.obs_logger import OBSLogger
from modelarts.exception.apig_exception import APIGException
from .obs_base import OBSApiBase, TransferJob
from . import constant as obs_constant

is_linux_system = sys.platform.lower().startswith(obs_constant.LINUX_SYSTEM)
MAX_OBJECT_NUMS = 1000


class HwcOBSApiImpl(OBSApiBase):
    """  Operate ROMA OBS object.
    """

    def __init__(self, server, ak, sk, security_token=None, is_secure=True,
                 path_style=True, proxy_host=None,
                 proxy_port=None, proxy_username=None, proxy_password=None):
        OBSApiBase.__init__(self)

        self.access_key_id = ak
        self.secret_access_key = sk
        self.security_token = security_token
        self.is_secure = is_secure
        self.server = server
        self.path_style = path_style
        self.proxy_host = proxy_host
        self.proxy_port = proxy_port
        self.proxy_username = proxy_username
        self.proxy_password = proxy_password
        self.obs_client = self._get_obs_client()

    def is_obs_file(self, obs_file):
        """ whether the file is obs file
        :param obs_file:
        :return: bool, True or False
        """
        OBSApiBase.check_obs_file_head_tail(obs_file)
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_file)
        object_meta_info = self._hwc_api_get_object_metadata(bucket_name, object_key)
        return object_meta_info.status == 200

    @retry(stop=stop_after_attempt(obs_constant.RETRY_TIMES), reraise=True,
           wait=wait_fixed(obs_constant.RETRY_INTERVAL))
    def upload_file(self, src_local_file, dst_obs_dir, file_size=None, check_file=True):
        """ upload local file to obs path
        :param src_local_file: source local file path, e.g. c://programs/obs.py"
        :param dst_obs_dir: destination obs directory, e.g. obs://bucket_name/obs_dir/"
        :param file_size: local file size
        :param check_file: whether to check file path and file size,
                False when called by upload_dir(do not check local files), otherwise, True(check local files).
        """
        dst_file_dir, dst_file_name = OBSApiBase.get_dst_file_name(src_local_file, dst_obs_dir)
        if dst_file_dir:
            dst_obs_dir = dst_file_dir
        if check_file:
            self._check_paths(src_local_file, dst_obs_dir, constant.UPLOAD_MODE,
                              obs_constant.FILE_MODE, is_check_obs_path_exist=False)
        file_path, file_name = os.path.split(src_local_file)
        if dst_file_name:
            file_name = dst_file_name

        file_size = file_size or self.get_file_size(src_local_file)
        legal_dst_obs_dir = quote(self._extract_obs_dir_format(dst_obs_dir))
        if file_size <= obs_constant.MAX_BLOCK_SIZE:
            self._hwc_api_put_file(legal_dst_obs_dir, file_name, src_local_file)
        else:
            self._hwc_api_upload_multi_blocks(legal_dst_obs_dir, file_name, src_local_file, file_size)

    def upload_dir(self, src_local_dir, dst_obs_dir, keep_last_dir):
        """ upload local directory to obs path
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_local_dir = OBSApiBase.add_suffix_slash(src_local_dir)
        dst_obs_dir = OBSApiBase.add_suffix_slash(dst_obs_dir)
        self._check_paths(src_local_dir, dst_obs_dir, constant.UPLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=False)
        src_local_file_list = OBSApiBase.get_local_dir_file_path_list(
            src_local_dir)
        self._upload_dir(src_local_dir, dst_obs_dir, src_local_file_list,
                         mode=obs_constant.NORMAL_MODE, silence=False, keep_last_dir=keep_last_dir)

    def increment_upload_dir(self, src_local_dir, dst_obs_dir, increment_files, keep_last_dir):
        """ upload local directory to obs path incrementally
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param increment_files: list of increment files to be upload, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_local_dir = OBSApiBase.add_suffix_slash(src_local_dir)
        dst_obs_dir = OBSApiBase.add_suffix_slash(dst_obs_dir)
        self._check_paths(src_local_dir, dst_obs_dir, constant.UPLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=False)
        if increment_files:
            # check local files
            OBSApiBase.check_increment_files(src_local_dir, increment_files)
        else:
            increment_files = OBSApiBase.get_increment_files(src_local_dir)
        upload_files_list = OBSApiBase.get_increment_upload_files(increment_files)
        self._upload_dir(src_local_dir, dst_obs_dir, upload_files_list,
                         mode=obs_constant.INCREMENT_MODE, silence=True, keep_last_dir=keep_last_dir)

    @retry(stop=stop_after_attempt(obs_constant.RETRY_TIMES), reraise=True,
           wait=wait_fixed(obs_constant.RETRY_INTERVAL))
    def download_file(self, src_obs_file, dst_local_dir, object_size=None, check_file=True):
        """ download obs file to local
        :param src_obs_file: source obs file path
        :param dst_local_dir: destination local directory
        :param object_size: obs file size
        :param check_file: whether to check file path and file size,
                False when called by upload_dir(do not check obs files), otherwise, True(check obs files).
        """
        dst_file_dir, dst_file_name = OBSApiBase.get_dst_file_name(src_obs_file, dst_local_dir)
        if dst_file_dir:
            dst_local_dir = dst_file_dir

        is_check_obs_path_exist = False if object_size is not None else check_file
        self._check_paths(dst_local_dir, src_obs_file, obs_constant.DOWNLOAD_MODE,
                          obs_constant.FILE_MODE, is_check_obs_path_exist=is_check_obs_path_exist)
        if check_file and object_size is None:
            object_size = self.get_file_size(src_obs_file)

        bucket_name, bucket_dir_path, bucket_file_name = self._get_bucket_info(src_obs_file)
        bucket_file_path_without_bucket_name = OBSApiBase.update_path_sep(
            os.path.join(bucket_dir_path, bucket_file_name)
        )
        if dst_file_name:
            bucket_file_name = dst_file_name
        dst_local_file_path = os.path.join(dst_local_dir, bucket_file_name)

        if object_size <= obs_constant.MAX_BLOCK_SIZE:
            self._hwc_api_get_object(bucket_name, bucket_file_path_without_bucket_name, dst_local_file_path)
        else:
            self._hwc_api_download_multi_blocks(bucket_name, bucket_file_path_without_bucket_name,
                                                dst_local_file_path, object_size)

    def download_dir(self, src_obs_dir, dst_local_dir, keep_last_dir, specified_objects=None):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :param specified_objects: type: list, specified objects to be downloaded, e.g. [object1, object2, ...]
        """
        if specified_objects and not isinstance(specified_objects, list):
            raise Exception(f"the type specified_objects should be [list], but got {type(specified_objects)}")

        src_obs_dir = OBSApiBase.add_suffix_slash(src_obs_dir)
        dst_local_dir = OBSApiBase.add_suffix_slash(dst_local_dir)

        self._check_paths(dst_local_dir, src_obs_dir, obs_constant.DOWNLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=True)
        bucket_name, bucket_dir_path, _ = self._get_bucket_info(src_obs_dir)
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        objects_attr_dict = self._get_objects_attribute(bucket_name,
                                                        bucket_dir_path)
        self._check_name_duplicates(objects_attr_dict)

        objects_key_and_size = {}
        for object_key, object_attr in objects_attr_dict.items():
            if not object_key.endswith(constant.SEP):
                object_path = f'{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}'
                objects_key_and_size[object_path] = object_attr.get('size')

        sub_objects_size = OBSApiBase._get_sub_objects(specified_objects, objects_key_and_size)
        self._download_dir(src_obs_dir, dst_local_dir, bucket_dir_path, sub_objects_size or objects_key_and_size,
                           mode=obs_constant.NORMAL_MODE, silence=False, keep_last_dir=keep_last_dir)

    def increment_download_dir(self, src_obs_dir, dst_local_dir, increment_files, keep_last_dir):
        """ download obs directory to local path incrementally
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory
        :param increment_files: list of increment files to be download, e.g. ['./dir1/file1', './dir2/file2', ...]
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        src_obs_dir = OBSApiBase.add_suffix_slash(src_obs_dir)
        dst_local_dir = OBSApiBase.add_suffix_slash(dst_local_dir)
        self._check_paths(dst_local_dir, src_obs_dir, obs_constant.DOWNLOAD_MODE,
                          constant.DIR_MODE, is_check_obs_path_exist=True)

        bucket_name, bucket_dir_path, _ = self._get_bucket_info(src_obs_dir)
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        if increment_files:
            # check obs files
            self._check_increment_files(src_obs_dir, increment_files)
            increment_files = {
                file_path: {'size': self.get_file_size(file_path), 'md5': self.get_object_attr(file_path)[1]}
                for file_path in increment_files}
        else:
            increment_files = self._get_objects_attribute(bucket_name, bucket_dir_path)

        download_files_list = OBSApiBase.get_increment_download_files(bucket_name, increment_files)
        if not download_files_list:
            return
        self._download_dir(src_obs_dir, dst_local_dir, bucket_dir_path, download_files_list,
                           mode=obs_constant.INCREMENT_MODE, silence=True, keep_last_dir=keep_last_dir)

    def copy(self, src_path, dst_path, keep_last_dir):
        """ Transfer data between OBS and Local. Support download from OBS or upload to OBS;
            Support transter files or directory
        :param src_path: obs path or local path
        :param dst_path: obs path or local path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        """
        if not src_path.startswith(constant.OBS_HEAD_FORMAT) and not dst_path.startswith(constant.OBS_HEAD_FORMAT):
            raise Exception(f'OBS path should start with {constant.OBS_HEAD_FORMAT}')

        if os.path.isdir(src_path) or self.is_obs_directory(src_path):
            self._copy_directory(src_path, dst_path, keep_last_dir)
        else:
            self._copy_file(src_path, dst_path)

    def del_obs_file(self, obs_file):
        """ delete obs object(file)
        :param obs_file: obs object(file)
        :return:
        """
        self._check_obs_path(obs_file, obs_constant.DOWNLOAD_MODE, obs_constant.FILE_MODE, True)
        bucket_name, bucket_dir_path, _ = self._get_bucket_info(obs_file)
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        try:
            object_keys = [Object(key=bucket_dir_path + obs_file.split(constant.SEP)[-1])]
            resp = self.obs_client.deleteObjects(bucket_name, DeleteObjectsRequest(False, object_keys))
            if resp.status >= 300:
                raise Exception(resp.errorMessage)
        except Exception as e:
            raise Exception(e)

    def del_obs_dir(self, obs_dir):
        """ delete obs objects(directory)
        :param obs_dir: obs objects(directory)
        :return:
        """
        obs_dir = OBSApiBase.add_suffix_slash(obs_dir)
        self._check_obs_path(obs_dir, obs_constant.DOWNLOAD_MODE, constant.DIR_MODE, True)
        bucket_name, bucket_dir_path, _ = self._get_bucket_info(obs_dir)
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        bucket_dir_object_list = self._get_bucket_dir_objects(bucket_name, bucket_dir_path)
        num_idx = 0
        while num_idx < len(bucket_dir_object_list):
            try:
                object_keys = [Object(key=i) for i in bucket_dir_object_list[num_idx:num_idx + MAX_OBJECT_NUMS]]
                num_idx += MAX_OBJECT_NUMS
                resp = self.obs_client.deleteObjects(bucket_name, DeleteObjectsRequest(False, object_keys))
                if resp.status >= 300:
                    raise Exception(resp.errorMessage)
            except Exception as e:
                raise Exception(e)

    def is_obs_path_exists(self, obs_path):
        """ check whether the obs path exists
        :param obs_path: obs directory or obs file
        :return: bool, True or False
        """
        if obs_path.startswith(constant.OBS_HEAD_FORMAT) and '\\' in obs_path:
            raise Exception(f'{obs_constant.WINDOWS_PATH_SEP_WARN}, got {obs_path}')
        if not obs_path.startswith(constant.OBS_HEAD_FORMAT):
            return False
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_client = self.obs_client.bucketClient(bucket_name)
        resp = bucket_client.getObjectMetadata(object_key)
        if resp.status == 200:
            return True

        obs_path = OBSApiBase.add_suffix_slash(obs_path)
        _, bucket_dir_path = OBSApiBase.split_obs_path(obs_path)
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        bucket_dir_object_list = self._get_bucket_dir_objects(bucket_name,
                                                              bucket_dir_path,
                                                              is_list_all_objects=False)
        return not len(bucket_dir_object_list) == 0

    def is_obs_directory(self, obs_path):
        """ check whether the obs path is directory
        :param obs_path:
        :return: bool, True or False
        """
        obs_path = OBSApiBase.add_suffix_slash(obs_path)
        return self.is_obs_path_exists(obs_path)

    def list_all_objects(self, obs_path, is_list_all_objects=True, show_progress=False):
        """ get all objects in obs directory
        :param obs_path: obs directory which should starts with obs:/ and ends with /
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_progress: show the progress of listing obs objects, default is False
        :return: list of obs files
        """
        obs_path = OBSApiBase.add_suffix_slash(obs_path)
        bucket_name, bucket_dir_path, _ = self._get_bucket_info(obs_path)
        # add '/' in to bucket_dir_path because obs client need it
        bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
        object_keys = self._get_bucket_dir_objects(bucket_name, bucket_dir_path, is_list_all_objects, show_progress)
        return [f"{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}" for object_key in object_keys]

    def create_obs_bucket(self, bucket_name, region_name=None):
        try:
            resp = self.obs_client.createBucket(bucketName=bucket_name, location=region_name)
            if resp.status >= 300:
                raise Exception(resp.errorMessage)
        except Exception as e:
            raise Exception(e)

    def list_buckets(self):
        bucket_list = []
        try:
            resp = self.obs_client.listBuckets()
            for bucket in resp.body.buckets:
                bucket_list.append(bucket.name)
        except Exception as e:
            raise Exception(e)
        return bucket_list

    def is_bucket_exists(self, bucket_name):
        try:
            resp = self.obs_client.headBucket(bucketName=bucket_name)
            return resp.status < 300
        except Exception as e:
            raise Exception(e)

    def make_obs_dir(self, obs_dir):
        """ make obs directory
        :param obs_dir: obs directory which should starts with obs://
        """
        bucket_name, bucket_dir_path, bucket_file_name = self._get_bucket_info(obs_dir)
        object_key = OBSApiBase.update_path_sep(os.path.join(bucket_dir_path, bucket_file_name, ''))
        try:
            self._get_obs_client().putContent(bucket_name, object_key, '')
        except Exception as e:
            raise e

    def get_objects_size(self, obs_path):
        """ get size of obs objects
        :param obs_path: obs directory or obs file
        :return: dict of obs path and obs file size, e.g. {'obs_object': file_size, ...}
        """
        objects_size = {}
        if self.is_obs_directory(obs_path):
            obs_path = OBSApiBase.add_suffix_slash(obs_path)
            bucket_name, bucket_dir_path, bucket_file_name = self._get_bucket_info(obs_path)
            bucket_dir_path = OBSApiBase.add_suffix_slash(bucket_dir_path)
            objects_attr = self._get_objects_attribute(bucket_name, bucket_dir_path, is_list_all_objects=True)
            for object_key, object_attr in objects_attr.items():
                objects_size[f"{constant.OBS_HEAD_FORMAT}{bucket_name}/{object_key}"] = int(object_attr.get('size'))
            return objects_size
        elif self.is_obs_file(obs_path):
            objects_size[obs_path] = int(self.get_object_attr(obs_path)[0])
            return objects_size
        else:
            raise Exception(f"Expected valid obs directory or obs file, but got {obs_path}")

    def get_object(self, obs_path, limited_size):
        """ get obs object with limited size
        :param obs_path: obs file path
        :param limited_size: obs object limited size
        :return: content size and content
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        resp = self.obs_client.getObject(bucket_name, object_key)
        content_size = 0
        content = ""
        if resp.status > 300:
            raise APIGException(code=resp.errorCode, message=resp.errorMessage)
        try:
            data = resp.body.response.read(limited_size)
            content_size = len(data)
            content = data.decode()
        except Exception as e:
            error_reason = "Failed to read data from response: {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)
        finally:
            resp.body.response.close()
        return content_size, content

    def _upload_dir(self, src_local_dir, dst_obs_dir, src_local_file_list, mode, silence, keep_last_dir):
        """ upload local directory to obs
        :param src_local_dir: source local directory path
        :param dst_obs_dir: destination obs directory path
        :param src_local_file_list: list of local files to be upload
        :param mode: normal or increment, normal represents upload, Otherwise, increment upload
        :param silence: show transfer progress, False for normal mode, True for increment
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        src_local_file_list, dst_obs_file_list = \
            OBSApiBase.get_upload_files_list(src_local_dir, dst_obs_dir, src_local_file_list, keep_last_dir)

        upload_job = TransferJob(self.upload_file,
                                 src_file_list=src_local_file_list,
                                 dst_file_list=dst_obs_file_list,
                                 file_size_list=None,
                                 mode=mode,
                                 silence=silence)

        OBSApiBase.do_transfer(upload_job)

    def _download_dir(self, src_obs_dir, dst_local_dir, bucket_dir_path, objects_key_and_size, mode, silence,
                      keep_last_dir):
        """ download obs directory to local path
        :param src_obs_dir: source obs directory path
        :param dst_local_dir: destination local directory path
        :param objects_key_and_size: type: dict, e.g. {objects1: size1, objects2: size2, ... }
        :param mode: normal or increment, normal represents upload or download, Otherwise, increment transfer
        :param silence: show transfer progress, False for normal mode(upload or download), True for increment
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        src_obs_file_list, dst_local_file_list, obs_object_size_list = \
            OBSApiBase.get_download_files_list(src_obs_dir,
                                               dst_local_dir,
                                               bucket_dir_path,
                                               objects_key_and_size,
                                               keep_last_dir)

        download_job = TransferJob(self.download_file,
                                   src_file_list=src_obs_file_list,
                                   dst_file_list=dst_local_file_list,
                                   file_size_list=obs_object_size_list,
                                   mode=mode,
                                   silence=silence)

        OBSApiBase.do_transfer(download_job)

    def _copy_directory(self, src_path, dst_path, keep_last_dir):
        """ upload/download directory
        :param src_path: source path
        :param dst_path: destination path
        :param keep_last_dir: If True,  copy files to ./dir2/dir1.  Otherwise, to ./dir2
        :return:
        """
        if os.path.isdir(src_path):
            self.upload_dir(src_path, dst_path, keep_last_dir)
        else:
            self.download_dir(src_path, dst_path, keep_last_dir)

    def _copy_file(self, src_path, dst_path):
        """ upload/download file
        :param src_path: source path
        :param dst_path: destination path
        :return:
        """
        if os.path.isfile(src_path):
            self.upload_file(src_path, dst_path)
        elif self.is_obs_path_exists(src_path.rstrip(constant.SEP)):
            self.download_file(src_path, dst_path)
        else:
            raise Exception(f'file {src_path} does not exist')

    def _get_bucket_info(self, obs_path):
        """
        :param obs_path:
        :return: bucket name, bucket directory path, file name
        """
        bukect_name, object_key = OBSApiBase.split_obs_path(obs_path)
        bucket_dir_path, bucket_file_name = os.path.split(object_key)
        return bukect_name, bucket_dir_path, bucket_file_name

    def _check_name_duplicates(self, objects_attr_dict):
        """ check for files and directories with the same name in obs
        :param bucket_dir_object_list: list of obs objects
        :return: legal files or directories to be transfered
        """
        for obs_file in objects_attr_dict.keys():
            if obs_file.endswith(constant.SEP):
                obs_file = obs_file.strip(constant.SEP)
                if obs_file in objects_attr_dict.keys():
                    raise Exception(f"find file and directory with same name in obs, can not download {obs_file}")

    def _check_increment_files(self, src_obs_dir, increment_files):
        """ check whether increment files legal
        :param src_obs_dir:
        :param increment_files:
        :return:
        """
        OBSApiBase.check_list_type(increment_files)
        for increment_file in increment_files:
            self._check_obs_path(increment_file, obs_constant.DOWNLOAD_MODE, obs_constant.FILE_MODE, True)
        OBSApiBase.check_parent_path(src_obs_dir, increment_files)

    def _get_source_files(self, bucket_name, bucket_dir_path):
        """ get source file paths
        :param bucket_name:
        :param bucket_dir_path:
        :return: list of files to be transfered
        """
        source_files = ["{}{}/{}".format(constant.OBS_HEAD_FORMAT, bucket_name, i) for i in
                        self._get_objects_attribute(bucket_name, bucket_dir_path)]
        return source_files

    def _check_paths(self, local_path, obs_path, transfer_mode, file_mode, is_check_obs_path_exist=True):
        """ check whether both the local path and obs path legal and exist
        :param local_path: local directory or local file
        :param obs_path:  obs directory or obs file
        :param transfer_mode:  download or upload
        :param file_mode: file or dir
        :param is_check_obs_path_exist: True for download, False for upload
        """
        self._check_obs_path(obs_path, transfer_mode, file_mode, is_check_obs_path_exist)
        OBSApiBase.check_local_path_legal(local_path, transfer_mode, file_mode)

    def _check_obs_path(self, obs_path, transfer_mode, file_mode, is_check_obs_path_exist):
        """ check whether the obs path legal and exists
        :param obs_path: obs directory or file
        :param transfer_mode: upload or download
        :param file_mode: file or dir
        :param is_check_obs_path_exist: True for download, False for upload
        """
        if not is_check_obs_path_exist:
            return
        OBSApiBase.check_obs_path_legal(obs_path, transfer_mode, file_mode)
        if not self.is_obs_path_exists(obs_path):
            raise Exception(f'your obs path {obs_path} does not exist')

    def _get_obs_client(self):
        """ initial obs client
        :return: obs client
        """
        return ObsClient(access_key_id=self.access_key_id,
                         secret_access_key=self.secret_access_key,
                         security_token=self.security_token,
                         is_secure=self.is_secure,
                         server=self.server,
                         path_style=self.path_style,
                         proxy_host=self.proxy_host,
                         proxy_port=self.proxy_port,
                         proxy_username=self.proxy_username,
                         proxy_password=self.proxy_password)

    def _get_bucket_dir_objects(self, bucket_name, bucket_dir_path, is_list_all_objects=True, show_list_progress=False):
        """ get bucket_dir all objects list, all objects integral path
        :param bucket_name:
        :param bucket_dir_path: bucket directory path, .e.g. dir1/dir2/
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_list_progress: default is False
        :return: object_list:  object list without bucket name, .e.g ['dir1/dir2/file1', 'dir1/dir2/file2']
        """
        object_attr_dict = self._get_objects_attribute(bucket_name, bucket_dir_path,
                                                       is_list_all_objects=is_list_all_objects,
                                                       show_list_progress=show_list_progress)
        return list(object_attr_dict.keys())

    def _get_objects_attribute(self, bucket_name, bucket_dir_path, is_list_all_objects=True, show_list_progress=False):
        """ get bucket_dir all objects list, all objects integral path
        :param bucket_name:
        :param bucket_dir_path: bucket directory path, .e.g. dir1/dir2/
        :param is_list_all_objects: set to False while checking obs path for reducing time of listing objects,
                                      True for transfer data, default is True
        :param show_list_progress: default is False
        :return: objects attribute, type: dict. e.g. {'obs://bucket_name/file_path:{'size':123, 'md5':'aaa'}, ...}
        """
        all_object_info_list = []
        marker = None

        while True:
            list_objects_resp = self._hwc_api_list_objects(bucket_name, bucket_dir_path, MAX_OBJECT_NUMS, marker)
            all_object_info_list.append(list_objects_resp)
            if not list_objects_resp.body.is_truncated or not is_list_all_objects:
                break
            marker = list_objects_resp.body.next_marker
            # got 1000 files in list_objects_resp each time while calling _hwc_api_list_objects
            if show_list_progress:
                OBSLogger.common_info_log(f'listing obs object: {MAX_OBJECT_NUMS * len(all_object_info_list)}')
        object_attr_dict = {}
        for object_info_list in all_object_info_list:
            for content in object_info_list.body.contents:
                object_attr_dict[content.key] = {"md5": content.etag.strip("\""), "size": content.size}
        return object_attr_dict

    @classmethod
    def _extract_obs_dir_format(cls, pre_obs_dir):
        """  extract obs dir as hwc obs format bucket_name/dir1
        :param pre_obs_dir: obs://bucket_name/dir1/ -> bucket_name/dir1
        :return: bucket_name/dir1
        """
        obs_dir_del_head = pre_obs_dir.split(constant.OBS_HEAD_FORMAT, 1)[-1]
        legal_obs_dir = OBSApiBase.update_path_sep(
            os.path.normpath(obs_dir_del_head)
        )
        return legal_obs_dir

    def _hwc_api_get_object_metadata(self, bucket_name, file_path):
        """
        :param bucket_name: bucket name
        :param file_path: file_path, .e.g.dir1/dir2/file1
        :return:
        """
        try:
            resp = self.obs_client.getObjectMetadata(bucket_name, file_path)
            if resp.status > 300 and resp.status != 404:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception("errorMessage: {}".format(resp.errorMessage))
            return resp
        except Exception as e:
            error_reason = "Failed to get object metadata, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_list_objects(self, bucket_name, prefix, max_keys, marker):
        """ hwc obs client list objects
        :param bucket_name:
        :param prefix: only get objects with specific prefix
        :param max_keys:
        :param marker:
        :return:
        """
        # for bucket, prefix should be None, else is the object path without bucket_name
        try:
            list_objects_resp = self.obs_client.listObjects(bucketName=bucket_name,
                                                            prefix=None if prefix == '/' else prefix,
                                                            max_keys=max_keys,
                                                            marker=marker)
            if list_objects_resp.status > 300:
                OBSLogger.hwc_error_log(api_response=list_objects_resp)
                raise Exception(
                    "errorMessage: {}".format(list_objects_resp.errorMessage))
            return list_objects_resp
        except Exception as e:
            error_reason = "Failed to list objects, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_get_object(self, bucket_name,
                            bucket_file_path_without_bucket_name,
                            dst_local_file_path):
        """ hwc obs client get object
        :param bucket_name: bucket name
        :param bucket_file_path_without_bucket_name:
        bucket file path without bucket name
        :param dst_local_file_path: local destination file path, include file name
        :return:
        """
        try:
            resp = self.obs_client.getObject(bucket_name,
                                             bucket_file_path_without_bucket_name)
            if resp.status > 300:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception(f'errorMessage is {resp.errorMessage}')
            with os.fdopen(os.open(dst_local_file_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                                   constant.FILE_PERMISSION), "wb") as f:
                while True:
                    chunk = resp.body.response.read(obs_constant.CHUNK_SIZE)
                    if not chunk:
                        break
                    f.write(chunk)
            resp.body.response.close()

        except Exception as e:
            error_reason = "Failed to download object, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _hwc_api_put_file(self, legal_dst_obs_dir, file_name, src_local_file):
        """ HWC OBS client for  putFile
        :param legal_dst_obs_dir:  bucket_name/dir1/dir2
        :param file_name: file.py , after upload to obs file_name
        :param src_local_file:
        :return:
        """
        try:
            resp = self.obs_client.putFile(legal_dst_obs_dir, file_name,
                                           src_local_file)
            if resp.status > 300:
                OBSLogger.hwc_error_log(api_response=resp)
                raise Exception(f'error message is {resp.errorMessage}')
        except Exception as e:
            error_reason = "Failed to upload file, for {}".format(e)
            OBSApiBase.handle_exception_logs(error_reason)

    def _upload_block(self, obsClient, completed_block, bucket_name, object_key, block_number, upload_id,
                      src_local_path,
                      cur_block_size, offset):
        """ upload a block of large file
        :param obsClient:
        :param completed_block: dict type, record completed file block
        :param bucket_name: obs bucket name
        :param object_key: obs path without bucket name
        :param block_number: index of file block
        :param upload_id: unique id for current large file
        :param src_local_path: source local path
        :param cur_block_size: size of current block
        :param offset: the starting offset size of a segment in the source file
        """
        resp = obsClient.uploadPart(bucket_name, object_key, block_number, upload_id, content=src_local_path,
                                    isFile=True,
                                    partSize=cur_block_size, offset=offset)
        if resp.status < 300:
            completed_block[block_number] = resp.body.etag
        else:
            OBSLogger.hwc_error_log(f'Part#{block_number} failed, error message is {resp.errorMessage}')

    def _init_multi_upload_id(self, obsClient, legal_dst_obs_dir, file_name):
        """ get unique upload id for current large file
        :param obsClient:
        :param legal_dst_obs_dir: obs directory
        :param file_name: obs file name
        :return: upload id, obs bucket name, object key
        """
        obs_path = OBSApiBase.update_path_sep(os.path.join(constant.OBS_HEAD_FORMAT, legal_dst_obs_dir, file_name))
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        resp = obsClient.initiateMultipartUpload(bucket_name, object_key)
        if resp.status >= 300:
            raise Exception(f'initiate multi block upload failed, error message is {resp.errorMessage}')
        return resp.body.uploadId, bucket_name, object_key

    def _multi_blocks_upload(self, obsClient, bucket_name, object_key, upload_id, completed_block):
        """ get unique upload id for current large file
        :param obsClient:
        :param bucket_name: obs bucket name
        :param object_key: obs path without bucket name
        :param upload_id: unique id for current large file
        :param completed_block: dict type, record completed file block
        """
        completed_block = sorted(completed_block.items(), key=lambda d: d[0])
        blocks = []
        for key, value in completed_block:
            blocks.append(CompletePart(partNum=key, etag=value))
        resp = obsClient.completeMultipartUpload(bucket_name, object_key, upload_id,
                                                 CompleteMultipartUploadRequest(blocks))

        if resp.status >= 300:
            raise Exception(f'failed to upload multi blocks, error message is {resp.errorMessage}')

    def _hwc_api_upload_multi_blocks(self, legal_dst_obs_dir, file_name, src_local_file, file_size):
        """ upload multi blocks of a file larger then 5 GB
        :param legal_dst_obs_dir: destination obs directory
        :param file_name: file name
        :param src_local_file: source local file path
        :param file_size: size of local file
        """
        upload_id, bucket_name, object_key = self._init_multi_upload_id(self.obs_client, legal_dst_obs_dir, file_name)

        block_count = self._get_block_count(file_size)
        if block_count > obs_constant.MAX_UPLOAD_BLOCKS:
            raise Exception(
                f'Total file size of {src_local_file} is {file_size}, larger than the maximum '
                f'size {obs_constant.MAX_UPLOAD_BLOCKS * obs_constant.MAX_BLOCK_SIZE}, '
                'please divide this large file into several smaller files with size less than'
                f' {obs_constant.MAX_UPLOAD_BLOCKS * obs_constant.MAX_BLOCK_SIZE}')

        proc = threading.Thread if not is_linux_system else multiprocessing.Process
        completed_block = dict() if not is_linux_system else multiprocessing.Manager().dict()
        processes = []
        for i in range(block_count):
            offset = i * obs_constant.MAX_BLOCK_SIZE
            cur_block_size = (file_size - offset) if i + 1 == block_count else obs_constant.MAX_BLOCK_SIZE
            p = proc(target=self._upload_block,
                     args=(self.obs_client, completed_block, bucket_name, object_key, i + 1, upload_id, src_local_file,
                           cur_block_size,
                           offset))
            p.daemon = True
            processes.append(p)

        self._handle_processes(processes)

        if len(completed_block) != block_count:
            raise Exception(
                'Upload multi blocks failed due to some blocks are not finished yet, '
                f'please retry upload {src_local_file}')
        self._multi_blocks_upload(self.obs_client, bucket_name, object_key, upload_id, completed_block)

    def _get_block_count(self, file_size):
        """ calculate the number of blocks
        :param file_size: size of local file or obs file
        :return: number of file blocks
        """
        try:
            res = int(file_size / obs_constant.MAX_BLOCK_SIZE)
        except ZeroDivisionError as e:
            raise ValueError('obs_constant.MAX_BLOCK_SIZE can not be zero') from e
        return res if file_size % obs_constant.MAX_BLOCK_SIZE == 0 else res + 1

    def _handle_processes(self, processes):
        for p in processes:
            p.start()
        for p in processes:
            p.join()

    def _hwc_api_download_multi_blocks(self, bucket_name, object_key, dst_local_file, file_size):
        """ download multi blocks of a file larger than 5GB
        :param bucket_name: destination obs directory
        :param object_key: obs path without bucket name
        :param dst_local_file: destination local file path
        :param file_size: file size
        """
        block_count = self._get_block_count(file_size)
        if os.path.exists(dst_local_file):
            os.remove(dst_local_file)

        lock = threading.Lock() if not is_linux_system else multiprocessing.Lock()
        proc = threading.Thread if not is_linux_system else multiprocessing.Process
        completed_block = dict() if not is_linux_system else multiprocessing.Manager().dict()
        completed_block['value'] = 0
        with os.fdopen(os.open(dst_local_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, constant.FILE_PERMISSION), "wb"):
            pass
        processes = []
        for i in range(block_count):
            start_pos = i * obs_constant.MAX_BLOCK_SIZE
            end_pos = file_size - 1 if (i + 1) == block_count else ((i + 1) * obs_constant.MAX_BLOCK_SIZE - 1)
            p = proc(target=self._download_block,
                     args=(lock, completed_block, bucket_name, object_key, dst_local_file, start_pos, end_pos, i))
            p.daemon = True
            processes.append(p)

        self._handle_processes(processes)

        if completed_block.get('value') != block_count:
            obs_path = OBSApiBase.update_path_sep(os.path.join(constant.OBS_HEAD_FORMAT, bucket_name, object_key))
            raise Exception(f'failed to download multi blocks due to some blocks are not finished yet, '
                            f'please retry download {obs_path}')

    def _download_block(self, lock, completed_block, bucket_name, object_key, dst_local_file, start_pos, end_pos, i):
        """ download a block of large file
        :param lock: thread lock
        :param completed_block: record downloaded block
        :param bucket_name: bucket name
        :param object_key: obs path without bucket name
        :param dst_local_file: destination local file path
        :param start_pos: start index of current block, calculated based on file size
        :param end_pos: end index of current block, calculated based on file size
        :param i: index of current block
        """
        resp = self.obs_client.getObject(bucket_name, object_key,
                                         headers=GetObjectHeader(range='%d-%d' % (start_pos, end_pos)))
        if resp.status >= 300:
            obs_path = OBSApiBase.update_path_sep(os.path.join(constant.OBS_HEAD_FORMAT, bucket_name, object_key))
            raise Exception(f'failed to download block {i + 1} of {obs_path}, error message is {resp.errorMessage}')

        response = resp.body.response
        chunk_size = obs_constant.CHUNK_SIZE
        if response is not None:
            with open(dst_local_file, 'rb+') as f:
                f.seek(start_pos, 0)
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                response.close()
        with lock:
            completed_block['value'] += 1

    def get_file_size(self, file_path):
        """ get file size
        :param file_path: local file or obs file
        :return: file size
        """
        if os.path.isfile(file_path):
            return OBSApiBase.get_local_file_size(file_path)
        if file_path.startswith(constant.OBS_HEAD_FORMAT):
            return self.get_object_attr(file_path)[0]
        raise Exception(f'file {file_path} does not exist')

    def get_object_attr(self, obs_path):
        """ calculate obs file size and get obs file md5
        :param obs_path: obs file path
        :return: obs file size, obs file md5
        """
        bucket_name, object_key = OBSApiBase.split_obs_path(obs_path)
        resp = self._hwc_api_get_object_metadata(bucket_name, object_key)
        if resp.status >= 300:
            raise Exception(f'failed to get size of {obs_path}, error message is {resp.errorMessage}')
        return int(dict(resp.header).get('content-length')), resp.body.get('etag').strip('\"')
