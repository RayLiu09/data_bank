import logging
import uuid
import re
import json
from enum import Enum
from typing import List, Dict

import attr

from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.serialize import serialize, prepare_for_properties, ref
from modelarts.workflow.core.steps import Step, AbstractOutput, StepTypeEnum
from modelarts.workflow.core.state import StepState
from modelarts.workflow.core.placeholder import Placeholder, PlaceholderDict, TRAIN_FLAVOR_ID_FORMAT, \
    TRAIN_FLAVOR_FORMAT, PACIFIC_FORMAT, PFS_FORMAT, NFS_FORMAT, TRAIN_ENV_FORMAT, PlaceholderType
from modelarts.workflow.data.dataset import Dataset, DatasetPlaceholder, DatasetConsumption
from modelarts.workflow.data.obs import OBSPath, OBSConsumption, OBSOutputConfig, OBSPlaceholder
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.client.job_client import JobClient
from modelarts.workflow.client.gallery_client import GalleryClient
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.core.steps import StepPlaceholders
from modelarts.workflow.client.dataset_client import DatasetClient
from modelarts.workflow.steps.model_step import ModelConfig, MODEL_STATE_MAPPING
from modelarts.workflow.data.model import ModelData
from modelarts.workflow.client.model_predictor_client import ModelPredictorClient
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.data.metric import MetricsConfig
from modelarts.workflow.core.data import VariableConsumption
from modelarts.workflow.data.third_party_service import TripartiteServiceConfig
from modelarts.workflow.data.data_selector import DataConsumptionSelector, DataSelector
from modelarts.workflow.util.utils import get_random_name, get_next_version_name

FLAVOR_TYPE = "flavor_type"
DEVICE_DISTRIBUTED_MODE = "device_distributed_mode"
ALGORITHM_RESOURCE_REQUIREMENTS = "resource_requirements"
ALGORITHM_VERSION_ID_PATTERN = r'^\d+\.\d+\.\d+$'

JOB_STATE_MAPPING = {
    "Creating": StepState.Running,
    "Pending": StepState.Pending,
    "Running": StepState.Running,
    "Completed": StepState.Completed,
    "Failed": StepState.Failed,
    "Terminating": StepState.Stopping,
    "Terminated": StepState.Stopped,
    "Abnormal": StepState.Failed
}

PARAMETER_TYPE_MAPPING = {
    "Integer": PlaceholderType.INT,
    "Float": PlaceholderType.FLOAT,
    "String": PlaceholderType.STR,
    "Boolean": PlaceholderType.BOOL
}


def transfer_parameter_value(parameter_type, value):
    if parameter_type == "Integer":
        return int(value)
    if parameter_type == "Float":
        return float(value)
    if parameter_type == "Boolean":
        if value == "True":
            return True
        else:
            return False
    return value


class JobTypeEnum(Enum):
    """
    Job type enum
    """
    JOB = "job"
    HETERO_JOB = "hetero_job"


@ref
@serialize
@attr.s
class JobInputConfig:
    """
    Attributes:
        access_method (Union[str, Placeholder]): job input access method, only support parameter、env
        local_dir (Union[str, Placeholder]): container local path for data input channel mapping
        description (Union[str, Placeholder]): job input description info
    """
    access_method = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    local_dir = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    remote_constraints = attr.ib(default=None, validator=attr.validators.instance_of((list, Placeholder, type(None))))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))

    def to_definition_json(self):
        return self.serialize()


@ref
@serialize
@attr.s
class JobOutputConfig:
    """
    Attributes:
        access_method (Union[str, Placeholder]): job input access method, only support parameter、env
        local_dir (Union[str, Placeholder]): container local path for data input channel mapping
        period (Union[int, Placeholder]): data upload time period
        mode (Union[str, Placeholder]): data upload mode, support upload_periodically
        modelarts_hosted (Union[bool, Placeholder]): whether modelarts hosted
        prefetch_to_local (Union[bool, Placeholder]): whether prefetch data to container local
        description (Union[str, Placeholder]): job output description info
    """
    access_method = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    local_dir = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    period = attr.ib(default=None, validator=attr.validators.instance_of((int, Placeholder, type(None))))
    mode = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    prefetch_to_local = attr.ib(default=None, validator=attr.validators.instance_of((bool, Placeholder, type(None))))
    modelarts_hosted = attr.ib(default=None, validator=attr.validators.instance_of((bool, Placeholder, type(None))))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))

    def to_definition_json(self):
        return self.serialize()


class JobInput(CommonInput):

    def __init__(self, name, data, input_config=None):
        """
        The input of JobStep
        Args:
            name (str): the name of input
            data (Union[Dataset, DatasetPlaceholder, DatasetConsumption, OBSPath, OBSConsumption,
                    OBSPlaceholder, DataConsumptionSelector, DataSelector]): input data used by an training job
            input_config (JobInputConfig): job input config info
        """
        self._check_input_data(data=data)
        super(JobInput, self).__init__(name, data)
        self.config = input_config

    def to_definition_json(self):
        result = super(JobInput, self).to_definition_json()
        if self.config:
            result["config"] = self.config.ref()
        return result

    def to_request(self) -> TransformType:
        """
        Get the request structure for workflow service calls
        Returns (TransformType): The request structure

        """
        request = {
            "name": self.name,
        }
        if isinstance(self.data, Dataset):
            if self.data.id is None or self.data.version_id is None:
                raise ValueError('The id and version id of the dataset {} cannot be empty when used in JobStep'.format(
                    self.data.dataset_name))
            request["remote"] = {
                "dataset": {
                    "id": self.data.id,
                    "version_id": self.data.version_id
                }
            }
        elif isinstance(self.data, OBSPath):
            request["remote"] = {
                "obs": {
                    "obs_url": self.data.obs_path
                }
            }
        return request

    @staticmethod
    def _check_input_data(data):
        """
        Check the input data type, and throw an TypeError if the data type is wrong
        Args:
            data (object): input data from user

        Returns:

        """
        data_type_tuple = (Dataset, DatasetPlaceholder, DatasetConsumption, OBSPath, OBSConsumption,
                           OBSPlaceholder, DataConsumptionSelector, DataSelector)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of JobInput must be one of the {}. But provided: {}'.format(data_type_tuple,
                                                                                                       type(data)))
        if isinstance(data, Dataset):
            if data.version_name is None:
                raise ValueError(
                    'The version name of the dataset {} cannot be empty when used in JobStep'.format(data.dataset_name))


class JobOutput(AbstractOutput):

    def __init__(self, name, obs_config=None, model_config=None, metrics_config=None, service_config=None, output_config=None):
        """
        The output of JobStep, only one of obs_config and model_config can be selected
        Args:
            name (str): The name of output
            obs_config (OBSOutputConfig): Output configuration when the model is exported to OBS
            model_config (ModelConfig): Output configuration when the model is automatically registered
            metrics_config (MetricsConfig): Specify configuration information for output metrics
            service_config (TripartiteServiceConfig): Specify configuration information for tripartite service config
            output_config (JobOutputConfig): Job output config info
        """
        self._check_output_config(obs_config, model_config, metrics_config, service_config)
        super().__init__(name)
        self.config = obs_config or model_config or metrics_config or service_config
        self.output_config = output_config

    def to_definition_json(self) -> TransformType:
        """
        Returns the serialization definition of JobOutput
        Returns (TransformType): The serialization structure

        """
        result = {
            "name": self.name
        }
        if isinstance(self.config, OBSOutputConfig):
            result["type"] = "obs"
            result["config"] = self.config.to_definition_json()
            if self.output_config:
                result["config"].update(self.output_config.ref())
        elif isinstance(self.config, ModelConfig):
            result["type"] = "model"
            result["config"] = self._model_config_to_definition_json()
        elif isinstance(self.config, MetricsConfig):
            result["type"] = "metrics"
            result["config"] = self.config.to_definition_json()
        elif isinstance(self.config, TripartiteServiceConfig):
            result["type"] = "service_content"
            result["config"] = self.config.to_definition_json()
        else:
            raise TypeError('The config type is abnormal: {}'.format(type(self.config)))
        return result

    def _model_config_to_definition_json(self) -> TransformType:
        result_json = {}
        if self.config.model_name is not None:
            result_json["model_name"] = self.config.model_name.ref() \
                if isinstance(self.config.model_name, Placeholder) else self.config.model_name
        if self.config.model_version is not None:
            result_json["model_version"] = self.config.model_version.ref() \
                if isinstance(self.config.model_version, Placeholder) else self.config.model_version
        return result_json

    def to_request(self) -> TransformType:
        """
        Get the request structure of JobOutput for workflow service calls
        Returns (TransformType): The request structure

        """
        request = {
            "name": self.name
        }
        if isinstance(self.config, OBSOutputConfig):
            request["remote"] = {
                "obs": self._config_to_request()
            }
        elif isinstance(self.config, ModelConfig):
            request["remote"] = {
                "model": self._model_config_to_request()
            }
        else:
            raise TypeError(
                'The config type must be OBSOutputConfig or ModelConfig. But provided: {}'.format(type(self.config)))
        return request

    def _model_config_to_request(self) -> TransformType:
        request = {}
        if self.config.model_name is not None:
            request["model_name"] = self.config.model_name.value \
                if isinstance(self.config.model_name, Placeholder) else self.config.model_name
        if self.config.model_version is not None:
            request["model_version"] = self.config.model_version.value \
                if isinstance(self.config.model_version, Placeholder) else self.config.model_version
        return request

    def _config_to_request(self) -> TransformType:
        request = {}
        if isinstance(self.config.obs_path, Placeholder):
            request["obs_url"] = self.config.obs_path.value
        elif isinstance(self.config.obs_path, Storage):
            if self.config.obs_path.path is None:
                raise ValueError('The path of Storage {} is None'.format(
                    self.config.obs_path.name))
            request["obs_url"] = self.config.obs_path.path
        else:
            request["obs_url"] = self.config.obs_path

        return request

    def as_input(self):
        """
        Get the AbstractDataConsumption object, which is used for data transfer between multiple Steps
        Returns (AbstractDataConsumption):

        """
        return self.config.data_consumption(self.step_name, self.name)

    @staticmethod
    def _check_output_config(obs_config, model_config, metrics_config, service_config):
        """
        Check the output config type, and throw an TypeError if the config type is wrong
        Args:
            obs_config (OBSOutputConfig):  input data from user, type is OBSOutputConfig or None
            model_config (ModelConfig):  input data from user, type is ModelConfig or None
            metrics_config (MetricConfig):  input data from user, type is MetricConfig or None
            service_config (TripartiteServiceConfig): input data from user, type is TripartiteServiceConfig or None

        Returns:

        """
        if obs_config is not None and not isinstance(obs_config, OBSOutputConfig):
            raise TypeError(
                'The obs_config type must be OBSOutputConfig. But provided: {}'.format(type(obs_config)))
        if model_config is not None and not isinstance(model_config, ModelConfig):
            raise TypeError(
                'The model_config type must be ModelConfig. But provided: {}'.format(type(model_config)))
        if metrics_config is not None and not isinstance(metrics_config, MetricsConfig):
            raise TypeError(
                'The metrics_config type must be MetricsConfig. But provided: {}'.format(type(metrics_config)))
        if service_config is not None and not isinstance(service_config, TripartiteServiceConfig):
            raise TypeError('The service_config type must be TripartiteServiceConfig. But provided: {}'.format(
                type(service_config)))

    def set_data_to_config(self, model):
        if not isinstance(model, ModelData):
            raise TypeError('The data type must be ModelData. But provided: {}'.format(type(model)))
        self.config._set_model(model)

    def set_to_skip(self):
        self.config.is_skipped = True


@attr.s
class RewardAttr:
    """
    Attributes:
        name (str): name of reward_attrs
        mode (str): mode of reward_attrs
        regex (str): regex of reward_attrs
    """
    name = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    mode = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    regex = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))


@attr.s
class SearchParam:
    """
    Attributes:
        name (str): name of search_params
        param_type (str): param type of search_params
        lower_bound (str): lower bound value of search_params
        upper_bound (str):upper bound value of search_params
        discrete_points_num (str): discrete points num of search_params
        discrete_values (List[str]): discrete values of search_params
    """
    name = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    param_type = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    lower_bound = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    upper_bound = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    discrete_points_num = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    discrete_values = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))


@attr.s
class AlgoConfigsParam:
    """
    Attributes:
        key (str): The name of algorithm config param
        value (str): algorithm config param value
        type (str): algorithm config param type
    """
    key = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    value = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    type = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))


@attr.s
class AlgoConfigs:
    """
    Attributes:
        name (str): The name of algorithm config
        params (List[AlgoConfigsParam]): The list of algorithm config param
    """
    name = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    params = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))


@attr.s
class AutoSearchPolicy:
    """
    The policy of auto search
    Attributes:
        skip_search_params (str): search params that need to be skipped
        reward_attrs (List[RewardAttr]): The List of RewardAttr
        search_params (List[SearchParam]): The List of SearchParam
        algo_configs (List[AlgoConfigs]): The List of AlgoConfigs
    """

    skip_search_params = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    reward_attrs = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))
    search_params = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))
    algo_configs = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))


@attr.s
class Policy:
    """
    Attributes:
        auto_search (AutoSearchPolicy): auto search policy
    """
    auto_search = attr.ib(default=None, validator=attr.validators.instance_of((AutoSearchPolicy, type(None))))


@attr.s
class JobEngine:
    """
    Engine information for the job
    Attributes:
        engine_id (Union[str, Placeholder]): engine ID
        engine_name Union[str, Placeholder]): engine name
        engine_version (Union[str, Placeholder]): engine version
        image_url (Union[str, Placeholder]): image url
        run_user (Union[str, Placeholder]): run user
        non_swr_image (Union[bool, Placeholder]): whether user swr image
    """
    engine_id = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    engine_name = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    engine_version = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    image_url = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    run_user = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    non_swr_image = attr.ib(default=None, validator=attr.validators.instance_of((bool, Placeholder, type(None))))


@attr.s
class AlgorithmParameters:
    """
    The algorithm parameters
    Attributes:
        name (str): parameter name
        value (Union[int, bool, float, str, list, dict, Placeholder, Storage, VariableConsumption]): parameter value
        description (Union[str, Placeholder]): algorithm description info
        constraint (Union[dict, Placeholder]): algorithm parameter constraint condition
    """
    name = attr.ib(validator=attr.validators.instance_of(str))
    value = attr.ib(validator=attr.validators.instance_of((int, bool, float, str, list, dict, Placeholder, Storage,
                                                           VariableConsumption)))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    constraint = attr.ib(default=None, validator=attr.validators.instance_of((dict, Placeholder, type(None))))

    def __attrs_post_init__(self):
        if isinstance(self.value, Placeholder) and not self.value.title:
            self.value.title = self.name
        if isinstance(self.value, (dict, list)):
            self.value = json.dumps(self.value)


@serialize
@attr.s
class BaseAlgorithm:
    """
    General algorithm object, and can choose one of id, subscription_id+item_version_id, code_dir+boot_file,
    code_dir+command to initialize
    Attributes:
        id (str): algorithm ID
        subscription_id (str): subscription ID of algorithm
        item_version_id (str): version ID of algorithm
        code_dir (Union[str, Placeholder, Storage]): code dir
        boot_file (Union[str, Placeholder, Storage]): boot file
        command (Union[str, Placeholder]): run command
        parameters (List[AlgorithmParameters]): The list of AlgorithmParameters
        policies (Policy): algorithm policy
        engine (JobEngine): engine information for the job
        environments (Dict, Placeholder)): environment variables
        local_code_dir (Union[str, Placeholder]): local code dir in container
        working_dir (Union[str, Placeholder]): working dir in container
    """
    id = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    subscription_id = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    item_version_id = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    code_dir = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, Storage, type(None))))
    boot_file = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, Storage, type(None))))
    command = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    parameters = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))
    policies = attr.ib(default=None, validator=attr.validators.instance_of((Policy, type(None))))
    engine = attr.ib(default=None, validator=attr.validators.instance_of((JobEngine, type(None))))
    environments = attr.ib(default=None, validator=attr.validators.instance_of((Dict, Placeholder, type(None))))
    local_code_dir = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    working_dir = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))

    def is_algorithm(self):
        return self.id is not None

    def is_gallery_algorithm(self):
        return self.subscription_id and self.item_version_id

    def __attrs_post_init__(self):
        if isinstance(self.environments, Placeholder):
            self.environments.format = TRAIN_ENV_FORMAT


class Algorithm(BaseAlgorithm):
    """
    Algorithm from algorithm management
    """

    def __init__(
            self,
            algorithm_id,
            parameters=None,
            environments=None
    ):
        """

        Args:
            algorithm_id (str): algorithm ID
            parameters (List[AlgorithmParameters]): The list of AlgorithmParameters
            environments (Dict, Placeholder)): environment variables
        """
        if algorithm_id is None:
            raise ValueError("algorithm_id is not allowed to be None!")
        super(Algorithm, self).__init__(id=algorithm_id, parameters=parameters, environments=environments)


class AIGalleryAlgorithm(BaseAlgorithm):
    """
    Algorithm from AIGallery
    """

    def __init__(
            self,
            subscription_id,
            item_version_id,
            parameters=None,
            environments=None
    ):
        """

        Args:
            subscription_id (str): subscription ID of algorithm
            item_version_id (str): version ID of algorithm
            parameters (List[AlgorithmParameters]): The list of AlgorithmParameters
            environments (Dict, Placeholder)): environment variables
        """
        if subscription_id is None or item_version_id is None:
            raise ValueError("subscription_id and item_version_id are not allowed to be None!")
        super().__init__(subscription_id=subscription_id, item_version_id=item_version_id, parameters=parameters,
                         environments=environments)


@serialize
@attr.s
class TrainingExperimentReference:
    """
    Training experiment info
    Attributes:
        id (Union[str, Placeholder]): experiment id
        name (Union[str, Placeholder]): experiment name
        description (Union[str, Placeholder]): experiment description info
    """
    id = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    name = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))

@serialize
@attr.s
class TrainingTag:
    """
    Training tag
    Attributes:
        key (Union[str, Placeholder]): tag key
        value (Union[str, Placeholder]): tag value
    """
    key = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    value = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))


@serialize
@attr.s
class JobMetadata:
    """
    Meta data of Job
    Attributes:
        name (str): The job name, automatically generated, and no perception of the user
        description (str): The description of job
        labels (Dict): dict of labels
        annotations (Dict): dict of annotations
        tags (List[TrainingTag]): The tags of job
    """
    name = attr.ib(init=False)
    description = attr.ib(default=None, validator=attr.validators.instance_of((str, type(None))))
    labels = attr.ib(default=None, validator=attr.validators.instance_of((Dict, type(None))))
    training_experiment_reference = attr.ib(default=None, validator=attr.validators.instance_of((TrainingExperimentReference, type(None))))
    annotations = attr.ib(default=None, validator=attr.validators.instance_of((Dict, type(None))))
    tags = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))

    def _set_name(self, name):
        self.name = name

    @name.default
    def _set_default_value(self):
        return "workflow-" + uuid.uuid4().hex


@attr.s
class NFS:
    """
    Attributes:
        nfs_server_path (Union[str, Placeholder]): nfs service path
        local_path (Union[str, Placeholder]): mount the path to the training container
        read_only (bool): whether it is read-only
    """
    nfs_server_path = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    local_path = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    read_only = attr.ib(default=None, validator=attr.validators.instance_of((bool, Placeholder, type(None))))


@attr.s
class PFS:
    """
    Attributes:
        pfs_path (Union[str, Placeholder]): pfs path
        local_path (Union[str, Placeholder]): mount the path to the training container
    """
    pfs_path = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))
    local_path = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))


@attr.s
class Volume:
    """
    The job mount volume information
    Attributes:
        nfs (NFS): mount volume in nfs mode
        pacific (OceanStor Pacific): mount volume in OceanStor Pacific mode
    """
    nfs = attr.ib(default=None, validator=attr.validators.instance_of((NFS, Placeholder, type(None))))
    pacific = attr.ib(default=None, validator=attr.validators.instance_of((Placeholder, type(None))))
    pfs = attr.ib(default=None, validator=attr.validators.instance_of((PFS, Placeholder, type(None))))

    def __attrs_post_init__(self):
        if isinstance(self.nfs, Placeholder):
            self.nfs.format = NFS_FORMAT
        if isinstance(self.pacific, Placeholder):
            self.pacific.format = PACIFIC_FORMAT
        if isinstance(self.pfs, Placeholder):
            self.pfs.format = PFS_FORMAT


@attr.s
class JobResource:
    """
    The job resource specification information
    Attributes:
        flavor_id (Placeholder): flavor ID, only support public resource pool
        node_count (Union[int, Placeholder]): node counts
        policy (Union[str, Placeholder]): default is "regular"
        flavor (Placeholder): can support public and dedicated resource pool
    """
    flavor_id = attr.ib(default=None, validator=attr.validators.instance_of((Placeholder, type(None))))
    node_count = attr.ib(default=1, validator=attr.validators.instance_of((int, Placeholder)))
    policy = attr.ib(default="regular", validator=attr.validators.instance_of((str, Placeholder)))
    flavor = attr.ib(default=None, validator=attr.validators.instance_of((Placeholder, type(None))))

    def __attrs_post_init__(self):
        if all([self.flavor_id, self.flavor]) or not any([self.flavor_id, self.flavor]):
            raise ValueError("only one of flavor_id and flavor can have a value")
        if self.flavor_id:
            self.flavor_id.format = TRAIN_FLAVOR_ID_FORMAT
        if self.flavor:
            self.flavor.format = TRAIN_FLAVOR_FORMAT


@attr.s
class LogExportPath:
    """
    Attributes:
        obs_url (Union[str, Placeholder]): obs path of log output
        host_path (Union[str, Placeholder]): host path of log output
    """
    obs_url = attr.ib(default=None, validator=attr.validators.instance_of(
        (str, Placeholder, Storage, type(None))
    ))
    host_path = attr.ib(default=None, validator=attr.validators.instance_of((str, Placeholder, type(None))))


@attr.s
class RequiredAffinity:
    """
    Attributes:
        node_type (Union[str]): the type of the node, default is "rack"
        node_labels (Union[dict]): Schedule to some node labels that need to be specified, for example {"KEY", "VALUE"}
    """
    node_type = attr.ib(default="rack", validator=attr.validators.instance_of(str))
    node_labels = attr.ib(default=None, validator=attr.validators.instance_of((dict, type(None))))


@attr.s
class SchedulePolicy:
    """
    Attributes:
        priority (Union[int, Placeholder]): job schedule priority, only support set 3 2 1,  respectively high middle low
        required_affinity (Union[RequiredAffinity]): The affinity scheduling setting for the node
    """
    priority = attr.ib(default=None, validator=attr.validators.instance_of((int, Placeholder, type(None))))
    required_affinity = attr.ib(default=None, validator=attr.validators.instance_of((RequiredAffinity, type(None))))


@serialize
@attr.s
class JobSpec:
    """
    The job specification information
    Attributes:
        resource (JobResource): The job resource specification information
        volumes (List[Volume]): The job mount volume information
        log_export_path (LogExportPath): log information export path
        schedule_policy (SchedulePolicy): The job scheduling policy
    """
    resource = attr.ib(validator=attr.validators.instance_of(JobResource))
    volumes = attr.ib(default=None, validator=attr.validators.instance_of((List, type(None))))
    log_export_path = attr.ib(default=None, validator=attr.validators.instance_of((LogExportPath, type(None))))
    schedule_policy = attr.ib(default=None, validator=attr.validators.instance_of((SchedulePolicy, type(None))))


class JobStep(Step):

    def __init__(
            self,
            name,
            algorithm,
            spec,
            kind=JobTypeEnum.JOB,
            inputs=None,
            outputs=None,
            metadata=None,
            title=None,
            description=None,
            policy=None,
            depend_steps=None
    ):
        """
        Construct a JobStep to create job
        Args:
            name (str): The name of JobStep
            inputs (Union(JobInput, List[JobInput])): A or a list of `JobInput` instance.
            outputs (Union(JobOutput, List[JobOutput])): A or a list of `JobOutput` instance.
            algorithm (BaseAlgorithm): The BaseAlgorithm
            spec (JobSpec): Job Specification parameters of training job
            kind (JobTypeEnum): The job type, default is "job"
            metadata (JobMetadata): The job meta information
            title (str): The title of the job, which is equal to name by default
            description (str): Description info of JobStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union(Step, List[Step])): A or a list of step which this `JobStep` depends on
        """
        metadata = JobMetadata() if metadata is None else metadata
        JobStep._checkout_init_info(algorithm, spec, kind, metadata)
        super().__init__(
            name=name,
            step_type=StepTypeEnum.JOB,
            title=title,
            description=description,
            inputs=inputs,
            outputs=outputs,
            properties=JobStep._prepare_properties(metadata=metadata, spec=spec),
            policy=policy,
            depend_steps=depend_steps
        )
        self.kind = kind
        self._original_algorithm = algorithm
        self.metadata = metadata
        self.spec = spec
        self.algorithm = None
        self._dataset_client = None
        self._model_client = None
        self._gallery_client = None

    def build_client(self, session):
        """
        Build a client for JobStep service calls
        Args:
            session (Session): building interactions with cloud service.

        Returns:

        """
        super(JobStep, self).build_client(session)
        self.client = JobClient(session=session)
        self._dataset_client = DatasetClient(session=session)
        self._model_client = ModelPredictorClient(session)
        self._gallery_client = GalleryClient(session)
        self._pre_process()

    def _pre_process(self):
        self._transfer_algorithm_version_id()
        algorithm_info = self._get_algorithm_info()
        if algorithm_info:
            self._check_inputs_and_outputs(algorithm_info)
            self._add_algorithm_parameters(algorithm_info)
            self._add_algorithm_constraint(algorithm_info)
        self._process_properties_and_placeholders()

    def _is_use_algorithm(self):
        return self._original_algorithm.is_algorithm()

    def _is_use_gallery_algorithm(self):
        return self._original_algorithm.is_gallery_algorithm()

    def _check_inputs_and_outputs(self, algorithm_info):
        """
        Check the names of inputs and outputs according to algorithm info
        Args:
            algorithm_info (dict): The queried algorithm info

        Returns:

        """
        algorithm_inputs = algorithm_info.get("job_config", {}).get("inputs", [])
        algorithm_outputs = algorithm_info.get("job_config", {}).get("outputs", [])
        self._check_inputs_or_outputs(algorithm_inputs, self.inputs)
        self._check_inputs_or_outputs(algorithm_outputs, self.outputs)

    def _check_inputs_or_outputs(self, origin, target):
        """
        Check the names of inputs or outputs according to algorithm info
        Args:
            origin (List): Inputs or outputs from algorithm info
            target (Union[StepInputDict, StepOutputDict]): The StepInputDict or StepOutputDict
        Returns:

        """
        origin_name_set = set()
        for data in origin:
            name = data.get("name")
            if name is None:
                raise KeyError("the input or output of queried algorithm has no name field")
            origin_name_set.add(name)
        target_name_set = set(target.keys())

        if self._is_use_gallery_algorithm() or self._is_use_algorithm():
            if not origin_name_set.issubset(target_name_set):
                raise ValueError("Input or output name is abnormal")

    def _get_algorithm_info(self):
        """
        Get the Algorithm or AI Gallery Algorithm info
        Returns (dict): algorithm info

        """
        if self._is_use_algorithm():
            return self.client.get_algorithm_info(algorithm_id=self._original_algorithm.id)
        if self._is_use_gallery_algorithm():
            return self.client.get_gallery_algorithm_info(subscription_id=self._original_algorithm.subscription_id,
                                                          version_id=self._original_algorithm.item_version_id)
        return {}

    def _process_properties_and_placeholders(self):
        """
        Transfer algorithm to properties and extract placeholders from properties
        Returns:

        """
        algorithm = self._original_algorithm
        prepared_algorithm_dict = prepare_for_properties(algorithm)
        self.properties.properties["algorithm"] = prepared_algorithm_dict
        placeholder_dict = PlaceholderDict()
        StepPlaceholders.extract_placeholder_in_dict(value=prepared_algorithm_dict, step_placeholders=placeholder_dict)
        self.placeholders = placeholder_dict
        self.algorithm = algorithm

    def _add_algorithm_constraint(self, algorithm_info):
        """
        Add algorithm resource constraint, include flavor_type and device_distributed_mode
        Args:
            algorithm_info (dict): The queried algorithm info

        Returns:
        """
        resource_requirements = algorithm_info.get(ALGORITHM_RESOURCE_REQUIREMENTS)
        if not resource_requirements:
            return
        constraint = {}
        for requirement in resource_requirements:
            if requirement.get("key", "") == FLAVOR_TYPE:
                constraint[FLAVOR_TYPE] = requirement.get("values", [])
            if requirement.get("key", "") == DEVICE_DISTRIBUTED_MODE:
                constraint[DEVICE_DISTRIBUTED_MODE] = requirement.get("values", [])
        if self.spec.resource.flavor_id:
            self.spec.resource.flavor_id.constraint = constraint
        else:
            self.spec.resource.flavor.constraint = constraint

    def _add_algorithm_parameters(self, algorithm_info):
        """
        Prepare parameters for algorithm
        Args:
            algorithm_info (dict): The queried algorithm info

        Returns:

        """
        algorithm_parameters = self._original_algorithm.parameters or []
        # parameters list from algorithm info
        parameters_from_algorithm = algorithm_info.get("job_config", {}).get("parameters", [])
        parameters_dict_algorithm = {parameter.get("name"): parameter for parameter in parameters_from_algorithm}
        parameters_dict_user = {parameter.name: parameter for parameter in algorithm_parameters}
        # if the parameters_customization field is not obtained, the parameters can be customized by default
        allow_customization = algorithm_info.get("job_config", {}).get("parameters_customization", True)
        # the difference set of key values is available in parameters_dict_algorithm, but not in parameters_dict_user
        algorithm_difference_keys = parameters_dict_algorithm.keys() - parameters_dict_user.keys()
        for key in algorithm_difference_keys:
            parameter_dict = parameters_dict_algorithm.get(key)
            if not parameter_dict.get("constraint", {}).get("required"):
                continue
            placeholder = self._generate_placeholder(parameter_dict, key)
            algorithm_parameters.append(
                AlgorithmParameters(name=key, value=placeholder)
            )
        # the difference set of key values is available in parameters_dict_user, but not in parameters_dict_algorithm
        user_difference_keys = parameters_dict_user.keys() - parameters_dict_algorithm.keys()
        if not allow_customization and user_difference_keys:
            raise ValueError("The algorithm does not allow custom parameters, "
                             "please modify the parameters name <{}>".format(user_difference_keys))
        intersection_keys = parameters_dict_user.keys() & parameters_dict_algorithm.keys()
        for key in intersection_keys:
            # if the editable field is not obtained, the parameter can be edited by default
            parameter_editable = parameters_dict_algorithm.get(key, {}).get("constraint", {}).get("editable", True)
            if not parameter_editable:
                if isinstance(parameters_dict_user.get(key).value, (Placeholder, Storage)) or \
                        str(parameters_dict_user.get(key).value) != parameters_dict_algorithm.get(key).get("value"):
                    raise ValueError("It is not allowed to modify algorithm parameter <{}>".format(key))
        if algorithm_parameters:
            self._original_algorithm.parameters = algorithm_parameters

    def _generate_placeholder(self,  parameter_dict, key):
        parameter_type = parameter_dict.get("constraint", {}).get("type", "String")
        parameter_value = parameter_dict.get("value")
        placeholder = Placeholder(
            name=self.name + '-' + key,
            placeholder_type=PARAMETER_TYPE_MAPPING.get(parameter_type),
            default=transfer_parameter_value(parameter_type, parameter_value) if parameter_value else None,
            description=parameter_dict.get("description"),
            delay=False,
            title=key
        )
        return placeholder

    def create_instance(self) -> (bool, str):
        self._check_client()
        request_body = self._to_request()
        logging.debug("The JobStep %s is creating job with request body: %s", self.name, request_body)
        job_id = self.client.create_job(create_job_body=request_body)
        return True, job_id

    def allowed_to_release_algorithm(self):
        if self._is_use_algorithm() or self._is_use_gallery_algorithm():
            return True
        type_tuple = (Placeholder, Storage)
        code_dir = self._original_algorithm.code_dir
        boot_file = self._original_algorithm.boot_file
        engine = self._original_algorithm.engine
        if isinstance(code_dir, type_tuple) or isinstance(boot_file, type_tuple):
            return False
        if isinstance(engine.engine_name, Placeholder) or isinstance(engine.engine_version, Placeholder) or \
                isinstance(engine.image_url, Placeholder):
            return False
        return True

    def create_algorithm(self, algorithm_name=None) -> (bool, str):
        request_body = self._to_algorithm_request(algorithm_name)
        logging.debug("The JobStep %s is creating algorithm with request body: %s", self.name, request_body)
        algorithm_id = self.client.create_algorithm(create_algorithm_body=request_body)
        logging.info("The JobStep %s created algorithm, the algorithm_name is %s, the algorithm_id is %s",
                     self.name,
                     request_body["metadata"]["name"],
                     algorithm_id)
        return True, algorithm_id

    def release_algorithm(self, content_id=None, cur_version_num=None, visibility="private", group_users=None):
        """
        Release the algorithm of jobstep to AIGallery
        Args:
            content_id: The content ID
            cur_version_num: The last version num
            visibility (str): The visibility of the content supports three types: private, public, and groups.
                            The group requires an additional field group_users to specify which users are visible
            group_users (list): A list of domain Ids that can access the content
        Returns (str, str): The content id and version id
        """
        algorithm_id = self._original_algorithm.id
        subscription_id = self._original_algorithm.subscription_id
        version_id = self._original_algorithm.item_version_id
        if subscription_id is not None:
            content_id = self._gallery_client.get_content_id(subscription_id)
            return content_id, version_id

        version_num = "1.0.0"
        if cur_version_num is not None:
            version_num = get_next_version_name([cur_version_num])

        if not content_id:
            content_name = '{}_{}'.format(self.name, get_random_name(""))
            logging.info("Start create a algorithm content to the AI Gallery, the name is %s.", content_name)
            content_id = self._gallery_client.publish_content(
                content_name,
                visibility,
                "algo",
                group_users)
            logging.info("The algorithm content successfully created, "
                         "and the name is %s, content ID is %s, title is %s",
                         content_name,
                         content_id,
                         content_name)

        if not algorithm_id:
            _, algorithm_id = self.create_algorithm()

        version_id = self.client.publish_algorithm(algorithm_id, content_id, version_num)
        logging.info("The algorithm successfully published to the AI gallery, "
                     "algorithm_id is %s, content_id is %s, "
                     "version_num is %s and version_id:%s",
                     algorithm_id,
                     content_id,
                     version_num,
                     version_id)
        return content_id, version_id

    def update_instance_state(self):
        if self.instance_id is None:
            raise ValueError('No instance of JobStep {}'.format(self.name))
        self._check_client()
        logging.debug(
            "The JobStep <step_name:%s, job_name:%s, instance_id:%s> is updating the state, and current state is %s",
            self.name, self.metadata.name, self.instance_id, self.state)
        job_state = self.client.get_job_state(job_id=self.instance_id)
        step_state = StepStateMapping.get_step_state(instance_state=job_state, mapping_dic=JOB_STATE_MAPPING)
        # job_state mapping to step_state
        if step_state == StepState.Completed:
            for output in self.outputs.values():
                if not isinstance(output.config, ModelConfig):
                    continue
                model_id = self.client.get_model_id(job_id=self.instance_id)
                model_state = self._model_client.get_model_state(model_id)
                # model_state mapping to step_state
                step_state = StepStateMapping.get_step_state(str(model_state), MODEL_STATE_MAPPING)
                if step_state == StepState.Completed:
                    self._set_data_to_output(output)
        self.set_state(step_state)

    def stop_instance(self) -> (bool, str):
        if self.instance_id is None:
            raise ValueError('No instance of JobStep {}'.format(self.name))
        if self.state not in (StepState.Creating, StepState.Pending, StepState.Running):
            raise TypeError('can not stop the state {}'.format(self.state))
        self._check_client()
        logging.debug(
            "The JobStep <step_name:%s, job_name:%s, instance_id:%s> is stopping the instance, and current state is %s",
            self.name, self.metadata.name, self.instance_id, self.state)
        job_state = self.client.stop_job(job_id=self.instance_id)
        step_state = StepStateMapping.get_step_state(instance_state=job_state, mapping_dic=JOB_STATE_MAPPING)
        self.set_state(step_state)
        return True, "success"

    def _transfer_algorithm_version_id(self):
        """
        Transfer algorithm version num to version ID
        Returns:

        """
        if not self._is_use_gallery_algorithm():
            return
        subscription_id = self._original_algorithm.subscription_id
        version_id = self._original_algorithm.item_version_id
        if re.match(ALGORITHM_VERSION_ID_PATTERN, version_id):
            self._original_algorithm.item_version_id = self._gallery_client.get_subscription_version_id(
                subscription_id, version_id)

    def _to_request(self):
        """
        Convert into the json body required by the training interface
        Returns:

        """
        request = {
            "kind": self.kind.value,
            "metadata": self.metadata.serialize(),
            "spec": JobStep._process_train_spec(self.spec.serialize())
        }
        JobStep._process_algorithm_parameters(self.algorithm)
        algorithm_dict = self.algorithm.serialize()
        JobStep._transfer_algorithm_parameters_type(algorithm_dict)
        algorithm_dict["inputs"] = self._serialize_inputs()
        algorithm_dict["outputs"] = self._serialize_outputs()
        request["algorithm"] = algorithm_dict
        return request

    def _to_algorithm_inputs_request(self):
        inputs_body = []
        for job_input in self.inputs.values():
            input_body = {
                "name": job_input.name,
                "description": "",
                "access_method": "parameter",
                "i18n_description": [{}],
                "remote_constraints": []
            }
            if job_input.config:
                input_body.update(job_input.config.to_definition_json())
            inputs_body.append(input_body)
        return inputs_body

    def _to_algorithm_outputs_request(self):
        outputs_body = []
        for job_output in self.outputs.values():
            if isinstance(job_output.config, MetricsConfig):
                continue
            elif isinstance(job_output.config, ModelConfig):
                output_body = {
                    "name": job_output.name,
                    "remote_constraints": [
                        {
                            "data_type": "model"
                        }
                    ],
                    "modelarts_hosted": True
                }
            else:
                output_body = {
                    "name": job_output.name,
                    "description": "",
                    "access_method": "parameter",
                    "i18n_description": [{}]
                }
                if job_output.output_config:
                    output_body.update(job_output.output_config.to_definition_json())
            outputs_body.append(output_body)
        return outputs_body

    def _to_algorithm_parameters_request(self):
        parameters_body = []
        alg_parameters = self._original_algorithm.parameters
        if alg_parameters is None:
            return parameters_body
        type_map = {
            int: "Integer",
            str: "String",
            float: "Float",
            bool: "Boolean",
            Enum: "enum",
            dict: "String",
            list: "String"
        }

        def get_param_type_and_value(param_value):
            if isinstance(param_value, int):
                return "Integer", str(param_value)
            elif isinstance(param_value, str):
                return "String", param_value
            elif isinstance(param_value, float):
                return "Float", str(param_value)
            elif isinstance(param_value, bool):
                return "Boolean", str(param_value)
            elif isinstance(param_value, (dict, list)):
                return "String", json.dumps(param_value)
            elif isinstance(param_value, Placeholder):
                if param_value.default_value is not None:
                    return get_param_type_and_value(param_value.default_value)
                param_type = type_map.get(param_value.placeholder_type.python_type, None)
                if param_type == "enum":
                    param_type, _ = get_param_type_and_value(param_value.enum_list[0])
                return param_type, ""
            return "String", ""

        for parameter in alg_parameters:
            t, v = get_param_type_and_value(parameter.value)

            parameter_body = {
                "name": parameter.name,
                "description": parameter.description,
                "value": v,
                "constraint":
                    {
                        "editable": True,
                        "required": True,
                        "sensitive": False,
                        "type": t,
                        "valid_range": [],
                        "valid_type": "None"
                    }
            }
            if isinstance(parameter.constraint, dict):
                parameter_body["constraint"].update(parameter.constraint)
            parameters_body.append(parameter_body)
        return parameters_body

    def _to_algorithm_request(self, algorithm_name=None):
        """
        Convert into the json body required by the algorithm interface
        Returns:
        """
        request = {
            "advanced_config": {},
            "job_config": {
                "code_dir": self.algorithm.code_dir,
                "boot_file": self.algorithm.boot_file,
                "local_code_dir": self.algorithm.local_code_dir,
                "working_dir": self.algorithm.working_dir,
                "engine":
                    {
                        "engine_name": self.algorithm.engine.engine_name,
                        "engine_version": self.algorithm.engine.engine_version,
                        "image_url": self.algorithm.engine.image_url
                    },
                "command": self.algorithm.command,
                "inputs": self._to_algorithm_inputs_request(),
                "outputs": self._to_algorithm_outputs_request(),
                "parameters": self._to_algorithm_parameters_request(),
                "parameters_customization": True
            },
            "metadata":
                {
                    "name": algorithm_name if algorithm_name is not None else get_random_name("algorithm-"),
                    "description": "",
                    "tags": None
                },
            "resource_requirements": []
        }
        return request

    @staticmethod
    def _process_train_spec(spec_dict):
        # JobResource is initialized to ensure that only one of the flavor_id and flavor has a value
        job_resource = spec_dict.get("resource")
        # only support public resource pool
        if job_resource.get("flavor_id"):
            return spec_dict
        # can support public and dedicated resource pool
        flavor = job_resource.get("flavor", {})
        pool_id = flavor.get("pool_id", "")
        flavor_id = flavor.get("flavor_id", "")
        if not any([pool_id, flavor_id]):
            raise ValueError("the value of flavor is abnormal")
        job_resource.pop("flavor", None)
        if pool_id:
            job_resource["pool_id"] = pool_id
        if flavor_id:
            job_resource["flavor_id"] = flavor_id
        return spec_dict

    @staticmethod
    def _transfer_algorithm_parameters_type(algorithm_dict):
        algorithm_parameters = algorithm_dict.get("parameters")
        if not algorithm_parameters:
            return
        for parameter in algorithm_parameters:
            parameter_value = parameter.get("value", "")
            if not isinstance(parameter_value, str):
                parameter["value"] = str(parameter_value)

    @staticmethod
    def _process_algorithm_parameters(algorithm):
        if not algorithm.parameters:
            return
        for parameter in algorithm.parameters:
            if isinstance(parameter.value, Placeholder) and parameter.value.format == "obs":
                parameter.value = JobStep._format_obs_prefix(parameter.value.value)
            if isinstance(parameter.value, Storage):
                parameter.value = JobStep._format_obs_prefix(parameter.value.path)

    @staticmethod
    def _format_obs_prefix(url_path):
        if url_path.startswith("obs://"):
            return url_path
        return 'obs://{}'.format(url_path.lstrip("/"))

    def _serialize_inputs(self):
        return [job_input.to_request() for job_input in self.inputs.values()]

    def _serialize_outputs(self):
        result = []
        for job_output in self.outputs.values():
            if isinstance(job_output.config, MetricsConfig):
                continue
            result.append(job_output.to_request())
        return result

    @staticmethod
    def _prepare_properties(metadata, spec):
        return {
            "kind": "job",
            "metadata": prepare_for_properties(metadata),
            "spec": prepare_for_properties(spec)
        }

    @staticmethod
    def _checkout_init_info(algorithm, spec, kind, metadata):
        if not isinstance(algorithm, BaseAlgorithm):
            raise TypeError('The algorithm type must be BaseAlgorithm. But provided: {}'.format(type(algorithm)))
        if not isinstance(spec, JobSpec):
            raise TypeError('The spec type must be JobSpec. But provided: {}'.format(type(spec)))
        if not isinstance(kind, JobTypeEnum):
            raise TypeError('The kind type must be JobTypeEnum. But provided: {}'.format(type(kind)))
        if not isinstance(metadata, JobMetadata):
            raise TypeError('The metadata type must be JobMetadata. But provided: {}'.format(type(metadata)))

    def _check_client(self):
        if self.client is None:
            raise ValueError("The client of JobStep {} is None, "
                             "please use the <build_client> method to initialize the client".format(self.name))

    def _set_data_to_output(self, output):
        model_id = self.client.get_model_id(job_id=self.instance_id)
        model_name = output.config.model_name.value if isinstance(output.config.model_name, Placeholder) \
            else output.config.model_name
        model_data = ModelData(name="{}-{}".format(model_name, model_id), model_id=model_id)
        output.set_data_to_config(model_data)

    def check_valid_to_release(self):
        """
        Check job step meets the conditions for publishing to AI Gallery
        Returns:

        """
        super(JobStep, self).check_valid_to_release()
        step_json = self.to_definition_json()
        algorithm_json = step_json.get("properties", {}).get("algorithm", {})
        if not algorithm_json:
            raise ValueError('algorithm is abnormal in JobStep {}'.format(step_json.get("name", "")))
