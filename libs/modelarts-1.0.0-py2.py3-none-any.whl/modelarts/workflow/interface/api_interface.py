from modelarts import constant
from modelarts.session import Session
from modelarts.workflow.interface.api_interface_impl import APIInterfaceAKSKImpl


class APIInterface:

    def __init__(self, session=None, headers=None):
        """
        Class for Client which makes ModelArts workflow service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        _session = session if session else Session()
        if _session.auth == constant.AKSK_AUTH:
            self._instance = APIInterfaceAKSKImpl(_session, headers)
        else:
            raise ValueError('Only support aksk authorization.')

    def create_workflow(self, body):
        """
        create_workflow
        Args:
            body (dict): request body of creating workflow

        Returns: response of creating workflow, including workflow id
        """
        resp = self._instance.create_workflow(body)
        workflow_id = resp.get("workflow_id")
        if workflow_id is None:
            raise KeyError("the response of create workflow has no workflow_id field")
        return workflow_id

    def update_workflow(self, workflow_id, body):
        """
        update_workflow
        Args:
            workflow_id (str): workflow_id
            body (dict): request body of updating workflow

        Returns: response of updating workflow, including workflow id
        """
        return self._instance.update_workflow(workflow_id, body)

    def get_workflow(self, workflow_id):
        """
        get_workflow
        Args:
            workflow_id (str): workflow_id

        Returns: workflow information
        """
        return self._instance.get_workflow(workflow_id)

    def delete_workflow(self, workflow_id):
        """
        delete_workflow
        Args:
            workflow_id (str): workflow_id

        Returns:
        """
        return self._instance.delete_workflow(workflow_id)

    def list_workflows(self, **kwargs):
        """
        list workflows according conditions
        Args:
            **kwargs: query args

        Returns: workflow list info

        """
        return self._instance.list_workflows(**kwargs)

    def create_execution(self, workflow_id, body=None):
        """
        create_execution
        Args:
            workflow_id (str): workflow_id
            body (dict): request body of creating execution

        Returns: response of creating execution, including execution id

        """
        resp = self._instance.create_execution(workflow_id, body)
        execution_id = resp.get("execution_id")
        if execution_id is None:
            raise KeyError("the response of create execution has no execution_id field")
        return execution_id

    def get_execution(self, workflow_id, execution_id):
        """
        get_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id

        Returns: execution information

        """
        return self._instance.get_execution(workflow_id, execution_id)

    def update_execution(self, workflow_id, execution_id, body):
        """
        update_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            body (dict): request body of updating execution

        Returns: execution information

        """
        return self._instance.update_execution(workflow_id, execution_id, body)

    def delete_execution(self, workflow_id, execution_id):
        """
        delete_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id

        Returns:

        """
        self._instance.delete_execution(workflow_id,execution_id)

    def operate_execution(self, workflow_id, execution_id, body):
        """
        operate_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            body (dict): request body of operate execution

        Returns: execution information

        """
        return self._instance.operate_execution(workflow_id, execution_id, body)

    def list_executions(self, workflow_id, **kwargs):
        """
        delete_execution
        Args:
            workflow_id (str): workflow_id
            **kwargs: query args

        Returns:

        """
        return self._instance.list_executions(workflow_id, **kwargs)

    def operate_step_execution(self, workflow_id, execution_id, step_execution_id, body):
        """
        operate_execution
        Args:
            workflow_id (str): workflow_id
            execution_id (str): execution_id
            step_execution_id (str): step_execution_id
            body (dict): request body of operate step execution

        Returns: execution information

        """
        self._instance.operate_step_execution(workflow_id, execution_id, step_execution_id, body)

    def get_workflow_id(self, name, workspace_id="0"):
        """
        get workflow ID according to name and workspace_id
        Args:
            name (str): workflow name
            workspace_id (str): workspace ID, default is "0"

        Returns (str): workflow ID, returns None when the specified workflow is not found

        """
        resp = self._instance.list_workflows(name=name, workspace_id=workspace_id, search_type="equal")
        for workflow in resp.get("items", []):
            if name == workflow.get("name", ""):
                return workflow.get("workflow_id", "")
        return None

    def create_workflow_schedule(self, workflow_id, body):
        """
        create_workflow_schedule
        Args:
            workflow_id (str): workflow_id
            body (dict): create workflow schedule request body

        Returns: create workflow schedule response, including schedule id

        """
        resp = self._instance.create_schedule(workflow_id, body)
        return resp.get("uuid", "")

    def get_workflow_schedule(self, workflow_id, schedule_id):
        """
        get_workflow_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule_id

        Returns: schedule info

        """
        return self._instance.get_schedule(workflow_id, schedule_id)

    def update_workflow_schedule(self, workflow_id, schedule_id, body):
        """
        update_workflow_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule_id
            body (dict): update workflow schedule request body

        Returns: schedule info

        """
        return self._instance.update_schedule(workflow_id, schedule_id, body)

    def delete_workflow_schedule(self, workflow_id, schedule_id):
        """
        delete_workflow_schedule
        Args:
            workflow_id (str): workflow_id
            schedule_id (str): schedule_id

        Returns:

        """
        self._instance.delete_schedule(workflow_id, schedule_id)
