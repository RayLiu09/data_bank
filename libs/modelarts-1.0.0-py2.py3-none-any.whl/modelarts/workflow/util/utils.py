import os
import string
import secrets

from modelarts.workflow.constant import SUPPORTED_REGION
from modelarts.util.config import Config
from modelarts.workflow.core.placeholder import Placeholder


def to_int(value):
    try:
        if isinstance(value, Placeholder):
            return value
        return int(value)
    except ValueError:
        raise ValueError("The type of value must can be converted to int. But "
                         "got value: {} with type: {}".format(value, type(value)))


def to_int_greater_than_zero(value):
    num = to_int(value)
    if isinstance(num, Placeholder):
        return num
    if num > 0:
        return num
    raise ValueError("The value of the instance count must be an integer "
                     "greater than 0. But provided: {}.".format(value))


def get_random_name(prefix='', len_random=4, len_total=None):
    """
    According to prefix, len_random and len_total generate random name
    Args:
        prefix (str): prefix of the name
        len_random (int): length of the random string, default is 4
        len_total (str): total length (priority)

    Returns (str): random name

    """
    length = len_random
    if len_total:
        length = len_total - len(prefix)
        length = 0 if length < 0 else length
    secrets_generator = secrets.SystemRandom()
    name = prefix + ''.join((secrets_generator.choice(
        string.ascii_letters + string.digits * 3) for _ in range(length)))
    return name


def get_obs_url(region_name, custom_path):
    """
    Convert custom path ("/path/to/model" or "obs://path/to/model") to obs
    path format ("https://path.{obs_domain}/to/model")
    Args:
        region_name (str): region name
        custom_path (str): custom path

    Returns (str): obs format path

    """
    if not custom_path:
        raise ValueError('The custom_path is null')

    if not isinstance(custom_path, str):
        raise TypeError("The expected type of custom_path is str. But "
                        "provided type: {}".format(type(custom_path)))

    # convert the "obs://path/to/model" to "path/to/model"
    if len(custom_path.split(":")) > 1:
        custom_path = custom_path.split(":")[1].strip("/")
    else:
        custom_path = custom_path.split(":")[0].strip("/")

    if region_name in SUPPORTED_REGION:
        obs_domain = Config.getenv("OBS_" + region_name)
    else:
        obs_domain = os.getenv("S3_ENDPOINT")

    # convert "path/to/model" to ("https://path.{}/to/model".format(obs_domain)
    return "https://{}.{}/{}".format(custom_path.split("/", 1)[0],
                                     obs_domain,
                                     custom_path.split("/", 1)[1])


def get_next_version_name(version_list):
    """
    Get the next version name
    Args:
        version_list (list[str]):  the list of the existed version

    Returns (str): the next version name

    """
    version_list.sort(key=lambda x: list(int(v) for v in x.split(".")))
    largest_version_reformat = list(int(v) for v in version_list[-1].split("."))
    next_version_reformat = largest_version_reformat
    if len(next_version_reformat) != 3:
        raise ValueError(
            'The format of the version should be "value.value.value", '
            'where the value is in the range 0 to 99')
    for idx in range(len(next_version_reformat) - 1, -1, -1):
        if 99 >= next_version_reformat[idx] + 1 >= 1:
            next_version_reformat[idx] += 1
            break
        elif next_version_reformat[idx] + 1 == 100:
            if idx == 0:
                raise ValueError('Maximum version 99.99.99 exceeded')
            next_version_reformat[idx] = 0
        else:
            raise ValueError(
                'The format of the version should be "value.value.value", '
                'where the value is in the range 0 to 99')
    next_version_name = ".".join(str(i) for i in next_version_reformat)
    return next_version_name
