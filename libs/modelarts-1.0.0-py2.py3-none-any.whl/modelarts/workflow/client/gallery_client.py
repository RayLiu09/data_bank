import json
import logging
from json import JSONEncoder

from modelarts import constant
from modelarts.config.auth import auth_by_apig, auth_by_roma_api
from modelarts.util.secret_util import auth_expired_handler

HTTPS_GET = constant.HTTPS_GET
HTTPS_POST = constant.HTTPS_POST
HTTPS_PUT = constant.HTTPS_PUT

SUBSCRIPTION_VERSIONS_LIMIT = 200


class _GalleryApiAKSKImpl:
    def __init__(self, session):
        """
        Initialize a ModelArts Algorithm instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session

    @auth_expired_handler
    def get_subscription_versions(self, subscription_id, **kwargs):
        """
        Get subscription versions according to subscription ID
        Args:
            subscription_id (str): The subscription ID of the subscription content
            **kwargs: query args

        Returns (dict): subscription versions

        """
        request_url = "/v1/aihub/subscriptions/{}/versions".format(subscription_id)
        resp = auth_by_apig(self.session, HTTPS_GET, request_url, query=kwargs)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def publish_content(self, request_body):
        request_url = "/v2/aihub/contents"
        body_encode = JSONEncoder().encode(request_body)
        resp = auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def publish_content_version(self, content_id, request_body):
        request_url = '/v1/aihub/contents/{}/versions'.format(content_id)
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_POST, request_url, body=body_encode)

    @auth_expired_handler
    def get_subscriptions(self, subscription_id):
        """
        Get subscriptions according to the subscription_id
        Args:
            subscription_id (str): The subscription ID of the subscription content

        Returns (dict): subscriptions

        """
        request_url = "/v1/aihub/subscriptions"
        query_args = {
            "search_content": subscription_id
        }
        resp = auth_by_apig(self.session, HTTPS_GET, request_url, query_args)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def get_content_versions(self, content_id, offset=0, limit=10):
        """
        Get content versions
        Args:
            content_id (str): The content ID
            offset (int): offset
            limit (int): limit

        Returns (dict): subscriptions

        """
        request_url = "/v1/aihub/contents/{}/versions".format(content_id)
        query_args = {
            "offset": offset,
            "limit": limit
        }
        resp = auth_by_apig(self.session, HTTPS_GET, request_url, query_args)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def get_metadata(self, content_id, version_id):
        """
        Get meta data
        Args:
            content_id (str): The content ID
            version_id (str): The version ID

        Returns (dict): subscriptions

        """
        request_url = "/v1/aihub/contents/metadata"
        query_args = {
            "content_id": content_id,
            "version_id": version_id
        }
        resp = auth_by_apig(self.session, HTTPS_GET, request_url, query_args)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def get_content_detail(self, content_id):
        """
        Get content detail info
        Args:
            content_id (str): The content ID

        Returns (dict): content detail

        """
        request_url = "/v1/aihub/contents/{}".format(content_id)
        resp = auth_by_apig(self.session, HTTPS_GET, request_url)
        if not resp:
            raise Exception("the response has no content")
        return resp

    @auth_expired_handler
    def update_content(self, content_id, request_body):
        """
        Update content attributes
        Args:
            content_id (str): The content ID
            request_body (dict): Update content request body

        Returns:

        """
        request_url = "/v1/aihub/contents/{}".format(content_id)
        body_encode = JSONEncoder().encode(request_body)
        return auth_by_apig(
            self.session, HTTPS_PUT, request_url, body=body_encode)


class _GalleryApiROMAImpl:
    def __init__(self, session):
        """
        Initialize a ModelArts Algorithm instance when using AKSK auth.
        Args:
            session (Session): building interactions with cloud service.
        """
        self.session = session

    @auth_expired_handler
    def get_subscription_versions(self, subscription_id, **kwargs):
        """
        Get subscription versions according to subscription ID
        Args:
            subscription_id (str): The subscription ID of the subscription content
            **kwargs: query args

        Returns (dict): subscription versions

        """
        request_url = "{host}/v1/aihub/subscriptions/{subscription_id}/versions".format(
            host=self.session.host, subscription_id=subscription_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_gallery_subscription_versions",
                                params=kwargs
                                )

    @auth_expired_handler
    def publish_content(self, request_body):
        request_url = "{host}/v2/aihub/contents".format(host=self.session.host)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="publish_gallery_content",
                                data=JSONEncoder().encode(request_body)
                                )

    @auth_expired_handler
    def publish_content_version(self, content_id, request_body):
        request_url = "{host}/v1/aihub/contents/{content_id}/versions".format(
            host=self.session.host, content_id=content_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="publish_gallery_content_version",
                                data=JSONEncoder().encode(request_body)
                                )

    @auth_expired_handler
    def get_subscriptions(self, subscription_id):
        """
        Get subscriptions according to the subscription_id
        Args:
            subscription_id (str): The subscription ID of the subscription content

        Returns (dict): subscriptions

        """
        request_url = "{host}/v1/aihub/subscriptions".format(host=self.session.host)
        query_args = {
            "search_content": subscription_id
        }
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_gallery_subscription",
                                params=query_args
                                )

    @auth_expired_handler
    def get_content_versions(self, content_id, offset=0, limit=10):
        """
        Get content versions
        Args:
            content_id (str): The content ID
            offset (int): offset
            limit (int): limit

        Returns (dict): subscriptions

        """
        request_url = "{host}/v1/aihub/contents/{content_id}/versions".format(
            host=self.session.host, content_id=content_id)
        query_args = {
            "offset": offset,
            "limit": limit
        }
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_gallery_content_versions",
                                params=query_args
                                )

    @auth_expired_handler
    def get_metadata(self, content_id, version_id):
        """
        Get meta data
        Args:
            content_id (str): The content ID
            version_id (str): The version ID

        Returns (dict): subscriptions

        """
        request_url = "{host}/v1/aihub/contents/metadata".format(host=self.session.host)
        query_args = {
            "content_id": content_id,
            "version_id": version_id
        }
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_gallery_content_metadata",
                                params=query_args
                                )

    @auth_expired_handler
    def get_content_detail(self, content_id):
        """
        Get content detail info
        Args:
            content_id (str): The content ID

        Returns (dict): content detail

        """
        request_url = "{host}/v1/aihub/contents/{content_id}".format(host=self.session.host, content_id=content_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_GET,
                                intf_action="get_gallery_content_detail"
                                )

    @auth_expired_handler
    def update_content(self, content_id, request_body):
        """
        Update content attributes
        Args:
            content_id (str): The content ID
            request_body (dict): Update content request body

        Returns:

        """
        request_url = "{host}/v1/aihub/contents/{content_id}".format(
            host=self.session.host, content_id=content_id)
        return auth_by_roma_api(session=self.session,
                                request_url=request_url,
                                request_type=constant.HTTPS_PUT,
                                intf_action="update_gallery_content",
                                data=JSONEncoder().encode(request_body)
                                )


class GalleryClient:

    def __init__(self, session):
        """
        Class for Client which makes AI Gallery service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        if session.auth == constant.AKSK_AUTH:
            self._client = _GalleryApiAKSKImpl(session)
        else:
            self._client = _GalleryApiROMAImpl(session)

    def get_content_id(self, subscription_id):
        """
        Get subscription content ID according to the subscription_id
        Args:
            subscription_id (str): The subscription ID of the subscription content

        Returns (str): The subscription content ID

        """
        resp = self._client.get_subscriptions(subscription_id)
        subscription_list = resp.get("subscription_infos")
        if not subscription_list:
            raise KeyError('the response has no subscription_infos field or subscription ID {} is not exist'.format(
                subscription_id))
        content_id = subscription_list[0].get("content_id")
        if content_id is None:
            raise KeyError('The response has no item_id field')
        return content_id

    def publish_content(self, title, visibility, type="simple_workflow", group_users=None):
        """
        Publish content to the AI Gallery
        Args:
            title (str): The name of the published content in the AI Gallery
            visibility (str): The visibility of the content supports three types: private, public, and groups.
                            The group requires an additional field group_users to specify which users are visible
            type (str): The type of content
            group_users (list): A list of domain Ids that can access the content

        Returns (str): content ID

        """
        if visibility == "group" and not group_users:
            raise ValueError('when visibility is group, group_users can not be None')
        body = {
            "title": title,
            "type": type,
            "sell_type": 0,
            "visibility": visibility
        }
        if group_users:
            body["group_users"] = group_users
        resp = self._client.publish_content(body)
        content_id = resp.get("content_id")
        if not content_id:
            raise KeyError('the response has no content_id field')
        return content_id

    def publish_content_version(self, content_id, version_num, metadata, desc=None):
        """
        Publish a new version for content
        Args:
            content_id (str): content ID
            version_num (str): the content version name, for example 1.0.0
            metadata (str): Meta data related to workflow
            desc (str): the description of content version

        Returns (dict): the response of publish content version

        """
        body = {
            "version_num": version_num,
            "metadata": metadata
        }
        if desc:
            body["desc"] = desc
        return self._client.publish_content_version(content_id, body)

    def get_subscription_version_id(self, subscription_id, version_num):
        """
        Get subscription version ID according to version num
        Args:
            subscription_id (str): The subscription ID of the subscription content
            version_num (str): the content version name, for example 1.0.0

        Returns (str): subscription version ID

        """
        versions = self._client.get_subscription_versions(
            subscription_id, limit=SUBSCRIPTION_VERSIONS_LIMIT).get("versions", [])
        for version_info in versions:
            if version_num == version_info.get("version_num", ""):
                return version_info.get("version_id", "")
        return ""

    def get_latest_version(self, content_id):
        """
        Get the last version_num of the content_id
        Args:
            content_id (str): The content ID

        Returns (str,str): version_id, version_num

        """
        resp = self._client.get_content_versions(content_id)
        version_list = resp.get("versions", [])
        if not version_list:
            return None, None
        return version_list[0].get("version_id", None), version_list[0].get("version_num", None)

    def get_workflow_assets_info(self, content_id, version_id):
        """
        Get the assets version from meta data
        Args:
            content_id (str): The content ID
            version_id (str): The version ID

        Returns (dict): stepname->(content_id, version_num)

        """
        resp = self._client.get_metadata(content_id, version_id)
        metadata_str = resp.get("metadata")
        metadata = json.loads(metadata_str)
        if not isinstance(metadata, dict):
            raise TypeError('The type of the metadata is incorrect.')
        steps = metadata.get("steps")
        if steps is None:
            raise ValueError('The metadata does not contain the steps field.')

        asset_map = {}
        for asset in metadata.get("assets", []):
            asset_name = asset.get("name", None)
            asset_content_id = asset.get("content_id", None)
            if not asset_name or not asset_content_id:
                raise ValueError('The format of assets is incorrect.')
            asset_map[asset_name] = asset_content_id

        step_contents = {}
        subscription_id_pattern = "$ref/assets/"
        for step in steps:
            if step.get("type") != "job":
                continue
            step_name = step.get("name")
            algorithm = step["properties"]["algorithm"]
            subscription_id = algorithm.get("subscription_id", None)
            if not subscription_id:
                continue
            if not subscription_id.startswith(subscription_id_pattern):
                raise ValueError('The format of the subscription_id %s is incorrect.'.format(subscription_id))
            subscription_id = subscription_id[len(subscription_id_pattern):]
            content_id = asset_map.get(subscription_id, None)
            if not content_id:
                raise ValueError('The format of the assets is incorrect,'
                                 'the assets does not contain {}.'.format(subscription_id))
            _, version_num = self.get_latest_version(content_id)
            if not version_num:
                continue
            step_contents[step_name] = (content_id, version_num)
        return step_contents

    def add_whitelist_users(self, content_id, user_groups):
        """
        Add new whitelist users based on the original whitelist
        Args:
            content_id (str): The content ID
            user_groups (list): User groups, only support domain ID

        Returns:

        """
        visibility, whitelist_users = self.get_content_visibility_and_users(content_id)
        if visibility == "public":
            logging.warning("Visibility of asset %s is public, not allowed to add whitelist", content_id)
            return

        whitelist_users.extend(user_groups)
        body = {
            "whitelist_users": list(set(whitelist_users))
        }
        if visibility == "private":
            body["visibility"] = "group"
        self._client.update_content(content_id, body)

    def delete_whitelist_users(self, content_id, user_groups):
        """
        Delete whitelist users for content
        Args:
            content_id (str): The content ID
            user_groups (list): User groups, only support domain ID

        Returns:

        """
        visibility, whitelist_users = self.get_content_visibility_and_users(content_id)
        if visibility != "group":
            logging.warning("Visibility of asset %s is %s, not allowed to delete whitelist", content_id, visibility)
            return

        for user in user_groups:
            if user in whitelist_users:
                whitelist_users.remove(user)
        body = {
            "whitelist_users": whitelist_users
        }
        self._client.update_content(content_id, body)

    def get_content_visibility_and_users(self, content_id):
        """
        Get content visibility and whitelist users
        Args:
            content_id (str): The content ID

        Returns (str, list[str]): Content visibility and whitelist users

        """
        content_detail = self._client.get_content_detail(content_id)
        whitelist_users = content_detail.get("content_detail", {}).get("whitelist_users", [])
        visibility = content_detail.get("content_detail", {}).get("visibility")
        return visibility, [whitelist_user.get("domain_id", "") for whitelist_user in whitelist_users]
