"""
A pool class for resource pool for modelarts sdk.
"""
from .config.auth import auth_by_apig
from .util.secret_util import auth_expired_handler
from . import constant


class Pool:

    def __init__(self, session, workspace_id=None):
        self.session = session
        self.workspace_id = workspace_id

        if session.auth == constant.AKSK_AUTH:
            self.request = self.request_by_apig
        else:
            raise ValueError('Only support aksk authorization.')

    @classmethod
    def get_pool_list(cls, session, **kwargs):
        """
        Get resource pool list
        :param session: session
        :param kwargs: support 'status', 'workspaceId'
        :return: pool List
        """
        if "status" not in kwargs.keys():
            kwargs["status"] = "created"
        return cls(session=session).__get_pool_list(**kwargs)

    @classmethod
    def get_pool_info(cls, session, pool_id):
        """
        Get resource pool info
        :param session: session
        :param pool_id: pool_id, it's the pool name in pool.metadate.name, but is NOT the os.modelarts/name in labels.
        :return: pool info
        """
        return cls(session=session).__get_pool_info(pool_id)

    @classmethod
    def get_pool_nodes(cls, session, pool_id):
        """
        Get node list in the resource pool
        :param session: session
        :param pool_id: pool_id, it's the pool name in pool.metadate.name, but is NOT the os.modelarts/name in labels.
        :return: node list
        """
        return cls(session=session).__get_pool_nodes(pool_id)

    def __get_pool_list(self, **kwargs):
        url = "/v2/{}/pools".format(self.session.project_id)
        return self.request(constant.HTTPS_GET, url, query=kwargs)

    def __get_pool_info(self, pool_id):
        url = "/v2/{}/pools/{}".format(self.session.project_id, pool_id)
        return self.request(constant.HTTPS_GET, url)

    def __get_pool_nodes(self, pool_id):
        url = "/v2/{}/pools/{}/nodes".format(self.session.project_id, pool_id)
        return self.request(constant.HTTPS_GET, url)

    @auth_expired_handler
    def request_by_apig(self, method, url, query=None, body=None, headers=None):
        return auth_by_apig(self.session, method, url, query, body, headers)
