from modelarts import constant
from modelarts.dataset.dataset_impl import DatasetApiAKSKImpl, DatasetApiROMAImpl
from modelarts.workflow.resource.workspace import Workspace


class DatasetClient:
    def __init__(self, session, headers=None):
        """
        Class for Client which makes ModelArts Dataset service calls.
        Args:
            session (Session): Building interactions with cloud service.
        """
        self._session = session
        if session.auth == constant.AKSK_AUTH:
            if not self._session.security_token:
                self._dataset_instance = DatasetApiAKSKImpl(self._session, headers)
            else:
                self._dataset_instance = DatasetApiAKSKImpl(self._session)
        else:
            self._dataset_instance = DatasetApiROMAImpl(self._session)

    def import_data(self, path, dataset_id, import_data_info=None, label_task_id=None):
        """
        Import data to structured dataset
        Args:
            path (str): Import data path, supporting OBS path and local path
            dataset_id (str): Dataset ID
            import_data_info (ImportDataInfo): Information about imported data
            label_task_id (str): The label task ID
        Returns:

        """
        if not path:
            raise ValueError('The path is required.')
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        import_data_body = dict()
        if import_data_info:
            import_data_body = import_data_info.serialize()
        import_data_body['import_path'] = path
        if label_task_id is not None:
            import_data_body["label_task_config"] = {
                "task_id": label_task_id
            }
        import_data_response = self._dataset_instance.import_data(dataset_id, import_data_body)
        task_id = import_data_response.get("task_id")
        if task_id is None:
            raise KeyError("the response has no task_id field")
        return task_id

    def get_import_task_info(self, dataset_id, task_id):
        """
        Get dataset import task info
        Args:
            dataset_id (str): dataset ID
            task_id (str): dataset import task ID

        Returns (dict): dataset import task info

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not task_id:
            raise ValueError('The task_id is required.')
        return self._dataset_instance.get_import_task_info(dataset_id, task_id)

    def get_import_task_state(self, dataset_id, task_id):
        """
        Get the state of dataset import task
        Args:
            dataset_id (str): dataset ID
            task_id (str): dataset import task ID

        Returns (str): the state of dataset import task

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not task_id:
            raise ValueError('The task_id is required.')
        task_info = self.get_import_task_info(dataset_id, task_id)
        state = task_info.get("status")
        if state is None:
            raise KeyError("the response has no status field")
        return state

    def get_dataset_state(self, dataset_id):
        """
        Get the dataset state
        Returns (int): The dataset state

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        dataset_info = self._dataset_instance.get_dataset_info(dataset_id)
        dataset_state = dataset_info.get("status")
        if dataset_state is None:
            raise KeyError("the response has no status field")
        return dataset_state

    def release_dataset_version(self, dataset_id, dataset_version_config):
        """
        Create dataset version
        Args:
            dataset_id (str): The dataset ID
            dataset_version_config (DatasetVersionConfig): configuration related to dataset version info

        Returns (str): The dataset version id

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not dataset_version_config:
            raise ValueError('The dataset_version_config is required.')
        create_version_body = dataset_version_config.serialize()
        dataset_info = self._dataset_instance.release_dataset_version(dataset_id, create_version_body)
        version_id = dataset_info.get("version_id")
        if version_id is None:
            raise KeyError("the response has no version_id field")
        return version_id

    def get_dataset_id(self, dataset_name):
        """
        Get the dataset ID according to the dataset name
        Args:
            dataset_name (str): The name of dataset

        Returns (str): Dataset ID

        """
        if not dataset_name:
            raise ValueError('The dataset_name is required.')
        search_content = '^' + dataset_name + '$'
        dataset_list_resp = self._dataset_instance.list_datasets(
            dataset_name=search_content, workspace_id=Workspace.instance().workspace_id)
        for dataset in dataset_list_resp.get("datasets", []):
            if dataset_name == dataset.get("dataset_name", ""):
                return dataset.get("dataset_id", "")
        raise ValueError('dataset<{}> is not exist'.format(dataset_name))

    def get_dataset_version_id(self, dataset_id, version_name):
        """
        Get the dataset version ID according to the dataset ID and version name
        Args:
            dataset_id (str): The dataset ID
            version_name (str): The version name

        Returns (str): The dataset version ID

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not version_name:
            raise ValueError('The version_name is required.')
        version_list = self._dataset_instance.get_version_list(dataset_id)
        for version_item in version_list["versions"]:
            if version_item["version_name"] == version_name:
                return version_item["version_id"]
        raise ValueError('dataset version <{}> is not exist'.format(version_name))

    def get_version_info(self, dataset_id, version_id):
        """
        Get dataset version information
        Args:
            dataset_id (str): Dataset ID
            version_id (str): Version ID

        Returns: Response of getting dataset version information

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not version_id:
            raise ValueError("The version_id is required.")
        return self._dataset_instance.get_version_info(dataset_id, version_id)

    def get_version_state(self, dataset_id, version_id):
        """
        Get dataset version state
        Args:
            dataset_id (str): Dataset ID
            version_id (str): Version ID

        Returns: Response of getting dataset version state

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not version_id:
            raise ValueError("The version_id is required.")
        version_info = self.get_version_info(dataset_id, version_id)
        state = version_info.get("status")
        if state is None:
            raise KeyError("the response of version info has no status field")
        return state

    def get_version_name(self, dataset_id, version_id):
        """
        Get dataset version name
        Args:
            dataset_id (str): Dataset ID
            version_id (str): version ID

        Returns (str): Dataset version name

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not version_id:
            raise ValueError("Version id is needed.")
        dataset_info = self.get_version_info(dataset_id, version_id)
        return dataset_info.get("version_name", "")

    def create_label_task(self, dataset_id, label_task_req):
        """
        Create a label task for dataset
        Args:
            dataset_id (str): dataset ID
            label_task_req (dict): the request body of create label task

        Returns (str): label task ID

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not label_task_req:
            raise ValueError("label_task_req is empty")
        resp = self._dataset_instance.create_label_task(dataset_id, label_task_req)
        task_id = resp.get("task_id")
        if task_id is None:
            raise KeyError("the response of create label task has no task_id field")
        return task_id

    def get_label_task_info(self, dataset_id, label_task_id):
        """
        Get the label task info
        Args:
            dataset_id (str): dataset ID
            label_task_id (str): label task ID

        Returns (dict): the label task info

        """
        if not dataset_id:
            raise ValueError('The dataset_id is required.')
        if not label_task_id:
            raise ValueError('The label_task_id is required.')
        return self._dataset_instance.get_label_task_info(dataset_id, label_task_id)

    def get_label_task_name(self, dataset_id, label_task_id):
        """
        Get the label task name
        Args:
            dataset_id (str): dataset ID
            label_task_id (str): label task ID

        Returns (str): the label task name

        """
        task_info = self.get_label_task_info(dataset_id, label_task_id)
        task_name = task_info.get("task_name")
        if task_name is None:
            raise KeyError("the response of label task info has no task_name field")
        return task_name

    def get_label_task_state(self, dataset_id, label_task_id):
        """
        Get the label task state
        Args:
            dataset_id (str): dataset ID
            label_task_id (str): label task ID

        Returns (int): the label task state

        """
        task_info = self.get_label_task_info(dataset_id, label_task_id)
        task_state = task_info.get("label_task_status")
        if task_state is None:
            raise KeyError("the response of label task info has no task_state field")
        return task_state

    def list_label_tasks(self, dataset_id):
        """
        List all labeling tasks under the specified dataset
        Args:
            dataset_id (str): dataset ID

        Returns (list): list of labeling tasks

        """
        resp = self._dataset_instance.list_label_tasks(dataset_id)
        tasks_list = resp.get("tasks")
        if tasks_list is None:
            raise KeyError("the response has no tasks field")
        return tasks_list

    def get_label_task_id(self, dataset_id, label_task_name):
        """
        Get the label task ID according to label task name
        Args:
            dataset_id (str): dataset ID
            label_task_name (str): dataset label task name

        Returns (str): label task ID

        """
        label_tasks = self.list_label_tasks(dataset_id)
        for label_task in label_tasks:
            task_name = label_task.get("task_name")
            if task_name is None:
                raise KeyError("the response of label task info has no task_name field")
            if task_name == label_task_name:
                task_id = label_task.get("task_id")
                if task_id is None:
                    raise KeyError("the response of label task info has no task_id field")
                return task_id
        raise ValueError('the label task {} is not found in the dataset {}'.format(label_task_name, dataset_id))

    def label_task_exists(self, dataset_id, label_task_name):
        """
        Determine whether the labeling task already exists
        Args:
            dataset_id (str): dataset ID
            label_task_name (str): label task name

        Returns (bool): Return TRUE if the labeling task exists, otherwise FALSE

        """
        label_tasks = self.list_label_tasks(dataset_id)
        for label_task in label_tasks:
            task_name = label_task.get("task_name")
            if task_name is None:
                raise KeyError("the response of label task info has no task_name field")
            if task_name == label_task_name:
                return True
        return False

    def create_dataset(self, request_body):
        """
        Create a dataset instance
        Args:
            request_body (dict): the request body

        Returns (str): dataset ID

        """
        request_body["workspace_id"] = Workspace.instance().workspace_id
        resp = self._dataset_instance.create_dataset(create_dataset_body=request_body)
        dataset_id = resp.get("dataset_id", "")
        if not dataset_id:
            raise KeyError("the response has no dataset_id field")
        return dataset_id

    def dataset_exists(self, dataset_name):
        """
        Confirm the existence of a dataset by name, and return the dataset ID
        Args:
            dataset_name (str): the name of dataset

        Returns (str): dataset ID

        """
        search_content = '^' + dataset_name + '$'
        dataset_list_resp = self._dataset_instance.list_datasets(
            dataset_name=search_content, workspace_id=Workspace.instance().workspace_id)
        for dataset in dataset_list_resp.get("datasets", []):
            if dataset_name == dataset.get("dataset_name", ""):
                return dataset.get("dataset_id", "")
        return None
