"""
Description: This file provide some methods of docker cli
Author: ModelArts SDK Team
"""
import subprocess


DOCKER_COMMAND_NAME = "docker"


class DockerCli(object):
    """
    This class implements some methods of docker cli
    """

    @staticmethod
    def pull(swr_path, options=[], progress_display=None):
        """
        Pull an image into this vim by executing docker pull [OPTIONS] NAME[:TAG|@DIGEST]
        :param swr_path: The image path which you want to pull
        :param options: The options of 'docker pull'
        :param progress_display: This parameter is used to display the progress the 'docker pull'
        """
        cmd = [DOCKER_COMMAND_NAME, "pull"]
        cmd.extend(options)
        cmd.append(swr_path)
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if progress_display is not None:
            progress_display.wait(p)
        return p

    @staticmethod
    def run(swr_path, options=[], run_command="", args=[], progress_display=None):
        """
        Start a container using image by executing docker run [OPTIONS] IMAGE [COMMAND] [ARG...]
        :param swr_path: Start a new container from this image
        :param options: The options used to start a container
        :param run_command: The command used to start a container
        :param args: Start parameters of run_command which should be a list
        :param progress_display: This parameter is used to display the progress the 'docker run'
        """
        cmd = [DOCKER_COMMAND_NAME, "run"]
        cmd.extend(options)
        cmd.append(swr_path)
        if run_command is not None and len(run_command) != 0:
            cmd.append(run_command)
            cmd.extend(args)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        progress_display.wait(p)
        return p.stdout.read()

    @staticmethod
    def images(options=[], swr_path=""):
        """
        List images by executing  docker images [OPTIONS] [REPOSITORY[:TAG]]
        :param options: options of docker images, a list
        :param swr_path: filter the result according to image
        :return: all images
        """
        cmd = [DOCKER_COMMAND_NAME, "images"]
        cmd.extend(options)
        if swr_path is not None and len(swr_path) > 0:
            cmd.append(swr_path)
        return subprocess.check_output(cmd)

    @staticmethod
    def inspect(name_or_id="", options=[]):
        """
        Look up the detail info of an image or a container using docker inspect [OPTIONS] NAME|ID [NAME|ID...]
        :param name_or_id: image swr path or id or container name or id
        :param options: options of docker inspect
        :return: detail info of image or container
        """
        if not name_or_id:
            raise ValueError("Parameter name_or_id is needed.")
        cmd = [DOCKER_COMMAND_NAME, "inspect"]
        cmd.extend(options)
        cmd.append(name_or_id)
        return subprocess.check_output(cmd)

    @staticmethod
    def stop(containers, options=[], progress_display=None):
        """
        Stop a running container using docker stop [OPTIONS] CONTAINER [CONTAINER...]
        :param containers: a list containing all containers which will be stopped
        :param options: stop options
        :param progress_display: This parameter is used to display the progress the 'docker stop'
        """
        cmd = [DOCKER_COMMAND_NAME, "stop"]
        cmd.extend(options)
        cmd.extend(containers)
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        progress_display.wait(p)

    @staticmethod
    def rm(containers, options=[], progress_display=None):
        """
        Remote one or more container using docker rm [OPTIONS] CONTAINER [CONTAINER...]
        :param containers: a list containing all containers which will be removed
        :param options: remove options
        :param progress_display: This parameter is used to display the progress the 'docker stop'
        """
        cmd = [DOCKER_COMMAND_NAME, "rm"]
        cmd.extend(options)
        cmd.extend(containers)
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        progress_display.wait(p)

    @staticmethod
    def ps(options, progress_display=None):
        """
        List all containers using docker ps [OPTIONS]
        :param options: list container options
        :param progress_display: This parameter is used to display the progress the 'docker ps'
        """
        cmd = [DOCKER_COMMAND_NAME, "ps"]
        cmd.extend(options)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        progress_display.wait(p)
        return p.stdout.read()

    @staticmethod
    def login(options, server):
        """
        Login swr.
        :param options: login options including -p and -u
        :param server: the swr server
        """
        cmd = [DOCKER_COMMAND_NAME, "login"]
        cmd.extend(options)
        cmd.append(server)
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        return res.returncode


class DockerComposeCli(object):
    """
    This class implements some methods of docker compose cli
    """
    @staticmethod
    def up(compose_options=None, options=None, service=""):
        """
        Start a project by executing docker-compose [compose-options] up [options] [SERVICE...]
        :param compose_options: options of docker-compose
        :param options: the options for docker-compose up
        :param service: start the service described in docker compose file
        :return:
        """
        compose_options = [] if compose_options is None else compose_options
        options = [] if options is None else options
        cmd = ["docker-compose"]
        cmd.extend(compose_options)
        cmd.append("up")
        cmd.extend(options)
        if service:
            cmd.append(service)
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    @staticmethod
    def down(compose_options=None, options=None):
        """
        Delete a project by executing docker-compose [compose-options] down [options]
        :param compose_options: options of docker-compose
        :param options: the options for docker-compose down
        :return:
        """
        compose_options = [] if compose_options is None else compose_options
        options = [] if options is None else options
        cmd = ["docker-compose"]
        cmd.extend(compose_options)
        cmd.append("down")
        cmd.extend(options)
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    @staticmethod
    def start(compose_options=None, service=""):
        """
        Start a stopped project by executing docker-compose [compose-options] start [SERVICE...]
        :param compose_options: options of docker-compose
        :param service: start the service described in docker compose file
        :return:
        """
        compose_options = [] if compose_options is None else compose_options
        cmd = ["docker-compose"]
        cmd.extend(compose_options)
        cmd.append("start")
        if service:
            cmd.append(service)
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    @staticmethod
    def stop(compose_options=None, options=None, service=""):
        """
        Stops running containers without removing them by executing
        docker-compose [compose-options] stop [options] [SERVICE...]
        :param compose_options: options of docker-compose
        :param options: the options for docker-compose up
        :param service: start the service described in docker compose file
        :return:
        """
        compose_options = [] if compose_options is None else compose_options
        options = [] if options is None else options
        cmd = ["docker-compose"]
        cmd.extend(compose_options)
        cmd.append("stop")
        cmd.extend(options)
        if service:
            cmd.append(service)
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    @staticmethod
    def ps(compose_options=None, options=None, service=""):
        """
        List containers of a project by executing docker-compose [compose-options] ps [options] [SERVICE...]
        :param compose_options: options of docker-compose
        :param options: the options for docker-compose ps
        :param service: start the service described in docker compose file
        :return: containers of the project
        """
        compose_options = [] if compose_options is None else compose_options
        options = [] if options is None else options
        cmd = ["docker-compose"]
        cmd.extend(compose_options)
        cmd.append("ps")
        cmd.extend(options)
        if service:
            cmd.append(service)
        try:
            containers_byte = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            return containers_byte.decode("utf-8")
        except subprocess.CalledProcessError as e:
            raise Exception("Failed to get dev containers status, err=", e)
