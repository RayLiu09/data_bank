# coding=utf-8
"""
A ModelArts APP can create APP, deploy APP service, get APP info and list,and delete APP.
"""
import os
import sys

sys.path.append(os.getcwd())

from modelarts import constant
from modelarts.config.auth import auth_by_apig
from json import JSONEncoder


class APP(object):
    """
    ModelArts application management, which is used to create applications,
    list the applications, and query application details based on the application ID.
    """

    @staticmethod
    def create(session, name, version, source_type, source_location, initial_config, description=None,
               workspace_id=None, cmd=None, deployment_constraints=None, specification=None, market_from=None,
               trace_info=None, labels=None):
        """
        Create application
        :param session: modelarts session
        :param name: AI app name
        :param version: AI app version
        :param source_type: The type of AI app, "Image" or "Rpm"
        :param source_location: source location of AI app, supports swr path or rpm path
        :param initial_config: AI app configs
        :param description: AI description
        :param workspace_id: workspace id
        :param cmd: execute command
        :param deployment_constraints: AI app deployment constraints
        :param specification: minimum resource specifications required by AI app inference
        :param market_from: whether comes from the AI gallery market
        :param trace_info: record source tracing information.
        :param labels: labels, up to 3
        :return: create result
        """
        request_body = ApplicationParam.create_application_create_body(name, version, source_type, source_location,
                                                                       initial_config, description, workspace_id,
                                                                       cmd, deployment_constraints, specification,
                                                                       market_from, trace_info, labels)
        request_url = '/v1/' + session.project_id + '/applications'
        request_body = JSONEncoder().encode(request_body).encode("utf8")
        resp = auth_by_apig(session, constant.HTTPS_POST, request_url, body=request_body)
        return resp

    @staticmethod
    def list(session, workspace_id=None, name=None, version=None, description=None, status=None, source_type=None,
             market_publishable=None, market_from=None, offset=None, limit=None, sort_by=None, order=None):
        """
        List application
        :param session: modelarts session
        :param workspace_id: workspace id, default value is "0"
        :param name: AI app name, fuzzy matching is supported
        :param version: AI app version
        :param description: description, fuzzy matching is supported
        :param status: AI app status, such as publishing, published and failed
        :param source_type: source type
        :param market_publishable:  published to the AI gallery market or not
        :param market_from: whether comes from the AI gallery market
        :param offset: query page offset, default 0
        :param limit: maximum number of entries returned on each page. default 1000.
        :param sort_by: sorted by, such as "create_at", "model_version", "model_size", default "create_at"
        :param order: order, "asc" or "desc", default "desc"
        :return: app list
        """
        query_dict = {}
        if workspace_id is not None:
            query_dict["workspace_id"] = workspace_id
        if name is not None:
            query_dict["name"] = name
        if version is not None:
            query_dict["version"] = version
        if description is not None:
            query_dict["description"] = description
        if status is not None:
            query_dict["status"] = status
        if source_type is not None:
            query_dict["source_type"] = source_type
        if market_publishable is not None:
            query_dict["market_publishable"] = market_publishable
        if market_from is not None:
            query_dict["market_from"] = market_from
        if offset is not None:
            query_dict["offset"] = offset
        if limit is not None:
            query_dict["limit"] = limit
        if sort_by is not None:
            query_dict["sort_by"] = sort_by
        if order is not None:
            query_dict["order"] = order

        request_url = '/v1/' + session.project_id + '/applications'
        return auth_by_apig(session, constant.HTTPS_GET, request_url, query=query_dict)

    @staticmethod
    def get(session, app_id=None):
        """
        query app by id
        :param session: modelarts session
        :param: app_id: app id
        :return: app details
        """
        if app_id is None:
            raise Exception("APP id is none, please check")
        request_url = '/v1/' + session.project_id + '/applications/' + app_id
        return auth_by_apig(session, constant.HTTPS_GET, request_url)


class ApplicationParam(object):
    """
    Application management parameter construction class,
    which is used to construct parameters in application management interfaces.
    """

    @staticmethod
    def create_application_create_body(name, version, source_type, source_location, initial_config, description=None,
                                       workspace_id=None, cmd=None, deployment_constraints=None, specification=None,
                                       market_from=None, trace_info=None, labels=None):
        """
        Create application building parameters
        :param name: AI app name
        :param version: AI app version
        :param source_type: The type of AI app, "Image" or "Rpm"
        :param source_location: source location of AI app, supports swr path or rpm path
        :param initial_config: AI app configs
        :param description: AI description
        :param workspace_id: workspace id
        :param cmd: execute command
        :param deployment_constraints: AI app deployment constraints
        :param specification: minimum resource specifications required by AI app inference
        :param market_from: whether comes from the AI gallery market
        :param trace_info: record source tracing information.
        :param labels: labels, up to 3
        :return: create result
        """
        request_body = {
            "name": name,
            "version": version,
            "source_type": source_type,
            "source_location": source_location,
            "initial_config": initial_config
        }
        if description is not None:
            request_body["description"] = description
        if workspace_id is not None:
            request_body["workspace_id"] = workspace_id
        if description is not None:
            request_body["description"] = description
        if cmd is not None:
            request_body["cmd"] = cmd
        if deployment_constraints is not None:
            request_body["deployment_constraints"] = deployment_constraints
        if specification is not None:
            request_body["specification"] = specification
        if market_from is not None:
            request_body["market_from"] = market_from
        if trace_info is not None:
            request_body["trace_info"] = trace_info
        if labels is not None:
            request_body["labels"] = labels
        return request_body

    @staticmethod
    def generate_initial_config(port=None, protocol=None, apis=None, health=None):
        """
        Generate initial config
        :param port: externally exposed ports
        :param protocol: protocol
        :param apis: externally exposed request format
        :param health: health check
        :return: initial_config parameters
        """
        initial_config = {}
        if port is not None:
            initial_config["port"] = port
        if protocol is not None:
            initial_config["protocol"] = protocol
        if apis is not None:
            initial_config["apis"] = apis
        if health is not None:
            initial_config["health"] = health
        return initial_config

    @staticmethod
    def generate_api(url, method=None):
        """
        Generate api parameters
        :param url: request url
        :param method: request method, default "POST"
        :return: api parameters
        """
        api = {
            "url": url
        }
        if method is not None:
            api["method"] = method
        return api

    @staticmethod
    def generate_health(url, initial_delay_seconds=None, timeout_seconds=None):
        """
        Generate health parameters
        :param url: health check request url
        :param initial_delay_seconds: wait time to request the health check after service started
        :param timeout_seconds: time out for health check
        :return: health parameters
        """
        health = {
            "url": url
        }
        if initial_delay_seconds is not None:
            health["initial_delay_seconds"] = initial_delay_seconds
        if timeout_seconds is not None:
            health["timeout_seconds"] = timeout_seconds
        return health

    @staticmethod
    def generate_deployment_constraints(request_mode, cpu_type, input_types, output_types, rsa, os_type=None,
                                        os_version=None, accelerators=None, task_config=None, service_config=None):
        """
        Generate deployment_constraints parameters
        :param request_mode: request mode, "async" or "sync"
        :param cpu_type: "x86_64", "x86_32", "aarch64" or "aarch32"
        :param input_types: supported input types
        :param output_types: supported output types
        :param rsa: secret
        :param os_type: operating system type, which is required when source_type is "rpm"
        :param os_version: operating system version, which is required when source_type is "rpm"
        :param accelerators: inference Acceleration Card Constraints
        :param task_config: task config, xml format
        :param service_config: service config, xml format
        :return: deployment_constraints parameters
        """
        deployment_constraints = {
            "request_mode": request_mode,
            "cpu_type": cpu_type,
            "input_types": input_types,
            "output_types": output_types,
            "rsa": rsa
        }
        if os_type is not None:
            deployment_constraints["os_type"] = os_type
        if os_version is not None:
            deployment_constraints["os_version"] = os_version
        if accelerators is not None:
            deployment_constraints["accelerators"] = accelerators
        if task_config is not None:
            deployment_constraints["task_config"] = task_config
        if service_config is not None:
            deployment_constraints["service_config"] = service_config
        return deployment_constraints

    @staticmethod
    def generate_accelerator(type, name, version=None):
        """
        Generate accelerator parameters
        :param type: accelerator card type, "gpu" or "npu"
        :param name: accelerator card  name, such as "T4" and "P4" for gpu, "D310" and "D910" for npu
        :param version: driver version
        :return: accelerator parameters
        """
        accelerator = {
            "type": type,
            "name": name
        }
        if version is not None:
            accelerator["version"] = version
        return accelerator

    @staticmethod
    def generate_rsa(mode, public_key, identification_code=None):
        """
        Generate sa parameters
        :param mode: filling format, OAEP is supported currently
        :param public_key: public key
        :param identification_code: identification code, used for edge deployment
        :return: rsa parameters
        """
        rsa = {
            "mode": mode,
            "public_key": public_key
        }
        if identification_code is not None:
            rsa["identification_code"] = identification_code
        return rsa

    @staticmethod
    def generate_specification(min_cpu, min_memory, min_gpu=None, min_ascend=None):
        """
        Generate specification parameters
        :param min_cpu: number of CPU cores required for inference
        :param min_memory: memory required for inference
        :param min_gpu: GPU required for inference
        :param min_ascend: D chip required for inference
        :return: specification parameters
        """
        specification = {
            "min_cpu": min_cpu,
            "min_memory": min_memory
        }
        if min_gpu is not None:
            specification["min_gpu"] = min_gpu
        if min_ascend is not None:
            specification["min_ascend"] = min_ascend
        return specification

    @staticmethod
    def generate_label(name, description):
        """
        Generate label parameters
        :param name: document name
        :param description: description
        :return: label parameters
        """
        label = {
            "name": name,
            "description": description
        }
        return label
