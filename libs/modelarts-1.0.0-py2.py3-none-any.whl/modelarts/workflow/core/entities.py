import abc
from typing import Any, Dict, List, Union

TransformType = Union[Dict[str, Any], List[Dict[str, Any]]]


class Entity(abc.ABC):
    """
    The classes in Pipeline that need to convert definitions to Json for calling the API to create Workflow should all
    inherit from this class
    """

    @abc.abstractmethod
    def to_definition_json(self) -> TransformType:
        """
        Used to convert a class written in Python to Json
        Returns (TransformType):

        """
