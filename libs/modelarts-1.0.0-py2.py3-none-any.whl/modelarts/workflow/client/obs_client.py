import json
import base64
import requests
import logging
from json import JSONDecodeError

from modelarts import constant


class APIException(Exception):
    def __init__(self, code=500, message=""):
        self.code = code
        self.message = message

    def __str__(self):
        return "err_code: {}, err_message: {}".format(self.code, self.message)


class ObsClient:
    def __init__(self, session):
        """
        Class for Client which makes ModelArts OBS service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        self._obs_management = session.obs
        self.session = session

    def get_data_from_obs_file(self, bucket_path):
        """
        get json data from OBS file
        Args:
            bucket_path (str): The path of OBS file

        Returns (dict): Dict format of data from OBS file

        """
        unified_bucket_path = ObsClient._process_bucket_path(bucket_path)
        bucket_path_split = unified_bucket_path.split('/', 1)
        bucket_name = bucket_path_split[0]
        object_name = bucket_path_split[1]
        return self._get_data_from_obs_file(bucket_name, object_name)

    @staticmethod
    def _process_bucket_path(path):
        """
        The path is processed uniformly, and finally converted to a uniform format：bucket_name/.../file_name
        Args:
            path (str): Path before unified processing

        Returns (str): Path after unified processing

        """
        path_split = path.split(':')
        if len(path_split) == 1:
            return path_split[0].strip('/')
        elif len(path_split) == 2:
            return path_split[1].strip('/')
        else:
            raise ValueError('The path {} is invalid'.format(path))

    def create_directory(self, bucket, directory):
        """
        Create a directory in OBS
        Args:
            bucket (str): The obs bucket path
            directory (str): The directory path

        Returns:

        """
        if directory:
            directory = '{}/'.format(directory.strip("/"))
        obs_dir = 'obs://{}/{}'.format(bucket, directory)
        self._obs_management.make_obs_dir(obs_dir)

    def is_obs_path_exists(self, obs_path):
        """
        Check whether the obs path exists
        Args:
            obs_path (str): obs directory or obs file, and must be startswith 'obs://'

        Returns (bool): True or False

        """
        return self._obs_management.is_obs_path_exists(obs_path)

    def _get_data_from_obs_file(self, bucket_name, object_name):
        if self.session.auth == constant.AKSK_AUTH:
            return self._get_data_with_hwc(bucket_name, object_name)
        else:
            return self._get_data_with_roma(bucket_name, object_name)

    def _get_data_with_hwc(self, bucket_name, object_name):
        hwc_impl = self._obs_management.obs_client
        resp = hwc_impl.obs_client.getObject(bucket_name, object_name)
        if resp.status > 300:
            raise APIException(code=resp.errorCode, message=resp.errorMessage)
        try:
            data = resp.body.response.read()
            return json.loads(data)
        except MemoryError as e:
            logging.error("Memory overflow due to too large file")
            raise e
        except JSONDecodeError as e:
            logging.error("The OBS file of %s is not a json file")
            raise e
        finally:
            resp.body.response.close()

    def _get_data_with_roma(self, bucket_name, object_name):
        roma_impl = self._obs_management.obs_client
        bucket_file_path_without_bucket_name_b64 = base64.b64encode(object_name.encode()).decode('utf-8')
        bucket_file_address = roma_impl._get_bucket_file_address(bucket_name)
        request_url = '{}/rest/boto3/s3/HEC/{}/{}/{}/{}'.format(
            bucket_file_address,
            roma_impl.region_name,
            roma_impl.csb_token,
            bucket_name,
            bucket_file_path_without_bucket_name_b64,
        )
        headers = {"Content-Type": "text/plain", "csb-token": roma_impl.csb_token}
        response = requests.get(request_url, headers=headers, verify=False)
        if response.status_code > 300:
            raise Exception(response.content)
        try:
            data = json.loads(response.content)
            return data
        except MemoryError as e:
            logging.error("Memory overflow due to too large file")
            raise e
        except JSONDecodeError as e:
            logging.error("The OBS file of %s is not a json file")
            raise e
