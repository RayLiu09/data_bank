from modelarts.workflow.core.steps import Step, StepTypeEnum


class MockTestStep(Step):
    def __init__(self, name, depend_steps, is_create_failed, running_states_transition, policy=None):
        """
        Mock step, only used to test the state change of the main frame
        Args:
            name (str): step name
            depend_steps (list[Step]): depend steps list
            is_create_failed (bool): instance is whether created failed
            running_states_transition (list[str]): states transition list
            policy (StepPolicy): step policy
        """
        super().__init__(name=name, step_type=StepTypeEnum.MOCK, depend_steps=depend_steps, policy=policy)
        self.is_create_failed = is_create_failed
        self.running_states_transition = running_states_transition
        self.cur_idx = 0

    def create_instance(self) -> (bool, str):
        if self.is_create_failed:
            return False, "step create instance failed (%s)." % self.name
        instance_id = "test-uuid-XXXX"
        return True, instance_id

    def stop_instance(self) -> (bool, str):
        return True, "success"

    def update_instance_state(self):
        running_state_size = len(self.running_states_transition)
        if not self.instance_id:
            return
        if running_state_size <= 0:
            return
        if self.cur_idx >= running_state_size:
            self.set_state(self.running_states_transition[running_state_size - 1])
            return
        self.set_state(self.running_states_transition[self.cur_idx])
        self.cur_idx = self.cur_idx + 1

    def is_ready(self) -> (bool, str):
        return True, "ready"

    def build_client(self, session):
        super(MockTestStep, self).build_client(session)
