#!/bin/bash

current_path=$(cd `dirname $0`;pwd)
model_path=$1
service_port=$2

py_file_num=$(ls ${model_path}/*.py | wc -l)
service_file=$(ls ${model_path}/*.py)

if [ ${py_file_num} -ge 2 ]; then
  service_file='${model_path}/customize_service.py'
fi

worker_timeout=120

worker_num=1

worker_threads=5

log_file=${model_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

export TF_MODEL_ARGS="--model_path=${model_path} --model_name=serve --service_file=${service_file}"
cd ${current_path} && gunicorn -w ${worker_num} --threads ${worker_threads} -t ${worker_timeout} -b 0.0.0.0:${service_port} app:app | tee ${log_file}
