"""
A network class for resource pool for modelarts sdk.
"""
from .config.auth import auth_by_apig
from .util.secret_util import auth_expired_handler
from . import constant


class Network:

    def __init__(self, session, workspace_id=None):
        self.session = session
        self.workspace_id = workspace_id

        if session.auth == constant.AKSK_AUTH:
            self.request = self.request_by_apig
        else:
            raise ValueError('Only support aksk authorization.')

    @classmethod
    def get_networks_list(cls, session, **kwargs):
        """
        Get resource network list
        :param session: session
        :param kwargs: support 'workspaceId'
        :return: network List
        """
        return cls(session=session).__get_network_list(**kwargs)

    @classmethod
    def get_network_info(cls, session, network_id):
        """
        Get resource network info
        :param session: session
        :param network_id: network_id, it's the network name in network.metadate.name, but is NOT the os.modelarts/name in labels.
        :return: network info
        """
        return cls(session=session).__get_network_info(network_id)

    def __get_network_list(self, **kwargs):
        url = "/v1/{}/networks".format(self.session.project_id)
        return self.request(constant.HTTPS_GET, url, query=kwargs)

    def __get_network_info(self, network_id):
        url = "/v1/{}/networks/{}".format(self.session.project_id, network_id)
        return self.request(constant.HTTPS_GET, url)

    @auth_expired_handler
    def request_by_apig(self, method, url, query=None, body=None, headers=None):
        return auth_by_apig(self.session, method, url, query, body, headers)
