from modelarts.estimatorV2 import TrainingJob
from modelarts.workflow.client.algorithm_client import AlgorithmClient
from modelarts.workflow.resource.workspace import Workspace
from modelarts.config.auth import auth_by_apig
from modelarts.util.secret_util import auth_expired_handler
from modelarts import constant

HTTPS_GET = constant.HTTPS_GET
POOL_STATUS = "RUNNING-SCALINGUP-SPEC_CHG_LOCK-TO_PERIOD_LOCK"
POOL_TYPE = "USER_DEFINED"


class JobClient:
    def __init__(self, session):
        """
        Class for Client which makes ModelArts Job service calls.
        Args:
            session (Session): building interactions with cloud service.
        """
        self._client = TrainingJob(session)
        self._algorithm_client = AlgorithmClient(session)
        self.session = session

    def create_job(self, create_job_body):
        """
        Create Training Job.
        Args:
            create_job_body (dict):The body of create job

        Returns (str):The instance_id of job

        """
        if not create_job_body:
            raise ValueError("create_job_body is empty")
        if not create_job_body.get("metadata"):
            raise ValueError("create_job_body is abnormal")
        create_job_body["metadata"]["workspace_id"] = Workspace.instance().workspace_id
        resp = self._client.create_training_job(body=create_job_body)
        job_id = JobClient._get_job_id(resp)
        return job_id

    def create_algorithm(self, create_algorithm_body):
        """
        Create algorithm.
        Args:
            create_algorithm_body (dict):The body of create algorithm

        Returns (str):The id of algorithm

        """
        if not create_algorithm_body:
            raise ValueError("create_algorithm_body is empty")
        create_algorithm_body["metadata"]["workspace_id"] = Workspace.instance().workspace_id
        algorithm_id = self._algorithm_client.create_algorithm(create_algorithm_body)
        return algorithm_id

    def publish_algorithm(self, algorithm_id, content_id, version_num):
        """
        publish algorithm.
        Args:
            algorithm_id (str): The algorithm ID
            content_id (str): The content ID of AI Gallery
            version_num (str): The version num of content

        Returns (str): the version id of content
        """
        if not algorithm_id:
            raise ValueError("algorithm_id is empty")
        if not content_id:
            raise ValueError("content_id is empty")
        if not version_num:
            raise ValueError("version_num is empty")
        version_id = self._algorithm_client.publish_algorithm(algorithm_id, content_id, version_num)
        return version_id

    def get_job_info(self, job_id):
        """
        Get the information of the specified step
        Args:
            job_id (str):The instance_id of job

        Returns (dict): The response of request

        """
        if not job_id:
            raise ValueError("job_id is empty")
        resp = self._client.get_job_info(job_id=job_id)
        return resp

    def get_job_state(self, job_id):
        """
        Get the job state
        Args (str):
            job_id:The job id

        Returns (str): The state of job

        """
        job_info = self.get_job_info(job_id)
        return JobClient._get_job_state_from_job_info(job_info)

    def stop_job(self, job_id):
        """
        Stop the specified step
        Args:
            job_id (str): The job id

        Returns (str): The state of job

        """
        job_info = self._client.control_job(job_id=job_id, action_type="terminate")
        return JobClient._get_job_state_from_job_info(job_info)

    @staticmethod
    def _get_job_id(resp):
        """
        Get the job id from the response of create job request
        Args:
            resp (dict): The response of create job request

        Returns (str): The job id

        """
        metadata = resp.get("metadata")
        if metadata is None:
            raise KeyError("the response of create job has no metadata field")
        job_id = metadata.get("id")
        if job_id is None:
            raise KeyError("the metadata has no job_id field")
        return job_id

    @staticmethod
    def _get_job_state_from_job_info(job_info):
        """
        Get the job state from job info
        Args:
            job_info (dict): The job info

        Returns (str): The job state

        """
        status = job_info.get("status")
        if status is None:
            raise KeyError("the response has no status field")
        job_state = status.get("phase")
        if job_state is None:
            raise KeyError("the status has no phase field")
        return job_state

    def get_algorithm_info(self, algorithm_id):
        """
        Get algorithm info according to the algorithm_id
        Args:
            algorithm_id (str): The algorithm ID

        Returns (dict): The algorithm info

        """
        algorithm_info = self._algorithm_client.get_algorithm_info(algorithm_id=algorithm_id)
        return algorithm_info

    def get_gallery_algorithm_info(self, subscription_id, version_id):
        """
        Get subscription algorithm info according to the subscription_id and version_id
        Args:
            subscription_id (str): The subscription ID of the subscription algorithm
            version_id (str): The version ID of the subscription algorithm

        Returns (dict): The subscription algorithm info

        """
        algorithm_info = self._algorithm_client.get_gallery_algorithm_info(
            subscription_id=subscription_id,
            version_id=version_id
        )
        return algorithm_info

    def get_model_id(self, job_id):
        """
        Get the auto-registered model ID
        Args:
            job_id (str): The job id

        Returns (str): The model ID

        """
        job_info = self.get_job_info(job_id)
        return JobClient._get_model_id_from_job_info(job_info)

    @staticmethod
    def _get_model_id_from_job_info(job_info):
        """
        Get the model ID from job info
        Args:
            job_info (dict): The job info

        Returns (str): The model ID

        """
        model_id = ""
        output_list = job_info.get("algorithm", {}).get("outputs")
        if output_list is None:
            raise KeyError("the response has no outputs field")
        for output in output_list:
            if output.get("modelarts_hosted") and output.get("remote", {}).get("model"):
                model_id = output.get("remote").get("model", {}).get("id")
        if not model_id:
            raise KeyError("the response has no id field")
        return model_id

    @auth_expired_handler
    def get_pool_list(self, **kwargs):
        """
        Get pool list info
        Args:
            **kwargs:

        Returns (dict): pool list info

        """
        if not kwargs.get("pool_type"):
            kwargs["pool_type"] = POOL_TYPE
        if not kwargs.get("status"):
            kwargs["status"] = POOL_STATUS
        if not kwargs.get("workspace_id"):
            kwargs["workspace_id"] = Workspace.instance().workspace_id
        request_url = "/v1/{project_id}/pools".format(project_id=self.session.project_id)
        return auth_by_apig(self.session, HTTPS_GET, request_url, kwargs)

    @auth_expired_handler
    def get_pool_id_list(self, **kwargs):
        """
        Get pool ID list
        Args:
            **kwargs:

        Returns (list): ID list

        """
        resp = self.get_pool_list(**kwargs)
        pool_list = resp.get("pools", [])
        return [pool.get("pool_id", "") for pool in pool_list]
