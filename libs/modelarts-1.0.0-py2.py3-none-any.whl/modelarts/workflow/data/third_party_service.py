from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.data.storage import Storage


class TripartiteServiceConfig:
    """
    configured objects for docking tripartite services
    """
    def __init__(self, config_file):
        """

        Args:
            config_file (Union[str, Placeholder, Storage]): config file path
        """
        self.config_file = config_file

    def to_definition_json(self):
        if isinstance(self.config_file, (Placeholder, Storage)):
            config_file = self.config_file.ref()
        else:
            config_file = self.config_file

        return {
            "config_file": config_file
        }
