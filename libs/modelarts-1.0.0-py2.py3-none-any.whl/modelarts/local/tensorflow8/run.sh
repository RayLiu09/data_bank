#!/bin/bash

current_path=$(cd `dirname $0`;pwd)
tmp=`mktemp`
rm -rf ${tmp}
mkdir -p ${tmp}/1
model_path="${tmp}/1"
cp -r $1* $model_path
service_port=$2

py_file_num=$(ls ${model_path}/*.py | wc -l)
service_file=$(ls ${model_path}/*.py)

if [ ${py_file_num} -ge 2 ]; then
  service_file='${model_path}/customize_service.py'
fi

worker_timeout=120

if [ -n "${MODELARTS_WORKER_TIMEOUT}" ]; then
  worker_timeout=${MODELARTS_WORKER_TIMEOUT}
fi

worker_num=1

if [ -n "${MODELARTS_WORKER_NUM}" ]; then
  worker_num=${MODELARTS_WORKER_NUM}
fi

worker_threads=5

if [ -n "${MODELARTS_WORKER_THREADS}" ]; then
  worker_threads=${MODELARTS_WORKER_THREADS}
fi

which tensorflow_model_server
if [ $? -ne 0 ]; then
   echo "tensorflow_model_server is required, you can download it as below command:"
   pythonpath=`which python`
   conda_env=${pythonpath%%/bin/python}
   is_conda_env=`conda env list|grep "${conda_env}"`
   if [ "x${is_conda_env}" = "x" ]; then
       echo "\"bash ${current_path}/tf_local_infer_envs.sh CPU\""
       echo "   or"
       echo "\"bash ${current_path}/tf_local_infer_envs.sh GPU\""
       exit 1
   else
       echo "\"source activate ${conda_env} && bash ${current_path}/tf_local_infer_envs.sh CPU\""
       echo "   or"
       echo "\"source activate ${conda_env} && bash ${current_path}/tf_local_infer_envs.sh GPU\""
       exit 1
   fi
fi

orig_model_path=$1
log_file=${orig_model_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

export TF_MODEL_ARGS="--model_path=${model_path} --model_name=serve --service_file=${service_file}"
cd ${current_path} && gunicorn -w ${worker_num} --threads ${worker_threads} -t ${worker_timeout} -b 0.0.0.0:${service_port} app:app | tee ${log_file}
