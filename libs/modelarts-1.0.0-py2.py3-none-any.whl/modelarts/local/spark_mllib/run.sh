#!/bin/bash
umask 0027
file_path=$1
service_port=$2
 
service_ip=127.0.0.1
current_path=$(cd `dirname $0`;pwd)

if [ -n "${MODELARTS_SERVICE_PORT}" ]
then
 service_port=${MODELARTS_SERVICE_PORT}
fi
 
if [ -z $JAVA_HOME ];then
    export JAVA_HOME=/home/ma-user/anaconda3/envs/PySpark-2.3.2/3rdComponent/jre
fi

model_path=$1
log_file=${model_path}log.txt
if [ -f "${log_file}" ]; then
  rm -rf "${log_file}"
fi

# start service
export SP_MODEL_ARGS="--file_path=${file_path} --service_ip=${service_ip} --service_port=${service_port}"
cd ${current_path} && gunicorn -w 2 -b ${service_ip}:${service_port} flaskApp:app | tee ${log_file}