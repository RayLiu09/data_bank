import re

# default max name length
CONST_MAX_NAME_LENGTH = 64

# default max description length
CONST_MAX_DESCRIPTION_LENGTH = 500


def check_name(name, length=CONST_MAX_NAME_LENGTH):
    if not name:
        raise ValueError('name is empty or none')
    if not isinstance(name, str):
        raise TypeError('name type is not str')
    if not isinstance(length, int) or length <= 0:
        raise TypeError('length is not int or value le 0')
    if len(name) > length:
        raise ValueError('name length is too long, max length is {}'.format(str(length)))
    # only support letters, digits, underscores (_), hyphens (-), and must start with a letter
    res = re.search("^[a-zA-Z][a-zA-Z0-9_-]*$", name)
    if not res:
        raise ValueError('name is not regular, only letters, digits, underscores (_), and hyphens (-) are allowed, '
                         'and must start with a letter')


def check_description(desc):
    if len(desc) > CONST_MAX_DESCRIPTION_LENGTH:
        raise ValueError('length of description is too long, max length is {}'.format(CONST_MAX_DESCRIPTION_LENGTH))
