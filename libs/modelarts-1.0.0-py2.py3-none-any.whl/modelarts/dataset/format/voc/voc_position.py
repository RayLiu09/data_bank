"""
Description: parse file of pascal voc format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

from enum import Enum, unique

from modelarts.dataset.format.manifest import constants


@unique
class PositionType(Enum):
    """
    Position type list of object detection
    """
    DASHED = "dashed"
    CIRCLE = "circle"
    POLYLINE = "polyline"
    BNDBOX = "bndbox"
    POINT = "point"
    LINE = "line"
    POLYGON = "polygon"


class Point(object):
    def __init__(self, x_value=None, y_value=None, x_name=constants.X, y_name=constants.Y):
        self.__x_name = x_name
        self.__x_value = x_value
        self.__y_name = y_name
        self.__y_value = y_value

    @property
    def x_name(self):
        return self.__x_name

    @property
    def x_value(self):
        return self.__x_value

    @property
    def y_name(self):
        return self.__y_name

    @property
    def y_value(self):
        return self.__y_value

    @property
    def feature(self):
        feature_points = [self.__x_value, self.__y_value]
        return feature_points

    @feature.setter
    def feature(self, feature):
        self.__x_value = feature[0]
        self.__y_value = feature[1]

    @classmethod
    def type(cls):
        return PositionType.POINT.value


class Line(object):
    def __init__(self, x1=None, y1=None, x2=None, y2=None):
        self.__x1 = x1
        self.__y1, = y1,
        self.__x2 = x2
        self.__y2 = y2

    @property
    def x1(self):
        return self.__x1

    @property
    def y1(self):
        return self.__y1

    @property
    def x2(self):
        return self.__x2

    @property
    def y2(self):
        return self.__y2

    def get_feature(self):
        feature_points = [[self.__x1, self.__y1], [self.__x2, self.__y2]]
        return feature_points

    def set_feature(self, feature):
        self.__x1 = feature[0][0]
        self.__y1 = feature[0][1]
        self.__x2 = feature[1][0]
        self.__y2 = feature[1][1]

    @classmethod
    def type(cls):
        return PositionType.LINE.value


class Dashed(object):
    def __init__(self, x1=None, y1=None, x2=None, y2=None):
        self.__x1 = x1
        self.__y1, = y1,
        self.__x2 = x2
        self.__y2 = y2

    @property
    def x1(self):
        return self.__x1

    @property
    def y1(self):
        return self.__y1

    @property
    def x2(self):
        return self.__x2

    @property
    def y2(self):
        return self.__y2

    def get_feature(self):
        feature_points = [[self.__x1, self.__y1], [self.__x2, self.__y2]]
        return feature_points

    def set_feature(self, feature):
        self.__x1 = feature[0][0]
        self.__y1 = feature[0][1]
        self.__x2 = feature[1][0]
        self.__y2 = feature[1][1]

    @classmethod
    def type(cls):
        return PositionType.DASHED.value


class Circle(object):
    def __init__(self, cx=None, cy=None, r=None):
        self.__cx = cx
        self.__cy = cy
        self.__r = r

    @property
    def cx(self):
        return self.__cx

    @property
    def cy(self):
        return self.__cy

    @property
    def r(self):
        return self.__r

    def get_feature(self):
        feature_points = [self.__cx, self.__cy, self.__r]
        return feature_points

    def set_feature(self, feature):
        self.__cx = feature[0]
        self.__cy = feature[1]
        self.__r = feature[2]

    @classmethod
    def type(cls):
        return PositionType.CIRCLE.value


class BNDBox(object):
    def __init__(self, x_min=None, y_min=None, x_max=None, y_max=None):
        self.__x_min = x_min
        self.__y_min = y_min
        self.__x_max = x_max
        self.__y_max = y_max

    @property
    def x_min(self):
        return self.__x_min

    @property
    def y_min(self):
        return self.__y_min

    @property
    def x_max(self):
        return self.__x_max

    @property
    def y_max(self):
        return self.__y_max

    def get_feature(self):
        feature_points = [[self.__x_min, self.__y_min], [self.__x_max, self.__y_max]]
        return feature_points

    def set_feature(self, feature):
        self.__x_min = feature[0][0]
        self.__y_min = feature[0][1]
        self.__x_max = feature[1][0]
        self.__y_max = feature[1][1]

    @classmethod
    def type(cls):
        return PositionType.BNDBOX.value


class Polygon(object):
    def __init__(self, points=None):
        self.__points = points

    @property
    def points(self):
        return self.__points

    def get_feature(self):
        points = self.points
        feature_points = []
        for point in points:
            feature_points.append([point.x_value, point.y_value])
        return feature_points

    def set_feature(self, feature):
        self.__points = []
        for point_num in range(len(feature)):
            point = feature[point_num]
            self.__points.append(Point(point[0], point[1], "x" + str(point_num + 1), "y" + str(point_num + 1)))

    @classmethod
    def type(cls):
        return PositionType.POLYGON.value


class Polyline(object):
    def __init__(self, points=None):
        self.__points = points

    @property
    def points(self):
        return self.__points

    def get_feature(self):
        points = self.points
        feature_points = []
        for point in points:
            feature_points.append([point.x_value, point.y_value])
        return feature_points

    @classmethod
    def type(cls):
        return PositionType.POLYLINE.value


def shape_is_point(doc, point_element, feature):
    x_element = doc.createElement(constants.X)
    x_element.appendChild(doc.createTextNode(str(feature[0])))
    point_element.appendChild(x_element)
    y_element = doc.createElement(constants.Y)
    y_element.appendChild(doc.createTextNode(str(feature[1])))
    point_element.appendChild(y_element)


def shape_is_line(doc, line_element, feature):
    point1 = feature[0]
    point2 = feature[1]
    x1_element = doc.createElement(constants.X1)
    x1_element.appendChild(doc.createTextNode(str(point1[0])))
    line_element.appendChild(x1_element)
    y1_element = doc.createElement(constants.Y1)
    y1_element.appendChild(doc.createTextNode(str(point1[1])))
    line_element.appendChild(y1_element)
    x2_element = doc.createElement(constants.X2)
    x2_element.appendChild(doc.createTextNode(str(point2[0])))
    line_element.appendChild(x2_element)
    y2_element = doc.createElement(constants.Y2)
    y2_element.appendChild(doc.createTextNode(str(point2[1])))
    line_element.appendChild(y2_element)


def shape_is_dashed(doc, dashed_element, feature):
    point1 = feature[0]
    point2 = feature[1]
    x1_element = doc.createElement(constants.X1)
    x1_element.appendChild(doc.createTextNode(str(point1[0])))
    dashed_element.appendChild(x1_element)
    y1_element = doc.createElement(constants.Y1)
    y1_element.appendChild(doc.createTextNode(str(point1[1])))
    dashed_element.appendChild(y1_element)
    x2_element = doc.createElement(constants.X2)
    x2_element.appendChild(doc.createTextNode(str(point2[0])))
    dashed_element.appendChild(x2_element)
    y2_element = doc.createElement(constants.Y2)
    y2_element.appendChild(doc.createTextNode(str(point2[1])))
    dashed_element.appendChild(y2_element)


def shape_is_circle(doc, circle_element, feature):
    cx_element = doc.createElement(constants.CX)
    cx_element.appendChild(doc.createTextNode(str(feature[0])))
    circle_element.appendChild(cx_element)
    cy_element = doc.createElement(constants.CY)
    cy_element.appendChild(doc.createTextNode(str(feature[1])))
    circle_element.appendChild(cy_element)
    r_element = doc.createElement(constants.R)
    r_element.appendChild(doc.createTextNode(str(feature[2])))
    circle_element.appendChild(r_element)


def shape_is_bndbox(doc, bndbox_element, feature):
    point1 = feature[0]
    point2 = feature[1]
    xmin_element = doc.createElement(constants.X_MIN)
    xmin_element.appendChild(doc.createTextNode(str(point1[0])))
    bndbox_element.appendChild(xmin_element)
    ymin_element = doc.createElement(constants.Y_MIN)
    ymin_element.appendChild(doc.createTextNode(str(point1[1])))
    bndbox_element.appendChild(ymin_element)
    xmax_element = doc.createElement(constants.X_MAX)
    xmax_element.appendChild(doc.createTextNode(str(point2[0])))
    bndbox_element.appendChild(xmax_element)
    ymax_element = doc.createElement(constants.Y_MAX)
    ymax_element.appendChild(doc.createTextNode(str(point2[1])))
    bndbox_element.appendChild(ymax_element)


def shape_is_polygon(doc, polygon_element, feature):
    for xy_pos in range(len(feature)):
        point = feature[xy_pos]
        x_element = doc.createElement("x" + str(xy_pos + 1))
        x_element.appendChild(doc.createTextNode(str(point[0])))
        polygon_element.appendChild(x_element)
        y_element = doc.createElement("y" + str(xy_pos + 1))
        y_element.appendChild(doc.createTextNode(str(point[1])))
        polygon_element.appendChild(y_element)


def shape_is_polyline(doc, polyline_element, feature):
    for xy_pos in range(len(feature)):
        point = feature[xy_pos]
        x_element = doc.createElement("x" + str(xy_pos + 1))
        x_element.appendChild(doc.createTextNode(str(point[0])))
        polyline_element.appendChild(x_element)
        y_element = doc.createElement("y" + str(xy_pos + 1))
        y_element.appendChild(doc.createTextNode(str(point[1])))
        polyline_element.appendChild(y_element)


shape_cases = {PositionType.POINT.value: shape_is_point,
               PositionType.DASHED.value: shape_is_dashed,
               PositionType.BNDBOX.value: shape_is_bndbox,
               PositionType.LINE.value: shape_is_line,
               PositionType.POLYGON.value: shape_is_polygon,
               PositionType.CIRCLE.value: shape_is_circle,
               PositionType.POLYLINE.value: shape_is_polyline}
