import logging
from abc import ABCMeta, abstractmethod
from json import JSONEncoder

from .. import constant
from ..config.auth import auth_by_apig
from . import ModelArtsService
from modelarts.exception.apig_exception import APIGException


logging.getLogger().setLevel(logging.INFO)


class ImageApi(metaclass=ABCMeta):
    """These Apis can interact with modelarts management service."""

    @abstractmethod
    def get_image(self, query_param=None):
        """Get images from modelarts image management service
        :param query_param: query parameters like 'type' or 'name'
        """
        pass

    @abstractmethod
    def get_image_by_id(self, image_id):
        """Get image info from modelarts image management service by image id
        :param image_id: image id
        """
        pass

    @abstractmethod
    def register_image(self, image):
        """Register this image into modelarts management service and user can create notebook or training job with it.
        :param image: an instance of class Image, containing the information which will be registered
        """
        pass

    @abstractmethod
    def unregister_image(self, image_id, delete_swr_image=False):
        """
        Delete the image from database. If delete_swr_image is true, delete the image from swr at same time.
        :param image_id: the image id which will be deleted.
        :param delete_swr_image: If this parameter is true, delete the image from swr at same time.
        """
        pass

    @staticmethod
    def gen_register_body(image):
        """Generate body for register image api.
        :param image: an instance of class Image, containing the information which will be registered
        :return a dictionary including the parameters for registering image
        """
        body = {"swr_path": image.swr_path}
        if image.arch:
            body.update({"arch": image.arch})
        if image.description:
            body.update({"description": image.description})
        if image.visibility:
            body.update({"visibility": image.visibility})
        if image.dev_services:
            services = []
            for svc in image.dev_services:
                # For now, roma does not support MODELBOX which is the same as AI_FLOW, so we replace it with AI_FLOW
                if svc.upper() == ModelArtsService.MODELBOX.value:
                    services.append("AI_FLOW")
                # Notebook supports SSH by default
                elif svc.upper() == ModelArtsService.NOTEBOOK.value:
                    services.append(svc)
                    services.append("SSH")
            body.update({"services": services})
        if image.resource_category:
            body.update({"resource_category": image.resource_category})
        if image.flavor_type:
            body.update({"flavor_type": image.flavor_type})
        return body


class ImageApiAKSKImpl(ImageApi):

    def __init__(self, session):
        super(ImageApiAKSKImpl, self).__init__()
        self._session = session

    def get_image(self, query_param=None):
        query_param = dict() if query_param is None else query_param
        # The feature of an image include 'NOTEBOOK' and 'DEFAULT' where the latter is used to create codelab.
        # We do not need display codelab images to users.
        query_param.update({"feature": "NOTEBOOK"})
        request_url = "/v1/" + self._session.project_id + "/images"
        return auth_by_apig(self._session, constant.HTTPS_GET, request_url, query=query_param)

    def get_image_by_id(self, image_id):
        request_url = "/v1/" + self._session.project_id + "/images/" + image_id
        try:
            return auth_by_apig(self._session, constant.HTTPS_GET, request_url)
        except APIGException:
            return dict()

    def register_image(self, image, obs_path=None):
        request_url = "/v1/" + self._session.project_id + "/images"
        body = self.gen_register_body(image)
        if image.workspace_id:
            body.update({"workspace_id": image.workspace_id})
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(self._session, constant.HTTPS_POST, request_url, body=body_encode)

    def unregister_image(self, image_id, delete_swr_image=False):
        request_url = "/v1/" + self._session.project_id + "/images/{}".format(image_id)
        body = {}
        if delete_swr_image:
            body = {"force_delete_swr_image": delete_swr_image}
        body_encode = JSONEncoder().encode(body)
        return auth_by_apig(self._session, constant.HTTPS_DELETE, request_url, body=body_encode)


def get_image_api_instance(session):
    return ImageApiAKSKImpl(session)
