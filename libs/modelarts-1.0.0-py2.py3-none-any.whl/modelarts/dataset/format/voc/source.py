"""
Description: parse file of pascal voc format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""


class Source(object):
    """
    VOC contain source, object and so on.
    This class is used to record source. Source contains database, annotation and so on.
    """

    def __init__(self, database=None, annotation=None, image=None):
        self.__database = database
        self.__annotation = annotation
        self.__image = image

    @property
    def database(self):
        return self.__database

    @database.setter
    def database(self, database):
        self.__database = database

    @property
    def annotation(self):
        return self.__annotation

    @annotation.setter
    def annotation(self, annotation):
        self.__annotation = annotation

    @property
    def image(self):
        return self.__image

    @image.setter
    def image(self, image):
        self.__image = image
