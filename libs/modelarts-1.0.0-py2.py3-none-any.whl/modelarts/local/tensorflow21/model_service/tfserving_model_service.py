# -*- coding: utf-8 -*-
import logging

import numpy as np
import tensorflow as tf
from modelarts.local.commons.model_service import SingleNodeService

logger = logging.getLogger(__name__)

try:
    from PIL import Image
except ImportError:
    logger.error("Please install Pillow package first.")


class TfServingBaseService(SingleNodeService):

    def __init__(self, model_name, model_path):
        self.model_name = model_name
        self.model_path = model_path
        self.model = None
        self.predict = None

        # label文件可以在这里加载,在后处理函数里使用
        # label.txt放在obs和模型包的目录

        # 非阻塞方式加载saved_model模型，防止阻塞超时
        self.load_model()

    def load_model(self):
        self.model = tf.saved_model.load(self.model_path)
        signature_defs = self.model.signatures.keys()
        signature = []
        # only one signature allowed
        for signature_def in signature_defs:
            signature.append(signature_def)

        if len(signature) != 1:
            logger.warning("signatures more than one, use serving_default signature")
            model_signature = tf.saved_model.DEFAULT_SERVING_SIGNATURE_DEF_KEY
        else:
            model_signature = signature[0]

        self.predict = self.model.signatures[model_signature]

    def _preprocess(self, data):
        # http 两种请求形式
        # form-data 文件格式的请求对应 data = {"请求key值":{"文件名":<文件io>}}
        # json格式对应 data = json.loads("接口传入的json体")

        preprocessed_data = {}
        for k, v in data.items():
            images = []
            for file_name, file_content in v.items():
                with Image.open(file_content) as image1:
                    image1 = image1.convert("RGB")
                    image1 = np.array(image1, dtype=np.float32)
                    image1 = image1[:, :, :]
                    images.append(image1)

            preprocessed_data = tf.convert_to_tensor(np.array(images))

        return preprocessed_data

    def _inference(self, data):

        return self.predict(data)

    def _postprocess(self, data):
        return data

    def ping(self):
        pass

    def signature(self):
        pass
