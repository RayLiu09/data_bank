import uuid
import logging

import attr
from attr import validators

from modelarts.workflow.util.utils import (
    to_int,
    get_random_name,
)
from modelarts.workflow.core.serialize import (
    serialize,
    prepare_for_properties,
    ref
)
from modelarts.workflow.core.data import (
    AbstractData,
    AbstractDataConsumption,
    AbstractOutputConfig
)
from modelarts.workflow.core.steps import (
    Step,
    StepTypeEnum,
    StepState,
    AbstractOutput,
)
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.placeholder import Placeholder, PlaceholderType, SERVICE_SCHEDULE_FORMAT
from modelarts.workflow.steps.common_input import CommonInput
from modelarts.workflow.steps.step_state_mapping import StepStateMapping
from modelarts.workflow.client.model_predictor_client import ModelPredictorClient
from modelarts.workflow.client.service_app_client import ServiceAPPClient
from modelarts.workflow.data.dataset import (
    ServiceInputPlaceholder,
    ServiceRunCfgDict,
    ServiceRunCfg,
    ServiceData,
    ServiceUpdatePlaceholder,
    SERVICE_DATA_TYPE
)
from modelarts.workflow.constant import MODEL_WEIGHT_SUM

SERVICE_STATE_MAPPING = {
    "deploying": StepState.Running,
    "running": StepState.Completed,
    "stopped": StepState.Stopped,
    "finished": StepState.Completed,
    "concerning": StepState.Failed,
    "failed": StepState.Failed,
}
SCHEDULE_VALUE = "stop"
SCHEDULE_TIME_UNIT = ("DAYS", "HOURS", "MINUTES")
INFER_TYPE = ("real-time", "batch", "edge")
STR_OR_PARAMETER = (str, Placeholder)
LIST_OR_PARAMETER = (list, Placeholder)
TYPE_OF_ENVS = (dict, Placeholder, type(None))
TYPE_OF_SCHEDULE = (list, Placeholder, type(None))


def _verify_infer_type(instance, attribute, value):
    if not isinstance(value, STR_OR_PARAMETER):
        raise TypeError("Type(infer_type) must be one of the {}. But  provided: {}.".format(
            STR_OR_PARAMETER, type(value)))
    if isinstance(value, str) and value not in INFER_TYPE:
        raise ValueError("Infer type only supports one of the values:  {}. But provided: "
                         "{}.".format(INFER_TYPE, value))


@serialize
@attr.s
class Schedule:
    """
    Schedule of Deploy service configuration

    Attributes:
        type (str): the schedule type, currently only supports the value: "stop"
        time_unit (str): the schedule time unit is {value}. Currently only
        supports the values: "DAYS", "HOURS", "MINUTES"
        duration (int): the value corresponding to the time unit
    """
    type = attr.ib(default="stop")
    time_unit = attr.ib(default="HOURS")
    duration = attr.ib(default=1, converter=to_int)


@serialize
@attr.s
class ServiceConfig(AbstractOutputConfig):
    """
    Deploy service configuration

    Attributes:
        infer_type (str, Placeholder): the infer type, the value is one of real-time/batch/edge
        service_name (str, Placeholder): name of service
        config (list, Placeholder): the model run configuration
        description (int): the description of the service
        vpc_id (str): the ID of the virtual private cloud deployed by the online service instance is empty by default
        subnet_network_id (str): the network ID of the subnet, which is empty by default
        security_group_id (str): security group, empty by default, this parameter is required when vpc_id is configured
        cluster_id (str): the dedicated cluster ID, which is empty by default, does not use the dedicated cluster
        schedule (list): service scheduling configuration, only online services can be configured, not used by default,
        the service runs for a long time
        additional_properties (dict): additional attributes of service level to facilitate service management
        apps (str, Placeholder, list): service support certified APP list

    """
    infer_type = attr.ib(default="real-time", validator=_verify_infer_type)
    service_name = attr.ib(default=None, validator=validators.instance_of((type(None), str, Placeholder)))
    description = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    vpc_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    subnet_network_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    security_group_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    cluster_id = attr.ib(default=None, validator=validators.instance_of((str, type(None))))
    schedule = attr.ib(default=None, validator=validators.instance_of((type(None), Placeholder)))
    additional_properties = attr.ib(default=None, validator=validators.instance_of((dict, type(None))))
    apps = attr.ib(default=None, validator=validators.instance_of((str, Placeholder, list, type(None))))
    envs = attr.ib(default=None, validator=validators.instance_of((dict, type(None))))
    _service = attr.ib(default=None, validator=validators.instance_of((ServiceData, type(None))))

    def __attrs_post_init__(self):
        if self.apps and not isinstance(self.apps, list):
            self.apps = [self.apps]
        if isinstance(self.schedule, Placeholder):
            self.schedule.format = SERVICE_SCHEDULE_FORMAT
        if not self.schedule:
            self.schedule = Placeholder(
                name=get_random_name(prefix="schedule_"),
                placeholder_type=PlaceholderType.INT,
                placeholder_format=SERVICE_SCHEDULE_FORMAT,
                delay=True,
                description="Set how long the deployed service will stop in hours, "
                            "where -1 means the service will always run")

    def _set_service(self, service):
        self._service = service

    def _set_schedule_name(self, name):
        self.schedule.name = name

    @property
    def service(self):
        return self._service

    def data_consumption(self, step_name, output_name):
        return _ServiceConsumption(self, step_name, output_name)


@serialize
@attr.s
class ModelAdditionalProperties:
    """
    Attributes:
        log_volume (Union[list]): host log directory mounting
        max_surge (Union[int, float, Placeholder]):
            when it is less than 1, it represents the percentage of the number of instances added during rolling upgrade;
            when it is greater than 1, it represents the maximum number of instances that can be expanded during rolling upgrade.
        max_unavailable (Union[int, float, Placeholder]):
            when it is less than 1, it represents the percentage of the number of instances that are allowed to be scaled down during rolling upgrade;
            when it is greater than 1, it represents the number of instances that is allowed to be scaled down during rolling upgrade.
        termination_grace_period_seconds (Union[int, Placeholder]): container graceful stop time
        persistent_volumes (Union[list]): persistent storage mount configuration
    """
    log_volume = attr.ib(default=None, validator=validators.instance_of((list, type(None))))
    max_surge = attr.ib(default=None, validator=validators.instance_of((int, float, Placeholder, type(None))))
    max_unavailable = attr.ib(default=None, validator=validators.instance_of((int, float, Placeholder, type(None))))
    termination_grace_period_seconds = attr.ib(default=None, validator=validators.instance_of((int, Placeholder, type(None))))
    persistent_volumes = attr.ib(default=None, validator=validators.instance_of((list, type(None))))


@ref
@serialize
@attr.s
class ServiceInputConfig:
    """
    Attributes:
        deploy_timeout_in_seconds (Union[int, Placeholder]): service deploy timeout
        additional_properties (Union[dict, ModelAdditionalProperties]): model additional properties
    """
    deploy_timeout_in_seconds = attr.ib(default=None, validator=validators.instance_of((int, Placeholder, type(None))))
    additional_properties = attr.ib(default=None, validator=validators.instance_of((dict, ModelAdditionalProperties, type(None))))


class _ServiceConsumption(AbstractDataConsumption):

    def __init__(self, config: ServiceConfig, step_name, output_name):
        super(_ServiceConsumption, self).__init__(config, step_name, output_name)

    def consume(self) -> AbstractData:
        return self.config.service

    def type(self):
        return SERVICE_DATA_TYPE


class ServiceInput(CommonInput):

    def __init__(self, name, data, input_config=None):
        """
        Args:
            name (str): the name of the ServiceInput
            data (ServiceInputPlaceholder, ServiceData, ServiceUpdatePlaceholder):
                        the data of ServiceInput currently only supports
            input_config (ServiceInputConfig): service input config
            ServiceInputPlaceholder and ServiceData types
        """
        self._check_input_data(data=data)
        super(ServiceInput, self).__init__(name, data)
        self._declared_data = data
        self._actual_data = None
        self.config = input_config

    def to_definition_json(self):
        result = super(ServiceInput, self).to_definition_json()
        if self.config:
            result["config"] = self.config.ref()
        return result

    def to_request(self):
        """
        Returns (dict) for constructing request body
        """
        if isinstance(self.data, ServiceRunCfgDict):
            config_list = []
            for value in self.data.values():
                if isinstance(value, ServiceRunCfg):
                    config_list.append(value.to_request())
                else:
                    raise ValueError("If the type of data of ServiceInput is ServiceRunCfgDict, the "
                                     "value of data must be ServiceRunCfg type and can not be empty")
            return {"config": config_list}
        if isinstance(self.data, ServiceData):
            if self.data.id and isinstance(self.data.id, str):
                return {"service_id": self.data.id}
            raise ValueError("If the type of data of ServiceInput is ServiceData, the id of data "
                             "must be str type and can not be empty")
        raise TypeError("The data must be type of ServiceRunCfgDict or ServiceData, but got "
                        "{}".format(type(self.data)))

    @staticmethod
    def _check_input_data(data):
        data_type_tuple = (ServiceInputPlaceholder, ServiceData, ServiceUpdatePlaceholder)
        if not isinstance(data, data_type_tuple):
            raise TypeError('The data type of ServiceInput must be one of the {}. But provided: {}'.format(
                data_type_tuple, type(data)))


class ServiceOutput(AbstractOutput):
    def __init__(self, name=None, service_config=None):
        """
        Args:
            name (str): the name of the ServiceOutput
            service_config (ServiceConfig): Service configuration, defining the service descriptions, etc.
        """
        super(ServiceOutput, self).__init__(name)
        self.name = name
        self.config = service_config or ServiceConfig()
        self._check_output_config(config=self.config)

    def as_input(self):
        return self.config.data_consumption(self.step_name, self.name)

    def to_request(self):
        """
        Returns (dict) for constructing request body
        """
        request = self.config.serialize()
        return self._process_config_schedule(request=request)

    def _process_config_schedule(self, request):
        if not request or request.get("schedule") is None:
            raise ValueError("request is empty or has no schedule field")
        if self.config.schedule.value == -1:
            del request["schedule"]
        elif self.config.schedule.value > 0:
            request["schedule"] = [{
                "type": "stop",
                "time_unit": "HOURS",
                "duration": self.config.schedule.value
            }]
        else:
            raise ValueError("The value of parameter {} is only allowed to be greater than 0 or equal to -1".format(
                self.config.schedule.name))
        return request

    def set_data_to_config(self, service):
        self.config._set_service(service)

    def to_definition_json(self) -> TransformType:
        return {
            "name": self.name,
            "type": "service"
        }

    @staticmethod
    def _check_output_config(config):
        if not isinstance(config, ServiceConfig):
            raise TypeError("The service_config type of ServiceOutput must be ServiceConfig. But provided: {}".format(
                type(config)))

    def set_to_skip(self):
        self.config.is_skipped = True


def _set_dedicated_resource_pool_param(request_body):
    if request_body.get("cluster_id"):
        return
    config_list = request_body.get("config")
    if not config_list:
        return
    for service_run_cfg in config_list:
        cluster_id = service_run_cfg.get("cluster_id")
        if cluster_id:
            request_body["cluster_id"] = cluster_id
            return


def _set_dedicated_os_pool_param(request_body):
    if request_body.get("pool_name"):
        return
    config_list = request_body.get("config")
    if not config_list:
        return
    for service_run_cfg in config_list:
        pool_name = service_run_cfg.get("pool_name")
        if pool_name:
            request_body["pool_name"] = pool_name
            return


def _set_spec_pool_param(request_body):
    _set_dedicated_os_pool_param(request_body)
    _set_dedicated_resource_pool_param(request_body)
    if request_body.get("pool_name") and request_body.get("cluster_id"):
        raise ValueError("pool_name and cluster_id can not set at the same time for service request body")


def _add_envs_to_model_list(request_body):
    envs = request_body.get("envs")
    if not envs:
        return
    config_list = request_body.get("config", [])
    for config in config_list:
        if config.get("envs"):
            config.get("envs").update(envs)
        else:
            config["envs"] = envs
    request_body.pop("envs", None)


class ServiceStep(Step):
    """Service step for workflow."""

    def __init__(
            self,
            name,
            inputs,
            outputs,
            title=None,
            description=None,
            policy=None,
            depend_steps=None
    ):
        """
            Constructs a ServiceStep to deploy or update service
        Args:
            name (str): The name of the service step.
            inputs (Union(ServiceInput, List[ServiceInput])): A or a list of `ServiceInput` instance. The number of
            elements of the service step's inputs is at most two.
            outputs (Union(ServiceOutput, List[ServiceOutput])): A or a list of `ServiceOutput` instance. The outputs
            of ServiceStep can only be a single output.
            title (str): The title message of ServiceStep.
            description (str): Description info of ServiceStep
            policy (StepPolicy): Step execution policy
            depend_steps (Union(Step, List[Step])): A or a list of step which this `ServiceStep` depends on.
        """

        if outputs and not isinstance(outputs, list):
            outputs = [outputs]
        super(ServiceStep, self).__init__(
            name=name,
            step_type=StepTypeEnum.SERVICE,
            title=title,
            description=description,
            inputs=inputs,
            outputs=outputs,
            properties=prepare_for_properties(outputs[0].config),
            policy=policy,
            depend_steps=depend_steps
        )
        self._check_init()
        self._service_id = None
        self._app_client = None

    def build_client(self, session):
        super(ServiceStep, self).build_client(session)
        self.client = ModelPredictorClient(session)
        self._app_client = ServiceAPPClient(session)

    def create_instance(self):
        self._service_id = self._get_service_id()
        request_body = self._to_request()
        apps = request_body.pop("apps", None)
        # Deploy service
        if not self._service_id:
            self._service_id = self._deploy_service(request_body)
            logging.info(
                "step(%s) successfully creates an instance. instance id: %s, service name: %s", self.name,
                self._service_id, request_body.get("service_name"))
        # Update service
        else:
            self._update_service(request_body)
        # authorize apps
        if apps:
            logging.info("Service %s authorize to apps %s", self._service_id, apps)
            self._authorize_to_app(service_id=self._service_id, apps=apps)
        return True, self._service_id

    def update_instance_state(self):
        if self.instance_id is None:
            raise ValueError("No instance of ServiceStep {}".format(self.name))
        self._check_client()
        logging.debug("The ServiceStep %s is updating the state, and current state is %s", self.name, self.state)
        service_state = self.client.get_service_state(self.instance_id)
        step_state = StepStateMapping.get_step_state(str(service_state), SERVICE_STATE_MAPPING)
        self.set_state(step_state)
        if step_state == StepState.Completed:
            self._set_data_to_output()
            self._set_variables_to_output()

    def stop_instance(self) -> (bool, str):
        if self.instance_id is None:
            raise ValueError("No instance of ServiceStep {}".format(self.name))
        self._check_client()
        if self.state not in (
                StepState.Creating, StepState.Pending, StepState.Running, StepState.Completed):
            raise TypeError('can not stop the state {}'.format(self.state))
        self.client.update_service(self.instance_id, {"status": "stopped"})
        return True, "success"

    def _authorize_to_app(self, service_id, apps):
        if not isinstance(apps, list):
            apps = [apps]
        api_id = self._app_client.get_api_id(service_id=service_id)
        if not api_id:
            # register the api and authorize the app
            return self._app_client.register_api_and_authorize_to_app(service_id=service_id, apps=apps)
        # update authorize app
        return self._app_client.update_authorize_app(service_id=service_id, api_id=api_id, apps=apps)

    def _deploy_service(self, request_body):
        self._check_client()
        logging.debug("The ServiceStep %s is deploying service with request body: %s", self.name, request_body)
        service_id = self.client.deploy_service(request_body)
        return service_id

    def _update_service(self, request_body):
        self._check_client()
        logging.debug("The ServiceStep %s is updating service configuration with request body: %s", self.name,
                      request_body)
        self._check_config(request_body)
        self.client.update_service(self._service_id, request_body)

    def _check_config(self, request_body):
        self._check_client()
        service_info = self.client.get_service_info(self._service_id)
        service_state = self.client.get_service_state(self._service_id)
        if not service_info:
            raise ValueError("the service info of service_id: {} is null".format(self._service_id))
        config_list = request_body.get("config")
        raw_config_list = service_info.get("config")
        config_dict = {}
        raw_config_dict = {}
        matching_config_list = ["model_name", "model_version", "weight", "specification", "cluster_id", "custom_spec",
                                "pool_name", "instance_count", "envs"]
        for cfg in config_list:
            name = "{}_{}".format(cfg.get("model_name"), cfg.get("model_version"))
            config_dict[name] = {}
            for k, v in cfg.items():
                if k in matching_config_list and v:
                    config_dict[name][k] = v
        for cfg in raw_config_list:
            name = "{}_{}".format(cfg.get("model_name"), cfg.get("model_version"))
            raw_config_dict[name] = {}
            for k, v in cfg.items():
                if k in matching_config_list and v:
                    raw_config_dict[name][k] = v

        if raw_config_dict == config_dict:
            logging.info(
                "step(%s) [Note]: The status of service(id:%s) is %s. Since the service configuration to be set is the "
                "same as the original service configuration(%s), the service status(%s) will not change. Please enter "
                "new content of ServiceInputPlaceholder the next time you run.", self.name, self._service_id,
                service_state, config_list, service_state)

    def _to_request(self):
        request_body = self.__generate_raw_request_body()
        _set_spec_pool_param(request_body)
        # Deploy service
        if not self._service_id:
            self._set_default_parameters(request_body)
            request_body.pop("status", None)
        # Update service
        else:
            for key in ["infer_type", "workspace_id", "vpc_id", "subnet_network_id", "security_group_id",
                        "service_name"]:
                request_body.pop(key, None)
        return request_body

    def _set_data_to_output(self):
        if self.instance_id is None:
            raise ValueError("No instance of ServiceStep {}".format(self.name))
        service = ServiceData(service_id=self.instance_id)
        output = list(self.outputs.values())[0]
        output.set_data_to_config(service)

    def _set_variables_to_output(self):
        if self.instance_id is None:
            raise ValueError("No instance of ServiceStep {}".format(self.name))
        output = list(self.outputs.values())[0]
        output.variables = self.client.get_service_access_addresses(self.instance_id)

    def _get_service_id(self):
        service_id = None
        for service_input in self.inputs.values():
            if isinstance(service_input.data, ServiceData):
                service_id = service_input.data.service_id
        return service_id

    def _check_init(self):
        self._verify_inputs()
        self._verify_outputs()

    def _verify_inputs(self):
        if len(self.inputs) < 1:
            raise ValueError("len(inputs) must be greater than or equal to one")
        for value in self.inputs.values():
            if not isinstance(value, ServiceInput):
                raise TypeError("The type of ServiceStep input must be ServiceInput")
        if len(self.inputs) == 1 and not isinstance(list(self.inputs.values())[0]._declared_data,
                                                    ServiceInputPlaceholder):
            raise ValueError("the date of inputs of ServiceStep must include ServiceInputPlaceholder")
        if len(self.inputs) == 2 \
                and (all(isinstance(service_input._declared_data, ServiceInputPlaceholder)
                         for service_input in self.inputs.values())
                     or all(isinstance(service_input._declared_data, ServiceData)
                            for service_input in self.inputs.values())):
            raise ValueError("When len(inputs) is equal to two, the date of inputs of ServiceStep must include "
                             "ServiceInputPlaceholder and ServiceData")
        if len(self.inputs) > 2:
            raise ValueError("Maximum of two inputs allowed")

    def _verify_outputs(self):
        if len(self.outputs) != 1:
            raise ValueError("len(outputs) must be equal to one")
        for value in self.outputs.values():
            if not isinstance(value, ServiceOutput):
                raise TypeError("The type of ServiceStep output must be ServiceOutput")

    def __generate_raw_request_body(self):
        service_output = list(self.outputs.values())[0]
        request_body = service_output.to_request()
        for service_input in self.inputs.values():
            if isinstance(service_input.data, ServiceRunCfgDict):
                request_body.update(service_input.to_request())
                _add_envs_to_model_list(request_body)
        self._verify_grayscale_release(request_body)
        return request_body

    def _verify_grayscale_release(self, request_body):
        self._verify_model_name_version(request_body)
        self._verify_weights(request_body)

    def _verify_model_name_version(self, request_body):
        self._check_client()
        config_list = request_body.get("config")
        if not config_list:
            return
        model_name_set = set()
        for service_run_cfg in config_list:
            if not service_run_cfg.get("model_id"):
                model_id = self.client.get_model_id(service_run_cfg.get("model_name"),
                                                    service_run_cfg.get("model_version"))
                service_run_cfg["model_id"] = model_id

            model_name_set.add(service_run_cfg.get("model_name"))
        if len(model_name_set) != 1:
            raise ValueError("All model ids must have the same model name. But got {} model "
                             "names: {}".format(len(model_name_set), model_name_set))

    @staticmethod
    def _set_default_parameters(request_dict):
        if not request_dict.get("service_name"):
            request_dict["service_name"] = 'service-' + uuid.uuid4().hex

    @staticmethod
    def _verify_weights(request_body, expected_sum=MODEL_WEIGHT_SUM):
        actual_sum = 0
        config_list = request_body.get("config")
        for config in config_list:
            actual_sum += config.get("weight")
        if actual_sum != expected_sum:
            raise ValueError("The sum of the weights must be equal to {}.".format(expected_sum))

    def _check_client(self):
        if self.client is None:
            raise ValueError("The client of ServiceStep {} is None, "
                             "please use the <build_client> method to initialize the client".format(self.name))
