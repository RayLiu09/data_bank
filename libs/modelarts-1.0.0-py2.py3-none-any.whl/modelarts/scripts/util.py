from modelarts.session import Session


def get_session(train_args):
    """
    :param train_args: it contains the parameters of user input
    :return: modelarts session
    """
    if train_args.is_roma:
        return Session(region_name=train_args.region_name,
                       w3_account=train_args.w3_account,
                       app_id=train_args.app_id,
                       app_token=train_args.app_token)
    else:
        return Session(region_name=train_args.region_name,
                       access_key=train_args.access_key,
                       secret_key=train_args.secret_key)
