import uuid

from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.data import AbstractData
from modelarts.workflow.client.gallery_client import GalleryClient

MODEL_DATA_TYPE = "model"
GALLERY_MODEL_DATA_TYPE = "gallery_model"


class ModelData(AbstractData):
    def __init__(self, name, model_id):
        """
        Args:
            name (str): data name
            model_id (str): model id
        """
        super(ModelData, self).__init__(name)
        self.model_id = model_id

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "model",
            "value": {
                "model_id": self.model_id
            }
        }
        return result

    def get_snapshot(self) -> TransformType:
        """
        get snapshot of model data
        Returns (TransformType): snapshot of model data

        """
        return {
            "name": self.name,
            "model_id": self.model_id
        }

    def type(self):
        return MODEL_DATA_TYPE


class GalleryModel(AbstractData):
    def __init__(self, subscription_id, version_num):
        """
        Subscription model from gallery
        Args:
            subscription_id (str): model subscription ID
            version_num (str): model version num, such as '1.0.0'
        """
        super(GalleryModel, self).__init__(uuid.uuid4().hex)
        self.subscription_id = subscription_id
        self.version_num = version_num
        self._content_id = ""

    @property
    def content_id(self):
        return self._content_id

    @content_id.setter
    def content_id(self, content_id):
        self._content_id = content_id

    def fill_content_id(self, gallery_client):
        if not isinstance(gallery_client, GalleryClient):
            raise TypeError('The type must be GalleryClient. But provided: {}'.format(type(gallery_client)))
        if not self.content_id:
            self.content_id = gallery_client.get_content_id(self.subscription_id)

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": "model",
            "content_id": self.content_id,
            "version_name": self.version_num
        }
        return result

    def get_snapshot(self) -> TransformType:
        """
        get snapshot of gallery model data
        Returns (TransformType): snapshot of gallery model data

        """
        return {
            "subscription_id": self.subscription_id,
            "version_name": self.version_num
        }

    def type(self):
        return GALLERY_MODEL_DATA_TYPE

    def ref(self):
        return "$ref/assets/{}".format(self.name)

    def is_need_consume(self):
        return True
