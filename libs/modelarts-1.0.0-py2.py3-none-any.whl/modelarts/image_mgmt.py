"""
Description: Image management, including build image
Author: ModelArts SDK Team
"""
import abc
import logging
import os
import shutil
import subprocess
import time
from json import JSONEncoder

from .util.process_utils import ProgressDisplay
from .util.docker_util import DockerCli
from . import constant
from .config.auth import auth_by_apig, auth_by_roma_api
from .util import notebook_util
from .images.image_def import ImageType, ImageQueryParams
from .images.image_factory import NotebookImageFactory
from .images.image_display import DisplayFactory
from .images.image_api import get_image_api_instance
from modelarts.util.config import Config

root_logger = logging.getLogger()
for h in root_logger.handlers:
    root_logger.removeHandler(h)
logging.basicConfig(level=logging.INFO, format='')
IS_ROMA = "IS_ROMA"
IMAGE_SAVE_QUERY_INTERVAL = 5
IMAGE_SAVE_MAX_WAIT_TIMES = 240
SSH_AUTH_FILE = os.path.expanduser('~') + "/.ssh/authorized_keys"
SSH_PUB_FILE = os.path.expanduser('~') + "/.ssh/id_rsa.pub"
IMAGE_STATUS_ACTIVE = "ACTIVE"


class ImageSave(object):
    """
    This class is used to save a container as an image.
    """

    def __init__(self, session, name, tag, organization=None, description=""):
        """
        Initialize an instance.
        :param description: description of new image
        :param name: new image name
        :param organization: organization of image in swr path
        :param tag: tag of new image
        """
        self.__session = session
        if session.auth == constant.ROMA_AUTH:
            if organization:
                raise ValueError("Parameter organization is not supported in roma.")
            self.instance = ImageSaveRomaImpl(session, name, tag, description)
        else:
            self.instance = ImageSaveAKSKImpl(session, name, tag, organization, description)

    def save(self):
        """
        Save notebook as an image.
        """
        self.__check_cur_environment()
        self.gen_ssh_secret()
        # may take a long time
        self.instance.save()
        logging.info("Starting save notebook as a new image. It will take a few "
                     "minutes, during which current notebook is frozen.")
        self.wait_for_image_save()

    def wait_for_image_save(self):
        """
        Wait for image save job finish
        """
        self.instance.wait_for_image_save()

    @staticmethod
    def gen_ssh_secret():
        """
        Generate SSH public and private keys
        """
        # if file exists, do not need to generate ssh keys
        if os.path.exists(SSH_AUTH_FILE) and os.path.getsize(SSH_AUTH_FILE):
            return
        command = 'ssh-keygen -t rsa -P "" -f ~/.ssh/id_rsa'
        try:
            subprocess.run(command, check=True, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        except subprocess.CalledProcessError as err:
            raise Exception("error happens when generate ssh keys, error={}".format(err))
        # copy public key
        os.mknod(SSH_AUTH_FILE)
        shutil.copyfile(SSH_PUB_FILE, SSH_AUTH_FILE)

    def __check_cur_environment(self):
        """
        Check if the current notebook or devcontainer can be saved as a new image.
        """
        if not self.__session._is_notebook_environ():
            raise Exception("Only in notebook or devcontainer it can be saved as a new image.")
        if notebook_util.is_mul_kernel_image():
            raise Exception("CodeLab using multi-kernel image does not support saving container as a new image.")
        if notebook_util.is_kernel_gateway():
            raise Exception("CodeLab after switching flavor does not support saving container as a new image. "
                            "Please switch to the original flavor.")


class ImageSaveBase(metaclass=abc.ABCMeta):
    """Abstract class which aims to define the function to save the image.
    """

    @abc.abstractmethod
    def save(self):
        """
        Save notebook as an new image.
        """
        pass

    @abc.abstractmethod
    def wait_for_image_save(self):
        """
        Wait for image save job finish
        """


class ImageSaveAKSKImpl(ImageSaveBase):
    """
    This class is used to save a container as an image in hwc.
    """

    def __init__(self, session, name, tag, organization=None, description=""):
        """
        Initialize an instance.
        :param description: description of new image
        :param name: new image name
        :param organization: organization of image in swr path
        :param tag: tag of new image
        """
        super(ImageSaveAKSKImpl, self).__init__()
        self.__name = name
        if organization:
            self.__organization = organization
        else:
            raise ValueError("Parameter organization is needed for hc.")
        self.__tag = tag
        self.__description = description
        self.__session = session
        self.__image_id = None

    def save(self):
        """
        Save notebook as an image in hwc.
        """
        notebook_id = notebook_util.get_notebook_id()
        request_url = "/v1/{project_id}/notebooks/{id}/create-image".format(
            project_id=self.__session.project_id, id=notebook_id)
        body = {
            "name": self.__name,
            "namespace": self.__organization,
            "tag": self.__tag,
            "pause": True,
            "description": self.__description
        }
        body_encode = JSONEncoder().encode(body)
        resp = auth_by_apig(self.__session, constant.HTTPS_POST, request_url, body=body_encode)
        self.__image_id = resp["id"]

    def wait_for_image_save(self):
        """
        Wait for image save job finish
        """
        request_url = "/v1/{}/images/{}".format(self.__session.project_id, self.__image_id)
        count = 0
        while True:
            response = auth_by_apig(self.__session, constant.HTTPS_GET, request_url)
            if response["status"].upper() == IMAGE_STATUS_ACTIVE:
                logging.info("Save image %s successfully.", self.__name)
                break
            if count >= IMAGE_SAVE_MAX_WAIT_TIMES:
                error_info = "It takes too long to save this notebook."
                raise Exception(error_info + " Please try again.")
            count = count + 1
            time.sleep(IMAGE_SAVE_QUERY_INTERVAL)


class ImageSaveRomaImpl(ImageSaveBase):
    """
    This class is used to save a container as an image in roma.
    """

    def __init__(self, session, name, tag, description=""):
        """
        Initialize an instance.
        :param description: description of new image
        :param name: new image name
        :param tag: tag of new image
        """
        super(ImageSaveRomaImpl, self).__init__()
        self.__name = name
        self.__tag = tag
        self.__description = description
        self.__session = session
        self.__image_version_id = None
        self.__session.headers["csb-token"] = self.__session.headers["App-Token"]
        self.roma_host = Config.getenv("ROMA_OBS_BUCKET_HOST", default=None)
        if self.roma_host is None:
            raise ValueError("ROMA image save does not supported.")

    def save(self):
        """
        Save notebook as an image in roma.
        """
        instance_id = self.get_roma_instance_id_by_instance_id()
        request_url = "{host}saas/ei/eiwizard/" \
                      "demanager/build-image?id={id}".format(host=self.roma_host, id=instance_id)
        body = {
            "imageName": self.__name,
            "tag": self.__tag,
            "description": self.__description
        }
        body_encode = JSONEncoder().encode(body)
        resp = auth_by_roma_api(session=self.__session,
                                request_url=request_url,
                                request_type=constant.HTTPS_POST,
                                intf_action="save notebook as an image",
                                data=body_encode)
        if resp["success"]:
            self.__image_version_id = resp["result"]
        else:
            raise Exception(resp["msg"])

    def get_roma_instance_id_by_instance_id(self):
        """
        Get instance id in roma by original instance id.
        :return instance id in roma
        """
        notebook_id = notebook_util.get_notebook_id()
        request_url = "{host}saas/ei/eiwizard/" \
                      "demanager/notebook/byinstance".format(host=self.roma_host)
        params = {
            "appid": self.__session.headers["App-ID"],
            "instance_id": notebook_id
        }
        response = auth_by_roma_api(session=self.__session,
                                    request_url=request_url,
                                    request_type=constant.HTTPS_GET,
                                    intf_action="get instance id",
                                    params=params)
        if response["success"]:
            return response["result"]["id"]
        else:
            raise Exception("Cannot get instance id in roma correctly.")

    def get_image_id_by_name(self):
        """
        Get image id according to image name
        :return: image id
        """
        image_list = self.get_exist_custom_images()
        for image in image_list:
            if image["imageName"] == self.__name:
                return image["id"]
        return None

    def get_exist_custom_images(self):
        """
        Get existing custom images.
        :return:
        """
        request_url = "{host}eiwizard/list/swr/image".format(host=self.roma_host)
        params = {
            "appid": self.__session.headers["App-ID"]
        }
        response = auth_by_roma_api(session=self.__session,
                                    request_url=request_url,
                                    request_type=constant.HTTPS_GET,
                                    intf_action="get images",
                                    params=params)

        if response["success"]:
            return response["imageList"]
        else:
            raise Exception("error happens when query custom images, "
                            "error = {}".format(response["msg"]))

    def wait_for_image_save(self):
        """
        Wait for image save job finish
        """
        request_url = "{host}eiwizard/list/swr/image/version/info".format(host=self.roma_host)
        params = {
            "id": self.__image_version_id
        }
        count = 0
        while True:
            response = auth_by_roma_api(session=self.__session,
                                        request_url=request_url,
                                        request_type=constant.HTTPS_GET,
                                        intf_action="get image info",
                                        params=params)
            if not response["success"]:
                raise Exception("error happens when query image info of {}, "
                                "error = {}".format(self.__name, response["msg"]))
            if response["result"]["status"] == IMAGE_STATUS_ACTIVE:
                logging.info("Save image %s successfully.", self.__name)
                break
            if count >= IMAGE_SAVE_MAX_WAIT_TIMES:
                error_info = "It takes too long to save this notebook."
                raise Exception(error_info + " Please try again.")
            count = count + 1
            time.sleep(IMAGE_SAVE_QUERY_INTERVAL)


class ImageManagement(object):
    """
    Manage the images of user.
    """

    IMPORTANT_MSG_LOG_FORMAT = "\033[1;31;40m{}\033[0m"
    SHORT_CONTAINER_ID_LENGTH = 12

    @staticmethod
    def register(session, image):
        """
        :param session: an object including the authentication information
        :param image: an instance of class Image, containing the information which will be registered
        """
        image_api = get_image_api_instance(session)
        return image_api.register_image(image)

    @staticmethod
    def get_image_by_name(session, name, output_format=None):
        """
        Get images according to the image name.
        :param session: an object including the authentication information
        :param name: the image name you want to query
        :param output_format: output format of querying images result
        :return: a list containing the all the images
        """
        query_params = {"name": name}
        return ImageManagement.get_image(session, query_params, output_format)

    @staticmethod
    def get_image_by_type(session, image_type=ImageType.ALL.value, output_format=None):
        """
        Get images according to the image name.
        :param session: an object including the authentication information
        :param image_type: ImageType.BUILD_IN.value: the common images provided notebook team, every user can use it
                           ImageType.DEDICATED.value: user private image, other user cannot use it
                           ImageType.ALL.value: include 'BUILD_IN' and 'DEDICATED'
        :param output_format: output format of querying images result
        :return: a list containing the all the images
        """
        if image_type == ImageType.ALL.value:
            return ImageManagement.get_image(session, output_format=output_format)
        query_params = {"type": image_type}
        return ImageManagement.get_image(session, query_params, output_format)

    @classmethod
    def get_image(cls, session, param=None, output_format=None):
        """
        Get images according to the param.
        :param session: an object including the authentication information
        :param param: a dictionary including the query parameters like name, type or arch, etc
        :param output_format: output format of querying images result
        :return: a list containing the all the images
        """
        cls._check_list_param(param)
        image_api = get_image_api_instance(session)
        image_list = image_api.get_image(param)["data"]
        if output_format is None:
            return image_list
        displayer = DisplayFactory.get_display_instance(output_format)
        displayer.display(image_list)
        return image_list

    @classmethod
    def get_image_by_id(cls, session, image_id=None):
        """
        Get images according to the param.
        :param session: an object including the authentication information
        :param image_id: image id
        :return: a dict contains image details
        """
        image_api = get_image_api_instance(session)
        return image_api.get_image_by_id(image_id)

    @staticmethod
    def _check_list_param(param: dict):
        if param is None:
            return
        for key in list(param.keys()):
            if param[key] is None:
                del param[key]
            if key not in ImageQueryParams.list():
                raise ValueError(f"the parameter {key} is not supported")
        # Authoring-service will not accept value 'all' for image type and not specifying image type means 'all'
        image_type = param.get(ImageQueryParams.TYPE.value)
        if image_type is not None and image_type == ImageType.ALL.value:
            del param[ImageQueryParams.TYPE.value]

    @staticmethod
    def unregister(session, image_id, delete_swr_image=False):
        """
        Delete the image from database. If delete_swr_image is true, delete the image from swr at same time.
        :param session: an object including the authentication information.
        :param image_id: the image id which will be deleted.
        :param delete_swr_image: If this parameter is true, delete the image from swr at same time.
        """
        if not isinstance(image_id, str):
            raise TypeError("Parameter image_id should be a string.")
        image_api = get_image_api_instance(session)
        image_api.unregister_image(image_id, delete_swr_image)

    @classmethod
    def debug(cls, image, region_name="", **kwargs):
        """
        This function can be used in vm where docker is available. We will create a container using the image to test
        whether this image is available.
        :param image: An instance of class 'Image' which includes all the necessary information to describe image.
        :param region_name: Region name like 'cn-north-4' or 'cn-north-7'
        """
        cls._clear_previous_container(image)
        images_list = DockerCli.images(options=["-q"], swr_path=image.swr_path)
        if len(images_list) < 1:
            raise Exception("Cannot find your image {}. Please pull it into this machine.".format(image.swr_path))
        if not region_name:
            region_name = ImageManagement._get_region_name(image.swr_path)
        ImageManagement._check_user_image(image)
        image_debugger = ImageManagement._get_image_debugger(image)
        container_id = image_debugger.debug(region_name, **kwargs)
        container_id = container_id[0:cls.SHORT_CONTAINER_ID_LENGTH]
        logging.info("A new container '%s' has been started from your image. "
                     "Please use the following document to explore it.\n", container_id)
        logging.info("COMMANDS")
        log_info = ImageManagement.IMPORTANT_MSG_LOG_FORMAT.format(f"\tdocker logs {container_id}")
        logging.info(log_info)
        logging.info("\tCheck logs of this container\n")
        log_info = ImageManagement.IMPORTANT_MSG_LOG_FORMAT.format(f"\tdocker exec -it {container_id} bash")
        logging.info(log_info)
        logging.info("\tEnter the container to debug further")
        logging.info("FAQ")
        logging.info("\tFor more information about how to operate docker container, please refer to "
                     "docker offical document https://docs.docker.com/engine/reference/commandline/cli/")

    @staticmethod
    def _get_image_debugger(image):
        # For now, we only support debugging notebook images.
        # Later, training images and infer images my be supported too.
        return NotebookImageFactory().create_image_debugger(image)

    @staticmethod
    def _check_user_image(image):
        machine = os.uname().machine
        if image.arch.upper() != machine.upper():
            raise ValueError("The arch {} of your image is not same with your current machine({}), please check it".
                             format(image.arch, machine))

    @staticmethod
    def _get_region_name(swr_path=""):
        swr_domain = swr_path.split("/")[0]
        return swr_domain.split(".")[1]

    @staticmethod
    def _check_docker_in_machine():
        if notebook_util.is_notebook_environ():
            raise Exception("You are now in a notebook or devcontainer and cannot use 'ImageManagement.debug' to "
                            "check your image. If you need to debug it, please use a workstation.")
        if not shutil.which("docker"):
            raise Exception("Your machine has no docker and cannot use 'ImageManagement.debug' to "
                            "check your image. If you need to debug it, please use a workstation installed docker.")

    @classmethod
    def _clear_previous_container(cls, image):
        """
        Stop the previous debug container.
        """
        containers = DockerCli.ps(options=["--filter", f"ancestor={image.swr_path}", "-a"],
                                  progress_display=ProgressDisplay(show_progress=False))
        if isinstance(containers, bytes):
            containers = containers.decode()
        container_list = containers.splitlines()[1:]
        containers_id = []
        for container in container_list:
            containers_id.append(container.split()[0])
        # the previous debugging container is still running
        if containers_id:
            DockerCli.stop(containers=containers_id,
                           progress_display=ProgressDisplay(msg="Stopping previous debugging containers",
                                                            new_line=False))
            DockerCli.rm(containers=containers_id,
                         options=["-v"],
                         progress_display=ProgressDisplay())

    @classmethod
    def list_images(cls, session, limit=None, name=None, name_fuzzy_match=None, namespace=None, offset=None,
                    service_type=None, sort_dir=None, sort_key=None, image_type=None, workspace_id=None):
        params = {}
        if limit:
            params.update({"limit": limit})
        if name:
            params.update({"name": name})
        if name_fuzzy_match:
            params.update({"name_fuzzy_match": name_fuzzy_match})
        if namespace:
            params.update({"namespace": namespace})
        if offset:
            params.update({"offset": offset})
        if service_type:
            params.update({"service_type": service_type})
        if sort_dir:
            params.update({"sort_dir": sort_dir})
        if sort_key:
            params.update({"sort_key": sort_key})
        if image_type:
            params.update({"type": image_type})
        if workspace_id:
            params.update({"workspace_id": workspace_id})
        image_api = get_image_api_instance(session)
        image_list = image_api.get_image(query_param=params)
        return image_list
