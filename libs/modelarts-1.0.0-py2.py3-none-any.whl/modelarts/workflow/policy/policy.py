from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.policy.scene import Scene


class Policy(object):

    def __init__(self, scenes=None):
        if scenes is None:
            scenes = []
        self.use_scene = False
        self.scene_id = None
        self.scenes = scenes

    def to_definition_json(self) -> TransformType:
        if len(self.scenes) == 0:
            return {}
        return {
            "scenes": [scene.to_definition_json() for scene in self.scenes]
        }

    def use_scene(self, scene_id: str):
        self.use_scene = True
        self.scene_id = scene_id

    def check(self):
        scene_names = []
        for scene in self.scenes:
            if not isinstance(scene, Scene):
                raise ValueError('Each element of scenes should be of type modelarts.workflow.policy.scene.Scene')
            scene.check()
            scene_names.append(scene.scene_name)
        if len(scene_names) != len(set(scene_names)):
            raise ValueError('The parameter scene_names must be unique.')
