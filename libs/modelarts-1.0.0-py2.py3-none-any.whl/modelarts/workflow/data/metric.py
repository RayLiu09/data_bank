import uuid

from modelarts.workflow.core.placeholder import Placeholder
from modelarts.workflow.data.storage import Storage
from modelarts.workflow.core.data import AbstractData, AbstractDataConsumption
from modelarts.workflow.core.entities import TransformType
from modelarts.workflow.core.data import AbstractOutputConfig


METRICS_DATA_TYPE = "metrics"


class MetricsConfig(AbstractOutputConfig):
    """
    metric configuration object
    """

    def __init__(self, metric_files, realtime_visualization=False, visualization=True):
        """

        Args:
            metric_files (Union[str, Placeholder, Storage, list]): metric file list
            realtime_visualization (Union[bool, Placeholder]): whether to output metric information in real time
            visualization (Union[bool, Placeholder]): whether to present independent visualization nodes
        """
        super(MetricsConfig, self).__init__()
        if not isinstance(metric_files, list):
            metric_files = [metric_files]
        self.metric_files = metric_files
        self.realtime_visualization = realtime_visualization
        self.visualization = visualization

    def to_definition_json(self):
        result = {}
        metric_files = []
        for metric_file in self.metric_files:
            if isinstance(metric_file, (Placeholder, Storage)):
                metric_files.append(metric_file.ref())
            else:
                metric_files.append(metric_file)
        result["metric_files"] = metric_files
        result["realtime_visualization"] = self.realtime_visualization
        result["visualization"] = self.visualization
        return result

    def data_consumption(self, step_name, output_name):
        return MetricsConsumption(self, step_name, output_name)


class Metrics(AbstractData):
    def __init__(self, metric_files):
        """

        Args:
            metric_files (list): metric files
        """
        super(Metrics, self).__init__(name=uuid.uuid4().hex)
        self.metric_files = metric_files

    def get_snapshot(self) -> TransformType:
        return {
            "metric_files": self.metric_files
        }

    def to_definition_json(self) -> TransformType:
        return {
            "metric_files": self.metric_files
        }

    def type(self):
        return METRICS_DATA_TYPE


class MetricsConsumption(AbstractDataConsumption):
    def __init__(self, config, step_name, output_name):
        super(MetricsConsumption, self).__init__(config=config, step_name=step_name, output_name=output_name)

    def consume(self) -> AbstractData:
        metric_files = []
        for file in self.config.metric_files:
            if isinstance(file, Placeholder):
                metric_files.append(file.value)
            elif isinstance(file, Storage):
                metric_files.append(file.path)
            else:
                metric_files.append(file)
        return Metrics(metric_files=metric_files)

    def type(self):
        return METRICS_DATA_TYPE
