import collections
import json
from enum import Enum
from modelarts.workflow.core.entities import Entity


TRAIN_FLAVOR_ID_FORMAT = "flavor"
TRAIN_FLAVOR_FORMAT = "train_flavor"
PACIFIC_FORMAT = "pacific"
PFS_FORMAT = "pfs"
NFS_FORMAT = "nfs"
SERVICE_SCHEDULE_FORMAT = "schedule"
TRAIN_ENV_FORMAT = "train_env"
INTERNAL_PARAM_FORMAT = "internal_param"

LIST_ELEMENT_TYPE_MAPPING = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool
}


class DuplicatePlaceholderException(Exception):
    pass


class PlaceholderNotReadyException(Exception):
    pass


class PlaceholderType(Enum):
    INT = "int"
    STR = "str"
    BOOL = "bool"
    FLOAT = "float"
    ENUM = "enum"
    JSON = "json"
    LIST = "list"

    @property
    def python_type(self):
        mapping = {
            PlaceholderType.INT: int,
            PlaceholderType.STR: str,
            PlaceholderType.BOOL: bool,
            PlaceholderType.FLOAT: float,
            PlaceholderType.ENUM: Enum,
            PlaceholderType.JSON: dict,
            PlaceholderType.LIST: list
        }
        return mapping[self]


class Placeholder(Entity):
    """
    The class used to configure parameters in workflow
    """

    def __init__(
        self,
        name,
        placeholder_type,
        default=None,
        placeholder_format=None,
        delay=False,
        description=None,
        enum_list=None,
        constraint=None,
        required=True,
        title=None
    ):
        """
            The placeholder is not allowed to have a default value when input at runtime(i.e. When delay_input is True,
                                                                                    default must be None).
        Args:
            name (string): The name of the placeholder, used in convert to json
            placeholder_type (PlaceholderType): The type of the placeholder.
            default (Any): The default value of placeholder
            placeholder_format (str): The format of the placeholder, such as flavor, obs, train_flavor, swr, pacific, pfs, nfs etc
            delay (bool): Represent whether the placeholder is input at runtime, default false
            description (str): The description of placeholder
            enum_list (list): The enum values list
            constraint (dict): Constraint of placeholder value
            required (bool): Whether this parameter must be set
            title (str): Display name
        """
        Placeholder._check_init_info(
            placeholder_type=placeholder_type, enum_list=enum_list,
            placeholder_format=placeholder_format, delay=delay, required=required)
        self.name = name
        self.placeholder_type = placeholder_type
        self.format = placeholder_format
        self.delay = delay
        self.description = description
        self.enum_list = enum_list
        self.constraint = constraint
        self.required = required
        self.title = title
        self._value = None
        self._is_value_set = False
        if not isinstance(self.placeholder_type, PlaceholderType):
            raise ValueError("placeholder_type should be enum value of PlaceholderType")
        self.default_value = default
        if default is not None:
            self.set_value(default)

    @property
    def value(self):
        return self._value

    def __repr__(self):
        return "placeholder name: '{}', placeholder type: <{}>".format(self.name, self.placeholder_type)

    def __eq__(self, obj):
        return self.name == obj.name and \
               self.placeholder_type == obj.placeholder_type and \
               self.default_value == obj.default_value and \
               self.delay == obj.delay and \
               self.description == obj.description and \
               self.format == obj.format and \
               self.enum_list == obj.enum_list and \
               self.required == obj.required and \
               self.constraint == obj.constraint

    def check_value(self, value):
        """
        Check the validity of the value
        Args:
            value: placeholder value

        Returns:

        """
        if self.placeholder_type == PlaceholderType.ENUM:
            for enum_value in self.enum_list:
                if value == enum_value:
                    return
            raise ValueError('The input value {} is not in enum_list : {}'.format(value, self.enum_list))
        if self.placeholder_type == PlaceholderType.LIST:
            for element in value:
                if not isinstance(element, LIST_ELEMENT_TYPE_MAPPING.get(self.format)):
                    raise ValueError('The element type is must be {}, but provided: {}'.format(self.format, type(element)))
        if not isinstance(value, self.placeholder_type.python_type):
            raise ValueError("The value of placeholder %s does not match the specified type!" % self.name)

    def set_value(self, value):
        """
        Set a new value for placeholder
        Args:
            value: a new value

        Returns:

        """
        self.check_value(value)
        self._is_value_set = True
        self._value = value

    def is_set(self):
        return self._is_value_set

    def get_snapshot(self):
        """
        get snapshot json dict of placeholder
        Returns:
            json dict
        """
        return {
            "name": self.name,
            "value": self.value,
        }

    def _transfer_value_to_placeholder_type(self, str_value):
        if self.placeholder_type == PlaceholderType.ENUM:
            for enum_value in self.enum_list:
                if str(enum_value) == str_value:
                    return enum_value
            raise ValueError('The input value {} is not in enum_list : {}'.format(str_value, self.enum_list))
        if self.placeholder_type == PlaceholderType.BOOL:
            return True if str_value.lower() == 'true' else False
        if self.placeholder_type in (PlaceholderType.JSON, PlaceholderType.LIST):
            return json.loads(str_value)
        return self.placeholder_type.python_type(str_value)

    def get_value_from_command_line(self):
        if self.placeholder_type == PlaceholderType.ENUM:
            param = input("Enter placeholder <{}>, type is <{}>, enum_list is <{}>, description is <{}>: ".format(
                self.name,
                self.placeholder_type,
                self.enum_list,
                self.description
            ))
        elif self.placeholder_type == PlaceholderType.JSON and self.format == TRAIN_FLAVOR_FORMAT:
            input_format = \
                '(1) public_resource_pool_format: {"flavor_id": "***"}' \
                '(2) dedicated_resource_pool_format: {"pool_id": "***", "flavor_id": "***"}'
            param = input("Enter placeholder <{}>, type is <{}>, description is <{}>, input_format is: {}".format(
                self.name,
                self.placeholder_type,
                self.description,
                input_format
            ))
        else:
            param = input("Enter placeholder <{}>, type is <{}>, description is <{}>: ".format(
                self.name,
                self.placeholder_type,
                self.description
            ))
        return self.set_value(self._transfer_value_to_placeholder_type(str_value=param))

    def to_definition_json(self):
        result = {
            "name": self.name,
            "type": self.placeholder_type.value
        }
        if self.default_value is not None:
            result["default"] = self.default_value
        if self.delay:
            result["delay"] = True
        if self.description:
            result["description"] = self.description
        if self.format:
            result["format"] = self.format
        if self.enum_list:
            result["enum"] = self.enum_list
        if self.constraint:
            result["constraint"] = self.constraint
        if not self.required:
            result["required"] = False
        if self.title:
            result["title"] = self.title
        return result

    def ref(self):
        return "$ref/parameters/{}".format(self.name)

    @staticmethod
    def _check_init_info(placeholder_type, enum_list, placeholder_format, delay, required):
        if placeholder_type == PlaceholderType.ENUM and not enum_list:
            raise ValueError("The enum_list can not be empty when placeholder type is enum")
        if placeholder_type == PlaceholderType.LIST:
            if placeholder_format not in LIST_ELEMENT_TYPE_MAPPING.keys():
                raise ValueError("The format value must be in {}".format(LIST_ELEMENT_TYPE_MAPPING.keys()))
        if not required and delay:
            raise ValueError("delay parameter should be required")


class PlaceholderDict(collections.UserDict):

    def check_ready(self):
        """
        Check that all placeholders have been set value
        Returns:

        """
        for param in self.values():
            if not param.is_set():
                raise PlaceholderNotReadyException("%s is not set" % param)

    def merge(self, param_dict):
        """
        Merge another PlaceholderDict into the current object
        Args:
            param_dict (PlaceholderDict): data to be merged

        Returns:
        """
        if not param_dict:
            return
        for param in param_dict.values():
            self.add_placeholder(param)

    def add_placeholder(self, param):
        """

        Returns:

        """
        if param.name in self and self[param.name] != param:
            raise DuplicatePlaceholderException("placeholder %s is repeated declared" % param.name)
        self[param.name] = param

    def get_snapshot(self):
        """
        get snap shot of placeholders
        Returns:

        """
        snapshot_result = []
        for placeholder in self.values():
            if not placeholder.is_set():
                continue
            snapshot_result.append(placeholder.get_snapshot())
        return snapshot_result
