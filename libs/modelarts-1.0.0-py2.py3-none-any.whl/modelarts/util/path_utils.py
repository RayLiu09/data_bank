"""Some methods of path operations."""
import os


def get_parent_dir(path):
    """
    get parent directory path
    :return parent directory path
    """
    if os.path.isdir(path):
        if path.endswith("/"):
            return os.path.dirname(path[:-1])
        else:
            return os.path.dirname(path)
    elif os.path.isfile(path):
        return os.path.dirname(path)
    else:
        raise Exception("Cannot find '{}' as a directory or file".format(path))
