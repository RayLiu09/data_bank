"""
Description: Function for Python 2 vs .3 compatibility. Conversion routines:
In addition to the functions below, 'as_str' converts an object to a 'str'.
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


def as_text(bytes_or_text, encoding='utf-8'):
    """Return the given argument as a unicode string.

    :arg:
    bytes_or_text: A 'bytes', 'str', or 'unicode' object.
    encoding: A string indicating the charset for encoding unicode.
    :return:
    A 'str' (Python 3) object.
    :raise:
    TypeError: If 'bytes_or_text' is not a binary or unicode string.
    """
    if isinstance(bytes_or_text, str):
        return bytes_or_text
    elif isinstance(bytes_or_text, bytes):
        return bytes_or_text.decode(encoding)
    else:
        raise TypeError('Excepted binary or unicode string, got %r' % bytes_or_text)


as_str = as_text
