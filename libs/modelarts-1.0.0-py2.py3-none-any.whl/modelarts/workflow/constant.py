SUPPORTED_REGION = ['cn-north-1', 'cn-north-2', 'cn-north-4', 'cn-north-5',
                    'cn-north-7', 'cn-northeast-1',
                    'cn-east-2', 'cn-south-1', 'ap-southeast-1', 'cn-east-3',
                    'ap-southeast-3', 'cn-hangzhou-1', 'eu-west-0']

MODEL_WEIGHT_SUM = 100
