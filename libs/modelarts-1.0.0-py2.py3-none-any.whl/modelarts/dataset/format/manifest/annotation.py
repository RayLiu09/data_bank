"""
Description: parse file of manifest format
Author: ModelArts SDK Team
Date: 2021/07/14 - 2021/07/14
"""


class Annotation:
    """
    A dataset maybe contains many samples. A sample maybe contains many annotations,
    this class is used to record annotation.
    Annotation contain annotation name, type, property and so on.
    """

    def __init__(
            self,
            name=None,
            type=None,
            id=None,
            annotation_loc=None,
            annotation_property=None,
            confidence=None,
            creation_time=None,
            annotated_by=None,
            annotation_format=None,
            hard=None,
            hard_coefficient=None,
            annotation_loc_map=None
    ):
        """"
        init method
        :param name: annotation name
        :param type: annotation type
        :param id: annotation id
        :param annotation_loc: annotation location
        :param annotation_property: annotation property
        :param confidence: confidence
        :param creation_time: create time
        :param annotated_by: annotated_by
        :param annotation_format: annotation format
        :param hard: whether is hard
        :param hard_coefficient: hard coefficient
        :param annotation_loc_map: annotation location map
        """
        self.__name = name
        self.__type = type
        self.__id = id
        self.__annotation_loc = annotation_loc
        self.__annotation_loc_map = annotation_loc_map
        self.__annotation_property = annotation_property
        self.__hard = hard
        self.__hard_coefficient = hard_coefficient
        self.__confidence = confidence
        self.__creation_time = creation_time
        self.__annotated_by = annotated_by
        self.__annotation_format = annotation_format

    @property
    def type(self):
        """
        :return type of dataset: modelarts/image_classification, modelarts/object_detection
        Optional field
        """
        return self.__type

    @property
    def name(self):
        """
        :return the name of this annotation, like "cat"
        Mandatory field if get_loc is None
        """
        return self.__name

    @property
    def id(self):
        """
        :return: the id of this annotation, used in Triplet
        Optional field
        """
        return self.__id

    @property
    def annotation_loc(self):
        """
        :return in case of object detection, this will return the annotation file,
        otherwise return null
        Mandatory field if get_name is None
        """
        return self.__annotation_loc

    @annotation_loc.setter
    def annotation_loc(self, new_annotation_loc):
        """
        set annotation_loc
        """
        self.__annotation_loc = new_annotation_loc

    @property
    def annotation_loc_map(self):
        """
        :return this will return the original annotation file,
        otherwise return null
        """
        return self.__annotation_loc_map

    @annotation_loc_map.setter
    def annotation_loc_map(self, new_loc):
        """
        set annotation_loc_map
        """
        self.__annotation_loc_map = new_loc

    @property
    def annotation_property(self):
        """
        :return a KV pair list
        Optional field
        """
        return self.__annotation_property

    @property
    def hard(self):
        """
        :return set true if it's hard annotation, set false  if it's not hard annotation
        Optional field
        """
        return self.__hard

    @hard.setter
    def hard(self, new_hard):
        """
        set true if it's hard annotation, set false  if it's not hard annotation
        Optional field
        """
        self.__hard = new_hard

    @property
    def hard_coefficient(self):
        """
        :return set the coefficient of hard
        Optional field
        """
        return self.__hard_coefficient

    @hard_coefficient.setter
    def hard_coefficient(self, hard_coefficient):
        """
        set hard_coefficient value
        Optional field
        """
        self.__hard_coefficient = hard_coefficient

    @property
    def confidence(self):
        """
        :return confidence of label
        Optional field
        """
        return self.__confidence

    @property
    def creation_time(self):
        """
        :return when this annotation is created
        Optional field
        """
        return self.__creation_time

    @property
    def annotation_format(self):
        """
        :return when this annotation format
        Optional field
        """
        return self.__annotation_format

    @property
    def annotated_by(self):
        """
        :return who this annotation is created by
        Optional field
        """
        return self.__annotated_by
